﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMAT.BAL;
using System.Web.Services;
using System.Data;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Web.Script.Services;


namespace AMAT.BIM_CommunicationWeb.Pages
{
    public partial class Test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        [ScriptMethod(UseHttpGet = true)]  // get history records
        public static List<ChangesRecords> GetHistoryRecords()
        {
            List<ChangesRecords> objList = new List<ChangesRecords>();
            BLL obj = new BLL();
            DataTable dt = obj.GetHistoryRecords();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ChangesRecords crobj = new ChangesRecords();
                    crobj.ChangeId = Convert.ToString(row["ChangeId"]);
                    crobj.BusinessFunction = Convert.ToString(row["BusinessFunction"]);
                    crobj.DashboardName = Convert.ToString(row["DashboardName"]);
                    crobj.ChangeType = Convert.ToString(row["Change"]) == "" ? Constant.NewRelease : Convert.ToString(row["Change"]);
                    crobj.ChangeDescription = Convert.ToString(row["ChangeDescription"]);
                    crobj.RequesterName = Convert.ToString(row["Requester"]);
                    crobj.Type = Convert.ToString(row["Type"]);
                    crobj.ReleaseDate = !string.IsNullOrEmpty(Convert.ToString(row["ReleaseDate"])) ? Convert.ToDateTime(row["ReleaseDate"]).ToString(Constant.DateFormat) : "";
                    crobj.CreatedDate = !string.IsNullOrEmpty(Convert.ToString(row["CreatedDate"])) ? Convert.ToDateTime(row["CreatedDate"]).ToString(Constant.DateFormat) : "";
                    objList.Add(crobj);
                }
            }
            return objList;
        }
    }
}