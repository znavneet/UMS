﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMAT.BAL;
using System.Web.Services;
using System.Data;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Web.Script.Services;
using System.IO;

namespace AMAT.BIM_CommunicationWeb
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IsCurrentIsAdmin();
                GetFunctionalDomain();
                GetAllDashoard();
            }        
            GetLatestFileFromLibrary();  //BIM Comm tab
        }

        [WebMethod]
        [ScriptMethod(UseHttpGet = true)]  // get history records
        public static List<ChangesRecords> GetHistoryRecords()
        {
            List<ChangesRecords> objList = new List<ChangesRecords>();
            BLL obj = new BLL();
            DataTable dt = obj.GetHistoryRecords();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ChangesRecords crobj = new ChangesRecords();
                    crobj.ChangeId = Convert.ToString(row["ChangeId"]);
                    crobj.BusinessFunction = Convert.ToString(row["BusinessFunction"]);
                    crobj.DashboardName = Convert.ToString(row["DashboardName"]);
                    crobj.ChangeType = Convert.ToString(row["Change"]) == "" ? Constant.NewRelease : Convert.ToString(row["Change"]);
                    crobj.ChangeDescription = Convert.ToString(row["ChangeDescription"]);
                    crobj.RequesterName = Convert.ToString(row["Requester"]);
                    crobj.Type = Convert.ToString(row["Type"]);
                    crobj.ReleaseDate = !string.IsNullOrEmpty(Convert.ToString(row["ReleaseDate"])) ? Convert.ToDateTime(row["ReleaseDate"]).ToString(Constant.DateFormat) : "";
                    crobj.CreatedDate = !string.IsNullOrEmpty(Convert.ToString(row["CreatedDate"])) ? Convert.ToDateTime(row["CreatedDate"]).ToString(Constant.DateFormat) : "";
                    objList.Add(crobj);
                }
            }
            return objList;
        }

        [WebMethod]
        [ScriptMethod(UseHttpGet = true)]  // get Latest 15 days  new and change records
        public static List<ChangesRecords> GetLatestRecordsChanges()
        {
            List<ChangesRecords> objList = new List<ChangesRecords>();
            BLL obj = new BLL();
            DataTable dt = obj.GetLatestRecordsChanges();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ChangesRecords crobj = new ChangesRecords();
                    crobj.ChangeId = Convert.ToString(row["ChangeId"]);
                    crobj.BusinessFunction = Convert.ToString(row["BusinessFunction"]);
                    crobj.DashboardName = Convert.ToString(row["DashboardName"]);
                    crobj.ChangeType = Convert.ToString(row["Change"]) == "" ? Constant.NewRelease : Convert.ToString(row["Change"]);
                    crobj.ChangeDescription = Convert.ToString(row["ChangeDescription"]);
                    crobj.RequesterName = Convert.ToString(row["Requester"]);
                    crobj.Type = Convert.ToString(row["Type"]);
                    crobj.DashboardURL = Convert.ToString(row["DashboardURL"]);
                    crobj.ReleaseDate = !string.IsNullOrEmpty(Convert.ToString(row["ReleaseDate"])) ? Convert.ToDateTime(row["ReleaseDate"]).ToString(Constant.DateFormat) : "";
                    crobj.CreatedDate = !string.IsNullOrEmpty(Convert.ToString(row["CreatedDate"])) ? Convert.ToDateTime(row["CreatedDate"]).ToString(Constant.DateFormat) : "";
                    objList.Add(crobj);
                }
            }
            return objList;
        }


        [WebMethod]  // Insert record
        public static string SaveRecords(string dataObj)
        {
            string changeId = string.Empty; int i = 0; string operation = string.Empty;
            if (dataObj != null)
            {
                ChangesRecords crObj = Newtonsoft.Json.JsonConvert.DeserializeObject<ChangesRecords>(dataObj);
                changeId = crObj.ChangeId;
                BLL obj = new BLL();
                if (string.IsNullOrEmpty(changeId))
                {
                    changeId = obj.GenerateNewId();
                    string date = DateTime.Now.ToString(Constant.DateFormat);
                    i = obj.InsertRecord(changeId, crObj.BusinessFunction, crObj.DashboardName, crObj.ChangeType, crObj.ChangeDescription, crObj.RequesterName, crObj.Type,
                         crObj.ReleaseDate, date, crObj.CreatedBy, crObj.DashboardURL);
                    operation = Constant.Insert;
                }
                else
                {
                    i = obj.UpdateRecord(changeId, crObj.BusinessFunction, crObj.DashboardName, crObj.ChangeType, crObj.ChangeDescription, crObj.RequesterName, crObj.Type,
                         crObj.ReleaseDate, crObj.DashboardURL);
                }
            }
            return i + "-" + changeId + "-" + operation;
        }


        // Get all function domain
        public void GetFunctionalDomain()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constant.FunctionalDomainList);
                    CamlQuery camlQry = new CamlQuery();
                    camlQry.ViewXml = "<OrderBy><FieldRef Name='Title' Ascending='true'/></OrderBy>";

                    // var qryFunctiondm = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(camlQry);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    foreach (Microsoft.SharePoint.Client.ListItem item in items)
                    {
                        string itemName = Convert.ToString(item["Title"]);
                        ddlBusinessFunction.Items.Add(new System.Web.UI.WebControls.ListItem(itemName, itemName));
                        // ddlFunctionHistory.Items.Add(new System.Web.UI.WebControls.ListItem(itemName, itemName));

                    }
                    ddlBusinessFunction.Items.Insert(0, "--Select--");
                    // ddlFunctionHistory.Items.Insert(0, "--Select--");
                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "GetFunctionalDomain", "Default.aspx");
                }
            }
        }

        // get all dashbaord list
        public void GetAllDashoard()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constant.BIMCatalog);

                    //CamlQuery camlQry = new CamlQuery();                  
                    //camlQry.ViewXml = "<Query><Where><Eq><FieldRef Name='ContentType0' /><Value Type='Choice'>Cube</Value></Eq></Where>";
                    //camlQry.ViewXml += "<OrderBy><FieldRef Name='Name' Ascending='True'/></OrderBy></Query>";
                    ////  var qrydashboardlist = CamlQuery.CreateAllItemsQuery();

                    var camlQry = new CamlQuery()
                    {
                        ViewXml = "<View><Query><Where><Eq><FieldRef Name='ContentType0' /><Value Type='Choice'>Dashboard</Value></Eq></Where><OrderBy><FieldRef Name='Name' Ascending='True' /></OrderBy></Query></View>"
                    };

                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(camlQry);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null && items.Count > 0)
                    {
                        foreach (Microsoft.SharePoint.Client.ListItem item in items)
                        {
                            if (Convert.ToString(item["Name"]) != null)
                            {
                                string itemName = Convert.ToString(item["Name"]);
                                ddlDashboardName.Items.Add(new System.Web.UI.WebControls.ListItem(itemName, itemName));
                                //ddldashboardHistory.Items.Add(new System.Web.UI.WebControls.ListItem(itemName, itemName));
                            }
                        }
                        ddlDashboardName.Items.Insert(0, "--Select--");
                        //ddldashboardHistory.Items.Insert(0, "--Select--");
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "GetAllDashoard", "Default.aspx");
                }
            }

        }

        //check for admin user
        public void IsCurrentIsAdmin()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                User user = clientContext.Web.CurrentUser;
                clientContext.Load(user);
                clientContext.ExecuteQuery();
                string currUserName = user.Title;
                hdnCreatedby.Value = currUserName;

                if (!string.IsNullOrEmpty(currUserName))
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constant.PMAAdminsList);
                    var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='PMA_Admin' /><Value Type='User'>" + currUserName + "</Value></Eq></Where></Query></View>" };
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null && items.Count > 0)
                    {
                        hdnIsUserAdmin.Value = "Yes";
                        // adminTab.Attributes.Add("style", "display:block");
                        adminPnl.Visible = true;
                    }
                    else
                    {
                        hdnIsUserAdmin.Value = "No";
                        //  adminTab.Attributes.Add("style", "display:none");
                        adminPnl.Visible = false;
                    }
                }
            }
        }

        [WebMethod]
        public static List<UserProperty> GetADUsers(string username)
        {
            List<UserProperty> lstADUsers = new List<UserProperty>();

            if (!string.IsNullOrEmpty(username))
            {
                using (PrincipalContext context = new PrincipalContext(ContextType.Domain))
                {
                    UserPrincipal user = new UserPrincipal(context);
                    user.DisplayName = username + "*";
                    using (PrincipalSearcher srch = new PrincipalSearcher(user))
                    {
                        int i = 0;
                        foreach (var result in srch.FindAll())
                        {
                            DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;
                            if (!String.IsNullOrEmpty((String)de.Properties["displayName"].Value))
                            {
                                i++;
                                UserProperty usp = new UserProperty();
                                usp.UserName = de.Properties["displayName"].Value.ToString();
                                if (de.Properties["mail"].Value != null)
                                    usp.Email = de.Properties["mail"].Value.ToString();

                                //if (de.Properties["EmployeeId"].Value != null)
                                //{
                                //    usp.EmpId = de.Properties["EmployeeId"].Value.ToString();
                                //}
                                //else
                                //    usp.EmpId = string.Empty;

                                lstADUsers.Add(usp);
                                if (i == 10) break;

                            }
                        }
                    }
                }
            }
            return lstADUsers;
        }
        public static void ErrorLog(ClientContext clientContext, string errorMessage, string source, string method, string pageName)
        {
            List logList = clientContext.Web.Lists.GetByTitle("ErrorLogList");
            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
            Microsoft.SharePoint.Client.ListItem item = logList.AddItem(itemCreateInfo);
            item["Message"] = errorMessage;
            item["Source"] = source;
            item["Method"] = method;
            item["PageName"] = pageName;
            item.Update();
            clientContext.ExecuteQuery();
        }

        public void GetlatestFile()
        {
            var inputDirectory = new DirectoryInfo(Server.MapPath("~/Files/"));
            if (inputDirectory.GetFiles().Count() > 0)
            {
                string fileName = inputDirectory.GetFiles().OrderByDescending(f => f.LastWriteTime).First().ToString();
                hdnFileName.Value = fileName;
            }
        }
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            //if (fileUpload.HasFile)
            //{
            //    string fileName = Path.GetFileName(fileUpload.PostedFile.FileName);
            //    if (!string.IsNullOrEmpty(fileName))
            //    {
            //        fileName = fileName.Split('.')[0];
            //        fileName = fileName + "_" + DateTime.Now.ToString("MMddyyyyHHmm") + ".pdf";
            //    }
            //    fileUpload.PostedFile.SaveAs(Server.MapPath("~/Files/") + fileName);

            UploadFile();           
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage2", "UploadMsg()", true);
        
        }

        /// <summary>
        /// Upload pdf file to sharepoint 
        /// </summary>
        public void UploadFile()
        {
            if (fileUpload.HasFile)
            {
                string fileName = Path.GetFileName(fileUpload.PostedFile.FileName);
                if (!string.IsNullOrEmpty(fileName))
                {
                    fileName = fileName.Split('.')[0];
                    fileName = fileName + "_" + DateTime.Now.ToString("MMddyyyyHHmm") + ".pdf";
                }
                var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
                using (var clientContext = spContext.CreateAppOnlyClientContextForSPHost())
                {
                    try
                    {
                        FileCreationInformation newFile = new FileCreationInformation();
                        byte[] FileContent = fileUpload.FileBytes;
                        newFile.ContentStream = new MemoryStream(FileContent);
                        newFile.Url = Path.GetFileName(fileName);
                        List list = clientContext.Web.Lists.GetByTitle(Constant.BIM_Comm_Docs);
                        Folder Clientfolder = list.RootFolder;
                        var uploadFile = Clientfolder.Files.Add(newFile);

                        clientContext.Load(Clientfolder);
                        clientContext.Load(uploadFile);
                        clientContext.ExecuteQuery();
                    }
                    catch (Exception ex)
                    {
                        ErrorLog(clientContext, ex.Message, ex.Source, "UploadFile", "Default.aspx");
                    }

                }
            }
        }
        // Get pdf file byte content
        public void GetLatestFileFromLibrary()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constant.BIM_Comm_Docs);
                    var q = new CamlQuery() { ViewXml = "<View><Query><OrderBy><FieldRef Name='Created' Ascending='False' /></OrderBy></Query><RowLimit>1</RowLimit> </View>" };
                    var items = list.GetItems(q);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null && items.Count > 0)
                    {
                        Microsoft.SharePoint.Client.ListItem item = items[0];
                        var filePath = Convert.ToString(item["FileRef"]);
                        Microsoft.SharePoint.Client.File file = clientContext.Web.GetFileByServerRelativeUrl(filePath);

                        if (file != null)
                        {
                            var stream = file.OpenBinaryStream();
                            clientContext.Load(file);
                            clientContext.ExecuteQuery();
                            using (System.IO.MemoryStream mStream = new System.IO.MemoryStream())
                            {
                                if (stream != null)
                                {
                                    stream.Value.CopyTo(mStream);                                   
                                    byte[] bytes = mStream.ToArray();
                                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                                    hdnByteArray.Value = base64String;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "GetLatestFileFromLibrary", "Default.aspx");
                }
            }
        }
    }
}