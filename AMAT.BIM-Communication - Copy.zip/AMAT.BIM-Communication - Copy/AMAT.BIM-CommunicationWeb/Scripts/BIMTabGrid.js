﻿
$(document).ready(function () {

  $('.loading').show();
    getRecentdata();
    getHistorydata();
  
});

// change data
function getRecentdata() {
  
    $.ajax({
        url: 'Default.aspx/GetLatestRecordsChanges',
        type: 'GET',
        contentType: "application/json; charset=utf-8",
        success: function (data) {                      
                getChangeData(data.d); 
        },
        error: function (error) {
            alert(JSON.stringify(error));
        }
    });
}

function GetKPIData(dataObj) {

    var fn = []; var dashbaord = []; var requestor = []; var mjchange = []; var mnChange = []; var html = ""; var getGridData = [];

    for (var i = 0; i < dataObj.length; i++) {

        if (dataObj[i].Type == "Change") {
            if (fn.indexOf(dataObj[i].BusinessFunction) == -1 && dataObj[i].BusinessFunction != "")
                fn.push(dataObj[i].BusinessFunction);

            if (dashbaord.indexOf(dataObj[i].DashboardName) == -1 && dataObj[i].DashboardName != "")
                dashbaord.push(dataObj[i].DashboardName);

            if (requestor.indexOf(dataObj[i].RequesterName) == -1 && dataObj[i].RequesterName != "")
                requestor.push(dataObj[i].RequesterName);

            if (dataObj[i].ChangeType == "Major" && dataObj[i].ChangeType != "")
                mjchange.push(dataObj[i].ChangeType);
            else
                mnChange.push(dataObj[i].ChangeType);


            getGridData.push(dataObj[i]);
        }

        if (dataObj[i].Type == "New")
            html += GetNewReleaseDashbaord(dataObj[i], i);
    }

    $('.release_scroll').empty().append(html);
    html = "";

    if (getGridData) {
        $('#kpiFn').text(fn.length);
        $('#kpiDashboard').text(dashbaord.length);
        $('#kpiRequester').text(requestor.length);
        $('#kpiMjChange').text(mjchange.length);
        $('#kpiMnChange').text(mnChange.length);
        var latestDate = getGridData[0].CreatedDate;
        $('#spnaLtDate').text(latestDate);
    }

    return getGridData;
}

function getChangeData(data) {

    var getGridData = GetKPIData(data);

    //const columnDefs = [
    //    { headerName: 'Function', field: 'BusinessFunction', wrapText: true, sortable: true, filter: true },
    //    { headerName: 'Dashboard', field: 'DashboardName', wrapText: true, sortable: true, filter: true },
    //    { headerName: 'Change', field: 'ChangeType', sortable: true, wrapText: true, filter: true},
    //    { headerName: 'Description', field: 'ChangeDescription', wrapText: true, sortable: true, tooltipField: "ChangeDescription"},
    //    { headerName: 'Release Date', field: 'ReleaseDate', wrapText: true, sortable: true },
    //    { headerName: 'Requester', field: 'RequesterName', wrapText: true, sortable: true}
    //];
    const columnDefs = [
        { headerName: 'Function', field: 'BusinessFunction', sortable: true, filter: true, width: 150, wrapText: true, cellClass: "cell-vertical-align-text-right" },
        { headerName: 'Dashboard', field: 'DashboardName', sortable: true, filter: true, width: 200, wrapText: true, cellClass: "cell-vertical-align-text-right" },
        { headerName: 'Change', field: 'ChangeType', sortable: true, filter: true, width: 150, wrapText: true, cellClass: "cell-vertical-align-text-right" },
        { headerName: 'Description', field: 'ChangeDescription', sortable: true, filter: true, width: 300, wrapText: true, tooltipField: "ChangeDescription" },
        { headerName: 'Release Date', field: 'ReleaseDate', sortable: true, filter: true, width: 150, wrapText: true, cellClass: "cell-vertical-align-text-right" },
        { headerName: 'Requester', field: 'RequesterName', sortable: true, filter: true, width: 200, wrapText: true, cellClass: "cell-vertical-align-text-right" }
    ];

     // let the grid know which columns and what data to use
    //const gridOptions = {
    //    defaultColDef: {         
    //        tooltipComponent: 'customTooltip',
    //    },
    //    columnDefs: columnDefs,
    //    rowData: getGridData,
    //    components: {
    //        customTooltip: CustomTooltip,
    //    },
    //    pagination: true,
    //    paginationPageSize: 4,
    //    rowHeight: 80,
    //    animateRows: true,
    //    tooltipShowDelay: 0,

    //};
    const gridOptions = {
        defaultColDef: {
            editable: true,
            sortable: true,
            flex: 1,
            filter: true,
            resizable: true,
            minWidth: 100,
            tooltipComponent: 'customTooltip',
        },
        pagination: true,
        paginationPageSize: 5,
        rowHeight: 80,
        animateRows: true,
        tooltipShowDelay: 0,

        // set rowData to null or undefined to show loading panel by default
        rowData: getGridData,
        columnDefs: columnDefs,
        isExternalFilterPresent: isExternalFilterPresent,
        doesExternalFilterPass: doesExternalFilterPass,

        components: {
            customTooltip: CustomTooltip,
        },
    };

    // lookup the container we want the Grid to use
    const eGridDiv = document.querySelector('#myGrid');

    // create the grid passing in the div to use together with the columns & data we want to use
    new agGrid.Grid(eGridDiv, gridOptions);
       $('.loading').hide();
}

function getHistorydata() {

    $.ajax({
        url: 'Default.aspx/GetHistoryRecords',
        type: 'GET',
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            console.log(data.d);
            GetHistoryGrid(data.d);
         
        },
        error: function (error) {
            alert(JSON.stringify(error));
        }
    });
}

function newGrid() {
   var gridDiv = document.querySelector('#myGrid');
    new agGrid.Grid(gridDiv, gridOptions);
    gridOptions.api.setRowData(isInitialData ? rowData : rowData2);
    isInitialData = !isInitialData;
}

function GetNewReleaseDashbaord(data, Instance) {
   
        html = "<div id='release_" + Instance + "' class='item_Class'>";
        html += "<div class='OwnerRequester_John_Do_Class'>";
        html += "<span>Owner/Requester:</span><span style='font-style:normal;font-weight:normal;'>&nbsp;" + data.RequesterName + "</span>";
        html += "</div>";
        html += "<div class='dashboard_Class'><a class='' href='" + data.DashboardURL + "' target='_blank'>" + data.DashboardName + "</a></div>";
        html += "<div class='top_row_Class'>";
        html += "<div class='date_Class'>" + data.ReleaseDate + "</div>";
        html += "<div class='vertical_Class'>" + data.BusinessFunction + "</div>";
        html += "</div>";
        html += "<svg class='Line_b' viewBox='0 0 394 1'>";
        html += "<path class='Line_b_Class' d='M 0 0 L 394 0'>";
        html += "</path>";
        html += "</svg>";
        html += "<div class='Description_TKM_VBR_Dashboard__Class'>";
        html += "<span>Description:</span><span style='font-style:normal;font-weight:normal;'>" + data.ChangeDescription + "</span><br>";
        html += "</div>";
        html += "</div>";
        html += "</div>";
    
    return html;
}


var dbType = '--Select--';
var fnType = '--Select--';
var db = ""; var fn = "";

function GetHistoryGrid(dataObj) {

    fillHistoryDDl(dataObj);

    $('#ddldashboardHistory').on('change', function () {
        //  alert(this.value);
        if (this.value !== '--Select--')
            db = "DB";

        dbType = this.value;
        gridOptions.api.onFilterChanged();
        db = "";
      
    });

    $('#ddlFunctionHistory').on('change', function () {
        //  alert(this.value);
        if (this.value !== '--Select--')
            fn = "FN";

        fnType = this.value;
        gridOptions.api.onFilterChanged();
        fn = "";
    
    });

    const columnDefs = [
        { headerName: 'Function', field: 'BusinessFunction', sortable: true, filter: true, width: 150, wrapText: true, cellClass: "cell-vertical-align-text-right" },
        { headerName: 'Dashboard', field: 'DashboardName', sortable: true, filter: true, width: 200, wrapText: true, cellClass: "cell-vertical-align-text-right"},
        { headerName: 'Change', field: 'ChangeType', sortable: true, filter: true, width: 150, wrapText: true, cellClass: "cell-vertical-align-text-right" },
        { headerName: 'Description', field: 'ChangeDescription', sortable: true, filter: true, width: 300, wrapText: true, tooltipField: "ChangeDescription" },
        { headerName: 'Release Date', field: 'ReleaseDate', sortable: true, filter: true, width: 150, wrapText: true, cellClass: "cell-vertical-align-text-right" },
        { headerName: 'Requester', field: 'RequesterName', sortable: true, filter: true, width: 200, wrapText: true, cellClass: "cell-vertical-align-text-right" }
    ];

    const gridOptions = {
        defaultColDef: {
            editable: true,
            sortable: true,
            flex: 1,
            filter: true,
            resizable: true,
            minWidth: 100,
            tooltipComponent: 'customTooltip',
        },
        pagination: true,
        paginationPageSize: 5,
        rowHeight: 80,
        animateRows: true,
        tooltipShowDelay: 0,

        // set rowData to null or undefined to show loading panel by default
        rowData: dataObj,
        columnDefs: columnDefs,
        isExternalFilterPresent: isExternalFilterPresent,
        doesExternalFilterPass: doesExternalFilterPass,

        components: {
            customTooltip: CustomTooltip,
        },
    };
  
    const eGridDiv = document.querySelector('#hsGrid');
    new agGrid.Grid(eGridDiv, gridOptions);
   
}


function fillHistoryDDl(dataObj) {

    dataObj.sort(dynamicSort("DashboardName")); 
    var ddlData = [];
  
    $("#ddldashboardHistory").append($("<option     />").val("--Select--").text("--Select--"));

    for (var i = 0; i < dataObj.length; i++) {  
        if (ddlData.indexOf(dataObj[i].DashboardName) == -1) {
            $("#ddldashboardHistory").append($("<option     />").val(dataObj[i].DashboardName).text(dataObj[i].DashboardName));
            ddlData.push(dataObj[i].DashboardName);
        }
    }

    $('#ddldashboardHistory').select2();
}

function isExternalFilterPresent() {

    if (db)
        return dbType !== '--Select--';
    if (fn)  
        return fnType !== '--Select--';
    
}

function doesExternalFilterPass(node) {
    //switch (dbType) {
    //    case 'below25':
    //        return node.data.age < 25;
    //    case 'between25and50':
    //        return node.data.age >= 25 && node.data.age <= 50;
    //    case 'above50':
    //        return node.data.age > 50;
    //    case 'dateAfter2008':
    //        return asDate(node.data.date) > new Date(2008, 1, 1);
    //    default:
    //        return true;
    //}
  
    if (db) {
  //      db = "";
            return node.data.DashboardName == dbType;
    }
    if (fn) {    
    //    fn = "";
        return node.data.BusinessFunction == fnType;
    }
  
}

function GetTableData() {
  
    $.ajax({
        url: 'Default.aspx/GetLatestRecordsChanges',
        type: "GET",       
        contentType: "application/json;charset=utf-8",
        dataType: "JSON",
        success: function (data) {
            console.log(data.d);
            $('#example').DataTable({
                data: data.d,
                columns: [
                    { 'data': 'BusinessFunction'},
                    { 'data': 'DashboardName' },
                    { 'data': 'ChangeType' },
                    { 'data': 'ChangeDescription', "width": "30%"  },
                    { 'data': 'ReleaseDate' },
                    { 'data': 'RequesterName' }
                  
                ],
                "pageLength": 3
            });
            $('.loading').hide();
        },
        failure: function (error) {
            JSON.stringify(error);
        }
    });
}


function dynamicSort(property) {
    var sortOrder = 1;

    if (property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }

    return function (a, b) {
        if (sortOrder == -1) {
            return b[property].localeCompare(a[property]);
        } else {
            return a[property].localeCompare(b[property]);
        }
    }
}