﻿
$(document).ready(function () {

    ViewAllHistoryRecords();
    

    $('.datetimepicker').datetimepicker({
        format: 'MM/DD/YYYY'
    });

    $('#ddlBusinessFunction').select2();
    $('#ddlDashboardName').select2();

    GetADUsersInBox();

    $('.popupCloseButton').click(function () {
        $('.hover_bkgr_fricc').hide();
    });

    RequestTypeValidation();
   // $('#letter').load(function () {
   //     $(this).css('visibility', 'visible');
   //     $(this).contents().find('body').css({ 'background-color': '#ffffff' });
   // });
   // $('#letter').ready(function () {
   //     $(this).css('visibility', 'hidden');
   // });

   // $('#letter').load(function () {
   //  //   $(this).contents().find('body').css({'background-color': '#ffffff' });
   //});

  
});



function switchTab(target) {

    var bimCom = $('#bimCom');
    var bim = $('#bim');
    var history = $('#hist');
    var admin = $('#admin');

    bimCom.css('display', 'none');
    bim.css('display', 'none');
    history.css('display', 'none');
    admin.css('display', 'none');
    $('#' + target).css('display', 'block');
    
    $('.tab_bimCom_Class path').attr('class', '');
    $('.tab_bim_Class path').attr('class', '');
    $('.tab_hist_Class path').attr('class', '');
    $('.tab_admin_Class path').attr('class', '');

    if (target == "bimCom") {

        $('.tab_bimCom_Class path').attr('class', 'whitebg');
        $('.tab_bim_Class path').attr('class', 'bluebg');
        $('.tab_hist_Class path').attr('class', 'bluebg');
        $('.tab_admin_Class path').attr('class', 'bluebg');

        $('.tab_bimCom_Class span').css('color', '#1ca2d9');
        $('.tab_bim_Class span').css('color', '#ffffff');
        $('.tab_hist_Class span').css('color', '#ffffff');
        $('.tab_admin_Class span').css('color', '#ffffff');  //blue color
    }
    if (target == "bim") {

        $('.tab_bimCom_Class path').attr('class', 'bluebg');
        $('.tab_bim_Class path').attr('class', 'whitebg');
        $('.tab_hist_Class path').attr('class', 'bluebg');
        $('.tab_admin_Class path').attr('class', 'bluebg');

        $('.tab_bimCom_Class span').css('color', '#ffffff');
        $('.tab_bim_Class span').css('color', '#1ca2d9');
        $('.tab_hist_Class span').css('color', '#ffffff');
        $('.tab_admin_Class span').css('color', '#ffffff');  //blue color
    }
    if (target == "hist") {     

        $('.tab_bimCom_Class path').attr('class', 'bluebg');
        $('.tab_bim_Class path').attr('class', 'bluebg');
        $('.tab_hist_Class path').attr('class','whitebg');
        $('.tab_admin_Class path').attr('class', 'bluebg');
        $('.tab_bimCom_Class span').css('color', '#ffffff');
        $('.tab_bim_Class span').css('color', '#ffffff');
        $('.tab_hist_Class span').css('color', '#1ca2d9');
        $('.tab_admin_Class span').css('color', '#ffffff');  //blue color
    }
    if (target == "admin") {

        $('.tab_bimCom_Class path').attr('class', 'bluebg');
        $('.tab_bim_Class path').attr('class', 'bluebg');
        $('.tab_hist_Class path').attr('class', 'bluebg');
        $('.tab_admin_Class path').attr('class', 'whitebg');
        $('.tab_bimCom_Class span').css('color', '#ffffff');
        $('.tab_bim_Class span').css('color', '#ffffff');  
        $('.tab_hist_Class span').css('color', '#ffffff'); 
        $('.tab_admin_Class span').css('color', '#1ca2d9');  //blue color
    }
 }

function closepopup() {
    $('.hover_bkgr_fricc').hide();
}
function openpopup() {
    emptyFields();
    $('.hover_bkgr_fricc').show();
    $('#changeid').hide();  
    $('#changeid').text('');
}

function ViewAllHistoryRecords() {

    $("#viewAllRequest").jqGrid({
        url: 'Default.aspx/GetLatestRecordsChanges',
        datatype: 'json',
        ignoreCase: true,
        mtype: 'GET',
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },
        ajaxGridOptions: { contentType: "application/json" },
        loadonce: true,
        colNames: ['Change Id', 'Function', 'Dashboard', 'Change', 'Description', 'Requester', 'Type', 'Release Date', 'Created Date','Link', 'Edit'],
        colModel: [

            //{
            //    name: 'ChangeId', index: 'ChangeId', width: 200, align: 'center', viewable: true, search: true, sortable: true, formatter: 'showlink',
            //    formatoptions: { baseLinkUrl: 'javascript:', showAction: "MainRequest('", addParam: "');" }
            //},
            { name: 'ChangeId', index: 'ChangeId', width: 120, align: 'center', viewable: true, search: false, title: false, sortable: true },
            { name: 'BusinessFunction', index: 'BusinessFunction', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true },
            { name: 'DashboardName', index: 'DashboardName', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true },
            { name: 'ChangeType', index: 'ChangeType', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
            { name: 'ChangeDescription', index: 'ChangeDescription', width: 350, align: 'center', viewable: true, search: false, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.ChangeDescription + '"'; }},
            { name: 'RequesterName', index: 'RequesterName', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true },
            { name: 'Type', index: 'Type', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true },
            { name: 'ReleaseDate', index: 'ReleaseDate', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
            { name: 'CreatedDate', index: 'CreatedDate', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
            { name: 'DashboardURL', index: 'DashboardURL', width: 150, align: 'center', viewable: true, hidden: true, search: false, title: false, sortable: true },
            { name: 'Edit', index: 'Edit', width: 50, search: false, sort: false, align: 'center', formatter: RequestHistory, hidedlg: true, title: false }
        ],
        pager: '#pagingGridAll',
        rowNum: 4,
        rowList: [20, 30, 40],
        rownumbers: false,
        viewrecords: true,
        gridview: true,
        shrinkToFit: false,
        onCellSelect: function (rowId, iCol, content, event) {

            var col = $("#viewAllRequest").jqGrid("getGridParam", "colModel");
            var colName = col[iCol]['index'];
            if (colName == "Edit" && content != "") {
                  var rowData = $(this).jqGrid('getRowData', rowId);
                EditForm(rowData);              
            }
        },
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },

    });

    var gridWidth = $("#admin").width()- 40;
  
    $('#viewAllRequest').jqGrid('setGridWidth', gridWidth);

    $("#viewAllRequest").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true,
        searchOnEnter: false
    });
}


function RequestHistory(cellValue, options, rowObject) {
    var cellHtml = "";
    if (cellValue == null) {
        cellHtml = "<a href='#' ><i class='fas fa-pencil-alt'></i></a>";
    }
    return cellHtml;
}


function EditForm(obj) {
    emptyFields();

    $('.hover_bkgr_fricc').show();
    $('#changeid').text(obj.ChangeId);
    $('#changeid').show();    
    $("#ddlBusinessFunction").val(obj.BusinessFunction).trigger('change');
    $("#ddlDashboardName").val(obj.DashboardName).trigger('change');
    $("#ddlChangetype").val(obj.ChangeType);
    $("#txtRequestor").val(obj.RequesterName);
    $("#txtReleaseDate").val(obj.ReleaseDate);
    $("#ddlType").val(obj.Type);
    $("#txtChangeDesc").val(obj.ChangeDescription);
    $("#txtdashbaordUrl").val(obj.DashboardURL);

    if ($('#ddlType').val() == "New") {
        $("#ddlChangetype").attr('disabled', 'disabled');
        $("#txtdashbaordUrl").removeAttr('disabled');
    }
    else {
        $("#ddlChangetype").removeAttr('disabled');
        $("#txtdashbaordUrl").attr('disabled', 'disabled');
    }
}


function SaveRecord() {

    if (ValidationForm()) {
        var dashboardURL = "";

        $('.loading').show();
        var changeId = $('#changeid').text();

        if ($('#ddlType').val())
            var changeType = $('#ddlType').val() == "Change" ? $('#ddlChangetype').val() : "";

        if ($('#ddlType').val()) {
            if ($('#txtdashbaordUrl').val())
                dashboardURL = $('#ddlType').val() == "New" ? $('#txtdashbaordUrl').val().trim() : "";
        }

        var dataObj = {
            ChangeId: changeId,
            BusinessFunction: $('#ddlBusinessFunction').val(),
            DashboardName: $('#ddlDashboardName').val(),
            ChangeType: changeType,
            RequesterName: $('#txtRequestor').val(),
            Type: $('#ddlType').val(),
            ReleaseDate: $('#txtReleaseDate').val(),
            ChangeDescription: $('#txtChangeDesc').val(),
            CreatedBy: $('#hdnCreatedby').val(),
            DashboardURL: dashboardURL
        }
        var obj = JSON.stringify(dataObj);

        $.ajax({
            url: 'Default.aspx/SaveRecords',
            type: "POST",
            data: "{ 'dataObj': '" + obj + "' }",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                var result = data.d.split('-');
                if (result[0] == 1 && result[2] == "Insert") {
                   // getChangedata();
                    alert("The record is saved with id: " + result[1]);
                    emptyFields();
                
                }
                else {
                    if (result[0] == 1) {
                     //   getChangedata();
                        alert("The record is updated successfully.");
                        emptyFields();                       
                    }
                }
                $('.hover_bkgr_fricc').hide();
                $("#viewAllRequest").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
                $('.loading').hide();
                location.reload();
               
            },
            error: function (error) {
                alert(JSON.stringify(error));
            }
        });
    }
}

function emptyFields() {

    $("#ddlBusinessFunction").val('--Select--').trigger('change');
    $("#ddlDashboardName").val('--Select--').trigger('change');  
    $('#ddlChangetype')[0].selectedIndex = 0;
    $('#txtRequestor').val("");
    $('#txtReleaseDate').val("");
    $('#txtChangeDesc').val("");
   
}

function ValidationForm() {
    var isvalid = false;
    var fn = $("#ddlBusinessFunction").val();
    var dbName = $("#ddlDashboardName").val();
    var cngtype = $("#ddlChangetype").val();
    var requester = $("#txtRequestor").val();
    var type = $("#ddlType").val();
    var dashbaordUrl = $("#txtdashbaordUrl").val();  
    //var relsdate = $("#txtReleaseDate").val();  

    if (fn == "--Select--" || dbName == "--Select--" || type == "--Select--" || requester == "") {
        alert("Enter the required fields.");
        return isvalid;
    }
    else
        isvalid = true;

   
    if ($("#ddlType").val() == "New") {
        if (dashbaordUrl == "") {
            alert("Enter the required fields.");
            isvalid = false;
            return isvalid;
        }
        else
             isvalid = true;
    }
    else {
        if (cngtype == "--Select--") {
            alert("Enter the required fields.");
            isvalid = false;
            return isvalid;
        }
        else
             isvalid = true;
    }

    return isvalid;

}

function GetADUsersInBox() {

    $('#txtRequestor').autocomplete({
        minLength: 3,
        select: function (event, ui) {
            GetNameEmailValues(ui.item.label)
            return false;
        },
        source: function (request, response) {
            $('#loader1').show();
            $.ajax({
                url: 'Default.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        if (item.Email)
                            // var result = item.UserName + "  | " + item.Email + "";
                            var result = item.UserName;

                        else
                            var result = item.UserName
                        return {
                            value: result
                        }
                    }))

                    $('#loader1').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loader1').hide();
                    $("#txtBusinessPM").val("");
                    alert("Not found.");
                }
            });
        }
    });
}

function GetNameEmailValues(str) {
    var value = str;
    $("#txtRequestor").val(value);
    $("#txtRequestor").blur();
    $('#loader1').hide();

    return false;
}

function RequestTypeValidation() {

    $("#ddlType").change(function () {
        if ($(this).val() == "New") {
            $("#ddlChangetype").attr('disabled', 'disabled');
            $("#txtdashbaordUrl").removeAttr('disabled');
            
        }
        else {
            $("#ddlChangetype").removeAttr('disabled');
            $("#txtdashbaordUrl").attr('disabled', 'disabled');
        }
    });
  
}
