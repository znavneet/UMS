﻿// URL of PDF document
var pdfAsArray;

$(document).ready(function () {


   // var url = "https://raw.githubusercontent.com/mozilla/pdf.js/ba2edeae/web/compressed.tracemonkey-pldi-09.pdf";   
  
    pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';

    var response = $('#hdnByteArray').val();
    var link = "data:application/pdf;base64, " + response;
    $('#download').attr("href", link);
  
    pdfAsArray = convertDataURIToBinary("data:application/pdf;base64, " + response);

    var loadingTask = pdfjsLib.getDocument(pdfAsArray);
    loadingTask.promise.then(function (pdf) {
        
        pdf.getPage(1).then(function (page) {
            var scale = 2.5;
            var viewport = page.getViewport({ scale: scale, });

            var canvas = document.getElementById('the-canvas');
            var context = canvas.getContext('2d');
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            //
            // Render PDF page into canvas context
            //
            var renderContext = {
                canvasContext: context,
                viewport: viewport,
            };
            page.render(renderContext);
        });
    });
});

var BASE64_MARKER = ';base64,';

function convertDataURIToBinary(dataURI) {
    var base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
    var base64 = dataURI.substring(base64Index);
    var raw = window.atob(base64);
    var rawLength = raw.length;
    var array = new Uint8Array(new ArrayBuffer(rawLength));

    for (var i = 0; i < rawLength; i++) {
        array[i] = raw.charCodeAt(i);
    }
    return array;
}
function UploadMsg() {
    $('#loading').hide();
    alert('File is upload successfully, Please refresh the page to view latest file.');
  //  window.location.reload();

}
function fileValidation() {
    var fileInput = document.getElementById('fileUpload');
              
            var filePath = fileInput.value;
          
            // Allowing file type
            var allowedExtensions = /(\.pdf)$/i;
              
            if (!allowedExtensions.exec(filePath)) {
                alert('Invalid file type, only pdf file accepted.');
                fileInput.value = '';
                return false;
    }
    $('#loading').show();
}