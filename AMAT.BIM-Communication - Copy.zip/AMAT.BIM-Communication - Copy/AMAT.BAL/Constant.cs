﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    public class Constant
    {     
        public static string GetNewIdSP = "GetNewChangeId";
        public static string GetHistorySP = "GetHistoryRecords";
        public static string GetLatestRecordsSP = "GetHistory";
        public static string InsertRecordSP = "InsertRecord";
        public static string UpdateRecordSP = "UpdateRecord";
        public const string GetLatestChangeRecordsSP = "GetLatestChangeRecords";

        public static string DateFormat = "MM/dd/yyyy";

        public const string FunctionalDomainList = "BIM_FunctionalDomain";
        public const string PMAAdminsList = "PMA_Admins";

        public const string BIMCatalog = "BIM_Catalog";
        public const string BIM_Comm_Docs = "BIM_Comm_Docs";
        

        public const string Insert = "Insert";

        public const string NewRelease = "New Release";


    }
}
