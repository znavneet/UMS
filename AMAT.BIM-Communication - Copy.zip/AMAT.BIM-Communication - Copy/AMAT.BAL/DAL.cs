﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace AMAT.BAL
{
    public class DAL
    {
        string connection = ConfigurationManager.ConnectionStrings["DBConnString"].ConnectionString;

        /// <summary>
        /// Generating new id for any new request
        /// </summary>
        /// <returns></returns>
        public string GenerateNewId()
        {
            string newId = string.Empty;
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(Constant.GetNewIdSP, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    newId = Convert.ToString(cmd.ExecuteScalar());
                    con.Close();
                }
            }
            return newId;
        }

        /// <summary>
        /// Get history
        /// </summary>
        /// <returns></returns>
        public DataTable GetHistory()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(Constant.GetHistorySP, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// getting latest records within 15 days span
        /// </summary>
        /// <returns></returns>
        public DataTable GetLatestRecordsChanges()
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(Constant.GetLatestChangeRecordsSP, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(ds);
                    if(ds.Tables.Count > 1)
                    {
                        dt.Merge(ds.Tables[0]);
                        dt.Merge(ds.Tables[1]);
                        dt.DefaultView.Sort = "Id desc";
                        dt = dt.DefaultView.ToTable();
                    }
                    else
                    {
                        dt.Merge(ds.Tables[0]);
                    }
                }
            }
            return dt;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="changeId"></param>
        /// <param name="function"></param>
        /// <param name="dashboardName"></param>
        /// <param name="changetype"></param>
        /// <param name="changeDescription"></param>
        /// <param name="requester"></param>
        /// <param name="releaseDate"></param>
        /// <param name="createdDate"></param>
        /// <param name="createdBy"></param>
        public int InsertRecord(string changeId,string function,string dashboardName, string changetype,string changeDescription,
            string requester,string type,string releaseDate,string createdDate, string createdBy,string dashboardUrl)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(Constant.InsertRecordSP, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@changeId", changeId);
                    cmd.Parameters.AddWithValue("@function", function);
                    cmd.Parameters.AddWithValue("@dashboardName", dashboardName);
                    cmd.Parameters.AddWithValue("@changetype", changetype);
                    cmd.Parameters.AddWithValue("@changeDescription", changeDescription);
                    cmd.Parameters.AddWithValue("@requester", requester);
                    cmd.Parameters.AddWithValue("@type", type);
                    cmd.Parameters.AddWithValue("@createdDate", createdDate);
                    cmd.Parameters.AddWithValue("@createdBy", createdBy);
                    cmd.Parameters.AddWithValue("@dashboardURL", dashboardUrl);

                    if (string.IsNullOrEmpty(releaseDate))
                        cmd.Parameters.AddWithValue("@releaseDate", DBNull.Value);
                    else
                        cmd.Parameters.AddWithValue("@releaseDate", releaseDate);
               

                    con.Open();
                    int i = cmd.ExecuteNonQuery();
                    con.Close();
                    return i;
                }
            }
        }

        // Update record
        public int UpdateRecord(string changeId, string function, string dashboardName, string changetype, string changeDescription,
           string requester, string type, string releaseDate, string dashboardUrl)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(Constant.UpdateRecordSP, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@changeId", changeId);
                    cmd.Parameters.AddWithValue("@function", function);
                    cmd.Parameters.AddWithValue("@dashboardName", dashboardName);
                    cmd.Parameters.AddWithValue("@changetype", changetype);
                    cmd.Parameters.AddWithValue("@changeDescription", changeDescription);
                    cmd.Parameters.AddWithValue("@requester", requester);
                    cmd.Parameters.AddWithValue("@type", type);
                    cmd.Parameters.AddWithValue("@dashboardURL", dashboardUrl);

                    if (string.IsNullOrEmpty(releaseDate))
                        cmd.Parameters.AddWithValue("@releaseDate", DBNull.Value);
                    else
                        cmd.Parameters.AddWithValue("@releaseDate", releaseDate);                 

                    con.Open();
                    int i = cmd.ExecuteNonQuery();
                    con.Close();
                    return i;
                }
            }
        }


    }
}
