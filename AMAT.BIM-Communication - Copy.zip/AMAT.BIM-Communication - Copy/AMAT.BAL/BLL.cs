﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    public class BLL
    {
        DAL obj = new DAL();

        // Inserting records
        public int InsertRecord(string changeId, string function, string dashboardName, string changetype, string changeDescription,
           string requester, string type,string releaseDate, string createdDate, string createdBy,string dashboardUrl)
        {
          return  obj.InsertRecord(changeId, function, dashboardName, changetype, changeDescription,
            requester,type, releaseDate, createdDate, createdBy, dashboardUrl);
        }

        // Update record
        public int UpdateRecord(string changeId, string function, string dashboardName, string changetype, string changeDescription,
               string requester, string type, string releaseDate, string dashboardUrl)
        {
            return obj.UpdateRecord(changeId, function, dashboardName, changetype, changeDescription, requester, type, releaseDate, dashboardUrl);
        }

        // Get history records
        public DataTable GetHistoryRecords()
        {
            return obj.GetHistory();
        }

        // Get last 15 days records
        public DataTable GetLatestRecordsChanges()
        {
            return obj.GetLatestRecordsChanges();
        }
        public string GenerateNewId()
        {
            return obj.GenerateNewId();
        }
    }
    public class ChangesRecords
    {
        public string ChangeId { get; set; }
        public string BusinessFunction { get; set; }
        public string DashboardName { get; set; }
        public string ChangeType { get; set; }
        public string ChangeDescription { get; set; }
        public string RequesterName { get; set; }
        public string ReleaseDate { get; set; }
        public string CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string Type { get; set; }
        public string DashboardURL { get; set; }

    }
    public class UserProperty
    {
        public string Email { get; set; }
        public string NameEmail { get; set; }
        public string UserName { get; set; }
    }
}
