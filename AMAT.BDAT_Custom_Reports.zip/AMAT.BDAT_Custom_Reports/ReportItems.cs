﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BDAT_Custom_Reports
{
    public class ReportItems
    {
        public string reportWindowText { get; set; }
        public string reportWindowVal { get; set; }
        public string reportTypes { get; set; }
        public string actionOwner { get; set; }
        public string region { get; set; }
        public string customer { get; set; }
        public string greenbook { get; set; }
        public string EmailID { get; set; }
        public string status { get; set; }
        public string actionCategory { get; set; }
        public string actiontype { get; set; }
        public string actionOwnerRole { get; set; }
        public string statusUpdateRole { get; set; }
        public string statusUpdateOwner { get; set; }
        public string includeActvtySmmry { get; set; }
        public bool viewReport { get; set; }
        public string highLowfilter { get; set; }
        public string Priority { get; set; }
        public string bluebook { get; set; }
        public string blackbook { get; set; }
        public string activityType { get; set; }
        public string emailSubject { get; set; }
        public string MailFrequency { get; set; }
        public string MailSendingDay { get; set; }
        public string IsReportActive { get; set; }
        public string reportTitle { get; set; }
        public string reportRecipientsEmail { get; set; }
        public int ListItemId { get; set; }
        public string Bi_WeeklySendDate { get; set; }
        public string Bi_MonthlySendDate { get; set; }



    }

    public class UserInfo
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
