﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BDAT_Custom_Reports
{
    public class Constants
    {
        public const string DEFAULT_ARCHIVAL_FREQUENCY = "30";
        public const string DEFAULT_CALENDAR_YEAR_PREFIX = "FY";

        public const string CONFIG_LIST = "Configurations";

        public const string PROPERTY_BAG_SITE_URL = "MDPSBU SITE URL";

        public const string CONFIG_FARM_CONNECTION_STRING = "BIM Connection String";
        public const string CONFIG_SPGROUP_ACTIONOWNERS = "MDPSBU ActionOwners Group";
        public const string CONFIG_ADMINMAILBOX = "MDPSBU Admin Mailbox";
        public const string CONFIG_SPGROUP_MANAGERS = "BDAT Managers Group";
        public const string CONFIG_MAILBOX_FAILURENOTIFICATION = "MDPSBU Job Failure Address";
        public const string CONFIG_STATUS_CLOSED = "Action Item Closure Status";
        public const string CONFIG_ERROR_MESSAGE = " An unexpected error occurred, please contact support team for assistance. ";
        public const string CONFIG_SUBJECT_ACTIONOWNERS = "Subject: Action Owner Report";
        public const string CONFIG_SUBJECT_LAST_7DAYS_UPDATED_REPORT = "Subject: Managers Last 7 days updated report";
        public const string CONFIG_SUBJECT_LAST_7DAYS_NOT_UPDATED_REPORT = "Subject: Managers Last 7 days not updated report";
        public const string CONFIG_SUBJECT_ACTION_OWNERS_TIMERJOB_FAILURE = "Subject: Action Owners TimerJob Failure Notification";
        public const string CONFIG_SUBJECT_MANAGERS_TIMERJOB_FAILURE = "Subject: Managers TimerJob Failure Notification";
        public const string CONFIG_SUBJECT_ARCHIVALOFLISTITEM_TIMERJOB_FAILURE = "Subject:Archival of List Item Failuare Notification";
        public const string CONFIG_ADMINS_GROUP = "BDAT Admins Group";
        public const string CONFIG_TIMERJOB_SERVER = "MDPSBU Application Server";
        public const string CONFIG_ARCHIVAL_FREQUENCY = "MDPSBU Archival Frequency";
        public const string CONFIG_SUPERUSERS_GROUP = "BDAT Super Users";
        public const string CONFIG_MEMBERUSERS_GROUP = "BD AT Actions Members";
        public const string CONFIG_PROJECTADMINS_GROUP = "BD AT Project Admins";

        public const string LIST_NAME_MDPSBU = "BD AT";
        public const string LIST_URL_BDAT = "MDP SBU";
        public const string LIST_NAME_MDPSBUProjects = "BDATProjects";
        public const string LIST_NAME_MDPSBUARCHIVE = "BD AT Archive";
        public const string LIST_NAME_STATUSUPDATE = "BD AT Status Updates";
        public const string LIST_NAME_STATUSUPDATE_ARCHIVE = "BD AT Status Updates Archive";
        public const string LIST_NAME_ERROR_LOG = "ErrorLog";
        public const string LIST_NAME_PROJTYPECONFIG = "ProjectTypeConfigList";
        public const string LIST_NAME_OWNERLIST = "OwnerList";
        public const string LIST_NAME_ProjectStatusLIST = "ProjectStatus";
        public const string LIST_NAME_EmailTemplate = "BDAT_Email_Template";
        public const string LIST_NAME_ATRoles = "ATRoles";
        public const string LIST_NAME_REPORTROLE_MAPPING = "ScheduleReport Mapping";

        public const string MAIL_SUBJECT_ACTIONOWNERS = "BD AT Actions Required";
        public const string MAIL_SUBJECT_MGR_UPDATEDREPORT = "BD AT - Status Updated Report";
        public const string MAIL_SUBJECT_MGR_NOTUPDATEDREPORT = "BD AT - Status Not Updated Report";
        public const string MAIL_SUBJECT_TIMERJOB_FAILURE = "BD AT - Timer Job Failed";
        public const string MAIL_DISCLAIMER_OWNERS = "<br/></br><strong>Please do not reply to this mail. Please contact Brian Kenney or Sreehari P Yarramcetty for any assitance.</strong>";
        public const string MAIL_SIGNATURE = "<br/>Thanks,<br/>MDP SBU Admins.";

        public const string DEBUG_CATEGORY_ERROR = "ERROR";
        public const string DEBUG_CATEGORY_INFO = "INFO";
        public const string RedirectQS = "&SPLanguage=en-US&SPClientTag=2&SPProductNumber=16.0.7206.1208";
        public const string UPDATEMESSAGE = "Project Added/Updated successfully !";
        public const string REGION_NAME = "Region";
        public const string WEEKLY = "Weekly";
        public const string BI_WEEKLY = "Bi-Weekly";
        public const string MONTHLY = "Monthly";


    }
}
