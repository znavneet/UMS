﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BDAT_Custom_Reports
{
    class Program
    {
        static void Main(string[] args)
        {
             Reports.GetAllDataAndSendReport();
        }
    }
}
