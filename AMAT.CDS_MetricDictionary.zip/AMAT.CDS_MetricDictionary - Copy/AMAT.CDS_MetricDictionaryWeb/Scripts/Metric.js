﻿
$(document).ready(function () {
    CheckForAdminUser();
    getData();
    $("<span style='font-size:21px;padding: 0 10px 0 0;font-weight: 100;color: #4e9eb8;'>Search</span>").insertBefore(".search-input");
    $('[data-toggle="tooltip"]').tooltip();
    $(".no-records-found").html("<td colspan=10><div style='color:black;text-align:center'> <img src='../img/loading.gif' alt='' width=22px; /> Loading...</div></td>");
});

function fileValidation() {
    var filePath = $('#fileUpload').val();

    var allowedExtensions = /(\.xls|\.xlsx)$/i;

    if (!filePath) {
        alert('Please select the metric excel file to upload.');
        return false;
    }

    if (!allowedExtensions.exec(filePath)) {
        alert('Please upload the filled metric excel template.');
        return false;
    }
    else {
        $('#loading').show();
    }
}


function getData() {

    $.ajax({
        url: "Default.aspx/GetMetricData",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "JSON",
        success: function (data) {
           // console.log(data.d);
           // return JSON.parse(data.d);
            //var $table = $('#table');
            //$table.bootstrapTable({ data: data.d });
            //$('#table').bootstrapTable({
            //    data: data.d
            //});

            $('#table').bootstrapTable('load', JSON.parse(data.d));
        },
        error: function (error) {
            console.log(JSON.stringify(error));
           // alert(JSON.stringify(error));
        }
    });
}

function nameFormatter(value, row) {

    return '<a class=anchor href=' + row.URL + ' target=_blank >' + value + '</a>';
}
function DescFormatter(value, row)
{
    var content; var newValue;
    if (value.length > 70) {
        newValue = value.substring(0, 70) + "...";
    }
    content = "<span data-toggle='tooltip' title='" + value + "'>" + newValue + "<span>";
    return content;
    
}
function responseHandler(res) {
    $.each(res.rows, function (i, row) {
        row.state = $.inArray(row.id, selections) !== -1
    })
    return res
}
function CheckForAdminUser() {
    var val = $('#hdnIsUserAdmin').val();
    if (val == "false") {
        $('#upload').hide();
        $('#two-tab').addClass('active');
        $('#two').addClass('active');
        $('#one').hide();
        $('#two').show();
        $('#two').css('opacity', '1');

    }
    
}