﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Text.RegularExpressions;
using AMAT.DAL;
using Microsoft.SharePoint.Client;
using System.Web.Services;
using Newtonsoft.Json;

namespace AMAT.CDS_MetricDictionaryWeb
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_PreInit(object sender, EventArgs e)
        {
            Uri redirectUrl;
            switch (SharePointContextProvider.CheckRedirectionStatus(Context, out redirectUrl))
            {
                case RedirectionStatus.Ok:
                    return;
                case RedirectionStatus.ShouldRedirect:
                    Response.Redirect(redirectUrl.AbsoluteUri, endResponse: true);
                    break;
                case RedirectionStatus.CanNotRedirect:
                    Response.Write("An error occurred while processing your request.");
                    Response.End();
                    break;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            BindMetricFile();
        }


        protected void btnUpload_Click(object sender, EventArgs e)
        {
            ReadExcelAsDataTable();
        }

        #region read excel and upload excel metric in Database

        public void ReadExcelAsDataTable()
        {
            DataTable dataTable = new DataTable();
            string value = string.Empty;
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    if (fileUpload.HasFiles)
                    {
                        byte[] filebytes = fileUpload.FileBytes;
                        MemoryStream msFileStream = new MemoryStream(filebytes);
                        using (SpreadsheetDocument spreadSheetDocument = SpreadsheetDocument.Open(msFileStream, true))
                        {
                            WorkbookPart workbookPart = spreadSheetDocument.WorkbookPart;
                            IEnumerable<Sheet> sheets = spreadSheetDocument.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>();
                            string relationshipId = sheets.ToList()[0].Id.Value;

                            WorksheetPart worksheetPart = (WorksheetPart)spreadSheetDocument.WorkbookPart.GetPartById(relationshipId);
                            Worksheet workSheet = worksheetPart.Worksheet;
                            SheetData sheetData = workSheet.GetFirstChild<SheetData>();
                            IEnumerable<Row> rows = sheetData.Descendants<Row>();

                            // foreach (Cell cell in rows.ElementAt(0))
                            foreach (Cell cell in rows.ElementAt(0))
                            {
                                string val = GetCellValue(spreadSheetDocument, cell);
                                dataTable.Columns.Add(val);
                            }
                            if (!IsExcelValid(dataTable))
                            {
                                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert4", "alert('Invalid Excel !! Please verify excel and try again!!')", true);
                                return;
                            }
                            foreach (var row in rows)
                            {
                                //From second row of excel onwards, add data rows to data table.
                                IEnumerable<Cell> cells = GetCellsFromRowIncludingEmptyCells(row);
                                DataRow newDataRow = dataTable.NewRow();
                                int columnCount = 0;
                                foreach (Cell currentCell in cells)
                                {
                                    value = GetCellValue(spreadSheetDocument, currentCell);
                                    //There are empty headers which are not added to data table columns. So avoid those.
                                    if (columnCount < dataTable.Columns.Count)
                                    {
                                        newDataRow[columnCount++] = value;
                                    }
                                }
                                if (!IsEmpty(newDataRow, dataTable))
                                    dataTable.Rows.Add(newDataRow);

                            }
                            dataTable.Rows.RemoveAt(0);
                            if (dataTable != null && dataTable.Rows.Count > 1)
                            {
                                DataClass obj = new DataClass();
                                DataTable finalDt = GetFinalDataTable(dataTable);
                                string status = obj.DeleteAndBulkInsertRecords(finalDt);
                                if (status == "success")
                                {
                                   UploadResourceExcel();
                                   ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert1", "alert('Metric Excel is uploaded successfully!!')", true);

                                }
                                else
                                {
                                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert2", "alert('Something went wrong !! Please verify excel and try after sometime!!')", true);
                                }
                            }
                            else
                                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert3", "alert('Excel does not have any records!!')", true);

                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.StackTrace, "ReadExcelAsDataTable", "Default");
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert5", "alert('Something went wrong !! Please verify excel and try after sometime!!')", true);

                }
            }

        }

        //reading cells including empty cell
        private IEnumerable<Cell> GetCellsFromRowIncludingEmptyCells(Row row)
        {
            int currentCount = 0;
            // row is a class level variable representing the current
            foreach (DocumentFormat.OpenXml.Spreadsheet.Cell cell in
                row.Descendants<DocumentFormat.OpenXml.Spreadsheet.Cell>())
            {
                string columnName = GetColumnName(cell.CellReference);
                int currentColumnIndex = ConvertColumnNameToNumber(columnName);
                //Return null for empty cells
                for (; currentCount < currentColumnIndex; currentCount++)
                {
                    yield return null;
                }
                yield return cell;
                currentCount++;
            }
        }

        public int ConvertColumnNameToNumber(string columnName)
        {
            Regex alpha = new Regex("^[A-Z]+$");
            if (!alpha.IsMatch(columnName)) throw new ArgumentException();

            char[] colLetters = columnName.ToCharArray();
            Array.Reverse(colLetters);

            int convertedValue = 0;
            for (int i = 0; i < colLetters.Length; i++)
            {
                char letter = colLetters[i];
                int current = i == 0 ? letter - 65 : letter - 64; // ASCII 'A' = 65
                convertedValue += current * (int)Math.Pow(26, i);
            }

            return convertedValue;
        }

        public string GetCellValue(SpreadsheetDocument document, Cell cell)
        {
            SharedStringTablePart stringTablePart = document.WorkbookPart.SharedStringTablePart;
            if (cell == null || cell.CellValue == null)
            {
                return "";
            }
            string value = cell.CellValue.InnerXml;
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
            }
            else
            {
                return value;
            }
        }
        public string GetColumnName(string cellReference)
        {
            // Match the column name portion of the cell name.
            Regex regex = new Regex("[A-Za-z]+");
            Match match = regex.Match(cellReference);

            return match.Value;
        }

        public bool IsEmpty(DataRow row, DataTable dt)
        {
            bool isBlank = true;
            foreach (DataColumn col in dt.Columns)
            {
                if (!string.IsNullOrEmpty(Convert.ToString(row[col.ColumnName])))
                {
                    isBlank = false;
                    return isBlank;
                }
            }
            return isBlank;
        }
        public bool IsExcelValid(DataTable dt)
        {
            bool IsValid = false;
            if (dt.Columns.Contains("BU") && dt.Columns.Contains("Tableau folder Name") && dt.Columns.Contains("Technical Name") && dt.Columns.Contains("Attribute Name")
                && dt.Columns.Contains("Metric Owner"))
            {
                IsValid = true;

            }
            return IsValid;
        }

        // get final data table
        public DataTable GetFinalDataTable(DataTable sourceDt)
        {                 
            DataTable finalDt = new DataTable();
            finalDt.Columns.Add("ID", typeof(string));
            finalDt.Columns.Add("Category", typeof(string));
            finalDt.Columns.Add("Name", typeof(string));
            finalDt.Columns.Add("Description", typeof(string));
            finalDt.Columns.Add("MetricGroup", typeof(string));
            finalDt.Columns.Add("BU", typeof(string));
            finalDt.Columns.Add("TableauFolderName", typeof(string));
            finalDt.Columns.Add("TechnicalName", typeof(string));
            finalDt.Columns.Add("AttributeName", typeof(string));
            finalDt.Columns.Add("AttributeDescription", typeof(string));
            finalDt.Columns.Add("ColumnType", typeof(string));
            finalDt.Columns.Add("IsCalculated", typeof(string));
            finalDt.Columns.Add("TechnicalFormula", typeof(string));
            finalDt.Columns.Add("MetricOwner", typeof(string));
            //finalDt.Columns.Add("BusinessOwner", typeof(string));
            finalDt.Columns.Add("URL", typeof(string));

            foreach (DataRow row in sourceDt.Rows)
            {
                DataRow newRow = finalDt.NewRow();
                //newRow["ID"] = Convert.ToInt32(row["ID"]);       

                if (!string.IsNullOrEmpty(Convert.ToString(row["Content Type"])))
                    newRow["Category"] = Convert.ToString(row["Content Type"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Name"])))
                    newRow["Name"] = Convert.ToString(row["Name"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Description"])))
                    newRow["Description"] = Convert.ToString(row["Description"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Metric Group"])))
                    newRow["MetricGroup"] = Convert.ToString(row["Metric Group"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["BU"])))
                    newRow["BU"] = Convert.ToString(row["BU"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Tableau folder Name"])))
                    newRow["TableauFolderName"] = Convert.ToString(row["Tableau folder Name"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Technical Name"])))
                    newRow["TechnicalName"] = Convert.ToString(row["Technical Name"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Attribute Name"])))
                    newRow["AttributeName"] = Convert.ToString(row["Attribute Name"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Attribute Description"])))
                    newRow["AttributeDescription"] = Convert.ToString(row["Attribute Description"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Column Type"])))
                    newRow["ColumnType"] = Convert.ToString(row["Column Type"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Is Calculated"])))
                    newRow["IsCalculated"] = Convert.ToString(row["Is Calculated"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Technical Formula"])))
                    newRow["TechnicalFormula"] = Convert.ToString(row["Technical Formula"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["Metric Owner"])))
                    newRow["MetricOwner"] = Convert.ToString(row["Metric Owner"]);

                //if (!string.IsNullOrEmpty(Convert.ToString(row["Business Owner"])))
                //    newRow["BusinessOwner"] = Convert.ToString(row["Business Owner"]);

                if (!string.IsNullOrEmpty(Convert.ToString(row["URL"])))
                    newRow["URL"] = Convert.ToString(row["URL"]);

            
                finalDt.Rows.Add(newRow);
            }

            return finalDt;
        }

        #endregion

        #region after saving excel data in db the save excel in sharepoint library 

        public void UploadResourceExcel()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                clientContext.Load(clientContext.Web, web => web.ServerRelativeUrl);
                clientContext.ExecuteQuery();
                string Url = clientContext.Web.ServerRelativeUrl + "/" + Constants.MetricLibrary;
                string filename = CheckFileExists(clientContext, Url, false);
                string fileUrl = String.Format("{0}/{1}", Url, filename);
                byte[] filebytes = fileUpload.FileBytes;
                MemoryStream msFileStream = new MemoryStream(filebytes);
                FileCreationInformation newFile = new FileCreationInformation();
                newFile.ContentStream = msFileStream;
                newFile.Url = fileUrl;
                List metricLibrary = clientContext.Web.Lists.GetByTitle(Constants.MetricLibrary);
                try
                {
                    if (!string.IsNullOrEmpty(filename))
                    {
                        Microsoft.SharePoint.Client.File metricFile = metricLibrary.RootFolder.Files.Add(newFile);
                        clientContext.ExecuteQuery();
                        fileUrlAnchor.Attributes.Remove("onclick");
                        fileUrlAnchor.HRef = clientContext.Url + "/" + Constants.MetricLibrary + "/" + filename;
                        string templateUrl = clientContext.Url + "/" + Constants.MetricLibrary + "/" + Constants.TemplateUrl;
                        templateFile.HRef = templateUrl;

                    }
                }
                catch (Exception ex)
                {
                    //  ExceptionLogger.ErrorLog(ex.StackTrace, ex.Message, ex.Source, "NewGISProjects:UploadResourceExcel", Convert.ToString(ex.InnerException), "");
                }
            }
        }
        public string CheckFileExists(ClientContext clientContext, string folderUrl, bool isbinding)
        {
            string filename = string.Empty;
            try
            {                      
                Folder folder = clientContext.Web.GetFolderByServerRelativeUrl(folderUrl);
                clientContext.Load(folder);
                clientContext.Load(folder.Files);
                clientContext.ExecuteQuery();               

                List<int> fileIndex = new List<int>();

                
                if (folder.Files.Count == 0)
                {
                    if (isbinding)
                        return filename;
                    else
                    {
                        filename = Constants.MetricExcelFile + 1 + ".xlsx";
                    }
                }
                else
                {
                    foreach (Microsoft.SharePoint.Client.File file in folder.Files)
                    {
                        if (file.Name.Contains(Constants.MetricExcelFile))
                        {
                            int findex = Convert.ToInt32(file.Name.Split('_')[1].Split('.')[0]);
                            fileIndex.Add(findex);
                        }
                    }
                    fileIndex.Sort();
                    if (isbinding)
                        filename = Constants.MetricExcelFile + fileIndex.Last() + ".xlsx";
                    else
                    {
                        filename = Constants.MetricExcelFile + (fileIndex.Last() + 1) + ".xlsx";
                    }
                }
            }
            catch (Exception ex)
            {
               
            }
            return filename;
        }
        public bool CheckIfLoginUserAsAdmin(ClientContext clientContext, string currentUser)
        {
            bool isAdmin = false;
            if (!string.IsNullOrEmpty(currentUser))
            {
                List list = clientContext.Web.Lists.GetByTitle(Constants.MetricLibrary);
                var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='AdminUser' /><Value Type='User'>" + currentUser + "</Value></Eq></Where></Query></View>" };
                Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                clientContext.Load(items);
                clientContext.ExecuteQuery();

                if (items != null && items.Count > 0)
                {
                    hdnIsUserAdmin.Value = "true";
                    isAdmin = true;
                }
                else
                    hdnIsUserAdmin.Value = "false";
            }
            return isAdmin;
        }

        public void BindMetricFile()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                Web userweb = clientContext.Web;
                User user = userweb.CurrentUser;
                clientContext.Load(user);
                clientContext.Load(clientContext.Web, web => web.ServerRelativeUrl);
                clientContext.ExecuteQuery();
                string curruser = user.Title;
                if(!CheckIfLoginUserAsAdmin(clientContext, curruser))
                {
                    return;
                }

                string templateUrl = clientContext.Url + "/" + Constants.MetricLibrary + "/" + Constants.TemplateUrl;
                templateFile.HRef = templateUrl;

                string Url = clientContext.Web.ServerRelativeUrl + "/" + Constants.MetricLibrary;
                string existingFileName = CheckFileExists(clientContext, Url, true);

                if (!string.IsNullOrEmpty(existingFileName))
                {
                    string fileUrl = clientContext.Url + "/" + Constants.MetricLibrary + "/" + existingFileName;
                    fileUrlAnchor.HRef = fileUrl;
                }
                else
                {
                    // Set roster excel latest file URL to download
                    fileUrlAnchor.Attributes.Add("onclick", "alert('No previous metric file available.')");
                }
            }
        }
        #endregion

        public void ErrorLog(ClientContext clientContext, string errorMessage, string source, string method, string pageName)
        {

            List logList = clientContext.Web.Lists.GetByTitle("ErrorLogList");
            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
            Microsoft.SharePoint.Client.ListItem item = logList.AddItem(itemCreateInfo);
            item["Message"] = errorMessage;
            item["Source"] = source;
            item["Method"] = method;
            item["PageName"] = pageName;
            item.Update();
            clientContext.ExecuteQuery();

        }

        [WebMethod]
        public static string GetMetricData()
        {
            DataClass obj = new DataClass();
            DataTable dt = obj.GetMetricData();
            List<MetricClass> objMetricList = new List<MetricClass>();
            if (dt.Rows.Count > 0)            {
              
                foreach(DataRow row in dt.Rows)
                {
                    MetricClass objMetric = new MetricClass();
                    objMetric.ID = Convert.ToString(row["ID"]);
                    objMetric.Category = Convert.ToString(row["Category"]);
                    objMetric.Name = Convert.ToString(row["Name"]);
                    objMetric.Description = Convert.ToString(row["Description"]);
                    objMetric.MetricGroup = Convert.ToString(row["MetricGroup"]);
                    objMetric.BU = Convert.ToString(row["BU"]);
                    objMetric.TableauFolderName = Convert.ToString(row["TableauFolderName"]);
                    objMetric.TechnicalName = Convert.ToString(row["TechnicalName"]);
                    objMetric.AttributeName = Convert.ToString(row["AttributeName"]);
                    objMetric.AttributeDescription = Convert.ToString(row["AttributeDescription"]);
                    objMetric.TechnicalFormula = Convert.ToString(row["TechnicalFormula"]);
                    objMetric.ColumnType = Convert.ToString(row["ColumnType"]);
                    objMetric.IsCalculated = Convert.ToString(row["IsCalculated"]);
                    objMetric.MetricOwner = Convert.ToString(row["MetricOwner"]);
                    objMetric.URL = Convert.ToString(row["URL"]);
                    objMetricList.Add(objMetric);
                }
            }
          

            string metricListstring = JsonConvert.SerializeObject(objMetricList);
            string appendString = "[{\"total\":\"" + dt.Rows.Count + "\",\"totalNotFiltered\":\"" + dt.Rows.Count + "\",\"rows\":" + metricListstring + "}";

            //  string appendString = "{total:" + dt.Rows.Count + ",totalNotFiltered:" + dt.Rows.Count + ",rows:" + metricListstring + "}";
           // appendString = JsonConvert.SerializeObject(appendString);
            appendString = appendString.Remove(0, 1);

            return appendString;
        }
    }
}