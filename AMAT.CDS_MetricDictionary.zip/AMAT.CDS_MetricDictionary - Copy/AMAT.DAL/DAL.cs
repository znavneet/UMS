﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.DAL
{
    public class DataClass
    {

        string conString = System.Configuration.ConfigurationManager.AppSettings["SQLDBConnectionString"];

        /// delete existing records before addig new records
        public string DeleteAndBulkInsertRecords(DataTable datatable)
        {
            string status = "success";
          //  SqlTransaction trans;
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("DeleteRecords", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;                 
                    con.Open();
                   // trans = con.BeginTransaction();
                  //  cmd.Transaction = trans;

                    cmd.ExecuteNonQuery();

                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conString))
                    {
                        bulkCopy.DestinationTableName = "CDS_Dictionary";
                        try
                        {
                            // Write from the source to the destination.
                            bulkCopy.WriteToServer(datatable);
                         //   trans.Commit();
                        }
                        catch (Exception ex)
                        {
                          //  if (trans != null)
                            {
                         //       trans.Rollback();
                                status = "Failed";
                            }
                        }
                        con.Close();
                    }
                    return status;
                }
            }
        }


        public DataTable GetMetricData()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(Constants.GetAllMetricRecordsSP, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
                return dt;
            }
        }
    }
}
