﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.DAL
{
    public class Constants
    {
        public static string MetricLibrary = "MetricExcelFiles";
        public static string MetricExcelFile = "MetricExcel_";
        public static string TemplateUrl = "/Template/CDSMetricFileTemplate.xlsx";
        public static string GetAllMetricRecordsSP = "GetAllMetricRecords";

    }

    public class MetricClass
    {
        public string ID { get; set; }
        public string Category { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string MetricGroup { get; set; }
        public string BU { get; set; }
        public string TableauFolderName { get; set; }
        public string TechnicalName { get; set; }
        public string AttributeName { get; set; }
        public string AttributeDescription { get; set; }
        public string ColumnType { get; set; }
        public string IsCalculated { get; set; }
        public string TechnicalFormula { get; set; }
        public string MetricOwner { get; set; }
        public string URL { get; set; }

    }
}
