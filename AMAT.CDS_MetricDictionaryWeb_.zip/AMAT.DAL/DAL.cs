﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.DAL
{
    public class DataClass
    {

        string conString = System.Configuration.ConfigurationManager.AppSettings["SQLDBConnectionString"];
        int bulkCopyTimeout = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["BulkCopyTimeout"]);
        public string DictionaryDataInsert(DataTable table)
        {
            string status = "success";
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlTransaction transaction = con.BeginTransaction();
                SqlCommand cmdDeleteRecords = new SqlCommand(Constants.DeleteRecords, con, transaction);
                cmdDeleteRecords.CommandType = CommandType.StoredProcedure;                
                cmdDeleteRecords.Transaction = transaction;

                table.Columns.Remove("ID");
                SqlCommand cmdDicData = new SqlCommand(Constants.DictionaryDataInsertSP, con, transaction);
                cmdDicData.CommandType = CommandType.StoredProcedure;
                SqlParameter parameter = cmdDicData.Parameters.AddWithValue("@dictionaryType", table);
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.TypeName = "AGS_BIM_CTLG.CDS_Type";
                cmdDicData.Transaction = transaction;

                try
                {
                    cmdDeleteRecords.ExecuteNonQuery();
                    cmdDicData.ExecuteNonQuery();
                    transaction.Commit();
                    con.Close();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    status = "Failed";
                    con.Close();
                }
            }
            return status;
        }
        ///// delete existing records before addig new records
        //public string DeleteAndBulkInsertRecords(DataTable datatable)
        //{
        //    string status = "success";
        //    SqlTransaction trans;
        //    using (SqlConnection con = new SqlConnection(conString))
        //    {
        //        using (SqlCommand cmd = new SqlCommand(Constants.DeleteRecords, con))
        //        {
        //            cmd.CommandType = CommandType.StoredProcedure;                 
        //            con.Open();
        //            trans = con.BeginTransaction();
        //            cmd.Transaction = trans;
        //            cmd.ExecuteNonQuery();

        //            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conString))
        //            {
        //                bulkCopy.DestinationTableName = Constants.CDSTableName;
        //                try
        //                {
        //                    // Write from the source to the destination.
        //                    bulkCopy.BulkCopyTimeout = bulkCopyTimeout;
        //                    bulkCopy.WriteToServer(datatable);
        //                    trans.Commit();
        //                }
        //                catch (Exception ex)
        //                {
        //                   if (trans != null)
        //                    {
        //                        trans.Rollback();
        //                        status = "Failed";
        //                    }
        //                }
        //                con.Close();
        //            }
        //            return status;
        //        }
        //    }
        //}
        public DataTable GetMetricData()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(Constants.GetAllMetricRecordsSP, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
                return dt;
            }
        }

        //Get Catatlog all records
        public DataTable GetCatalogData()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(Constants.GetAllCatalogRecords, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
                return dt;
            }
        }
        //Get BIM content Type records
        public DataTable GetContentType()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(Constants.GetContentTypeSP, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
                return dt;
            }
        }
        //Get BIM content Type records
        public DataTable GetFunctionalDomain()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(Constants.GetFunctionalDomain, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
                return dt;
            }
        }

        // inserting catalog record
        public void InsertCatalogRecord(string name,string desc,string contentType,string bof,string businessOwner, string bimOwner, string link,string documentLink, string trainingPath,string createdby, string createdDate, string lastModifydate, string lastmodifiedBy)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(Constants.InsertCatalogRecordSP,con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@desc", desc);
                    cmd.Parameters.AddWithValue("@contenttype", contentType);
                    cmd.Parameters.AddWithValue("@businessOwnfn", bof);
                    cmd.Parameters.AddWithValue("@businessOwner", businessOwner);
                    cmd.Parameters.AddWithValue("@bimproductOwner", bimOwner);
                    cmd.Parameters.AddWithValue("@link", link);
                    cmd.Parameters.AddWithValue("@documentlink", documentLink);
                    cmd.Parameters.AddWithValue("@traininglink", trainingPath);                 
                    cmd.Parameters.AddWithValue("@createddate", createdDate);
                    cmd.Parameters.AddWithValue("@createdby", createdby);
                    cmd.Parameters.AddWithValue("@lastmodifieddate", lastModifydate);
                    cmd.Parameters.AddWithValue("@modifiedby", lastmodifiedBy);  //modify by

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
            }
        }
        //update catalog record
        public void UpdateCatalogRecord(int id, string name, string desc, string contentType, string bof, string businessOwner, string bimOwner, string link, string documentLink, string trainingPath,int isActive, string modifiedby,string modifiedDate)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(Constants.UpdateCatalogRecordSP,con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@desc", desc);
                    cmd.Parameters.AddWithValue("@contenttype", contentType);
                    cmd.Parameters.AddWithValue("@businessOwnfn", bof);
                    cmd.Parameters.AddWithValue("@businessOwner", businessOwner);
                    cmd.Parameters.AddWithValue("@bimproductOwner", bimOwner);
                    cmd.Parameters.AddWithValue("@link", link);
                    cmd.Parameters.AddWithValue("@documentlink", documentLink);
                    cmd.Parameters.AddWithValue("@traininglink", trainingPath);
                    cmd.Parameters.AddWithValue("@active", Convert.ToString(isActive));                
                    cmd.Parameters.AddWithValue("@modifiedby", modifiedby);
                    cmd.Parameters.AddWithValue("@lastmodifieddate", modifiedDate);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
            }
        }

        //inserting data in catalog
        public string DeleteAndBulkInsertRecordsCatalog(DataTable datatable)
        {
            string status = "success";
            SqlTransaction trans;
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("Delete from " + Constants.BIMCatalogTableName + "", con))
                {
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    trans = con.BeginTransaction();
                    cmd.Transaction = trans;
                    cmd.ExecuteNonQuery();

                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conString))
                    {
                        bulkCopy.DestinationTableName = Constants.BIMCatalogTableName;
                        try
                        {
                            // Write from the source to the destination.
                            bulkCopy.BulkCopyTimeout = bulkCopyTimeout;
                            bulkCopy.WriteToServer(datatable);
                            trans.Commit();
                        }
                        catch (Exception ex)
                        {
                            if (trans != null)
                            {
                                trans.Rollback();
                                status = "Failed";
                            }
                        }
                        con.Close();
                    }
                    return status;
                }
            }
        }
    }
}
