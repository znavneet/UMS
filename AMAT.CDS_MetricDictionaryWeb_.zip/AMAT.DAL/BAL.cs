﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.DAL
{
   public class BAL
    {
        //Get all metric records
        DataClass obj = new DataClass();
        public DataTable GetMetricData()
        {          
            DataTable dt = obj.GetMetricData();
            return dt;
        }

        //Get allcatalog records
        public DataTable GetActiveCatalogRecords()
        {
            DataTable dt = obj.GetCatalogData();            
            return dt;
        }
        //Get contentType records
        public DataTable GetContentType()
        {
            DataTable dt = obj.GetContentType();
            return dt;
        }

        //Get contentType records
        public DataTable GetfnDomain()
        {
            DataTable dt = obj.GetFunctionalDomain();
            return dt;
        }

        public string DictionaryDataInsert(DataTable dt)
        {
            return obj.DictionaryDataInsert(dt);
        }
        //Insert record
        public void InsertRecord(string name, string desc, string contentType, string bof, string businessOwner, string bimOwner, string link, string documentLink, string trainingPath, string createdby, string createdDate, string lastModifydate,string lastmodifiedBy)
        {
            obj.InsertCatalogRecord(name, desc, contentType, bof, businessOwner, bimOwner, link, documentLink, trainingPath, createdby, createdDate, lastModifydate, lastmodifiedBy);
        }
        //update record
        public void UpdateRecord(int id, string name, string desc, string contentType, string bof, string businessOwner, string bimOwner, string link, string documentLink, string trainingPath, int isActive, string modifiedby, string modifiedDate)
        {
            obj.UpdateCatalogRecord(id, name, desc, contentType, bof, businessOwner, bimOwner, link, documentLink, trainingPath, isActive, modifiedby, modifiedDate);
        }
    }

    public class MetricClass
    {
        public string ID { get; set; }
        public string ContentType { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string MetricGroup { get; set; }
        public string BU { get; set; }
        public string TableauFolderName { get; set; }
        public string TechnicalName { get; set; }
        public string AttributeName { get; set; }
        public string AttributeDescription { get; set; }
        public string ColumnType { get; set; }
        public string IsCalculated { get; set; }
        public string TechnicalFormula { get; set; }
        public string MetricOwner { get; set; }
        public string URL { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }

    }


    public class BIMCatalog
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ContentType { get; set; }
        public string BusinessOwner { get; set; }
        public string BusinessOwningFunction { get; set; }
        public string BIMProductOwner { get; set; }
        public string DocumentLink { get; set; }
        public string TraningLink { get; set; }
        public string Link { get; set; }
        public int Active { get; set; }
        public string CreatedDate { get; set; }
        public string LastModifiedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string IsCDSExistForThis { get; set; }
    }
    public class UserInformation
    {
        public string UserName { get; set; }
        public string UserEmail { get; set; }

    }
}
