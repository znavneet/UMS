﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.DAL
{
    public class Constants
    {
        public static string MetricLibrary = "MetricExcelFiles";
        public static string MetricExcelFile = "MetricExcel_";
        public static string TemplateUrl = "/Template/CDSMetricFileTemplate.xlsx";
        public static string GetAllMetricRecordsSP = "AGS_BIM_CTLG.USP_GetAllMetricRecords";
        public static string DeleteRecords = "AGS_BIM_CTLG.USP_DeleteRecords";
        public static string GetAllCatalogRecords = "AGS_BIM_CTLG.USP_GetAllCatalogRecords";
        public static string CDSTableName = "AGS_BIM_CTLG.CDS_Dictionary";
        public static string BIMCatalogTableName = "AGS_BIM_CTLG.BIM_Catalog";
        public static string GetContentTypeSP = "AGS_BIM_CTLG.USP_GetContentType";
        public static string InsertCatalogRecordSP = "AGS_BIM_CTLG.USP_InsertCatalogRecord";
        public static string UpdateCatalogRecordSP = "AGS_BIM_CTLG.USP_UpdateCatalogRecord";
        public static string GetFunctionalDomain = "AGS_BIM_CTLG.USP_GetFunctionalDomain";
        public static string BIMCatalogList = "BIM_Catalog";
        public static string DictionaryDataInsertSP = "AGS_BIM_CTLG.DictionaryDataInsert";
    
        


    }


}
