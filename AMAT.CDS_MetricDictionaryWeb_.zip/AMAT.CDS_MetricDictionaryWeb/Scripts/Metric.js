﻿
$(document).ready(function () {
    CheckForAdminUser();
    getCatalogData();
    getMetricData();
   // $("<span style='font-size:21px;padding: 0 10px 0 0;font-weight: 100;color: #4e9eb8;'>Search</span>").insertBefore(".search-input");
 
    $(".search_links").insertAfter("#one .fixed-table-toolbar");

    $('[data-toggle="tooltip"]').tooltip();
    $(".no-records-found").html("<td colspan=10><div style='color:black;text-align:center'> <img src='../img/loading.gif' alt='' width=22px; /> Loading...</div></td>");

    TriggerFunction();
    GetAdUser();

    TabClickFunction();
});

function fileValidation() {
    var filePath = $('#fileUpload').val();

    var allowedExtensions = /(\.xls|\.xlsx)$/i;

    if (!filePath) {
        alert('Please select the metric excel file to upload.');
        return false;
    }

    if (!allowedExtensions.exec(filePath)) {
        alert('Please upload the filled metric excel template.');
        return false;
    }
    else {
        $('#loading').show();
    }
}

var cdsData=[];
function getMetricData() {

    $.ajax({
        url: "Default.aspx/GetMetricData",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "JSON",
        success: function (data) {
           // console.log(data.d);
           // return JSON.parse(data.d);
            //var $table = $('#table');
            //$table.bootstrapTable({ data: data.d });
            //$('#table').bootstrapTable({
            //    data: data.d
            //});
            cdsData.push(data.d);
            $('#table').bootstrapTable('load', JSON.parse(data.d));
        },
        error: function (error) {
            console.log(JSON.stringify(error));
           // alert(JSON.stringify(error));
        }
    });
}


function nameFormatter(value, row) {

    let url = decodeURIComponent(row.URL);
    return '<a class=anchor href=' + url + ' target=_blank >' + value + '</a>';
}
function DescFormatter(value, row) {
    var newValue = "";
    if (value) {
        if (value.length > 70) {
            newValue = value.substring(0, 70) + "...";
        }
        else {
            newValue = value;
        }
        let content = "<span data-toggle='tooltip' title='" + value + "'>" + newValue + "<span>";
        return content;
    }
}

function EditFormatter(value, row) { 
  
  //  row.Name = encodeURIComponent(row.Name);
  //  row.Description = encodeURIComponent(row.Description);

    let url = decodeURIComponent(row.Link);
    row.Link = encodeURIComponent(url);

    let documentLink = decodeURIComponent(row.DocumentLink);
    row.DocumentLink = encodeURIComponent(documentLink);

    let traningLink = decodeURIComponent(row.TraningLink);
    row.TraningLink = encodeURIComponent(traningLink);
  
    return "<a class=anchor href='#' title='Edit' onclick='AddNewEditRecord("+JSON.stringify(row)+")'><i class='fas fa-pencil-alt deep-purple-text' aria-hidden='true'></i></a>";
}
function responseHandler(res) {
    $.each(res.rows, function (i, row) {
        row.state = $.inArray(row.id, selections) !== -1
    })
    return res
}
function CheckForAdminUser() {
    var val = $('#hdnIsUserAdmin').val();
    if (val == "false") {
        $('#upload').hide();
        $('.addRecord').hide();
        $('#catalogTable').bootstrapTable('hideColumn', 'Edit');
        $('#recordLi').hide();
       // $('#two').css('opacity', '1');
    }    
}

//************** BIM Catalog Data fetch********************

function getCatalogData() { //URLFormattor

    $.ajax({
        url: "Default.aspx/GetCatalogData",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "JSON",
        success: function (data) {
            console.log(JSON.parse(data.d));
            $('#catalogTable').bootstrapTable('load', JSON.parse(data.d));
            $('#catalogTable').bootstrapTable('hideColumn', 'ID');
            
        },
        error: function (error) {
            console.log(JSON.stringify(error));
            // alert(JSON.stringify(error));
        }
    });
}


function URLFormattor(value, row) {
    let url = decodeURIComponent(row.Link);
    return '<a class=anchor href=' + url + ' target=_blank  title="' + url + '">' + value + '</a>';
}

function searchCDS(source, cdsname) {
    var results;
    source = JSON.parse(source);
    var results = [];
    var searchField = "Name";
    var searchVal = cdsname;
    for (var i = 0; i < source.rows.length; i++) {
        if (source.rows[i][searchField].replace(/\s+/g, '').toLowerCase() == searchVal) {
            results.push(source.rows[i]);
        }
    }

    results= JSON.stringify(results);

   // var newAppendJson = '{"total":"' + results.length + '","totalNotFiltered":"' + results.length + '","rows":"' + results + '"}';
    var newAppendJson = "{\"total\":\"" + results.length + "\",\"totalNotFiltered\":\"" + results.length + "\",\"rows\":" + results + "}";


    var newJson = JSON.parse(JSON.stringify(newAppendJson));

    $('#cdsreftable').bootstrapTable('load', JSON.parse(newJson));
   // return results;
}

function GetCDSRef(cdsname) {
   
    cdsname = decodeURIComponent(cdsname.toLowerCase());
    cdsname = cdsname.replace(/\s+/g, '');   

    var cdsdata = JSON.parse(cdsData);
    searchCDS(cdsData, cdsname);
   $('#cdsRef').modal('show');
}
// for click on cds ref link in grid column
var cds = [];
function cdsPopup(value, row) {
  
    if (row.IsCDSExistForThis == "Yes") {
        return "<a class=anchor  href='#' onclick=Javascript:GetCDSRef('" + encodeURIComponent(row.Name) + "')>Data dictionary</a>";
    }
    else {
        return "";
    }
}

// for click on cds ref link in grid column
function DocLink(value, row) {
    if (row.DocumentLink) {
        value = decodeURIComponent(value);
        return "<a class=anchor target='_blank'  href='" + value + "'>View</a>";
    }
    else {
        return "";
    }
}
function TraningLink(value, row) {
    if (row.TraningLink) {
        value = decodeURIComponent(value);
        return "<a class=anchor target='_blank'  href='" + value + "'>View</a>";
    }
    else {
        return "";
    }
}



// for adding new record link

function AddNewEditRecord(row) {

    $('#txtName').val('');
    $('#ddlContentType').val('0');
    $('#ddlfndomain').val('0');
    $('#txtbusinessOwner').val('');
    $('#txtProductOwner').val('');
    $('#txtDesc').val('');
    $('#txtLink').val('');
    $('#txtDoumentLink').val('');
    $('#txtTraningLink').val('');
    $('#chkActiveOnEdit').hide();
    //for update
    if (row) {        
        $('#txtName').val(decodeURIComponent(row.Name));
        $('#ddlContentType').val(row.ContentType);        
        $('#ddlfndomain').val(row.BusinessOwningFunction);
        $('#txtbusinessOwner').val(row.BusinessOwner);
        $('#txtProductOwner').val(row.BIMProductOwner);
        $('#txtDesc').val(decodeURIComponentSafe(row.Description));
        $('#txtLink').val(decodeURIComponent(row.Link));
        $('#txtDoumentLink').val(decodeURIComponent(row.DocumentLink));
        $('#txtTraningLink').val(decodeURIComponent(row.TraningLink));
        var id = row.ID;
        $('#hdnRowId').val(id);
        $('#chkActiveOnEdit').show();
        $('#isActive').prop('checked', true);
    }
    else { // for new record
        $('#hdnRowId').val('');
    }
    $('#addEditRecord').modal('show');
}

function decodeURIComponentSafe(uri, mod) {
    var out = new String(),
        arr,
        i = 0,
        l,
        x;
    typeof mod === "undefined" ? mod = 0 : 0;
    arr = uri.split(/(%(?:d0|d1)%.{2})/);
    for (l = arr.length; i < l; i++) {
        try {
            x = decodeURIComponent(arr[i]);
        } catch (e) {
            x = mod ? arr[i].replace(/%(?!\d+)/g, '%25') : arr[i];
        }
        out += x;
    }
    return out;
}
var $table = $('#catalogTable');

function TriggerFunction() {

    $('#Dashboard').click(function () {
        $('.search_links a').removeClass('active');
        $('#Dashboard').addClass('active');

        $('#catalogTable').bootstrapTable('filterBy', {
            ContentType: 'Dashboard'
        });
    });
    $('#Report').click(function () {
        $('.search_links a').removeClass('active');
        $('#Report').addClass('active');

        $('#catalogTable').bootstrapTable('filterBy', {
            ContentType: 'Report'
        })
    });
    $('#Cube').click(function () {
        $('.search_links a').removeClass('active');
        $('#Cube').addClass('active');

        $('#catalogTable').bootstrapTable('filterBy', {
            ContentType: 'Cube'
        })
    });
    $('#CDS').click(function () {
        $('.search_links a').removeClass('active');
        $('#CDS').addClass('active');

        $('#catalogTable').bootstrapTable('filterBy', {
            ContentType: 'CDS'
        })
    });
    $('#All').click(function () {

        $('.search_links a').removeClass('active');
        $('#All').addClass('active');

        $('#catalogTable').bootstrapTable('filterBy', {
            Active: 1
        })

      
    });


    $('#chkActive').click(function () {
        if (this.checked) {
            $('#catalogTable').bootstrapTable('filterBy', {
                Active: 1
            });
        }
        else {
            $('#catalogTable').bootstrapTable('filterBy', {
                Active: 0
            });
        }

    });

  //  $('#All').on('click', function () { $('.filter-show-clear').trigger('click') });
   // $('#All').bootstrapTable('refreshOptions');

    //$("#searchInput").on("keyup", function () {
    //    var value = $(this).val().toLowerCase();
    //    $("#catalogTable tr").filter(function () {
    //        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    //    });
    //});
}


// Get user info from AD for business user

function GetAdUser() {

    $('#txtbusinessOwner').autocomplete({
        minLength: 3,
        select: function (event, ui) {
            GetNameEmailBussOwner(ui.item.label)
            return false;
        },
        source: function (request, response) {
            $('#loadBusinessOwner').show();
            $.ajax({
                url: 'Default.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        if (item.UserEmail) {
                            var result = item.UserName;
                            return {
                                value: result
                            }
                        }
                    }))

                    $('#loadBusinessOwner').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loadBusinessOwner').hide();
                    $("#txtBusinessOwner").val("");
                    alert("Not found.");
                }
            });
        }
    });

    $('#txtProductOwner').autocomplete({
        minLength: 3,
        select: function (event, ui) {
            GetNameEmailProductOwner(ui.item.label)
            return false;
        },
        source: function (request, response) {
              $('#loadProductOwner').show();
            $.ajax({
                url: 'Default.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        if (item.UserEmail) {
                            var result = item.UserName;
                            return {
                                value: result
                            }
                        }
                    }))

                    $('#loadProductOwner').hide();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loadProductOwner').hide();
                    $("#txtProductOwner").val("");
                    alert("Not found.");
                }
            });
        }
    });
}

// Get user info from AD for product owner



function GetNameEmailBussOwner(str) {
    var value = str;
    $("#txtbusinessOwner").val(value);  
    return false;
}
function GetNameEmailProductOwner(str) {
    var value = str;
    $("#txtProductOwner").val(value);
    return false;
}

function TabClickFunction() {
    var val = $('#hdnIsUserAdmin').val();
   
    $('#one-tab').click(function () {
        if (val !== "false")
            $('.addRecord').css('display', 'inline-flex');
    });
    $('#two-tab').click(function () {
        $('.addRecord').css('display', 'none');
    });
    $('#three-tab').click(function () {
        $('.addRecord').css('display', 'none');
    });
   
}
// ************************** Form Validation ******************

function ValidateForm() {

    let msg = "Please enter the value for mandatory fields. \n--------------------------------------------------\n";
    let isValid = true;
    let name = $('#txtName').val();
    let desc = $('#txtDesc').val();
    let contentType = $('#ddlContentType').val();
    let bof = $('#ddlfndomain').val();
    let businessOwner = $('#txtbusinessOwner').val();
    let productOwner = $('#txtProductOwner').val();
    let link = $('#txtLink').val();

    if (!name) {
        msg += "Enter name. \n";
        isValid = false;
    }
    if (contentType == "0") {
        msg += "Select content type. \n";
        isValid = false;
    }
    if (bof == "0") {
        msg += "Select business owning function name. \n";
        isValid = false;
    }
    if (!businessOwner) {
        msg += "Enter the name for business owner. \n";
        isValid = false;
    }
    if (!productOwner) {
        msg += "Enter the name of BIM product owner. \n";
        isValid = false;
    }
    if (!link) {
        msg += "Enter the URL for related object. \n";
        isValid = false;
    }

    if (isValid) {
        $("#loading").show();
        $("#loadingSpan").text("Processing record...");
    }
    else {
        alert(msg);
    }

    return isValid;
}