﻿
///category onchange event

$(document).ready(function () {
    linkValidation();

    $("input[type='radio']").change(function () {
        var selection = $(this).val();

        if (selection == "others") {
            $('#otherBusinessdiv').show();
        }
        else {
            $('#otherBusinessdiv').hide();
        }
    });
   
});


function ValidateBimRequestForm() {
    
    var IsTrue = true;
      
    var businessVal = $("input[name='inlineRadioOptions']:checked").val();
    if (!businessVal)
    {
        alert("Please enter all required field values.");
        IsTrue = false;
        return false;
    }

    var category = $('#creqcategory').val();
    var titleval = $('#creqtitle').val();
    var descval = $('#reqDesc').val();

    if (titleval == "" || descval == "" || category == null || businessVal == "") {
        alert("Please enter all required field values.");
        IsTrue = false;
        return false;
    }

    if(IsTrue)
        $("#loading").show();

}

function resetFormfields() {

    $('#creqcategory').val('--Select--');
    $('#ddlIssue').val('--Select--');
    $('#ddlDashboardName').val('--Select--');
    $('#creqtitle').val('');
    $('#reqDesc').empty();
    $('#issuetitle').val('');
    $('#issuedesc').empty();
}

function validationIssueRequest()
{
    var IsTrue = true;
    var titleval = $('#issuetitle').val(); 
    var category = $('#ddlIssue').val(); 
    var descval = $('#issuedesc').val(); 
    var dashboard = $('#ddlDashboardName').val();

    if (titleval == "" || dashboard == null || category == null || descval == "") {
        alert("Please enter all required field values.");
        IsTrue = false;
        return false;
    }

    if (IsTrue)
        $("#loading").show();
}


//number validation

function isNumber(evt) {
    var iKeyCode = (evt.which) ? evt.which : evt.keyCode
    if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
        return false;

    return true;
}

function validateDate(dateValue) {
    var selectedDate = dateValue;
    if (selectedDate == '')
        return false;

    var regExp = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/; //Declare Regex
    var dateArray = selectedDate.match(regExp); // is format OK?

    if (dateArray == null) {
        return false;
    }

    month = dateArray[1];
    day = dateArray[3];
    year = dateArray[5];

    if (month < 1 || month > 12) {
        return false;
    } else if (day < 1 || day > 31) {
        return false;
    } else if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
        return false;
    } else if (month == 2) {
        var isLeapYear = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isLeapYear)) {
            return false
        }
    }
    return true;
}

function linkValidation()
{
    $('#createbimreq').click(function () {
        $('#createBimRequest').show();
        $('#createIssueRequest').hide();
        $('#viewMyRequest').hide();

        $('#createbimreq a').addClass('active');
        $('#createissuereq a').removeClass('active');
        $('#myrequest a').removeClass('active');

    });
    $('#createissuereq').click(function () {
        $('#createIssueRequest').show();
        $('#createBimRequest').hide();
        $('#viewMyRequest').hide();

        $('#createbimreq a').removeClass('active');
        $('#createissuereq a').addClass('active');
        $('#myrequest a').removeClass('active');
    });
    $('#myrequest').click(function () {
        $('#createBimRequest').hide();
        $('#createIssueRequest').hide();
        $('#viewMyRequest').show();

        $('#createbimreq a').removeClass('active');
        $('#createissuereq a').removeClass('active');
        $('#myrequest a').addClass('active');
       // loadViewMyRequest();

    });
   
    $('#creqcategory').on('change', function () {
        $('#hdnBimRequestCat').val($(this).val());
    });

    $('#ddlIssue').on('change', function () {
        $('#hdnIssueRequestCat').val($(this).val());
    });

    $('#ddlDashboardName').on('change', function () {
        $('#hdndashboardname').val($(this).val());
    });
}