﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using MSXML2;
using System.Text;
using Microsoft.SharePoint.Client;
using System.Net.Http;
using System.IO;
using System.Net;
using System.Net.Http.Headers;
using Microsoft.Activities.Messaging;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.SharePoint.Client.Utilities;
using Newtonsoft.Json;
using System.Globalization;
using System.Configuration;
using System.Security;
using AMAT.Utilities.ExcelComponent;
using System.Data;

namespace AMAT.BIM_UMSWeb.Pages
{
    public partial class Test : System.Web.UI.Page
    {
        Constant obj = new Constant();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllDashoard();
                GetFunctionalDomain();
                GetJIRAUsers();
                ISCurrentUserAdmin();
                //  GetCurrentUserEmail();


                if (!string.IsNullOrEmpty(Request.QueryString["tab"]))
                {
                    string tabName = Convert.ToString(Request.QueryString["tab"]);
                    hdntab.Value = tabName;
                }

                if (!string.IsNullOrEmpty(Request.QueryString["category"]))
                {
                    string ddlcategory = Convert.ToString(Request.QueryString["category"]);
                    hdnddlCategory.Value = ddlcategory;
                }

                string env = ConfigurationManager.AppSettings["JIRAUrl"];
                if (env.Contains("-qa")) // for QA
                    hdnJiraEnv.Value = Constant.JiraShortUrlShortQA;
                else // for Prod
                    hdnJiraEnv.Value = Constant.JiraShortUrlShort;
            }
        }

        #region submit/esclate Button events

        protected void btnBimSubmit_Click(object sender, EventArgs e)
        {
            SavingBIMValues();
        }

        protected void btnIssueSubmit_Click(object sender, EventArgs e)
        {
            SavingIssueValues();
        }

        #endregion

        #region Saving Bim/Bug values in JIRA

        /// <summary>
        /// Saving BIM request values to JIra
        /// </summary>
        protected void SavingBIMValues()
        {

            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string jiraUrl = obj.JiraUrl;
                    string projectId = string.Empty; string issueId = string.Empty;
                    if (jiraUrl.Contains("-qa"))
                    {
                        projectId = Constant.ProjectIdQA;
                        issueId = Constant.BimIssueIdQA;
                    }
                    else
                    {
                        projectId = Constant.ProjectId;
                        issueId = Constant.BimIssueId;
                    }
                    string requestType = hdnBimRequestCat.Value;
                    string bimTitle = RemoveCharacter(creqtitle.Value);
                    string requesterInfo = string.Empty;
                    string requestorName = string.Empty;
                    string requestorEmail = string.Empty;
                    string requestorId = string.Empty;
                    string businessValueType = string.Empty;
                    string reqDescription = RemoveCharacter(reqDesc.InnerText);
                    string fromRMS = "Yes";
                    string emailNotification = string.Empty;
                    string fnDomain = ddlfunctionalDomain.Value;

                    ///get requester name
                    if (requesterchk.Checked)
                    {
                        requesterInfo = hdnCsomDelegateTo.Value;
                        requesterInfo = requesterInfo.TrimStart(new char[] { '[' }).TrimEnd(new char[] { ']' });
                        requestorName = JObject.Parse(requesterInfo)["Name"].ToString();
                        requestorEmail = JObject.Parse(requesterInfo)["Email"].ToString();
                    }
                    else
                    {
                        requestorName = currentuser.InnerText;
                        requestorEmail = hdnUserMail.Value;
                    }

                    if (chkNotification.Checked)
                        emailNotification = "Yes";
                    else
                        emailNotification = "No";

                    // taking radion button value
                    if (inlineRadio1.Checked == true)
                        businessValueType = "Revenue Growth";

                    if (inlineRadio2.Checked == true)
                        businessValueType = "Cost Saving";

                    if (inlineRadio3.Checked == true)
                        businessValueType = "Productivity Gain";

                    if (inlineRadio4.Checked == true)
                        businessValueType = "Others";

                    businessValueType = GetBusineValues(businessValueType);

                    JIRA jira = new JIRA();
                    //jira.JiraUrl = Constant.JiraUrlForCreating;  
                    jira.JiraUserName = obj.UserId;
                    jira.JiraPassword = obj.Password;
                    jiraUrl = obj.JiraUrl;


                    requestorId = obj.UserId; //devops // reporter name

                    string jsonStr = string.Empty;

                    if (jiraUrl.Contains("-qa"))
                    {
                        // jsonStr = @"{""fields"": {""project"": { ""id"": """ + projectId + @"""}, ""summary"": """ + bimTitle + @""", ""customfield_10100"": """ + Constant.BIMEpicNameQA + @""",""description"": """ + reqDescription + @""",""customfield_10540"": {""value"": """ + requestType + @"""},""customfield_10512"": {""value"": """ + businessValueType + @"""},""customfield_12700"": """ + requestorEmail + @""",""customfield_11107"": {""value"": """ + fromRMS + @"""},""reporter"": {""name"": """ + requestorId + @"""},""issuetype"": {""id"": """ + issueId + @"""},""customfield_12605"": {""value"": """ + emailNotification + @"""},""customfield_12800"": {""value"": """ + fnDomain + @"""}}}";
                        jsonStr = @"{""fields"": {""project"": { ""id"": """ + projectId + @"""}, ""summary"": """ + bimTitle + @""",""description"": """ + reqDescription + @""",""customfield_10100"": """ + Constant.BIMEpicNameQA + @""",""customfield_10540"": {""value"": """ + requestType + @"""},""customfield_10512"": {""value"": """ + businessValueType + @"""},""customfield_12700"": """ + requestorEmail + @""",""customfield_13801"": """ + requestorName + @""",""customfield_11107"": {""value"": """ + fromRMS + @"""},""reporter"": {""name"": """ + requestorId + @"""},""issuetype"": {""id"": """ + issueId + @"""},""customfield_12605"": {""value"": """ + emailNotification + @"""},""customfield_12800"": {""value"": """ + fnDomain + @"""}}}";

                    }
                    else
                    {
                        //Production string
                        jsonStr = @"{""fields"": {""project"": { ""id"": """ + projectId + @"""}, ""summary"": """ + bimTitle + @""",""description"": """ + reqDescription + @""",""customfield_10100"": """ + Constant.BIMEpicName + @""",""customfield_10713"": {""value"": """ + requestType + @"""},""customfield_10512"": {""value"": """ + businessValueType + @"""},""customfield_12208"": """ + requestorEmail + @""",""customfield_10802"": {""value"": """ + fromRMS + @"""},""reporter"": {""name"": """ + requestorId + @"""},""issuetype"": {""id"": """ + issueId + @"""},""customfield_12207"": {""value"": """ + emailNotification + @"""},""customfield_11006"": {""value"": """ + fnDomain + @"""}}}";
                    }
                    jira.JiraUrl = jiraUrl;
                    jira.JiraJson = ToParseJSON(jsonStr);
                    //  string response = jira.addJiraIssue();
                    string response = Convert.ToString(jira.addJiraIssue());
                    string key = Convert.ToString(JObject.Parse(response)["key"]);

                    if (!string.IsNullOrEmpty(key))
                    {
                        if (bimFileUpload.HasFile)
                            AddAttachment(key, jira, bimFileUpload);

                        // ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert1", "alert('Your Request submitted successfully')", true);
                        lblbmsg.Text = "Your Request submitted is with key no: " + key + "  successfully.";
                    }
                    else
                        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert1", "alert('Something went wrong!!')", true);

                    ClearFields();
                }
                catch (Exception ex)
                {
                    ErrorLogClass obj = Constant.ErrorLog(ex.Message, ex.Source, "addJiraIssue", "Jira.cs");
                    Constant.ErrorLog(clientContext, obj.ErrorMessage, obj.Source, "SavingBIMValues", "UMS.aspx");
                }
            }

        }

        protected void ClearFields()
        {
            creqcategory.SelectedIndex = 0;
            creqtitle.Value = string.Empty;
            reqDesc.InnerText = string.Empty;
            inlineRadio1.Checked = false;
            inlineRadio2.Checked = false;
            inlineRadio3.Checked = false;
            inlineRadio4.Checked = false;
            issuetitle.Value = string.Empty;
            ddlIssue.SelectedIndex = 0;
            issuedesc.InnerText = string.Empty;
            ddlDashboardName.SelectedIndex = 0;
            requesterchk.Checked = false;
            hdnCsomDelegateTo.Value = "";
        }

        /// <summary>
        /// Saving Issue/Bug request values to JIra
        /// </summary>
        protected void SavingIssueValues()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string jiraUrl = obj.JiraUrl;
                    string projectId = string.Empty; string issueId = string.Empty;
                    string emailNotification = string.Empty;
                    string fromRMS = "Yes";
                    if (jiraUrl.Contains("-qa"))
                    {
                        projectId = Constant.ProjectIdQA;
                        issueId = Constant.BugIssueIdQA;
                    }
                    else
                    {
                        projectId = Constant.ProjectId;
                        issueId = Constant.BugIssueId;
                    }
                    string issueType = hdnIssueRequestCat.Value;
                    string issueTitle = issuetitle.Value;
                    string dashBoardname = hdndashboardname.Value;
                    string issueDescription = "Dashboard Name:- " + dashBoardname + ":       Description:- " + issuedesc.InnerText;


                    string requesterInfo = string.Empty;
                    string requestorName = string.Empty;
                    string requestorEmail = string.Empty;
                    string requestorId = string.Empty;
                    string fnDomain = ddlfunctionalDomainReports.Value;


                    ///get requester name
                    if (requesterchk.Checked)
                    {
                        requesterInfo = hdnCsomDelegateTo.Value;
                        requesterInfo = requesterInfo.TrimStart(new char[] { '[' }).TrimEnd(new char[] { ']' });
                        requestorName = JObject.Parse(requesterInfo)["Name"].ToString();
                        requestorEmail = JObject.Parse(requesterInfo)["Email"].ToString();
                    }
                    else
                    {
                        requestorName = currentuser.InnerText;
                        requestorEmail = hdnUserMail.Value;
                    }

                    if (chkNotification.Checked)
                        emailNotification = "Yes";
                    else
                        emailNotification = "No";

                    JIRA jira = new JIRA();
                    jiraUrl = obj.JiraUrl;
                    jira.JiraUrl = jiraUrl;
                    jira.JiraUserName = obj.UserId;
                    jira.JiraPassword = obj.Password;

                    requestorId = obj.UserId; //devops // reporter name

                    string jsonStr = string.Empty;

                    if (jiraUrl.Contains("-qa"))
                    {
                        //  jsonStr = @"{""fields"": {""project"": { ""id"": """ + projectId + @"""}, ""summary"": """ + issueTitle + @""",""customfield_12800"": {""value"": """ + fnDomain + @"""},""customfield_10100"": """ + Constant.IssueEpicNameQA + @""",""description"": """ + issueDescription + @""",""customfield_10540"": {""value"": """ + issueType + @"""},""customfield_12700"": """ + requestorEmail + @""",""reporter"": {""name"": """ + requestorId + @"""},""customfield_11107"": {""value"": """ + fromRMS + @"""},""issuetype"": {""id"": """ + issueId + @"""}}}";
                        jsonStr = @"{""fields"": {""project"": { ""id"": """ + projectId + @"""}, ""summary"": """ + issueTitle + @""",""customfield_12800"": {""value"": """ + fnDomain + @"""},""description"": """ + issueDescription + @""",""customfield_10100"": """ + Constant.IssueEpicNameQA + @""",""customfield_10540"": {""value"": """ + issueType + @"""},""customfield_12700"": """ + requestorEmail + @""",""reporter"": {""name"": """ + requestorId + @"""},""customfield_11107"": {""value"": """ + fromRMS + @"""},""customfield_12605"": {""value"": """ + emailNotification + @"""},""issuetype"": {""id"": """ + issueId + @"""}}}";
                    }
                    else
                    {
                        jsonStr = @"{""fields"": {""project"": { ""id"": """ + projectId + @"""}, ""summary"": """ + issueTitle + @""",""customfield_11006"": {""value"": """ + fnDomain + @"""},""description"": """ + issueDescription + @""",""customfield_10100"": """ + Constant.IssueEpicName + @""",""customfield_10713"": {""value"": """ + issueType + @"""},""customfield_12208"": """ + requestorEmail + @""",""reporter"": {""name"": """ + requestorId + @"""},""customfield_10802"": {""value"": """ + fromRMS + @"""},""customfield_12207"": {""value"": """ + emailNotification + @"""},""issuetype"": {""id"": """ + issueId + @"""}}}";

                    }

                    jira.JiraJson = ToParseJSON(jsonStr);
                    string response = jira.addJiraIssue();
                    string key = Convert.ToString(JObject.Parse(response)["key"]);

                    if (!string.IsNullOrEmpty(key))
                    {
                        if (issuefileupload.HasFile)
                            AddAttachment(key, jira, issuefileupload);

                        lblimsg.Text = "Your Request submitted " + key + "  successfully.";
                    }
                    else
                        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert1", "alert('Something went wrong!!')", true);

                    // ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert2", "alert('Your Request submitted successfully')", true);

                    ClearFields();
                    hdntabNameHolder.Value = "Issuesaved";
                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "SavingIssueValues", "UMS.aspx");
                }
            }

        }

        #endregion

        # region Adding attachment

        /// <summary>
        /// Adding attachment to JIRA
        /// </summary>
        /// <param name="key"></param>
        /// <param name="jira"></param>
        public void AddAttachment(string key, JIRA jira, FileUpload fileupload)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    Constant obj = new Constant();
                    string jiraUrl = obj.JiraUrl;
                    string postUrl = jiraUrl + key + "/attachments";

                    System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();

                    client.DefaultRequestHeaders.Add("X-Atlassian-Token", "nocheck");
                    client.BaseAddress = new System.Uri(postUrl);
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", jira.GetEncodedCredentials());
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                    MultipartFormDataContent content = new MultipartFormDataContent();

                    // Constant.ErrorLog(clientContext, fileupload.FileBytes.ToString(), fileupload.FileName, "AddAttachment", "UMS.aspx");
                    //  HttpContent fileContent = new ByteArrayContent(System.IO.File.ReadAllBytes(fileupload.PostedFile.FileName));

                    HttpContent fileContent = new ByteArrayContent(fileupload.FileBytes);

                    string mimeType = System.Web.MimeMapping.GetMimeMapping(fileupload.PostedFile.FileName);
                    string filename = Path.GetFileName(fileupload.PostedFile.FileName);
                    fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse(mimeType);

                    content.Add(fileContent, "file", filename);
                    var result = client.PostAsync(postUrl, content);
                    try
                    {
                        result.Wait();
                        // result = result.Result;
                    }
                    catch (AggregateException e)
                    {
                        foreach (Exception ie in e.InnerExceptions)
                            Console.WriteLine("{0}: {1}", ie.GetType().Name,
                                              ie.Message);
                    }

                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "AddAttachment", "UMS.aspx");
                }
            }
        }

        #endregion

        #region  Loading data from Sharepoint lists on Page load

        public string ISCurrentUserAdmin()
        {
            string username = string.Empty;
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    Web web = clientContext.Web;
                    User user = web.CurrentUser;
                    clientContext.Load(web);
                    clientContext.ExecuteQuery();
                    clientContext.Load(user);
                    clientContext.ExecuteQuery();
                    username = user.Title;
                    hdnUserMail.Value = user.Email;
                    hdncurrentuser.Value = user.Title;

                    if (!string.IsNullOrEmpty(username))
                    {
                        List list = web.Lists.GetByTitle(Constant.RMS_UsersList);
                        var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='RMS_Admins' /><Value Type='User'>" + username + "</Value></Eq></Where></Query></View>" };
                        Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                        clientContext.Load(items);
                        clientContext.ExecuteQuery();

                        if (items != null && items.Count > 0)
                        {
                            hdnIsUserAdmin.Value = "true";
                            PrioritizationRequest.Visible = true;
                            prioritizationTab.Visible = true;
                        }
                        else
                        {
                            hdnIsUserAdmin.Value = "false";
                            PrioritizationRequest.Visible = false;
                            prioritizationTab.Visible = false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "ISCurrentUserAdmin", "UMS.aspx");
                }
                return username;
            }
        }

        public void GetJIRAUsers()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constant.RMS_UsersList);
                    var getPrdOwnerQry = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(getPrdOwnerQry);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();
                    GetUsers(items, Constant.ProductOwnerField, hdnOwners);
                    GetUsers(items, Constant.JIRAField, hdnJiraUsers);
                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "GetJIRAUsers", "UMS.aspx");
                }
            }
        }

        public void GetFunctionalDomain()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List list2 = clientContext.Web.Lists.GetByTitle(Constant.FunctionalDomainList);
                    var qryFunctiondm = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection functionsItems = list2.GetItems(qryFunctiondm);
                    clientContext.Load(functionsItems);
                    clientContext.ExecuteQuery();
                    LoadFunctionalLocation(functionsItems);
                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "GetFunctionalDomain", "UMS.aspx");
                }
            }
        }

        /// <summary>
        /// Load functional domain dropdown from list
        /// </summary>
        /// <param name="items"></param>
        public void LoadFunctionalLocation(Microsoft.SharePoint.Client.ListItemCollection items)
        {
            if (items != null && items.Count > 0)
            {
                string selectString = "--Select--:--Select--;";
                foreach (Microsoft.SharePoint.Client.ListItem item in items)
                {
                    if (Convert.ToString(item["Title"]) != null)
                    {
                        string itemName = Convert.ToString(item["Title"]);
                        selectString += itemName + ":" + itemName + ";";
                        ddlfunctionalDomain.Items.Add(new System.Web.UI.WebControls.ListItem(itemName, itemName));
                        ddlfunctionalDomainReports.Items.Add(new System.Web.UI.WebControls.ListItem(itemName, itemName));
                    }
                }
                selectString = selectString.Remove(selectString.Length - 1, 1);
                hdnFunctionalDomain.Value = selectString;
                ddlfunctionalDomain.Items.Insert(0, "--Select--");
                ddlfunctionalDomainReports.Items.Insert(0, "--Select--");
            }
        }

        public void GetAllDashoard()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constant.BIM_CatalogList);
                    var qrydashboardlist = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(qrydashboardlist);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null && items.Count > 0)
                    {
                        foreach (Microsoft.SharePoint.Client.ListItem item in items)
                        {
                            if (Convert.ToString(item["Name"]) != null)
                            {
                                string itemName = Convert.ToString(item["Name"]);
                                ddlDashboardName.Items.Add(new System.Web.UI.WebControls.ListItem(itemName, itemName));
                            }
                        }
                        ddlDashboardName.Items.Insert(0, "--Select--");
                    }

                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "GetAllDashoard", "UMS.aspx");
                }
            }

        }

        public void GetUsers(Microsoft.SharePoint.Client.ListItemCollection items, string fieldtype, HiddenField hdnField)
        {
            string users = string.Empty;
            if (fieldtype == Constant.JIRAField)
                users = "--Select--:--Select--;";

            if (items != null && items.Count > 0)
            {
                foreach (Microsoft.SharePoint.Client.ListItem item in items)
                {
                    // string value = Convert.ToString(item[fieldtype]);
                    if (!string.IsNullOrEmpty(Convert.ToString(item[fieldtype])))
                    {
                        FieldUserValue val = (FieldUserValue)item[fieldtype];
                        users += val.LookupValue + ":" + val.LookupValue + ";";
                    }
                }
                users = users.Remove(users.Length - 1, 1);
                hdnField.Value = users;
            }
        }

        #endregion

        #region Update values into JIRA from grid/ Inline editing

        [WebMethod]  // change to priortization
        public static void ChangeStatusOfRequests(string requestIds)
        {
            GridRow row = Newtonsoft.Json.JsonConvert.DeserializeObject<GridRow>(requestIds);

            if (row != null)
            {
                string Key = row.Key;
                string jsonStr = string.Empty;
                JIRA jira = new JIRA();
                Constant obj = new Constant();
                jira.JiraUserName = obj.UserId;
                jira.JiraPassword = obj.Password;
                string jiraUrl = obj.JiraUrl + Key;
                jira.JiraUrl = jiraUrl;

                string status = JIRAStatus(row.Status, jiraUrl);
                jsonStr = GetJSONQuery(row, jiraUrl);

                JObject jobj = JObject.Parse(jsonStr);
                string newJsonString = Convert.ToString(jobj);
                jira.JiraJson = newJsonString;

                try
                {
                    string response = jira.UpdateJiraIssue();
                }
                catch (Exception ex)
                {
                    UpdateStatus(status, jira, jiraUrl);
                }

                // string msg = "Requests are Prioritize successfully";
                // ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "", "alert('" + msg + "')", true);
            }
        }

        [WebMethod] // change to mail subscription
        public static void ChangeSusbcriptionOfRequests(string requestIds)
        {
            IList<SubscriptionObject> arrarylist = Newtonsoft.Json.JsonConvert.DeserializeObject<IList<SubscriptionObject>>(requestIds);

            string jsonStr = string.Empty;
            JIRA jira = new JIRA();
            Constant obj = new Constant();
            jira.JiraUserName = obj.UserId;
            jira.JiraPassword = obj.Password;

            if (arrarylist != null && arrarylist.Count > 1)
            {
                for (int i = 0; i < arrarylist.Count; i++)
                {
                    string id = arrarylist[i].id;
                    string subscription = arrarylist[i].isChecked;
                    string jiraUrl = obj.JiraUrl + arrarylist[i].id;
                    jira.JiraUrl = jiraUrl;

                    if (jiraUrl.Contains("-qa"))
                    {
                        jsonStr = @"{""fields"": {""customfield_12605"": {""value"": '" + subscription + "'}}}";
                    }
                    else
                    {
                        jsonStr = @"{""fields"": {""customfield_12207"": {""value"": '" + subscription + "'}}}";
                    }

                    JObject jobj = JObject.Parse(jsonStr);
                    string newJsonString = Convert.ToString(jobj);
                    jira.JiraJson = newJsonString;

                    try
                    {
                        string response = jira.UpdateJiraIssue();
                    }
                    catch (Exception ex)
                    {
                        // throw;
                        continue;
                    }
                }
            }
        }

        public static string GetJSONQuery(GridRow row, string jiraUrl)
        {
            string jsonStr = string.Empty;
            string productOwner = string.Empty;
            string assignTo = string.Empty;
            string Key = row.Key;
            string fnDomain = string.Empty;
            //if (row.ProductOwner == ("--Select--"))
            //    productOwner = "--Select--";
            //else
            productOwner = GetUserDetails(row.ProductOwner).sAMAccountName;

            if (Convert.ToString(row.Assignee) == ("--Select--"))
                assignTo = "--Select--";
            else
                assignTo = GetUserDetails(Convert.ToString(row.Assignee)).sAMAccountName;

            string priority = row.Priority;
            string effortEst = row.EffEstimation;
            string duedate = getFormateddate(row.Duedate);
            string rank = row.PRank;
            string status = row.Status;
            if (row.FunctionalDomain == ("--Select--"))
                fnDomain = "--Select--";
            else
                fnDomain = row.FunctionalDomain;

            if (jiraUrl.Contains("-qa")) // QA
            {
                if (status.Equals("Prioritized"))
                {
                    if (assignTo.Equals("--Select--"))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRankQA + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomainQA + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatusQA + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwnerQA + @""": {""name"": """ + productOwner + @"""}}}";
                    }
                    if (assignTo != "--Select--" && string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRankQA + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomainQA + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatusQA + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwnerQA + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                    if (assignTo != "--Select--" && !string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""duedate"": [{""set"": """ + duedate + @"""}],""" + Constant.PrioritizationRankQA + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomainQA + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatusQA + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwnerQA + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                }
                else
                {
                    if (assignTo.Equals("--Select--"))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRankQA + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomainQA + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwnerQA + @""": {""name"": """ + productOwner + @"""}}}";
                    }
                    if (assignTo != "--Select--" && string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRankQA + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomainQA + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwnerQA + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                    if (assignTo != "--Select--" && !string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""duedate"": [{""set"": """ + duedate + @"""}],""" + Constant.PrioritizationRankQA + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomainQA + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwnerQA + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                }
            }
            else //Production string
            {
                if (status.Equals("Prioritized"))
                {
                    if (assignTo.Equals("--Select--"))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatus + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""}}}";
                    }
                    if (assignTo != "--Select--" && string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatus + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                    if (assignTo != "--Select--" && !string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""duedate"": [{""set"": """ + duedate + @"""}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatus + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                }
                else
                {
                    if (assignTo.Equals("--Select--"))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""}}}";
                    }
                    if (assignTo != "--Select--" && string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                    if (assignTo != "--Select--" && !string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""duedate"": [{""set"": """ + duedate + @"""}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                }
            }

            return jsonStr;
        }

        public static void UpdateStatus(string statusId, JIRA jira, string issueUrl)
        {
            if (!string.IsNullOrEmpty(statusId))
            {
                string jStr = string.Empty;
                string url = jira.JiraUrl + "/transitions";
                jira.JiraUrl = url;

                if (issueUrl.Contains("-qa"))
                {
                    jStr = @"{""transition"": {""id"": """ + statusId + @"""}}";
                }
                else
                {
                    jStr = @"{""transition"": {""id"": """ + statusId + @"""}}";
                }
                JObject jobj = JObject.Parse(jStr);
                string newJsonString = Convert.ToString(jobj);
                jira.JiraJson = newJsonString;

                try
                {
                    string response = jira.addJiraIssue();
                }
                catch (Exception ex)
                {

                }
            }
        }

        public static string getFormateddate(string date)
        {
            string dateValue = string.Empty;
            if (!date.Equals("1/1/0001 12:00:00 AM") && !string.IsNullOrEmpty(date))
                dateValue = Convert.ToDateTime(date).ToString("yyyy-MM-dd");
            return dateValue;
        }

        #endregion

        #region Get all type of Requests from JIRA on page load

        [WebMethod]  //My Request
        public static List<GridRow> GetMyRequestData(string currentUser)
        {
            Constant obj = new Constant();
            JIRA jira = new JIRA();

            string jiraUrl = obj.JiraUrl;
            jira.JiraUserName = obj.UserId;
            jira.JiraPassword = obj.Password;

            string[] projects = GetProjects(jiraUrl);  // Get issues from listed projects in JIRA

            List<GridRow> rowList = new List<GridRow>();

            for (int j = 0; j < projects.Length; j++)
            {
                if (jiraUrl.Contains("-qa")) // for QA
                {
                    jira.JiraUrl = Constant.JiraUrlForSearchingQA + "jql='project' = '" + projects[j] + "' AND 'Requestor Email' ~ '" + currentUser + "' AND 'From RMS' =Yes&maxResults=1000&fields=customfield_12700,customfield_12605,summary,customfield_10100,customfield_10540,status,priority,assignee,created,updated,duedate&ORDER BY key DESC";

                }
                else // for Prod
                {
                    jira.JiraUrl = Constant.JiraForSearching + "jql='project' = '" + projects[j] + "' AND 'Requestor Email' ~ '" + currentUser + "' AND 'From RMS' =Yes&maxResults=1000&fields=customfield_12208,customfield_12207,summary,customfield_10100,customfield_10713,status,priority,assignee,created,updated,duedate&ORDER BY key DESC";

                }

                string response = jira.GetUsersRecordsFronJira();
                RootObject ro = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(response);
                GetRootObjectWithContent(ro, projects[j], jiraUrl, rowList);
            }
            rowList = rowList.OrderByDescending(o => o.ID).ToList();
            GetMyRequestTable(rowList);
            return rowList;
        }

        [WebMethod]  //All Request
        public static List<GridRow> GetAllProjectRequests()
        {
            List<GridRow> rowList = new List<GridRow>();

            Constant obj = new Constant();
            JIRA jira = new JIRA();
            jira.JiraUserName = obj.UserId;
            jira.JiraPassword = obj.Password;
            string jiraUrl = obj.JiraUrl;

            string[] projects = GetProjects(jiraUrl);  // Get issues from listed projects in JIRA               

            for (int j = 0; j < projects.Length; j++)
            {
                if (jiraUrl.Contains("-qa")) // for qa
                {
                    jira.JiraUrl = Constant.JiraUrlForSearchingQA + "jql='project' = '" + projects[j] + "' AND 'From RMS' ='Yes'&maxResults=1000&fields=customfield_12700,summary,customfield_10100,customfield_10540,customfield_12800,status,priority,assignee,created,duedate&ORDER BY key DESC";
                }
                else // for pord
                {
                    jira.JiraUrl = Constant.JiraForSearching + "jql='project' = '" + projects[j] + "' AND 'From RMS' ='Yes'&maxResults=1000&fields=customfield_12208,summary,customfield_10100,customfield_10713,customfield_11006,status,priority,assignee,created,duedate&ORDER BY key DESC";
                }

                string response = jira.GetUsersRecordsFronJira();
                RootObject ro = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(response);
                GetRootObjectWithContent(ro, projects[j], jiraUrl, rowList);
            }
            GetAllRequestTable(rowList);
            rowList = rowList.OrderByDescending(o => o.ID).ToList();

            return rowList;
        }

        [WebMethod]  //New Request to priortised 
        public static List<GridRow> GetNewRequestsToPrioritize()
        {
            Constant obj = new Constant();
            JIRA jira = new JIRA();
            string jiraUrl = obj.JiraUrl;
            jira.JiraUserName = obj.UserId;
            jira.JiraPassword = obj.Password;
            string[] projects = GetProjects(jiraUrl);  // Get issues from listed projects in JIRA

            List<GridRow> rowList = new List<GridRow>();

            for (int j = 0; j < projects.Length; j++)
            {
                if (jiraUrl.Contains("-qa")) // for qa
                {
                    jira.JiraUrl = Constant.JiraUrlForSearchingQA + "jql='project' = '" + projects[j] + "' AND 'From RMS' ='Yes' AND 'status'='New' AND 'Epic Link' = 'BIM Request' AND 'Prioritization Status' is EMPTY &maxResults=1000&fields=customfield_12700,summary,customfield_10100,customfield_12605,customfield_10540,Original Estimate,status,priority,assignee,created,duedate,updated,timetracking,customfield_12801,customfield_12704,customfield_12800&ORDER BY key DESC";
                }
                else // for pord
                {
                    jira.JiraUrl = Constant.JiraForSearching + "jql='project' = '" + projects[j] + "' AND 'From RMS' ='Yes' AND 'status'='New' AND 'Epic Link' = 'BIM Request' AND 'issuetype' = 'User Story' AND 'Prioritization Status' is EMPTY&maxResults=1000&fields=customfield_12208,summary,customfield_10100,customfield_12207,customfield_10713,Original Estimate,status,priority,assignee,created,duedate,updated,timetracking,customfield_11111,customfield_11202,customfield_11006&ORDER BY key DESC";
                }
                string response = jira.GetUsersRecordsFronJira();
                RootObject ro = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(response);
                GetRootObjectWithContent(ro, projects[j], jiraUrl, rowList);
            }
            rowList = rowList.OrderByDescending(o => o.ID).ToList();
            GetPriorityRequestTable(rowList);
            return rowList;
        }



        //[WebMethod]
        //public static List<GridRow> GetFuntionalDomain()
        //{
        //    Constant obj = new Constant();
        //    JIRA jira = new JIRA();
        //    jira.JiraUserName = obj.UserId;
        //    jira.JiraPassword = obj.Password;
        //    string jiraUrl = obj.JiraUrl;     
        //    string[] projects = { Constant.BIMDBProject };
        //    List<GridRow> rowList = new List<GridRow>();

        //    for (int j = 0; j < projects.Length; j++)
        //    {
        //        if (jiraUrl.Contains("-qa")) // for qa
        //        {
        //            jira.JiraUrl = Constant.JiraForCreatemetaQA + "projectIds=" + Constant.ProjectIdQA + "&issuetypeIds=" + Constant.BimIssueIdQA + "&expand=projects.issuetypes.fields";
        //        }
        //        else // for pord
        //        {
        //            jira.JiraUrl = Constant.JiraForCreatemeta + "jql='project' = '" + projects[j] + "' AND 'From RMS' ='Yes'&maxResults=1000&fields=customfield_10503,summary,customfield_10100,customfield_10713,status,priority,assignee,created,duedate&ORDER BY created DESC";
        //        }

        //        string response = jira.GetUsersRecordsFronJira();
        //        JObject jobj = JObject.Parse(response);
        //       // string key = "customfield_12800";
        //      // JArray val1 = (JArray)jobj["projects"][0]["issuetypes"][0]["fields"]["customfield_12800"]["allowedValues"];



        //        Root ro = Newtonsoft.Json.JsonConvert.DeserializeObject<Root>(response);
        //       // Root ro = JsonConvert.DeserializeObject<Root>(response); 
        //        GetFunctionalDomain(ro,jiraUrl);
        //    }
        //    return rowList;
        //}

        // common funtion for getting all request type 
        //[WebMethod]  
        //public static List<GridRow> GetRequestsfromJIRA(string currentUser, string newRequest)
        //{

        //    Constant obj = new Constant();
        //    string jiraUrl = obj.JiraUrl;
        //    RootObject ro = null;

        //    string[] projects = {Constant.BIMAAProject, Constant.COOProject, Constant.SP3Project };

        //    List<GridRow> rowList = new List<GridRow>();

        //    for (int j = 0; j < projects.Length; j++)
        //    {
        //        //if (string.IsNullOrEmpty(currentUser) && string.IsNullOrEmpty(newRequest))  // for fetch all JIRA request
        //        //    ro = GetAllProjectRequests(projects[j]);

        //        //if (!string.IsNullOrEmpty(currentUser) && string.IsNullOrEmpty(newRequest)) // for fetch all JIRA  My request
        //        //    ro = GetMyRequestData(projects[j], currentUser);

        //        //if (string.IsNullOrEmpty(currentUser) && !string.IsNullOrEmpty(newRequest)) // for fetch all JIRA New request
        //        //    ro = GetNewRequestsToPrioritize(projects[j]);

        //        string projectName = projects[j];

        //        for (int i = 0; i < ro.issues.Count; i++)
        //        {
        //            GridRow newRow = new GridRow();
        //            if (jiraUrl.Contains("-qa"))
        //            {
        //                if (ro.issues[i].fields.customfield_10540 != null)
        //                    newRow.Category = ro.issues[i].fields.customfield_10540.value;

        //                if (ro.issues[i].fields.customfield_10504 != null)
        //                    newRow.RequestorName = Convert.ToString(ro.issues[i].fields.customfield_12700).Split('@')[0];
        //                // newRow.RequestorName = Convert.ToString(ro.issues[i].fields.customfield_10504[0].Split('@')[0]);


        //                if (ro.issues[i].fields.customfield_12605 != null)
        //                    newRow.Subscribe = ro.issues[i].fields.customfield_12605.value;

        //            }
        //            else
        //            {
        //                if (ro.issues[i].fields.customfield_10713 != null)
        //                    newRow.Category = Convert.ToString(ro.issues[i].fields.customfield_10713.value);

        //                if (ro.issues[i].fields.customfield_10503 != null)
        //                    newRow.RequestorName = Convert.ToString(ro.issues[i].fields.customfield_10503[0].Split('@')[0]);
        //            }


        //            newRow.Key = ro.issues[i].key;
        //            newRow.Summary = ro.issues[i].fields.summary;

        //            newRow.ProjectName = projects[j];
        //            newRow.Status = GetStatus(ro.issues[i].fields.status.name);
        //            newRow.Priority = ro.issues[i].fields.priority.name;

        //            string epicName = Convert.ToString(ro.issues[i].fields.customfield_10100);
        //            newRow.ProjectArea = GetEpicName(epicName);

        //            if (ro.issues[i].fields.assignee != null)
        //            {
        //                newRow.Assignee = ro.issues[i].fields.assignee.displayName;
        //                newRow.AssigneeEmail = ro.issues[i].fields.assignee.emailAddress;
        //            }
        //            if (ro.issues[i].fields.TimeTracking != null) //Effort Est.
        //            {
        //                newRow.EffEstimation = ro.issues[i].fields.TimeTracking.originalEstimate;
        //            }
        //            if (ro.issues[i].fields.customfield_10524 != null)  //Est.Start Date
        //            {
        //                newRow.EstStartDate = Convert.ToDateTime(ro.issues[i].fields.customfield_10524).ToString("MM/dd/yyyy");
        //            }
        //            if (!string.IsNullOrEmpty(ro.issues[i].fields.duedate)) //actual end date
        //                newRow.Duedate = Convert.ToDateTime(ro.issues[i].fields.duedate).ToString("MM/dd/yyyy");

        //            if (ro.issues[i].fields.customfield_10502 != null)  //priortization rank
        //            {
        //                newRow.PrRank = ro.issues[i].fields.customfield_10502;
        //                foreach (string str in newRow.PrRank)                        
        //                    newRow.PRank += str + ',';                        

        //                if (!string.IsNullOrEmpty(newRow.PRank.ToString()))
        //                    newRow.PRank = newRow.PRank.ToString().Remove(newRow.PRank.ToString().Length - 1, 1);
        //            }
        //            if (ro.issues[i].fields.updated != null)  // last modify
        //            {
        //                newRow.LastModify = ro.issues[i].fields.updated.Date.ToString("MM/dd/yyyy");
        //            }
        //            if (ro.issues[i].fields.customfield_12701 != null)  //planned end date
        //            {
        //                newRow.EstEndDate = Convert.ToDateTime(ro.issues[i].fields.customfield_12701).ToString("MM/dd/yyyy");
        //            }
        //            if (ro.issues[i].fields.customfield_12702!= null)  //UAT date
        //            {
        //                newRow.UATDate = Convert.ToDateTime(ro.issues[i].fields.customfield_12702).ToString("MM/dd/yyyy");
        //            }
        //           // if (ro.issues[i].fields.customfield_12702 != null)  //Product owner
        //            {
        //                newRow.ProductOwner = "";
        //            }

        //            newRow.Created = ro.issues[i].fields.created.Date.ToString("MM/dd/yyyy");
        //           // 



        //            rowList.Add(newRow);
        //        }
        //    }
        //    return rowList;
        //}

        // function for getting on behalf user people picker

        [WebMethod]
        public static string GetPeoplePickerData()
        {
            return PeoplePickerHelper.GetPeoplePickerSearchData();
        }

        //public static void GetFunctionalDomain(Root ro, string jiraUrl)
        //{           
        //    List<string> obj = new List<string>();
        //    if (ro != null)
        //    {
        //     //   for (int i = 0; i < ro.issues.Count; i++)
        //     //   {                   
        //            if (jiraUrl.Contains("-qa"))
        //            {
        //                if (ro.Projects[0].Issuetypes[0].Fields.customfield_12800 != null)
        //                {
        //                    List<AllowedValue> values = ro.Projects[0].Issuetypes[0].Fields.customfield_12800.AllowedValues;

        //                }
        //            }
        //            else
        //            {

        //            }
        //      //  }
        //    }           
        //}

        /// <summary>
        /// Function calling creating grid data
        /// </summary>
        /// <param name="ro"></param>
        /// <param name="projectName"></param>
        /// <param name="jiraUrl"></param>
        /// <param name="rowList"></param>
        /// <returns></returns>
        public static GridRow GetRootObjectWithContent(RootObject ro, string projectName, string jiraUrl, List<GridRow> rowList)
        {
            GridRow newRow = null;
            if (ro.issues != null)
            {
                for (int i = 0; i < ro.issues.Count; i++)
                {
                    newRow = new GridRow();
                    if (jiraUrl.Contains("-qa"))
                    {
                        if (ro.issues[i].fields.customfield_10540 != null)
                            newRow.Category = ro.issues[i].fields.customfield_10540.value; //category

                        if (ro.issues[i].fields.customfield_12700 != null)
                            newRow.Requestor = Convert.ToString(ro.issues[i].fields.customfield_12700).Split('@')[0]; // requestor mail

                        if (ro.issues[i].fields.customfield_12605 != null)
                            newRow.Subscribe = ro.issues[i].fields.customfield_12605.value;   //issue subscribe

                        if (ro.issues[i].fields.customfield_12800 != null)
                            newRow.FunctionalDomain = ro.issues[i].fields.customfield_12800.value;  // fn domain

                        if (ro.issues[i].fields.customfield_12704 != null)  //Product owner
                            newRow.ProductOwner = ro.issues[i].fields.customfield_12704.displayName;

                        if (ro.issues[i].fields.customfield_12801 != null)  //priortization rank
                            newRow.PRank = ro.issues[i].fields.customfield_12801.value;

                    }
                    else
                    {
                        if (ro.issues[i].fields.customfield_10713 != null)
                            newRow.Category = Convert.ToString(ro.issues[i].fields.customfield_10713.value);  // category

                        if (ro.issues[i].fields.customfield_12208 != null)
                            newRow.Requestor = Convert.ToString(ro.issues[i].fields.customfield_12208).Split('@')[0]; // requestor mail

                        if (ro.issues[i].fields.customfield_12207 != null)
                            newRow.Subscribe = ro.issues[i].fields.customfield_12207.value;   //issue subscribe

                        if (ro.issues[i].fields.customfield_11006 != null)
                            newRow.FunctionalDomain = ro.issues[i].fields.customfield_11006.value;  // fn domain

                        if (ro.issues[i].fields.customfield_11202 != null)  //Product owner
                            newRow.ProductOwner = ro.issues[i].fields.customfield_11202.displayName;

                        if (ro.issues[i].fields.customfield_11111 != null)  //priortization rank
                            newRow.PRank = ro.issues[i].fields.customfield_11111.value;
                    }

                    newRow.Key = ro.issues[i].key;
                    newRow.Summary = ro.issues[i].fields.summary;

                    newRow.ProjectName = projectName;
                    newRow.Status = GetStatus(ro.issues[i].fields.status.name);
                    newRow.Priority = ro.issues[i].fields.priority.name;
                    newRow.ID = Convert.ToInt32(ro.issues[i].key.Split('-')[1].ToString());

                    string epicName = Convert.ToString(ro.issues[i].fields.customfield_10100);
                    newRow.ProjectArea = GetEpicName(epicName);

                    if (ro.issues[i].fields.assignee != null)
                    {
                        newRow.Assignee = ro.issues[i].fields.assignee.displayName;
                        newRow.AssigneeEmail = ro.issues[i].fields.assignee.emailAddress;
                    }
                    if (ro.issues[i].fields.TimeTracking != null) //Effort Est.
                        newRow.EffEstimation = ro.issues[i].fields.TimeTracking.originalEstimate;

                    if (!string.IsNullOrEmpty(ro.issues[i].fields.duedate)) //actual end date
                        newRow.Duedate = getFormateddate(ro.issues[i].fields.duedate);

                    if (ro.issues[i].fields.updated != null)  // last modify                    
                        newRow.LastModify = getFormateddate(ro.issues[i].fields.updated.Date.ToString());

                    newRow.Created = getFormateddate(ro.issues[i].fields.created.Date.ToString());

                    rowList.Add(newRow);
                }
            }
            return newRow;
        }

        // get multiple status
        public static string GetStatus(string status)
        {
            switch (status)
            {
                case Constant.ToDo:
                    status = Constant.Development;
                    break;
                case Constant.InDevelopment:
                    status = Constant.Development;
                    break;
                case Constant.DeploymentReady:
                    status = Constant.Resolved;
                    break;
                case Constant.UnitTesting:
                    status = Constant.Development;
                    break;
                case Constant.Testing:
                    status = Constant.Development;
                    break;
                case Constant.UAT:
                    status = Constant.UAT;
                    break;
                case Constant.QAReady:
                    status = Constant.Development;
                    break;
                case Constant.QA:
                    status = Constant.Development;
                    break;
                case Constant.Deployed:
                    status = Constant.Closed;
                    break;
                case Constant.Done:
                    status = Constant.Closed;
                    break;
            }

            return status;

        }

        /// <summary>
        /// Get all projects from JIRA
        /// </summary>
        /// <param name="jiraUrl"></param>
        /// <returns></returns>
        public static string[] GetProjects(string jiraUrl)
        {
            string[] projects = { };
            if (jiraUrl.Contains("-qa")) // for QA
            {
                string[] projectsQA = { Constant.BIMDBProject, Constant.BIMAAProject, Constant.COOProject, Constant.SP3Project };
                projects = projectsQA;
            }
            else
            {
                string[] projectsprd = { Constant.BIMDBProject, Constant.BIMAAProject, Constant.COOProject, Constant.SP3Project, Constant.BIMDMProject, Constant.BIMDAProject, Constant.PLProject, Constant.BIMSIProject, Constant.SSCMProject };
                projects = projectsprd;
            }
            return projects;
        }

        #endregion

        #region Esclation and Email subscription change block

        protected void btnEsclate_Click(object sender, EventArgs e)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string subsRequest = hdnSubsIds.Value;
                    string expRequest = hdnExpIds.Value;

                    ChangeEmailSubscriptionOfRequests(subsRequest);
                    EsclateforRequests(expRequest);
                    string msg = "Requests are submitted successfully";
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "", "alert('" + msg + "')", true);
                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "btnEsclate_Click", "UMS.aspx");
                }
            }

        }

        /// <summary>
        /// Change Email subsription checkbox
        /// </summary>
        /// <param name="requestIds"></param>
        public void ChangeEmailSubscriptionOfRequests(string requestIds)
        {
            IList<SubscriptionObject> arrarylist = Newtonsoft.Json.JsonConvert.DeserializeObject<IList<SubscriptionObject>>(requestIds);

            string jsonStr = string.Empty;
            JIRA jira = new JIRA();
            Constant obj = new Constant();
            jira.JiraUserName = obj.UserId;
            jira.JiraPassword = obj.Password;

            if (arrarylist != null && arrarylist.Count > 0)
            {
                for (int i = 0; i < arrarylist.Count; i++)
                {
                    string id = arrarylist[i].id;
                    string subscription = arrarylist[i].isChecked;
                    string jiraUrl = obj.JiraUrl + arrarylist[i].id;
                    jira.JiraUrl = jiraUrl;

                    if (jiraUrl.Contains("-qa"))
                    {
                        jsonStr = @"{""fields"": {""customfield_12605"": {""value"": '" + subscription + "'}}}";
                    }
                    else
                    {
                        jsonStr = @"{""fields"": {""customfield_12207"": {""value"": '" + subscription + "'}}}";
                    }

                    JObject jobj = JObject.Parse(jsonStr);
                    string newJsonString = Convert.ToString(jobj);
                    jira.JiraJson = newJsonString;

                    try
                    {
                        string response = jira.UpdateJiraIssue();
                        // string key = Convert.ToString(JObject.Parse(response));
                    }
                    catch (Exception ex)
                    {
                        // throw;
                        continue;
                    }
                }
            }
        }

        protected static ADMethods.ADAttributes GetUserDetails(string userName)
        {
            ADMethods.ADAttributes ADResult = null;
            bool isUserExists = false;
            ADMethods AD = new ADMethods();

            isUserExists = AD.IsUserExist(userName, ADMethods.AdPrpoertyParameters.displayName);
            if (isUserExists)
                ADResult = AD.GetEmployeeAttributes(userName, ADMethods.AdPrpoertyParameters.displayName);

            return ADResult;
        }

        #endregion

        #region Esclation Email block

        /// <summary>
        /// Email for esclation
        /// </summary>
        /// <param name="requestIds"></param>
        public void EsclateforRequests(string requestIds)
        {
            string jiraUrl = obj.JiraUrl;
            string url = string.Empty;
            string htmlContent = string.Empty;
            string issueLink = string.Empty;
            IList<EsclateObject> arrarylist = Newtonsoft.Json.JsonConvert.DeserializeObject<IList<EsclateObject>>(requestIds);

            if (arrarylist != null && arrarylist.Count > 0)
            {
                htmlContent = "<table style='font-family: Helvetica, sans-serif;border-collapse: collapse;width: 80%;'>";
                htmlContent += "<tr style='line-height: 13px;font-size: 12px;'>";
                htmlContent += "<th style='padding-top: 9px;padding-bottom:9px;text-align:left;background-color: #a4a4a4;color: white;'>Key</th>";
                htmlContent += "<th style='padding-top: 9px;padding-bottom:9px;text-align:left;background-color: #a4a4a4;color: white;'>Title</th>";
                htmlContent += "<th style='padding-top: 9px;padding-bottom:9px;text-align:left;background-color: #a4a4a4;color: white;'>Status</th>";
                htmlContent += "<th style='padding-top: 9px;padding-bottom:9px;text-align:left;background-color: #a4a4a4;color: white;'>Requestor</th>";
                htmlContent += "<th style='padding-top: 9px;padding-bottom:9px;text-align:left;background-color: #a4a4a4;color: white;'>Created On</th>";
                htmlContent += "<th style='padding-top: 9px;padding-bottom:9px;text-align:left;background-color: #a4a4a4;color: white;'>Last Updated</th>";
                htmlContent += "</tr>";

                for (int i = 0; i < arrarylist.Count; i++)
                {
                    if (jiraUrl.Contains("-qa"))
                    {
                        url = Constant.JiraShortUrlShortQA + "/browse/" + arrarylist[i].id;
                        issueLink = "<a href=" + url + " target=_blank>" + arrarylist[i].id + "</a>";
                    }
                    else
                    {
                        url = Constant.JiraShortUrlShort + "/browse/" + arrarylist[i].id;
                        issueLink = "<a href=" + url + " target=_blank>" + arrarylist[i].id + "</a>";
                    }

                    htmlContent += "<tr style='line-height: 12px;font-size: 12px;'>";
                    htmlContent += "<td style='border: 1px solid #ddd;padding: 8px;'>" + issueLink + "</td>";
                    htmlContent += "<td style='border: 1px solid #ddd;padding: 8px;'>" + arrarylist[i].Title + "</td>";
                    htmlContent += "<td style='border: 1px solid #ddd;padding: 8px;'>" + arrarylist[i].Status + "</td>";
                    htmlContent += "<td style='border: 1px solid #ddd;padding: 8px;'>" + hdncurrentuser.Value + "</td>";
                    htmlContent += "<td style='border: 1px solid #ddd;padding: 8px;'>" + arrarylist[i].CreatedOn + "</td>";
                    htmlContent += "<td style='border: 1px solid #ddd;padding: 8px;'>" + arrarylist[i].LastModify + "</td>";
                    htmlContent += "</tr>";
                }
                htmlContent += "</table>";
                SendMail(htmlContent, hdncurrentuser.Value);
            }
        }
        public void SendMail(string emailBody, string requestorName)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string toUsersEmail = string.Empty; string subject = string.Empty; string body = string.Empty; string linkUrl = string.Empty;
                    //string bccUsers = string.Empty;
                    List list = clientContext.Web.Lists.GetByTitle(Constant.RMSEmailTemplate);
                    CamlQuery query = CamlQuery.CreateAllItemsQuery();

                    Web webCtx = clientContext.Web;
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                    clientContext.Load(clientContext.Web, web => web.Url);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null && items.Count > 0)
                    {
                        foreach (Microsoft.SharePoint.Client.ListItem item in items)
                        {
                            subject = Convert.ToString(item["Title"]);
                            body = Convert.ToString(item["EmailBody"]);


                            FieldUserValue[] userValues = (FieldUserValue[])item["EmailTo"];

                            foreach (FieldUserValue value in userValues)
                                toUsersEmail += value.LookupValue + ";";
                        }

                        if (clientContext.Web.Url.Contains("qa"))
                            linkUrl = clientContext.Web.Url + "/Pages/UMS.aspx";
                        else
                            linkUrl = clientContext.Web.Url + "/Pages/RMS.aspx";

                        string requestUrl = "<a href = '" + linkUrl + "'> Link </a>";


                        body = body.Replace("<<RequestorName>>", requestorName);
                        body = body.Replace("<<space>>", "</br>");
                        body = body.Replace("<<Requests>>", emailBody);

                        bool sendMail = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["SendMail"]);
                        if (clientContext != null && sendMail)
                        {
                            var emailp = new EmailProperties();
                            emailp.To = new List<string> { toUsersEmail };
                            emailp.CC = new List<string> { hdnUserMail.Value };
                            emailp.From = Constant.BIM_SupportFormUserMail;
                            emailp.Body = body;
                            emailp.Subject = subject;
                            Utility.SendEmail(clientContext, emailp);
                            clientContext.ExecuteQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "Send Mail", "UMS.aspx");
                }
            }

        }

        #endregion

        #region common function

        public static string ToJSON(object obj)
        {
            // JavaScriptSerializer serializer = new JavaScriptSerializer();
            string serializer = Newtonsoft.Json.JsonConvert.SerializeObject(obj);
            return serializer;
            //  return serializer.Serialize(obj);
        }

        public string GetBusineValues(string businessValues)
        {
            switch (businessValues)
            {
                case "Revenue Growth":
                    businessValues = "Very High (2+ months)";
                    break;
                case "Cost Saving":
                    businessValues = "High (1-2 months)";
                    break;
                case "Productivity Gain":
                    businessValues = "Medium (2-4 weeks)";
                    break;
                case "Others":
                    businessValues = "Low (0-2 weeks)";
                    break;
            }
            return businessValues;
        }

        /// <summary>
        /// Get email for user for saving in Jira
        /// </summary>
        public void GetCurrentUserEmail()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                User spUser = null;
                spUser = clientContext.Web.CurrentUser;
                clientContext.Load(spUser);
                clientContext.ExecuteQuery();
                hdncurrentuser.Value = spUser.Title;
                currentuser.InnerText = spUser.Title;
                hdnUserMail.Value = spUser.Email;

            }
        }

        /// <summary>
        /// replacing Epic values with BIM-Request, Issues 
        /// </summary>
        /// <param name="Values"></param>
        /// <returns></returns>
        public static string GetEpicName(string Values)
        {
            if (!string.IsNullOrEmpty(Values))
            {
                if (Values.Equals(Constant.BIMEpicName) || Values.Equals(Constant.BIMEpicNameQA))
                {
                    Values = Constant.BIMEpicString;
                }
                if (Values.Equals(Constant.IssueEpicName) || Values.Equals(Constant.IssueEpicNameQA))
                {
                    Values = Constant.IssueEpicString;
                }

                if (Values.Equals(Constant.COOEpicName) || Values.Equals(Constant.SP3EpicName) || Values.Equals(Constant.BIMAAEpicName))
                {
                    Values = Constant.IssueEpicString;
                }

            }
            return Values;
        }

        public string DecodeUrlString(string url)
        {
            string newUrl;
            while ((newUrl = Uri.UnescapeDataString(url)) != url)
                url = newUrl;
            return newUrl;
        }

        public string RemoveCharacter(string value)
        {
            value = value.Replace('"', '\'');
            return value;
        }

        public string ToParseJSON(string jsonString)
        {
            JObject obj = JObject.Parse(jsonString);
            string newJsonString = Convert.ToString(obj);
            return newJsonString;
        }

        public ClientContext GetContext(string siteURL)
        {

            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

            string UserName = "SPO365_ORM@amat.com";
            string Password = "AugApplied@2020";

            ClientContext clientContext = new ClientContext(siteURL);
            var securePassword = new SecureString();
            foreach (char c in Password)
                securePassword.AppendChar(c);
            securePassword.MakeReadOnly();

            using (clientContext = new ClientContext(siteURL))
            {
                clientContext.Credentials = new SharePointOnlineCredentials(UserName, securePassword);
            }
            return clientContext;
        }

        /// <summary>
        /// ger jira status
        /// </summary>
        /// <param name="trasition"></param>
        /// <param name="envURL"></param>
        /// <returns></returns>
        public static string JIRAStatus(string trasition, string envURL)
        {
            string trasitionId = string.Empty;
            if (envURL.Contains("-qa"))
            {
                switch (trasition)
                {
                    case "On hold":
                        trasitionId = "261";
                        break;
                    case "Rejected":
                        trasitionId = "271";
                        break;
                    case "Prioritized":
                        trasitionId = "211";
                        break;
                }
            }
            else
            {
                switch (trasition)
                {
                    case "On hold":
                        trasitionId = "221";
                        break;
                    case "Rejected":
                        trasitionId = "231";
                        break;
                    case "Prioritized":
                        trasitionId = "281";
                        break;
                }
            }

            return trasitionId;
        }

        #endregion

        #region Download Excel function

        protected void lnkmyrequestExport_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)Session["MyRequests"];
            if (dt != null && dt.Rows.Count > 0)
            {

                ExportToExcel(dt, "MyJiraRequest_Excel");
            }
        }
        protected void lnkPriorityExport_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)Session["PriorityRequests"];
            if (dt != null && dt.Rows.Count > 0)
            {
                ExportToExcel(dt, "PriortyRequest_Excel");
            }
        }
        protected void lnkAllRequest_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)Session["AllRequests"];
            if (dt != null && dt.Rows.Count > 0)
            {
                ExportToExcel(dt, "AllJiraRequest_Excel");
            }
        }

        public static void GetPriorityRequestTable(List<GridRow> list)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Key");
            dt.Columns.Add("Requestor");
            dt.Columns.Add("Summary");
            dt.Columns.Add("Category");
            dt.Columns.Add("Business function");
            dt.Columns.Add("Status");
            dt.Columns.Add("Priorty");
            dt.Columns.Add("Rank");
            dt.Columns.Add("Product owner");
            dt.Columns.Add("Est.Effort");
            dt.Columns.Add("Assign To");
            dt.Columns.Add("Due Date");
            dt.Columns.Add("Created on");

            for (int i = 0; i < list.Count; i++)
            {
                DataRow row = dt.NewRow();
                row["Key"] = Convert.ToString(list[i].Key);
                row["Requestor"] = Convert.ToString(list[i].ProjectName);
                row["Summary"] = Convert.ToString(list[i].Summary);
                row["Category"] = Convert.ToString(list[i].Category);
                row["Business function"] = Convert.ToString(list[i].Category);
                row["Status"] = Convert.ToString(list[i].Status);
                row["Priorty"] = Convert.ToString(list[i].Priority);
                row["Rank"] = Convert.ToString(list[i].Priority);
                row["Product owner"] = Convert.ToString(list[i].Priority);
                row["Est.Effort"] = Convert.ToString(list[i].Priority);
                row["Assign To"] = Convert.ToString(list[i].Assignee);
                row["Due Date"] = Convert.ToString(list[i].Duedate);
                row["Created on"] = Convert.ToString(list[i].Created);
                dt.Rows.Add(row);
            }
            HttpContext.Current.Session["PriorityRequests"] = dt;
        }

        public static void GetMyRequestTable(List<GridRow> list)
        {
            //DataTable dt = (DataTable)HttpContext.Current.Session["My_AllRequests"];
            //if (dt != null && dt.Rows.Count > 0)
            //    return;

            DataTable dt = new DataTable();
            dt.Columns.Add("Key");
            dt.Columns.Add("Project Name");
            dt.Columns.Add("Summary");
            dt.Columns.Add("Category");
            dt.Columns.Add("Status");
            dt.Columns.Add("Priorty");
            dt.Columns.Add("Assignee");
            dt.Columns.Add("Due Date");
            dt.Columns.Add("Created on");
            dt.Columns.Add("Subscribe");

            for (int i = 0; i < list.Count; i++)
            {
                DataRow row = dt.NewRow();
                row["Key"] = Convert.ToString(list[i].Key);
                row["Project Name"] = Convert.ToString(list[i].ProjectName);
                row["Summary"] = Convert.ToString(list[i].Summary);
                row["Category"] = Convert.ToString(list[i].Category);
                row["Status"] = Convert.ToString(list[i].Status);
                row["Priorty"] = Convert.ToString(list[i].Priority);
                row["Assignee"] = Convert.ToString(list[i].Assignee);
                row["Due Date"] = Convert.ToString(list[i].Duedate);
                row["Created on"] = Convert.ToString(list[i].Created);
                row["Subscribe"] = Convert.ToString(list[i].Subscribe);
                dt.Rows.Add(row);
            }
            HttpContext.Current.Session["MyRequests"] = dt;
        }

        public static void GetAllRequestTable(List<GridRow> list)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Key");
            dt.Columns.Add("Requestor");
            dt.Columns.Add("Project Name");
            dt.Columns.Add("Summary");
            dt.Columns.Add("Category");
            dt.Columns.Add("Status");
            dt.Columns.Add("Priorty");
            dt.Columns.Add("Assignee");
            dt.Columns.Add("Due Date");
            dt.Columns.Add("Created on");

            for (int i = 0; i < list.Count; i++)
            {
                DataRow row = dt.NewRow();
                row["Key"] = Convert.ToString(list[i].Key);
                row["Requestor"] = Convert.ToString(list[i].Requestor);
                row["Project Name"] = Convert.ToString(list[i].ProjectName);
                row["Summary"] = Convert.ToString(list[i].Summary);
                row["Category"] = Convert.ToString(list[i].Category);
                row["Status"] = Convert.ToString(list[i].Status);
                row["Priorty"] = Convert.ToString(list[i].Priority);
                row["Assignee"] = Convert.ToString(list[i].Assignee);
                row["Due Date"] = Convert.ToString(list[i].Duedate);
                row["Created on"] = Convert.ToString(list[i].Created);
                dt.Rows.Add(row);
            }
            HttpContext.Current.Session["AllRequests"] = dt;
        }

        public void ExportToExcel(DataTable dt, string excelName)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                ExcelWriter ew = new ExcelWriter();
                MemoryStream ms = ew.ExportDataTable(dt);
                //Convert the memorystream to an array of bytes.
                byte[] byteArray = ms.ToArray();
                //Clean up the memory stream
                ms.Flush();
                ms.Close();
                // Clear all content output from the buffer stream
                Response.ClearContent();
                Response.ClearHeaders();
                Response.AddHeader("Content-Disposition", "attachment; filename=" + excelName + ".xlsx");
                Response.AddHeader("Content-Length", Convert.ToString(byteArray.Length));
                // Set the HTTP MIME type of the output stream
                Response.ContentType = "Application/octet-stream";
                // Write the data out to the client.
                Response.BinaryWrite(byteArray);
                Response.Flush();
            }
        }

        #endregion

        //public void Getowner()
        //{
        //    var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
        //    using (var clientContext = spContext.CreateUserClientContextForSPHost())
        //    {
        //        string listname = "RMS_Users";
        //        List list = clientContext.Web.Lists.GetByTitle(listname);
        //        var query = CamlQuery.CreateAllItemsQuery();
        //        Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
        //        clientContext.Load(items);
        //        clientContext.ExecuteQuery();
        //        foreach(Microsoft.SharePoint.Client.ListItem item in items)
        //        {
        //            FieldUserValue val  = (FieldUserValue)item["Owner"];
        //            ADMethods.ADAttributes value = GetUserDetails(val.LookupValue);
        //            hdnOwners.Value += value.sAMAccountName + ":" + val.LookupValue + ";";
        //        }

        //    }
        //}            


        [WebMethod]
        public static List<GridRow> GetNestedtDatabyKey(string key)
        {
            Constant obj = new Constant();
            JIRA jira = new JIRA();

            string jiraUrl = obj.JiraUrl;
            jira.JiraUserName = obj.UserId;
            jira.JiraPassword = obj.Password;

            string[] projects = {"BIMDB"};  // Get issues from listed projects in JIRA

            List<GridRow> rowList = new List<GridRow>();

            if (jiraUrl.Contains("qa")) // for QA
            {
                jira.JiraUrl = "https://dtr-qa.amat.com/rest/api/2/issue/" + key;

            }
            else // for Prod
            {
                //  jira.JiraUrl = Constant.JiraForSearching + "jql='project' = '" + projects[j] + "' AND 'Requestor Email' ~ '" + currentUser + "' AND 'From RMS' =Yes&maxResults=1000&fields=customfield_12208,customfield_12207,summary,customfield_10100,customfield_10713,status,priority,assignee,created,updated,duedate&ORDER BY key DESC";

            }
            string response = jira.GetUsersRecordsFronJira();
            Root ro = Newtonsoft.Json.JsonConvert.DeserializeObject<Root>(response);
            GetRootNestedContent(ro, jiraUrl, rowList, key);
            return rowList;
        }
        public static GridRow GetRootNestedContent(Root ro, string jiraUrl, List<GridRow> rowList, string key)
        {
            GridRow newRow = null;
            if (ro != null)
            {
                newRow = new GridRow();
                newRow.Key = key;
                newRow.FunctionalDomain = ro.fields.customfield_12800.value;
                newRow.PRank = ro.fields.customfield_12801.value;
                newRow.ProductOwner = ro.fields.customfield_12704.displayName;
                newRow.Category = ro.fields.customfield_10540.value;
                rowList.Add(newRow);
            }
            return newRow;
        }
    }
}