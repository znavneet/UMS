﻿using MSXML2;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Authentication;
using System.Text;
using System.Web;

namespace AMAT.BIM_UMSWeb
{
    public class JIRA
    {
        public String JiraUserName { get; set; }
        public String JiraPassword { get; set; }
        public String JiraUrl { get; set; }
        public String JiraJson { get; set; }


        #region Add issue to JIRA POST request

        //public String addJiraIssue1()
        //{

        //    string url = URL();
        //    XMLHTTP60 JiraService = new XMLHTTP60();
        //    // ServerXMLHTTP60 JiraService = new ServerXMLHTTP60();
        //    JiraService.open("POST", JiraUrl);
        //    JiraService.setRequestHeader("Origin", url);
        //    JiraService.setRequestHeader("Content-Type", "application/json");
        //    JiraService.setRequestHeader("Accept", "application/json");
        //    JiraService.setRequestHeader("Authorization", "Basic " + GetEncodedCredentials());
        //    JiraService.send(JiraJson);
        //    String response = JiraService.responseText;
        //    JiraService.abort();
        //    return response;
        //}

        public string addJiraIssue()
        {
            string responseText = string.Empty;
            ServicePointManager.Expect100Continue = true;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(JiraUrl);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Accept = "application/json";
            httpWebRequest.Method = "POST";
            httpWebRequest.Headers.Add("Authorization", "Basic " + GetEncodedCredentials());
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(JiraJson);
                streamWriter.Flush();
            }
            WebResponse webResponse = (HttpWebResponse)httpWebRequest.GetResponse();

            using (var streamReader = new StreamReader(webResponse.GetResponseStream()))
            {
                responseText = streamReader.ReadToEnd();
            }
            return responseText;
        }

        public string addJiraIssuebyRESTClient()
        {
            var client = new RestClient(JiraUrl);
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", "Basic " + GetEncodedCredentials());
            request.AddHeader("Content-Type", "application/json");           
            request.AddParameter("application/json", JiraJson, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            return response.Content;
        }

        #endregion

        #region Update issue to JIRA PUT request

        //public String UpdateJiraIssue1()
        //{
        //    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
        //    String response = string.Empty;
        //    string url = URL();
        //    ServerXMLHTTP60 JiraService = new ServerXMLHTTP60();
        //    JiraService.open("PUT", JiraUrl);
        //    JiraService.setRequestHeader("Origin", url);
        //    JiraService.setRequestHeader("Content-Type", "application/json");
        //    JiraService.setRequestHeader("Accept", "application/json");
        //    JiraService.setRequestHeader("Authorization", "Basic " + GetEncodedCredentials());
        //    JiraService.send(JiraJson);
        //    while (JiraService.readyState != 4)
        //    {
        //        response = JiraService.responseText;
        //    }
        //    // JiraService.abort();
        //    return response;
        //}

        public String UpdateJiraIssue()
        {
            string responseText = string.Empty;
            ServicePointManager.Expect100Continue = true;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(JiraUrl);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Accept = "application/json";
            httpWebRequest.Method = "PUT";
            httpWebRequest.Headers.Add("Authorization", "Basic " + GetEncodedCredentials());
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(JiraJson);
                streamWriter.Flush();
            }
            WebResponse webResponse = (HttpWebResponse)httpWebRequest.GetResponse();

            using (var streamReader = new StreamReader(webResponse.GetResponseStream()))
            {
                responseText = streamReader.ReadToEnd();
            }
            return responseText;
        }

        public String UpdateJiraIssueByRestSharpClient()
        {
            var client = new RestClient(JiraUrl);
            client.Timeout = -1;
            var request = new RestRequest(Method.PUT);
            request.AddHeader("Authorization", "Basic " + GetEncodedCredentials());
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", JiraJson, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            return response.Content;
        }

        #endregion

        #region Get issues to JIRA GET request

        //public String GetUsersRecordsFronJira1()
        //{
        //    string url = URL();
        //    XMLHTTP60 JiraService = new XMLHTTP60();
        //    JiraService.open("GET", JiraUrl);
        //    JiraService.setRequestHeader("Origin", url);
        //    JiraService.setRequestHeader("Content-Type", "application/json");
        //    JiraService.setRequestHeader("Accept", "application/json");
        //    JiraService.setRequestHeader("Authorization", "Basic " + GetEncodedCredentials());
        //    JiraService.send(JiraJson);
        //    String response = JiraService.responseText;
        //    JiraService.abort();
        //    return response;
        //}

        public String GetUsersRecordsFronJira()
        {
            string responseText = string.Empty;
            ServicePointManager.Expect100Continue = true;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(JiraUrl);                 
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Accept = "application/json";
            httpWebRequest.Method = "GET";
            httpWebRequest.Headers.Add("Authorization", "Basic " + GetEncodedCredentials());     

            using (WebResponse response = httpWebRequest.GetResponse())
            {
                using (var streamReader = new StreamReader(response.GetResponseStream()))
                {
                    responseText = streamReader.ReadToEnd();
                }    

            }
           
            //string url = URL();
            //ServerXMLHTTP60 JiraService = new ServerXMLHTTP60();
            //JiraService.open("GET", JiraUrl);
            //JiraService.setRequestHeader("Origin", url);
            //JiraService.setRequestHeader("Content-Type", "application/json");
            //JiraService.setRequestHeader("Accept", "application/json");
            //JiraService.setRequestHeader("Authorization", "Basic " + GetEncodedCredentials());
            //JiraService.send(JiraJson);
            //String response = JiraService.responseText;
            //JiraService.abort();


            return responseText;
        }

        public String GetRecordsbyRestSharpClient()
        {
            ServicePointManager.Expect100Continue = true;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var client = new RestClient(JiraUrl);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Basic " + GetEncodedCredentials());
          
            IRestResponse response = client.Execute(request);
            return response.Content;
        }

        #endregion

        public string GetEncodedCredentials()
        {
            Constant obj = new Constant();
            string mergedCredentials = string.Format("{0}:{1}", obj.UserId, obj.Password);         
            byte[] byteCredentials = UTF8Encoding.UTF8.GetBytes(mergedCredentials);
            return Convert.ToBase64String(byteCredentials);
        }

        //public string URL()
        //{
        //    Constant obj = new Constant();
        //    string jiraUrl = obj.JiraUrl;
        //    string url = string.Empty;
        //    if (jiraUrl.Contains("qa"))
        //        url = Constant.JiraShortUrlShortQA;
        //    else
        //        url = Constant.JiraShortUrlShort;
            
        //    return url;
        //}
    }
}