﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AMAT.BIM_UMSWeb
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class PriorityProd
    {
        public string self { get; set; }
        public string iconUrl { get; set; }
        public string name { get; set; }
        public string id { get; set; }
    }

    public class Customfield11006Prod
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
        public bool disabled { get; set; }
    }

    public class Customfield10713Prod
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
        public bool disabled { get; set; }
    }

    public class Customfield12207Prod
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
        public bool disabled { get; set; }
    }

    public class customfield_11111Prod  //rank prod
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield12615Prod // Dashbaord name for prod
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
        public bool disabled { get; set; }
    }

    public class AssigneeProd
    {
        public string self { get; set; }
        public string name { get; set; }
        public string key { get; set; }
        public string emailAddress { get; set; }
        public AvatarUrls avatarUrls { get; set; }
        public string displayName { get; set; }
        public bool active { get; set; }
        public string timeZone { get; set; }
    }

    public class StatusCategoryProd
    {
        public string self { get; set; }
        public int id { get; set; }
        public string key { get; set; }
        public string colorName { get; set; }
        public string name { get; set; }
    }

    public class StatusProd
    {
        public string self { get; set; }
        public string description { get; set; }
        public string iconUrl { get; set; }
        public string name { get; set; }
        public string id { get; set; }
        public StatusCategoryProd statusCategory { get; set; }
    }
    public class Customfield12607Prod  // for CDS names in prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield12914Prod   // Approve reject by prod
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public AvatarUrls avatarUrls { get; set; }
        public string displayName { get; set; }

    }
    public class Customfield12702Prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield12610Prod   // BIM PM on approval form for prod
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public string displayName { get; set; }
    }
    public class Customfield12605Prod   //impact type in approval form for prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    //public class IssuetypeProd
    //{
    //    public string name { get; set; }
    //    public Fields Fields { get; set; }
    //}
    public class timetrackingProd
    {
        public string originalEstimate { get; set; }
    }

    public class Customfield_13410Prod  // align with buss owner qa
    {
        public string value { get; set; }
        public string id { get; set; }
    }

    public class Customfield13407Prod
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
        public bool disabled { get; set; }
    }
    public class IssuetypeProd
    {
        public string self { get; set; }
        public string id { get; set; }
        public string description { get; set; }
        public string iconUrl { get; set; }
        public string name { get; set; }
        public bool subtask { get; set; }
    }
    public class FieldsProd
    {
        public string summary { get; set; }
        public DateTime created { get; set; }
      //  public string customfield_13410 { get; set; }
        public PriorityProd priority { get; set; }
        public string customfield_10100 { get; set; }
        public double? customfield_13403 { get; set; }
        public string customfield_13402 { get; set; }
        public Customfield11006Prod customfield_11006 { get; set; }
        public string customfield_13405 { get; set; }
        public string customfield_13404 { get; set; }

        public string customfield_13406 { get; set; } // security info
        public string customfield_12208 { get; set; }
    
        public Customfield10713Prod customfield_10713 { get; set; }
        public string customfield_13409 { get; set; }
        public string customfield_13408 { get; set; }
        public string duedate { get; set; }
        public string customfield_12908 { get; set; }
        public AssigneeProd assignee { get; set; }
        public StatusProd status { get; set; }
        public Customfield12207Prod customfield_12207 { get; set; }
        public customfield_11111Prod customfield_11111 { get; set; }

        public List<Customfield12615Prod> customfield_12615 { get; set; }// Dashboard name for prod
        public List<Customfield12607Prod> customfield_12607 { get; set; } // for CDS Name for prod
        public Customfield12914Prod customfield_12914 { get; set; } // Approve/reject by prod
        public Customfield12702Prod customfield_12702 { get; set; } //  Approval status, in approval form prod
        public string customfield_12911 { get; set; } // production dashboard Link QA
        public string customfield_12913 { get; set; } // Approve date
        public Customfield12610Prod customfield_12610 { get; set; } // BIM PM on approval form for prod
        public string description { get; set; } // description
        public Customfield12605Prod customfield_12605 { get; set; }  // impact type for prod
        public IssuetypeProd issuetype { get; set; }
        public timetrackingProd TimeTracking { get; set; }  // effort Estimate

        public DateTime updated { get; set; }

        public Customfield13407Prod customfield_13407 { get; set; }
        public Customfield_13410Prod customfield_13410 { get; set; }  // align with buss owner

    
    }

    public class IssueProd
    {
        public string expand { get; set; }
        public string id { get; set; }
        public string self { get; set; }
        public string key { get; set; }
        public FieldsProd fields { get; set; }
    }

    public class RootProd
    {
        public string expand { get; set; }
        public int startAt { get; set; }
        public int maxResults { get; set; }
        public int total { get; set; }
        public List<IssueProd> issues { get; set; }
    }


}