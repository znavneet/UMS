﻿
///category onchange event

$(document).ready(function () {

  
    $('#myDropDownlistID').on('change', function () {
        $('#hdndashboardname').val($(this).val());
    });


    $('#ddlCRDashboard option:selected').val();
    $('#ddlCRDashboard').on('change', function () {
        $('#hdnCRdashboardname').val($(this).val());
       // $('#hdnCRdashboardname').val($(this).find("option:selected").text());
    });

    $('#myDropDownlistID').select2();
    
    $('#ddlCRDashboard').select2();

    $("input[name='inlineRadioOptions']").change(function () {
        var selection = $(this).val();

        if (selection == "others") {
            $('#resubmitotherBusinessdiv').show();

          
        }
        else {
            $('#resubmitotherBusinessdiv').hide();
        }

     /*   $('#ddlCRFeasiblity').on('change', function () {
          $('#hdnCRFeasiblity').val($(this).val());
        });
        $('#ddlPMCRComplexity').on('change', function () {
            $('#hdnComplexity').val($(this).val());
        });*/
    });

    $("input[id*='assigneeduedate']").datepicker({
        showOn: "button",
        buttonImage: "../Images/Calender.png",
        buttonImageOnly: true,
        buttonText: "Select date",
        dateFormat: 'mm/dd/yy'
    });



    $("input[name ='issueType']").change(function () {
        var selection = $(this).val();

        if (selection == "others") {
            $('#otherBusinessdiv').show();

           

        }
        else {
            $('#otherBusinessdiv').hide();
            
        }
    });


$("#creqcategory").change(function () {
    var value = $('option:selected', this).text();
    if (value == "BIM Request") {

        $('#idnumber').empty().append('Request Number');
        $('#request').show();
        $('#issue').hide();
        $('#CR').hide();
    }

    if (value == "Log the Issue") {
        $('#idnumber').empty().append('Issue Number');
        $('#issue').show();
        $('#request').hide();
        $('#CR').hide();
    }
    if (value == "Change Request") {
        $('#idnumber').empty().append('Change Request');
        $('#CR').show();
        $('#issue').hide();
        $('#request').hide();
    }
});





$("#requesterchk").on('click', function () {

    var $box = $(this);
   
    if ($box.is(":checked")) {
        $('#requesterppldiv').show();
        $('#requestercurrentuserdiv').hide();
    }

    else {

        $('#requesterppldiv').hide();
        $('#requestercurrentuserdiv').show()
    }


});



});



function validatesubmitissue() {

    var reqName;
    var isChecked = $('#requesterchk:checked').val() ? true : false;

    if (isChecked) {
      reqName = $('#spanReqName').text();
    }

    else {
        reqName = $('#currentuser').text();
        
    }

    var title = $('#issuetitle').val();
    var desc = $('#issuedesc').val();
    var priority = $('#issuepriority').val();
    var idduefounfin = $('#myDropDownlistID').val();
    var isDisabled = $('#myDropDownlistID').prop('disabled');
    var category = $('#creqcategory').val();
   

    if (idduefounfin == null || idduefounfin == "--Select--") {

        if (isDisabled) {

            alert("Error in fetching Catalog title. Please try again later.")
            return false;
        }
        else {

            alert("Please enter all required field values.");
            return false;
        }

    }


    if (idduefounfin != "" && reqName != "" && title != "" && desc != "" && priority != null && category == "Log the Issue" && priority !="--Select--") {

        $("#loader").show();
        return true;

    }

    else {

        alert("Please enter all required field values.");
        return false;

    }



}

///issue reset////
function issuereser() {

     $('#issuetitle').val('');
     $('#issuedesc').val('');
     $('#issuepriority').val('');
     $('#issuefileupload').val('');

}



//////for PM controls////////////
function validateissuePM(){

    var category = $('#issuecategory').val();
    var assignee = $('#issueassignee').val();
    var comments = $('#issuepmcomments').val();


    if (category != null && assignee != "--Select--" && comments != "") {

        if ($("#issuetype4").prop("checked")) {
            var businessothers = $('#otherissuetype').val();
            if (businessothers != "") {
                $("#loader").show();
                return true;
            }
            else {
                alert("Please enter value for issue type others.");
                return false;
            }
        }

        else {

            $("#loader").show();
            return true;
        }


    }

    else {

        alert("Please enter all required field values.");
        return false;
    }




}

function validateIssueAssignee() {

    var date = $('#assigneeduedate').val();
    var comments = $('#assigneecomments').val();
    var status = $('#assigneestatus').val();

    if (date != "" && comments != "") {

        if (status == "Completed") {

            var r = confirm("Please make sure you have uploaded the user conformation mail to close this issue. Do you wish to proceed?");
            if (r == true) {
                $("#loader").show();
                return true;
            }

            else {

                return false;

            }

        }


        else {


            $("#loader").show();
            return true;
        }




    }

    else {

        alert("Please enter all required field values.");
        return false;

    }

}

function ShowReviewRejectProgressBar() {
    ///validation

    var reviewerComments = $('#reviewcomm').val();

    if (reviewerComments != "") {
        $("#loader").show();
        return true;
    }

    else {

        alert("Please enter comments.")
        return false;
    }

        

    
}


////////resubmit request/////////////////

function vieweditreq() {

    $('#viewrequestsection').show();
    $('#viewissuesection').hide();
    $('#viewreqinbox').hide();
    $('#disreviewersection').hide();
    $('#dispmsection').hide();
    $('#dispzsection').hide();
    $('#dispdsection').hide();
    $('#resubmitedit').hide();    

    $('#resubmitdiv').show();
    $("#reviewerReSubmit").show();
}


function rewReSubmit() {

    var r = confirm("Are you sure, yow want to resubmit this request?");
    if (r == true) {

        $("#loader").show();
        return true;

    }


    else {
        return false;


    }

}

function rewReSubmit() {

    //var reqName;
    //var isChecked = $('#requesterchk:checked').val() ? true : false;

    //if (isChecked) {
    //    reqName = $('#spanReqName').text();
    //}

    //else {
    //    reqName = $('#currentuser').text();

    //}



    var reqtitle = $('#resubmitreqtitle').val();
    var bussjust = $('#resubmitbusinessjus').val();
    var reqtype = $('#resubmitreqtype').val();
  

    var desc = $('#resubmitdesc').val();
   // if (reqName != "" && reqtitle != "" && bussjust != "" && desc != "" && reqtype != null && reqCategory != null)
        if (reqtitle != "" && bussjust != "" && desc != "" && reqtype != null) {

            if ($("#resubmitRadio4").prop("checked")) {
                var businessothers = $('#resubmitothertext').val();
            if (businessothers != "") {
                $("#loader").show();
                return true;
            }
            else {
                alert("Please enter value for business value type others.");
                return false;
            }

        }

        else {
            $("#loader").show();
            return true;
        }



    }

    else {
        alert("Please enter all required field values.");
        return false;
    }


}
