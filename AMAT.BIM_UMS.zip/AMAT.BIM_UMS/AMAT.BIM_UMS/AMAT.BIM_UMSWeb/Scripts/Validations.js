﻿
///category onchange event
var catalogData = [];

$(document).ready(function () {

    $('.popupCloseButton').click(function () {
        $('.hover_bkgr_fricc').hide();
        $('#resultHTML').text('');
    });


    linkValidation();
    var value = $('#hdntabNameHolder').val();
    if (value)
        IssueSelected();

    $("input[type='radio']").change(function () {
        var selection = $(this).val();

        if (selection == "others") {
            $('#otherBusinessdiv').show();
        }
        else {
            $('#otherBusinessdiv').hide();
        }
    });

    $("#reqDesc").keyup(function () {
        $("#count").text("(Characters left: " + (4000 - $(this).val().length) + ")");       
    });
    $("#txtJustification").keyup(function () {
        $("#count11").text("(Characters left: " + (4000 - $(this).val().length) + ")");
    });
    $("#txtBestApproach").keyup(function () {
        $("#count20").text("(Characters left: " + (4000 - $(this).val().length) + ")");
    });
    $("#issuedesc").keyup(function () {
        $("#count1").text("(Characters left: " + (4000 - $(this).val().length) + ")");
    });

    
    CategoryCheckboxChangeEvents(); // All checkbox events
    GetADUsersInBox();
  
    var newdata = JSON.parse($('#hdnJsonResponse').val());
    catalogData.push(newdata);

  
});

function ValidateRequestForm() {

    var isTrue = true;
    var msg = "Please Enter the following fields.\r\n-----------------------------------------\r\n";

    var category = $('#creqcategory').val();          // category   
    var title = $('#creqtitle').val();                // title
    var reqDesc = $('#reqDesc').val();               // request desc
    var fnDomain = $('#ddlfunctionalDomain').val();  // fn domain
    var justification = $('#txtJustification').val();  // business justification
    var bussOwner = $('#txtBusinessOwner').val();  // business owner  

    var changeType = $('#ddlChangeType').val();
    var changeName = $('#ddlChangeName').val(); // dropdown value
    var otherChangeName = $('#txtName').val(); // other text box value
    var userCount = $('#txtUsercount').val();   // user count
    var frequency = $('#ddlRefeshFrequency').val();   // db frequency
    var trainingOwner = $('#txtTrainingOwner').val();  // training owner

    var IsAligned = $('#rdoAligned input:radio:checked').length; // align with business owner  
    var IsSecure = $('#rdoSecured input:radio:checked').length;  // radio Need Security implementation
    var businessVal = $("input[name='inlineRadioOptions']:checked").val();   // business value type    
    var IsStrategic = $('#rdoInitiative input:radio:checked').length; // radio Part of Strategic Initiative

    if (category == "--Select--") {
        msg = "Please select issue category. \r\n";
        alert(msg);
        isTrue = false;
        return isTrue;
    }

    if (category == "New Request" || category == "Adhoc") {

        if (!title) {
            msg += "Enter the 'Title'. \r\n";
            isTrue = false;
        }
        if (!reqDesc) {
            msg += "Enter the 'Request Description'. \r\n";
            isTrue = false;
        }
        if (fnDomain == "--Select--") {
            msg += "Enter the 'Functional Domain'. \r\n";
            isTrue = false;
        }
        if (!justification) {
            msg += "Enter the 'Bussiness Justification'. \r\n";
            isTrue = false;
        }
      
        if (IsStrategic !== 1) {
            msg += "Select 'Strategic Initiative'. \r\n";
            isTrue = false;
        }
        else {
            if ($('#rdoInitiative input:radio:checked').val() == "Yes" && $('#txtStrategic').val() == "") {
                msg += "Enter 'Strategic Initiative'.\r\n";
                isTrue = false;
            }
        }

        if (!bussOwner) {
            msg += "Select 'Bussiness Owner'. \r\n";
            isTrue = false;
        }
        if (IsSecure !== 1) {
            msg += "Select 'Eecurity Implementation'.\r\n";
            isTrue = false;         
        }
        else {
            if ($('#rdoSecured input:radio:checked').val() == "Yes" && $('#txtDashboardSecurity').val() == "") {
                msg += "Detail the level of 'Dashbaord Security'.\r\n";
                isTrue = false;               
            }
        }
        if (frequency == "--Select--") {
            msg += "Select the 'Dashbaord Frequency'.\r\n";
            isTrue = false;
        }
        if (!userCount) {
            msg += "Enter 'Potential User Base count'. \r\n";
            isTrue = false;
        }
        if (!trainingOwner) {
            msg += "Enter the 'Communication and Training owner'. \r\n";
            isTrue = false;
        }
        if (!businessVal) {
            msg += "Select 'Business Value type'.\r\n";
            isTrue = false;
        }

    }

    if (category == "Change Request") {

        if (!title) {
            msg += "Enter the 'Title'. \r\n";
            isTrue = false;
        }
        if (!reqDesc) {
            msg += "Enter the 'Request Description'. \r\n";
            isTrue = false;
        }
        if (fnDomain == "--Select--") {
            msg += "Enter the 'Functional Domain'. \r\n";
            isTrue = false;
        }
       
        if (changeType == "--Select--") {
            msg += "Select 'Change Type'. \r\n";
            isTrue = false;
        }
        else {
            if (changeType == "Other") {
                if (!otherChangeName) {
                    msg += "Enter 'Change Name'. \r\n";
                    isTrue = false;
                }
            }
            else {
                if (changeName == "--Select--") {
                    msg += "Select 'Change Name'. \r\n";
                    isTrue = false;
                }
            }
        }
        if (!justification) {
            msg += "Enter the 'Bussiness Justification'. \r\n";
            isTrue = false;
        }
        if (IsStrategic !== 1) {
            msg += "Select 'Strategic Initiative'. \r\n";
            isTrue = false;
        }
        else {
            if ($('#rdoInitiative input:radio:checked').val() == "Yes" && $('#txtStrategic').val() == "") {
                msg += "Enter 'Strategic Initiative'.\r\n";
                isTrue = false;
            }
        }

        if (IsAligned !== 1) {
            msg += "Select 'Changes Aligned with Business Owner' \r\n";
            isTrue = false;
        }
        if (!businessVal) {
            msg += "Select 'Business Value type'.\r\n";
            isTrue = false;
        }
    }

    if (isTrue)
        $("#loading").show();
    else
        alert(msg);

    return isTrue;
}



function resetFormfields() {

    $('#creqcategory').val('--Select--');
    $('#ddlIssue').val('--Select--');
    $('#ddlDashboardName').val('--Select--');
    $('#creqtitle').val('');
    $('#reqDesc').empty();
    $('#issuetitle').val('');
    $('#issuedesc').empty();
}

function validationIssueRequest()
{
    var IsTrue = true;
    var titleval = $('#issuetitle').val(); 
    var category = $('#ddlIssue').val(); 
    var descval = $('#issuedesc').val(); 
    var dashboard = $('#ddlDashboardName').val();
    var fnDomain = $('#ddlfunctionalDomainReports').val();
    

    if (titleval == "" || dashboard == "--Select--" || category == null || descval == "" || fnDomain == "--Select--") {
        alert("Please enter all required field values.");
        IsTrue = false;
        return false;
    }

    if (IsTrue)
        $("#loading").show();
}
//number validation
function isNumber(evt) {
    var iKeyCode = (evt.which) ? evt.which : evt.keyCode
    if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
        return false;

    return true;
}

function validateDate(dateValue) {
    var selectedDate = dateValue;
    if (selectedDate == '')
        return false;

    var regExp = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/; //Declare Regex
    var dateArray = selectedDate.match(regExp); // is format OK?

    if (dateArray == null) {
        return false;
    }

    month = dateArray[1];
    day = dateArray[3];
    year = dateArray[5];

    if (month < 1 || month > 12) {
        return false;
    } else if (day < 1 || day > 31) {
        return false;
    } else if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
        return false;
    } else if (month == 2) {
        var isLeapYear = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isLeapYear)) {
            return false
        }
    }
    return true;
}

function linkValidation()
{
    $('#createbimreq').click(function () {
        BIMSelected();
        return false;
    });
    $('#createissuereq').click(function () {
        IssueSelected();
        return false;
    });
    $('#myrequest').click(function () {
        GridSelected();
        return false;
    });

    $('#allRequest').click(function () {
        GridAllSelected();
        return false;
    });

    $('#PrioritizationRequest').click(function () {
        PrioritizationTab();
        return false;
    });

    $('#productionDeployment').click(function () {
        ProductionDeploymentview();
        return false;
    });

    $('#changeRequest').click(function () {
        ChangeLogview();
        return false;
    });
   
    $('#creqcategory').on('change', function () {
        $('#hdnBimRequestCat').val($(this).val());
    });

    $('#ddlIssue').on('change', function () {
        $('#hdnIssueRequestCat').val($(this).val());
    });

    $('#ddlDashboardName').on('change', function () {
        $('#hdndashboardname').val($(this).val());
    });
}
function BIMSelected() {
    $('#createBimRequest').show();
    $('#createIssueRequest').hide();
    $('#viewMyRequest').hide();
    $('#viewAllBIMRequest').hide();
    $('#deploymentApprovalView').hide();
    $('#prioritizationTab').hide();

    $('#createbimreq a').addClass('active');
    $('#createissuereq a').removeClass('active');
    $('#myrequest a').removeClass('active');
    $('#allRequest a').removeClass('active');
    $('#productionDeployment a').removeClass('active');
    $('#PrioritizationRequest a').removeClass('active');

    $('#lblHead').text("New Requests");
    $('#lblHead').addClass("HeadCss");
    $('#pplreq').show();
    $('.select2-container').attr('style', 'width:380px !important');
    $('.select2-selection').attr('style', 'height:38px !important');
    $('#emailNotify').attr('style', 'display:block');

    $('#allExcel').hide();
    $('#myrequestExcel').hide();
    $('#priortyExcel').hide();
    $('.dashbaodlink').show();
}

function IssueSelected() {
    $('#createIssueRequest').show();
    $('#createBimRequest').hide();
    $('#viewMyRequest').hide();
    $('#viewAllBIMRequest').hide();
    $('#prioritizationTab').hide();
    $('#deploymentApprovalView').hide();
    $('#changeLogRequestView').hide();

    $('#createbimreq a').removeClass('active');
    $('#createissuereq a').addClass('active');
    $('#myrequest a').removeClass('active');
    $('#allRequest a').removeClass('active');
    $('#PrioritizationRequest a').removeClass('active');
    $('#productionDeployment a').removeClass('active');
    $('#changeRequest a').removeClass('active');

    $('#lblHead').text("Report Issues");
    $('#lblHead').addClass("HeadCss");
    $('#pplreq').show();
    $('.select2-container').attr('style', 'width:380px !important');
    $('.select2-selection').attr('style', 'height:38px !important');
    // $('#emailNotify').attr('style', 'display:none');
    $('#allExcel').hide();
    $('#myrequestExcel').hide();
    $('#priortyExcel').hide();
    $('.dashbaodlink').hide();
}
function GridSelected() {
    $('#createBimRequest').hide();
    $('#createIssueRequest').hide();
    $('#viewMyRequest').show();
    $('#viewAllBIMRequest').hide();
    $('#prioritizationTab').hide();
    $('#deploymentApprovalView').hide();
    $('#changeLogRequestView').hide();

    $('#createbimreq a').removeClass('active');
    $('#createissuereq a').removeClass('active');
    $('#myrequest a').addClass('active');
    $('#allRequest a').removeClass('active');
    $('#PrioritizationRequest a').removeClass('active');
    $('#productionDeployment a').removeClass('active');
    $('#changeRequest a').removeClass('active');
    // loadViewMyRequest();
    $('#lblHead').text("My Requests");
    $('#lblHead').addClass("HeadCss");
    $('#pplreq').hide();
    $('#allExcel').hide();
    $('#myrequestExcel').show();
    $('#priortyExcel').hide();
    $('.dashbaodlink').hide();
}
function GridAllSelected() {
    $('#createBimRequest').hide();
    $('#createIssueRequest').hide();
    $('#viewMyRequest').hide();
    $('#viewAllBIMRequest').show();
    $('#prioritizationTab').hide();
    $('#deploymentApprovalView').hide();
    $('#changeLogRequestView').hide();

    $('#createbimreq a').removeClass('active');
    $('#createissuereq a').removeClass('active');
    $('#myrequest a').removeClass('active');
    $('#changeRequest a').removeClass('active');
    $('#PrioritizationRequest a').removeClass('active');
    $('#productionDeployment a').removeClass('active');
    $('#allRequest a').addClass('active');
    // loadViewMyRequest();
    $('#lblHead').text("All Requests");
    $('#lblHead').addClass("HeadCss");
    $('#pplreq').hide();
    $('#allExcel').show();
    $('#myrequestExcel').hide();
    $('#priortyExcel').hide();
    $('.dashbaodlink').hide();
}

function PrioritizationTab(){
    $('#createBimRequest').hide();
    $('#createIssueRequest').hide();
    $('#viewMyRequest').hide();
    $('#viewAllBIMRequest').hide();
    $('#prioritizationTab').show();
    $('#deploymentApprovalView').hide();
    $('#changeLogRequestView').hide();


    $('#createbimreq a').removeClass('active');
    $('#createissuereq a').removeClass('active');
    $('#myrequest a').removeClass('active');
    $('#allRequest a').removeClass('active');
    $('#PrioritizationRequest a').addClass('active');
    $('#productionDeployment a').removeClass('active');
    $('#changeRequest a').removeClass('active');

    // loadViewMyRequest();
    $('#lblHead').text("Requests for Prioritization");
    $('#lblHead').addClass("HeadCss");
    $('#pplreq').hide();
    $('#allExcel').hide();
    $('#myrequestExcel').hide();
    $('#priortyExcel').show();
    $('.dashbaodlink').hide();
    
}

function ProductionDeploymentview() {
    $('#lblHead').text("Production Deployment Approval requests");
    $('#lblHead').addClass("HeadCss");

    $('#createBimRequest').hide();
    $('#createIssueRequest').hide();
    $('#viewMyRequest').hide();
    $('#viewAllBIMRequest').hide();
    $('#prioritizationTab').hide();
    $('#deploymentApprovalView').show();
    $('#changeLogRequestView').hide();
    
    $('#createbimreq a').removeClass('active');
    $('#createissuereq a').removeClass('active');
    $('#myrequest a').removeClass('active');
    $('#allRequest a').removeClass('active');
    $('#PrioritizationRequest a').removeClass('active');
    $('#productionDeployment a').addClass('active');
    $('#changeRequest a').removeClass('active');

    $('#pplreq').hide();
    $('#allExcel').hide();
    $('#myrequestExcel').hide();
    $('#priortyExcel').hide();
    $('.dashbaodlink').hide();
}


function ChangeLogview()
{
    $('#lblHead').text("Change log requests");
    $('#lblHead').addClass("HeadCss");

    $('#createBimRequest').hide();
    $('#createIssueRequest').hide();
    $('#viewMyRequest').hide();
    $('#viewAllBIMRequest').hide();
    $('#prioritizationTab').hide();
    $('#deploymentApprovalView').hide();
    $('#changeLogRequestView').show();
    
    $('#createbimreq a').removeClass('active');
    $('#createissuereq a').removeClass('active');
    $('#myrequest a').removeClass('active');
    $('#allRequest a').removeClass('active');
    $('#PrioritizationRequest a').removeClass('active');
    $('#productionDeployment a').removeClass('active');
    $('#changeRequest a').addClass('active');

    $('#pplreq').hide();
    $('#allExcel').hide();
    $('#myrequestExcel').hide();
    $('#priortyExcel').hide();
    $('.dashbaodlink').hide();
}

//******* New validation ********

function ShowHideControl(value) {
  
    $("#userCount").css("display", value);
    $("#dbScure").css("display", value);
    $("#dataFrequency").css("display", value);
    $("#trainingOwner").css("display", value);

    $("#Changetype option[value=--Select--]").attr('selected', 'selected');
}

function CategoryCheckboxChangeEvents() {

    //for change category dropdown on load

      
    $("#creqcategory").val("--Select--").change();  

    if ($("#creqcategory").val() === "Change Request") {
        $("#Changetype").css("display", "block");
        $("#ChangeName").css("display", "block");
        
    }
    else {
        $("#Changetype").css("display", "none");
        $("#ChangeName").css("display", "none");
    }

    // on change
    $('#creqcategory').change(function () {
        if (this.value === "Change Request") {
            $("#Changetype").css("display", "block");
            $("#ChangeName").css("display", "block");
            $("#txtName").css("display", "block");
            $("#divAlignedBussOwner").css("display", "block");          
            $("#txtBusinessOwner").val("");
            $("#txtTrainingOwner").val("");
            ShowHideControl("none");
            
        }
        else {
            $("#Changetype").css("display", "none");
            $("#ChangeName").css("display", "none");
            $("#divAlignedBussOwner").css("display", "none");
            $("#txtBusinessOwner").val("");
            $("#txtTrainingOwner").val("");
            $("#txtName").css("display", "none");
            
            ShowHideControl("block");
        }
        $("#ddlChangeType").val("--Select--");
        $('#ddlChangeName').empty();
        $('#txtBusinessOwner').val(''); 
    });

    // for Strategic radio on page load
    if ($('#rdoInitiative input:radio:checked').val() == "Yes")
        $("#txtStrategic").css('display', 'block');
    else 
        $("#txtStrategic").css('display', 'none');
    
   // on Strategic change
    $("#rdoInitiative").change(function () {
        var Ischecked = $("#rdoInitiative input:checked").val();   
        if (Ischecked == "Yes") {
            $("#txtStrategic").css('display', 'block');
        }
        else {
           $("#txtStrategic").css('display', 'none');
        }
    });

      // for security radio on page load
    if ($('#rdoSecured input:radio:checked').val() == "Yes")
        $("#txtDashboardSecurity").css('display', 'block');
    else
        $("#txtDashboardSecurity").css('display', 'none');

     // on security change
    $("#rdoSecured").change(function () {
        var Ischecked = $("#rdoSecured input:checked").val();
        if (Ischecked == "Yes") {
            $("#txtDashboardSecurity").css('display', 'block');
        }
        else {
            $("#txtDashboardSecurity").css('display', 'none');
        }
    });

     // for Aligned with Business Owne check box selection
    $("#rdoAligned").change(function () {
        var Ischecked = $("#rdoAligned input:checked").val();
    });
    
    // for on behalf change
    $("#requesterchk").change(function () {

        if ($(this).prop('checked')) {
            $("#txtOnbehalf").css('display', 'block');
        }
        else {
            $("#txtOnbehalf").css('display', 'none');
            $("#txtOnbehalf").val('');
        }
    });

    // for change type dropdown manipulation // filling dashboard/report/cube dropdowm fields
    $("#ddlChangeType").change(function () {

        var keyName = this.value;
        if (keyName == "Other") {
            $("#ChangeName").hide();
            $("#otherName").show();            
        }
        else {
            $("#ChangeName").show();
            $("#otherName").hide();
        }
        if (keyName == "--Select--")
            $("#lblName").text("Name");
        else
            $("#lblName").text("Name of " + keyName);

        if (keyName !== "--Select--" || keyName !== "Other") {

            var filterData = $.grep(catalogData[0], function (element, index) {
                return element.ContentType == keyName;
            });

            if (filterData) {
                $('#ddlChangeName').empty();
                var option = '<option value=--Select-->--Select--</option>';
                for (i = 0; i < filterData.length; i++) {
                    option += '<option value="' + filterData[i].Name + '">' + filterData[i].Name + '</option>';
                }
                $('#ddlChangeName').append(option);
                $('#ddlChangeName').select2();
            }            
        }
        $('#txtBusinessOwner').val('');
    });

    $("#ddlChangeName").change(function () {
        var dbName = this.value;
     
        $('#txtBusinessOwner').val('');

        if (dbName !== "--Select--") {
            var filterData = $.grep(catalogData[0], function (element, index) {
                return element.Name == dbName;
            });
            $('#txtBusinessOwner').val(filterData[0].BusinessOwner);

            $("#hdnChangeName").val(dbName);
        }
       
    });
}
    
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        alert('Only Numbers allowed.')
        return false;
    }
    return true;
}

function CheckForblank(evt)
{
    evt = (evt) ? evt : window.event;
    if ($("#creqcategory").val() === "Change Request") {
        if ($('#txtBusinessOwner').val().length == 0) {
            $("#divAlignedBussOwner").css("display", "block");
        }
    }
    return true;
}

function GetADUsersInBox() {


    $('#txtTrainingOwner').autocomplete({
        minLength: 3,
        select: function (event, ui) {
            GetNameEmailValues(ui.item.label)
            return false;
        },
        source: function (request, response) {
            $('#ownerLoad').show();
            $.ajax({
                url: 'UMS.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        if (item.UserEmail) {
                            var result = item.UserName;
                            return {
                                value: result
                            }
                        }
                    }))
                    $('#ownerLoad').hide();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#ownerLoad').hide();
                    $("#txtBusinessPM").val("");
                    alert("Not found.");
                }
            });
        }
    });

    $('#txtOnbehalf').autocomplete({
        minLength: 3,
        select: function (event, ui) {
            GetNameEmailValuesOnBehalf(ui.item.label)
            return false;
        },
        source: function (request, response) {
            $('#onBehalfLoad').show();
            $.ajax({
                url: 'UMS.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        if (item.UserEmail) {
                            var result = item.UserName;
                            return {
                                value: result
                            }
                        }
                    }))

                    $('#onBehalfLoad').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#onBehalfLoad').hide();
                    $("#txtOnbehalf").val("");
                    alert("Not found.");
                }
            });
        }
    });

    $('#txtBusinessOwner').autocomplete({
        minLength: 3,
        select: function (event, ui) {
            GetNameEmailBussOwner(ui.item.label)
            return false;
        },
        source: function (request, response) {
            $('#bussOwnerLoad').show();
            $.ajax({
                url: 'UMS.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        if (item.UserEmail) {
                            var result = item.UserName;
                            return {
                                value: result
                            }
                        }
                    }))

                    $('#bussOwnerLoad').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#bussOwnerLoad').hide();
                    $("#txtBusinessOwner").val("");
                    alert("Not found.");
                }
            });
        }
    });
}

function GetNameEmailBussOwner(str) {
    var value = str;
    $("#txtBusinessOwner").val(value);
    if (!$("#txtTrainingOwner").val()) {
        $("#txtTrainingOwner").val(value);
    }

    if ($("#creqcategory").val() === "Change Request") {
        if ($("#hdncurrentuser").val() === value) {
            $("#divAlignedBussOwner").css("display", "none");
            $('#rdoAligned input[value="Yes"]').attr('checked', 'checked');
        }
        else {
            $("#divAlignedBussOwner").css("display", "block");
          //  $('#rdoAligned input[value="No"]').attr('checked', 'checked');
        }
    }
   
    return false;
}
function GetNameEmailValues(str) {
        var value = str;
        $("#txtTrainingOwner").val(value);
       return false;
    }
function GetNameEmailValuesOnBehalf(str) {
    var value = str;
    $("#txtOnbehalf").val(value);
    return false;
}