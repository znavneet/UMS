﻿
var gridWidth;
var expIds = []; var subsIds = []; var priorIds = [];
var owners;
var subsIdsOnload = [];

$(document).ready(function () {

    PeoplePickerControlInit();
    owners = $('#hdnOwners').val();
  //  JSON.stringify(console.log($('#hdnOwners').val()));

    
    $('#ddlfunctionalDomain').select2();
    $('#ddlfunctionalDomainReports').select2();    
    $('#ddlDashboardName').select2();  
   
 
    GetMyRequest();
    GetAllRequest();    
    GetPrioritizationRequest();
    ProductionDeploymentView();
    ChangeLogViewRequest();

   
    $('#viewMyRequest').show();
    gridWidth = $("#gridbody").width();
    $('#btnEsclate').click(function () {
        /*  var myGrid = $('#viewMyRequest'), i, rowData, emails = "";
          for (i = 0; i < rowIds.length; i++) {
              rowData = myGrid.jqGrid("getRowData", rowIds[i]);
              if (rowData.Key) {
                  emails += rowData.Key + ';';
              }
              alert(emails);
          }
          if (emails) {
               //alert(emails);
              $('#hdnesclateMail').val(emails);
          }*/



    });
    $('#viewMyRequest').hide();

    GetQryString();

   
});

function getQueryString(name, url) {
    if (!url) {
        url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function GetQryString() {

   
    var tabName = $('#hdntab').val();
    var ddlCategory  = $('#hdnddlCategory').val();


    if (tabName === "Issue") {
        IssueSelected();
        ddlCategory = decodeURIComponent(ddlCategory);
        $('#ddlDashboardName').val([ddlCategory]).trigger('change');
    }
    else if(tabName === "MyRequest") {
        GridSelected(); //my request
        $('#viewRequest').jqGrid('setGridWidth', gridWidth);
    }
    else if (tabName === "AllRequest") {
        GridAllSelected(); //all request
    }  

}

var myRequestData = [];
function GetMyRequest() {
    
    var userEmail = $("#hdnUserMail").val();
    var newpriorRequest = "";

    $("#viewRequest").jqGrid({
        url: 'UMS.aspx/GetMyRequestData',
        datatype: 'json',
        ignoreCase: true,
        mtype: 'POST',       
        postData: { filters: '', currentUser: userEmail },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },

        ajaxGridOptions: { contentType: "application/json" },
        loadonce: true,
        colNames: ['Key', 'Project Name', 'Business Function', 'Summary', 'Category', 'Status', 'Priority', 'Assignee', 'Created on', 'Due Date', 'Expedite', 'Subscribe'],
        colModel: [

            { name: 'Key', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, formatter: NewFieldsDisplayMyRequest, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
            { name: 'ProjectName', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
            { name: 'FunctionalDomain', index: 'FunctionalDomain', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
                { name: 'Summary', index: 'Summary', width: 350, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.Summary + '"'; } },
            { name: 'Category', index: 'Category', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
            { name: 'Status', index: 'Status', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
            { name: 'Priority', index: 'Priority', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
                { name: 'Assignee', index: 'Assignee', width: 250, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Created', index: 'Created', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'Duedate', index: 'Duedate', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
                {
                    name: 'Expedite', width: 130, align: 'center', index: 'Expedite', key: true, search: false,
                    edittype: 'checkbox',
                    editoptions: { value: 'Yes:No' },
                    formatoptions: { disabled: false },
                    formatter: function (cellvalue, options, rowObject) {
                        return '<input type="checkbox" class="expchk" id="cbPassed-' + rowObject.Key +
                            (rowObject.active === true ? '" checked="checked" />' : '" />');
                    }
                },
                {
                    name: 'Subscribe', width: 130, align: 'center', index: 'Subscribe', key: true, search: false,
                    edittype: 'checkbox',
                    editoptions: { value: 'Yes:No' },
                    formatoptions: { disabled: false },
                    formatter: function (cellvalue, options, rowObject) {
                        var checked = "No";
                        if (rowObject.Subscribe === "Yes") {
                            checked = "Yes";
                        }
                        var sbsObj = {
                            id: rowObject.Key,
                            isChecked: checked
                        }
                        var result = $.grep(subsIdsOnload, function (e) { return e.id == rowObject.Key; });
                        if (result.length == 0) {
                            subsIdsOnload.push(sbsObj);
                        }
                        // checkForExpBtnState(expIds, subsIdsOnload);
                        return '<input type="checkbox" id="chkSubscribe-' + rowObject.Key + (rowObject.Subscribe === "Yes" ? '" checked="checked" />' : '" />');
                    }
                }
        ],
        beforeSelectRow: function (rowid, e) {
            var checked = "No";
            var $self = $(this),
                iCol = $.jgrid.getCellIndex($(e.target).closest("td")[0]),
                cm = $self.jqGrid("getGridParam", "colModel"),
                localData = $self.jqGrid('getRowData', rowid);

            if (cm[iCol].name === "Expedite") {
                if ($(e.target).is(":checked")) {
                    expIds = [];
                    var expObj = {
                        id: localData.Key,
                        Title: localData.Summary,
                        Status: localData.Status,
                        LastModify: localData.LastModify,
                        CreatedOn: localData.Created
                    }
                    expIds.push(expObj);
                }
                else {
                    if ($(e.target).prop('checked') == false) {
                        expIds = $.grep(expIds, function (e) {
                            return e.id != localData.Key;
                        });
                    }
                }
            }
            if (cm[iCol].name === "Subscribe") {
                if ($(e.target).is(":checked")) {
                    var checked = "Yes";
                    $.each(subsIdsOnload, function () {
                        if (this.id == localData.Key.split('>')[1].split('<')[0]) {
                            this.isChecked = checked;
                        }
                    });
                }
                else {
                    if ($(e.target).prop('checked') == false) {
                        var checked = "No";
                        $.each(subsIdsOnload, function () {
                            if (this.id == localData.Key) {
                                this.isChecked = checked;
                            }
                        });
                    }
                }
            }
            $('input.expchk').on('change', function () {
                $('input.expchk').not(this).prop('checked', false);
            });
            console.log(expIds);
            console.log(subsIdsOnload);
            $('#hdnSubsIds').val(JSON.stringify(subsIdsOnload));
            $('#hdnExpIds').val(JSON.stringify(expIds));
            //checkForExpBtnState(expIds, subsIdsOnload);
            return true; // allow selection
        },
        onPaging: function (pgButton) {
            subsIdsOnload = [];
            expIds = [];
        },
        // multiselect: true,
        pager: '#pagingGrid',
        rowNum: 14,
        rowList: [20, 30, 40],
        viewrecords: true,
        gridview: true,
        ondblClickRow: function (rowId) {
            var rowData = $(this).getRowData(rowId);
            var key = rowData['Key'];
            key = key.split('<')[1].split('>')[1];
            OpenMyRequest(key);
        },
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { myRequestData = obj.d; return obj.d; },
            repeatitems: false,
            id: "0"
        },
        caption: 'Requests'
    });

}

function checkForExpBtnState(expids, subsIdsOnload) {

    $.each(subsIdsOnload, function () {
        if (this.isChecked == "Yes") {
            $("#btnEsclate").prop('disabled', false);
        }
        else
            $("#btnEsclate").prop('disabled', true);
    });
   
}

function viewMyRequest() {
    
    $("#viewRequest").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true,
        searchOnEnter: false
      });

    $('#viewRequest').jqGrid('setGridWidth', gridWidth);
    EmptyIdsArrayOnTabswitching();  // empty array when switchng tabs

}


//******************* View All request section ****************************
var allRequestData = [];
function GetAllRequest() {

    $("#viewAllRequest").jqGrid({
        url: 'UMS.aspx/GetAllProjectRequests',
        datatype: 'json',
        ignoreCase: true,
        mtype: 'POST',
        // postData: { filters: '', currentUser: userEmail, newRequest: newpriorRequest },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },

        ajaxGridOptions: { contentType: "application/json" },
        // loadonce: true,
        colNames: ['Key', 'Project Name', 'Requestor', 'Business Function', 'Summary', 'Category', 'Status', 'Priority', 'Assignee', 'Created on', 'Due Date', 'Assignee Email'],
        colModel: [
            {
                name: 'Key', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, editable: true, classes: 'wrap', formatter: NewFieldsDisplayAllRequest,
                cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; }
            },

            { name: 'ProjectName', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; }},
            { name: 'Requestor', index: 'Requestor', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
            { name: 'FunctionalDomain', index: 'FunctionalDomain', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
                { name: 'Summary', index: 'Summary', width: 350, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.Summary + '"'; } },
            { name: 'Category', index: 'Category', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
            { name: 'Status', index: 'Status', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="Double click on row to view project details.."'; } },
                { name: 'Priority', index: 'Priority', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Assignee', index: 'Assignee', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Created', index: 'Created', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'Duedate', index: 'Duedate', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'AssigneeEmail', index: 'AssigneeEmail', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true, hidden: true, }

        ],
        pager: '#pagingAllGrid',
        rowNum: 15,
        loadonce: true,
        rowList: [20, 30, 40],
        viewrecords: true,
        gridview: true,
        ondblClickRow: function (rowId) {
            var rowData = $(this).getRowData(rowId);
            var key = rowData['Key'];
            key = key.split('<')[1].split('>')[1];
            OpenAllRequest(key);
        },
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { allRequestData = obj.d; return obj.d; },
            repeatitems: false,
            id: "0"
        },
        caption: 'Requests',
    });
}

function viewAllRequest() {   
    $("#viewAllRequest").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true,
        searchOnEnter: false
    });
  
    $('#viewAllRequest').jqGrid('setGridWidth', gridWidth);

}


///******************* Prioritization Request tab ********

function GetPrioritizationRequest() {  
   
    var lastsel2 = "";

    $("#prioritizationRequest").jqGrid({
        url: 'UMS.aspx/GetNewRequestsToPrioritize',
        datatype: 'json',
        ignoreCase: true,
        loadonce: true,
        mtype: 'POST',
      //  postData: { filters: '', newRequest: newpriorRequest },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },

        ajaxGridOptions: { contentType: "application/json" },
        loadonce: true,
     //   colNames: ['Select', 'Key', 'Requestor', 'Summary', 'Project Area', 'Category', 'Business Function', 'Status', 'Priority', 'Rank', 'Product Owner', 'Est.Effort', 'Assign To', 'Due Date', 'Created on', 'Edit'],
        colNames: ['Select', 'Key', 'Requestor', 'Summary', 'Project Area', 'Category', 'Business Function', 'Status', 'Priority', 'Rank', 'Est.Effort', 'Assign To', 'Due Date', 'Created on', 'Edit'],
        colModel: [
                 {
                     name: 'Select', width: 110, align: 'center', index: 'Select', key: true,
                     edittype: 'checkbox',
                     hidden:true,
                     editoptions: { value: 'Yes:No', defaultValue: 'Yes' },
                     formatoptions: { disabled: false },
                     formatter: function (cellvalue, options, rowObject) {
                         return '<input type="checkbox" id="cbprior-' + rowObject.id +
                             (rowObject.active === true ? '" checked="checked" />' : '" />');
                     }
                 },
                { name: 'Key', width: 220, align: 'center', viewable: true, search: true, title: false, sortable: true ,formatter: jiraLink },
                { name: 'Requestor', index: 'Requestor', width: 300, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Summary', index: 'Summary', width: 350, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.Summary + '"'; } },
                { name: 'ProjectArea', index: 'ProjectArea', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true, hidden:true },
                { name: 'Category', index: 'Category', width: 250, align: 'center', viewable: true, search: true, title: false, sortable: true },
                {
                    name: 'FunctionalDomain', index: 'FunctionalDomain', width: 280, align: 'center', viewable: true, search: true, title: false, sortable: true,
                    editable: true,
                    edittype: 'select',
                    editoptions: {
                        value: $('#hdnFunctionalDomain').val(),
                        dataInit: function (element) {
                          //  $(element).select2();
                          //  $(element).attr('style', 'height:32px !important');
                          //  $('.select2-selection__rendered').text('--Select--');
                          //  $(element).attr('style', 'width:130px !important');
                          //  $('.select2-results').attr('style', 'font-size:13px !important');
                        }
                    }
                },
                //{ name: 'Status', index: 'Status', width: 180, align: 'center', viewable: true, search: true, title: false, sortable: true, editable: true, formatter: 'select', edittype: "select", editoptions: { value: 'New:New;Prioritized:Prioritized;On hold:On hold;Rejected:Rejected:ASSESSMENT:ASSESSMENT' } },
                { name: 'Status', index: 'Status', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true, editable: true, formatter: 'select', edittype: "select", editoptions: { value: 'New:New;Prioritized:Prioritized;On Hold:On Hold;Rejected:Rejected;Pending for priority:Pending for priority', defaultValue: 'New' } },
                { name: 'Priority', index: 'Priority', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true, editable: true, formatter: 'select', edittype: "select", editoptions: { value: 'Highest:Highest;High:High;Medium:Medium;Low:Low;Lowest:Lowest', defaultValue: 'Medium' } },
                {
                    name: 'PRank', index: 'PRank', width: 100, align: 'center', viewable: true, search: false, title: false, sortable: true, editable: true, formatter: 'select', edittype: "select",
                    editoptions: { value: '1:1;2:2;3:3;4:4;5:5;6:6;7:7;8:8;9:9;10:10;11:11;12:12;13:13;14:14;15:15;16:16;17:17;18:18;19:19;20:20', defaultValue: '1' }
                },
                //{
                //    name: 'ProductOwner', index: 'ProductOwner', width: 360, align: 'center', viewable: false, search: true, title: false, sortable: true, editable: true, formatter: 'select',
                //    edittype: "select",
                //    editoptions: {
                //        value: $('#hdnOwners').val(),
                //        dataInit: function (element) {                         
                //        }
                //    }
                //},                
                {
                    name: 'EffEstimation', index: 'EffEstimation', width: 130, align: 'center', viewable: true, search: false, title: false, sortable: true, editable: true, cellattr: function (rowId, cellValue, rowObject) {
                        return 'title="(eg. 3w 4d 12h)"';
                    }
                },
                {
                    name: 'Assignee', index: 'Assignee', width: 360, align: 'center', viewable: true, search: true, title: false, sortable: true,
                  editable: true,
                  edittype: 'select',
                  editoptions: {
                      value: $('#hdnJiraUsers').val(),
                      dataInit: function (element) {
                          $(element).select2();
                          $('.select2-selection').attr('style', 'height:32px !important');
                          $('.select2-selection__rendered').text('--Select--');
                          $('.select2-container').attr('style', 'width:180px !important');
                          $('.select2-results').attr('style', 'font-size:13px !important');
                      }
                  }
                },
                {name: 'Duedate', index: 'Duedate', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true, editable: true,
                    editoptions: {
                        dataInit: function (element) {
                            $(element).datepicker({
                                id: 'due_datePicker',
                                dateFormat: 'yy-mm-dd',
                                //minDate: new Date(2010, 0, 1),
                                //maxDate: new Date(2020, 0, 1),
                                showOn: 'focus'
                            });
                        }
                    }
                },               
                { name: 'Created', index: 'Created', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                {
                    name: 'Edit', index: 'Edit', width: 120, align: 'center', viewable: true, search: false, title: false, sortable: true, cellattr: function (rowId, cellValue, rowObject) {
                        return " class='editColumn'";
                    },
                 formatter: "actions",
                 formatoptions: {
                    keys: true, // we want use [Enter] key to save the row and [Esc] to cancel editing.
                    onEdit: function (rowid) {
                        // alert("in onEdit: rowid="+rowid+"\nWe don't need return anything");
                        var rowData = $(this).jqGrid('getRowData', rowid);
                        //$('#' + rowid + '_Status option[value="On Hold"]').remove();
                        $('#' + rowid + '_FunctionalDomain').css('width', '95%');
                        $('#' + rowid + '_Status option').each(function () {
                            if ($(this).val() == 'Pending for priority') {
                                $(this).remove();
                            }
                        });
                    },
                    onSuccess: function (rowid, jqXHR) {
                        var rowData = $(this).jqGrid('getRowData', rowid);
                        return true;
                    },
                    onError:function(rowid, jqXHR, textStatus) {                            
                      //  alert("Onerror");
                    },
                    afterSave: function (rowid) {
                        var rowData = $(this).jqGrid('getRowData', rowid);
                        var dueDate = rowData.Duedate;
                        var assign = rowData.Assignee;
                        if (dueDate && assign == "--Select--") {
                            alert('Please assign someone before setting due date!!');                        
                            $("#prioritizationRequest #" + rowid + " td").eq(12).text('');
                            return false;
                        }                       
                            
                        $("#loading").show();
                        SaveValue(rowData);                      
                    },
                    afterRestore: function (rowid) {
                        var rowData = $(this).jqGrid('getRowData', rowid);
                       // alert("in afterRestore (Cancel): rowid="+rowid+"\nWe don't need return anything");
                    },
                },
              }
        ],
        beforeSelectRow: function (rowid, e) {
              if (rowid !== lastsel2) {
                $('#prioritizationRequest').jqGrid('restoreRow', lastsel2);
                lastsel2 = rowid;
            }
            return true;
        },
        inlineEditing: {
            keys: true,
        },
        //ondblClickRow: function (rowid) {
        //    $(this).jqGrid('editRow', rowid, true, null, null, null, {}, function (rowid) {
        //        $(this.rows.namedItem(rowid)).hide();
        //        $(this).focus();
        //    });
        //},
        // multiselect: true,
        editurl: 'clientArray',
        pager: '#pagingPriority',
        rowNum: 15,
        rowList: [20, 30, 40],
        viewrecords: true,
        gridview: true,
        onSelectRow:editRow,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },
        caption: 'Requests'
    });

    function editRow(id) {

        if (id && id !== lastsel2) {
            jQuery('#prioritizationRequest').restoreRow(lastsel2);
            jQuery('#prioritizationRequest').editRow(id, true);
            lastsel2 = id;
        }
    }
}

function jiraLink(cellValue, options, rowObject) {
    var cellHtml = "";
    var lnk = $('#hdnJiraEnv').val() + "/browse/" + cellValue; //$('#hdnJiraEnv').val() + "/" + cellValue;
    if (cellValue !== null) {
        cellHtml = "<a class='lnkClass' href=" + lnk + " target='_blank'>" + cellValue + "</a>";
    }

    return cellHtml;
}
function jiraLink1(cellValue, options, rowObject) {
    var cellHtml = "";
    var lnk = $('#hdnJiraEnv').val() + "/browse/" + rowObject.Key; //$('#hdnJiraEnv').val() + "/" + cellValue;
    if (cellValue !== null) {
        cellHtml = "<a class='lnkClass' href=" + lnk + " target='_blank'>Approve</a>";
    }

    return cellHtml;
}

function DashboardLink(cellValue, options, rowObject) {
    var cellHtml = "";
    var lnk = rowObject.ProductionLink;
    if (cellValue !== null) {
        cellHtml = "<a class='lnkClass' href=" + lnk + " target='_blank'>Link</a>";
    }

    return cellHtml;
}

function NewFieldsDisplayMyRequest(cellValue, options, rowdata, rowObject) {
    var rowId = options.rowId + ":" + cellValue;
    return "<a href='#' class='lnkClass' title='Double click on row to view project details..' onclick=Javascript:OpenMyRequest('" + rowId + "')>" + cellValue + "</a>";
}

function NewFieldsDisplayAllRequest(cellValue, options, rowdata, rowObject) {
    var rowId = options.rowId + ":" + cellValue;
    return "<a href='#' class='lnkClass' title='Double click on row to view project details..' onclick=Javascript:OpenAllRequest('" + rowId + "')>" + cellValue + "</a>";
}

function OpenMyRequest(rowId) {
    let key;
    if (rowId.indexOf(':') > -1)
        key = rowId.split(':')[1];
    else
        key = rowId;

    var rowsData = $.grep(myRequestData, function (element, index) {
        return element.Key == key ;
    });
    var rowData = rowsData[0];

    ClearFields();
    $('#reqNo').text(key);
    $('#reqtype').text(rowData.Category);
    ShowhideFields(rowData);
}

function OpenAllRequest(rowId) {

    let key;
    if (rowId.indexOf(':') > -1)
        key = rowId.split(':')[1];
    else
        key = rowId;

    var rowsData = $.grep(allRequestData, function (element, index) {
        return element.Key == key;
    });
    var rowData = rowsData[0];

    ClearFields();
    $('#reqNo').text(key);
    $('#reqtype').text(rowData.Category);

    ShowhideFields(rowData);    
}

function ShowhideFields(rowData) {

    $('#fields tr').show();

    $('.hover_bkgr_fricc').show();

    if (rowData.Category == "New Request" || rowData.Category == "Adhoc") {
        $("#changeName").css('display', 'none');
        $("#alignedBussOwner").css('display', 'none');
    }
    if (rowData.Category == "Change Request") {
        $("#dbUserCount").css('display', 'none');
        $("#dbSecurity").css('display', 'none');
        $("#Cmowner").css('display', 'none');
        $("#frequency").css('display', 'none');
    }

    if (rowData.Summary)
        $("#spanTitle").text(rowData.Summary);

    if (rowData.UserCount)
        $("#spanUserCount").text(parseInt(rowData.UserCount));

    if (rowData.BusinessJustification)
        $("#spanJustification").text(rowData.BusinessJustification);

    if (rowData.StrategicInitiative)
        $("#spanStrategic").text(rowData.StrategicInitiative);

    if (rowData.ProductOwner)
        $("#spanBussOwner").text(rowData.ProductOwner);

    if (rowData.NameOfChangeObject)
        $("#spanChangeName").text(rowData.NameOfChangeObject);
    if (rowData.BusinessOwnerAlignment)
        $("#spanBusinessAlign").text(rowData.BusinessOwnerAlignment);

    if (rowData.DashboardSecurity)
        $("#spanDashboardSesure").text(rowData.DashboardSecurity);
    if (rowData.RefreshFrequency)
        $("#spanFrequency").text(rowData.RefreshFrequency);

    if (rowData.CMOwner)
        $("#spanCMowner").text(rowData.CMOwner);

    if (rowData.RequestDescription)
        $("#spanReqDesc").text(rowData.RequestDescription);

    if (rowData.AlternateSolution)
        $("#spanApproach").text(rowData.AlternateSolution);
  
   

}

function ClearFields() {
    $('#reqtype').text("");
    $("#spanUserCount").text("");
    $("#spanJustification").text("");
    $("#spanStrategic").text("");
    $("#spanBussOwner").text("");
    $("#spanChangeName").text("");
    $("#spanBusinessAlign").text("");
    $("#spanDashboardSesure").text("");
    $("#spanFrequency").text("");
    $("#spanCMowner").text("");
    $("#spanReqDesc").text("");
    $("#spanApproach").text("");
  
}

function SaveValue(rowData)
{   

    var jiraobj = {
        Key: rowData.Key.split('>')[1].split('<')[0],
        ProductOwner: rowData.ProductOwner,
        Assignee: rowData.Assignee,
        Priority:rowData.Priority,
        EffEstimation: rowData.EffEstimation,
        EstStartDate: rowData.EstStartDate,
        EstEndDate: rowData.EstEndDate,
        Status:rowData.Status,
        Duedate: rowData.Duedate,
        UATDate: rowData.UATDate,
        PRank: rowData.PRank,
        FunctionalDomain: rowData.FunctionalDomain
    }
    var obj = JSON.stringify(jiraobj);
    if (obj) {
        $.ajax({
            url: 'UMS.aspx/ChangeStatusOfRequests',
            data: "{ 'requestIds': '" + obj + "' }",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataFilter: function (data) { return data; },
            success: function (data) {                                          
                $("#prioritizationRequest").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
                $("#viewAllRequest").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
                PrioritizationTab();
                $("#loading").hide();
                alert('Requests are Prioritize successfully');
            },
            error: function (error) {
                console.log(JSON.stringify(error));
            }
        });
    }
}

function GetFunctionalDomain() {  
        $.ajax({
            url: 'UMS.aspx/GetFuntionalDomain',
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
            },
            error: function (error) {
                console.log(JSON.stringify(error));
            }
        });
}

function viewPrioritizationRequest() {
    
    //var userEmail = $("#hdnUserMail").val();
    //$("#prioritizationRequest").jqGrid('setGridParam', {
    //    postData: { "filters": '', "currentUser": userEmail }
    //}).trigger('reloadGrid', [{ page: 1 }]);

    $("#prioritizationRequest").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true,
        searchOnEnter: false
    });

    $('#prioritizationRequest').jqGrid('setGridWidth', gridWidth);
    EmptyIdsArrayOnTabswitching();
}

//****************************  End *********************

// **************************** Production deployment View *********************

function ProductionDeploymentView() {

    $("#productionDeploymentview").jqGrid({
        url: 'UMS.aspx/ViewProductionApprovalRequests',
        datatype: 'json',
        ignoreCase: true,
        mtype: 'POST',
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },
        ajaxGridOptions: { contentType: "application/json" },
        colNames: ['Key', 'Issue type', 'Business Function', 'Dashboard Name', 'CDS Name', 'Requested By', 'Impact', 'Approve/Reject By', 'Approval Status', 'Request Date', 'Approved Date', 'Approve'],
  
        colModel: [            
                { name: 'Key', width: 120, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Issuetype', index: 'Issuetype', width: 120, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'FunctionalDomain', index: 'FunctionalDomain', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'DashboardName', index: 'DashboardName', width: 280, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.DashboardName + '"'; } },
                { name: 'CDSName', index: 'CDSName', width: 280, align: 'center', viewable: true, search: true, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.CDSName + '"'; } },
                { name: 'Assignee', index: 'Assignee', width: 180, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'ImapctType', index: 'ImapctType', width: 100, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'ApprovedBy', index: 'ApprovedBy', width: 220, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'ApprovalStatus', index: 'ApprovalStatus', width: 190, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'DeploymentRequestDate', index: 'DeploymentRequestDate', width: 180, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'ApprovalDate', index: 'ApprovalDate', width: 180, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Approve', width: 120, align: 'center', viewable: true, search: false, title: false, sortable: true, formatter: jiraLink1 }

        ],
        pager: '#pagingproductionDeployment',
        rowNum: 15,
        loadonce: true,
        rowList: [20, 30, 40],
        viewrecords: true,
        gridview: true,          
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },
        caption: 'Requests',
    });

}

function viewProdApprovalRequest() {
    $("#productionDeploymentview").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true,
        searchOnEnter: false
    });

    $('#productionDeploymentview').jqGrid('setGridWidth', gridWidth);
    EmptyIdsArrayOnTabswitching();
}
//******************* View Change log section ****************************

function ChangeLogViewRequest() {

    $("#changeLogRequest").jqGrid({
        url: 'UMS.aspx/ViewChangeLogRequests',
        datatype: 'json',
        ignoreCase: true,
        mtype: 'POST',
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },
        ajaxGridOptions: { contentType: "application/json" },  
        colNames: ['Key', 'Dashboard Name'],// 'Product Owner'],
        colModel: [
                  { name: 'Key', width: 120, align: 'center', viewable: true,hidden:true, search: true, title: false, sortable: true },
                  { name: 'DashboardName', index: 'DashboardName', width: 250, align: 'center', viewable: true, search: true, title: false, sortable: true }
                  /*{ name: 'ProductOwner', index: 'ProductOwner', width: 250, align: 'center', viewable: false, search: false, title: false, sortable: true },*/
               
        ],
        pager: '#pagingchangeLog',
        rowNum: 15,
        loadonce: true,
        rowList: [20, 30, 40],
        viewrecords: true,
        gridview: true,
        rownumbers: true,
        subGrid: true,
        subGridRowExpanded: showNestedChildGrid,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },
        caption: 'Requests',
    });
   
}

function viewChangeLogRequest()
{
    $("#changeLogRequest").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true,
        searchOnEnter: false
    });

    $('#changeLogRequest').jqGrid('setGridWidth', gridWidth);
    EmptyIdsArrayOnTabswitching();
}

function showNestedChildGrid(parentRowID, parentRowKey) {
    var childGridID = parentRowID + "_table";
    var childGridPagerID = parentRowID + "_pager";

    var rowData = $(this).jqGrid('getRowData', parentRowKey);

    $('#' + parentRowID).append('<table id=' + childGridID + ' class = nestedGrid></table><div id=' + childGridPagerID + ' class=scroll></div>');

    $("#" + childGridID).jqGrid({
        url: 'UMS.aspx/ViewNestedChangeLogRequests',
        datatype: 'json',
        mtype: 'POST',
        postData: { filters: '', dashboardName: rowData.DashboardName },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },
        ajaxGridOptions: { contentType: "application/json" },     
        colNames: ['Key', 'Business Function','Requestor', 'Impact Type',  'Change Description', 'UAT Sign Off', 'Approved Date','BIM PM'],
        //colNames: ['Key', 'Dashboard Name', 'CDS Name', 'Requested By', 'Business Function', 'Impact','Change Description','Status', 'Deploy.Request Date', 'Approved Date', 'Approvar'],

        colModel: [
            { name: 'Key', width: 170, align: 'center', viewable: true, search: true, title: false, sortable: true, formatter: jiraLink },
            { name: 'FunctionalDomain', index: 'FunctionalDomain', width: 180, align: 'center', viewable: true, search: true, title: false, sortable: true },
            { name: 'Requestor', index: 'Requestor', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
            { name: 'ImapctType', index: 'ImapctType', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
            { name: 'ChangeDescription', index: 'ChangeDescription', width: 350, align: 'center', viewable: true, search: true, title: false, sortable: true },
            { name: 'UATSignOffUser', index: 'UATSignOffUser', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
            { name: 'ApprovalDate', index: 'ApprovalDate', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
            { name: 'BIMOwner', index: 'BIMOwner', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true }
        

            //{ name: 'DashboardName', index: 'DashboardName', width: 250, align: 'center', viewable: true, search: true, title: false, sortable: true },
            //{ name: 'CDSName', index: 'CDSName', width: 300, align: 'center', viewable: true, search: true, title: false, sortable: true },
            //{ name: 'Assignee', index: 'Assignee', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
            //{ name: 'ImapctType', index: 'ImapctType', width: 180, align: 'center', viewable: true, search: true, title: false, sortable: true },
            //{ name: 'ApprovalStatus', index: 'ApprovalStatus', width: 250, align: 'center', viewable: true, search: false, title: false, sortable: true },
            //{ name: 'DeploymentRequestDate', index: 'DeploymentRequestDate', width: 250, align: 'center', viewable: true, search: false, title: false, sortable: true },
         
        ],
        loadonce: true,
        width: 500,
        viewrecords: true,
        gridview: true,
        height: '40px !important',
        // pager: "#" + childGridPagerID,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },
        loadComplete: function () {
            if ($("#" + childGridID).getGridParam('records') === 0) {
                oldGrid = $("#" + childGridID+ " tbody").html();
                $("#" + childGridID + " tbody").html("<div class='emptyRecordmsg'>-- No Records found --</div>");
            }
            else
                oldGrid = "";
        }
    }); 
    $('#' + childGridID).jqGrid('setGridWidth', gridWidth-120);  
};
//******************* View Change log end ****************************

function EmptyIdsArrayOnTabswitching()
{
    expIds = []; priorIds = [];
    
}


