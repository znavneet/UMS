﻿
var gridWidth;
var expIds = []; var subsIds = []; var priorIds = [];
var owners;
var subsIdsOnload = [];

$(document).ready(function () {

    PeoplePickerControlInit();
    owners = $('#hdnOwners').val();
  //  JSON.stringify(console.log($('#hdnOwners').val()));

    
    $('#ddlfunctionalDomain').select2();
    $('#ddlfunctionalDomainReports').select2();    
    $('#ddlDashboardName').select2();  

 
    GetMyRequest();
    GetAllRequest();    
    GetPrioritizationRequest();

   
    $('#viewMyRequest').show();
    gridWidth = $("#gridbody").width();
    $('#btnEsclate').click(function () {
        /*  var myGrid = $('#viewMyRequest'), i, rowData, emails = "";
          for (i = 0; i < rowIds.length; i++) {
              rowData = myGrid.jqGrid("getRowData", rowIds[i]);
              if (rowData.Key) {
                  emails += rowData.Key + ';';
              }
              alert(emails);
          }
          if (emails) {
               //alert(emails);
              $('#hdnesclateMail').val(emails);
          }*/



    });
    $('#viewMyRequest').hide();

    GetQryString();

    $('#btnEdit').click(function () {
        var dt =   $("#prioritizationRequest").jqGrid('getRowData', 1);
        var localGridData = $("#prioritizationRequest").jqGrid('getGridParam', 'data'),
                       idsToDataIndex = grid.jqGrid('getGridParam', '_index'),
                       selRows = grid.jqGrid('getGridParam', 'selarrrow'),
                       dataToSend = [], i, l = selRows.length;
        for (i = 0; i < l; i++) {
            dataToSend.push(localGridData[idsToDataIndex[selRows[i]]]);
        }
    });
   
});

function getQueryString(name, url) {
    if (!url) {
        url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function GetQryString() {

   
    var tabName = $('#hdntab').val();
    var ddlCategory  = $('#hdnddlCategory').val();


    if (tabName === "Issue") {
        IssueSelected();
        ddlCategory = decodeURIComponent(ddlCategory);
        $('#ddlDashboardName').val([ddlCategory]).trigger('change');
    }
    else if(tabName === "MyRequest") {
        GridSelected(); //my request
        $('#viewRequest').jqGrid('setGridWidth', gridWidth);
    }
    else if (tabName === "AllRequest") {
        GridAllSelected(); //all request
    }  

}

function GetMyRequest() {
   
    var userEmail = $("#hdnUserMail").val();
    var newpriorRequest = "";

    $("#viewRequest").jqGrid({
        url: 'UMS.aspx/GetMyRequestData',
        datatype: 'json',
        mtype: 'POST',
        postData: { filters: '', currentUser: userEmail},
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },

        ajaxGridOptions: { contentType: "application/json" },
        loadonce: true,
        colNames: ['Key', 'Project Name', 'Summary', 'Category', 'Status', 'Priority', 'Assignee', 'Created on', 'Due Date', 'Expedite', 'Subscribe'],
        colModel: [
                 
                { name: 'Key', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'ProjectName', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Summary', index: 'Summary', width: 350, align: 'center', viewable: true, search: false, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.Summary + '"'; } },
                { name: 'Category', index: 'Category', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Status', index: 'Status', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Priority', index: 'Priority', width: 150, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Assignee', index: 'Assignee', width: 250, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Created', index: 'Created', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'Duedate', index: 'Duedate', width: 150, align: 'center', viewable: true, search: false, title: false, sortable: true },
                {
                    name: 'Expedite', width: 130, align: 'center', index: 'Expedite', key: true, search: false,
                    edittype: 'checkbox',
                    editoptions: { value: 'Yes:No' },
                    formatoptions: { disabled: false },
                    formatter: function (cellvalue, options, rowObject) {
                        return '<input type="checkbox" class="expchk" id="cbPassed-' + rowObject.Key +
                            (rowObject.active === true ? '" checked="checked" />' : '" />');
                    }
                },
                {
                    name: 'Subscribe', width: 130, align: 'center', index: 'Subscribe', key: true, search: false,
                    edittype: 'checkbox',
                    editoptions: { value: 'Yes:No'},
                    formatoptions: { disabled: false },
                    formatter: function (cellvalue, options, rowObject) {
                        var checked = "No";
                        if (rowObject.Subscribe === "Yes") {                          
                                checked = "Yes";                            
                        }
                        var sbsObj = {
                            id: rowObject.Key,
                            isChecked: checked
                        }
                        var result = $.grep(subsIdsOnload, function (e) { return e.id == rowObject.Key; });
                        if (result.length == 0) {
                            subsIdsOnload.push(sbsObj);
                        }
                       // checkForExpBtnState(expIds, subsIdsOnload);
                        return '<input type="checkbox" id="chkSubscribe-' + rowObject.Key + (rowObject.Subscribe === "Yes" ? '" checked="checked" />' : '" />');                       
                    }
                }
        ],
        beforeSelectRow: function (rowid, e) {           
            var checked = "No";
            var $self = $(this),
                iCol = $.jgrid.getCellIndex($(e.target).closest("td")[0]),
                cm = $self.jqGrid("getGridParam", "colModel"),
                localData = $self.jqGrid('getRowData', rowid);

            if (cm[iCol].name === "Expedite") {
                if ($(e.target).is(":checked")) {
                    expIds = [];
                    var expObj = {
                        id: localData.Key,
                        Title: localData.Summary,
                        Status: localData.Status,
                        LastModify:localData.LastModify,
                        CreatedOn: localData.Created
                    }
                    expIds.push(expObj);
                }
                else {
                    if ($(e.target).prop('checked') == false) {
                        expIds = $.grep(expIds, function (e) {
                            return e.id != localData.Key;
                        });
                    }
                }
            }
            if (cm[iCol].name === "Subscribe") {
                if ($(e.target).is(":checked")) {
                    var checked = "Yes";                   
                    $.each(subsIdsOnload, function () {
                        if (this.id == localData.Key) {
                            this.isChecked = checked;
                        }
                    });
                }
                else {
                    if ($(e.target).prop('checked') == false) {
                        var checked = "No";
                        $.each(subsIdsOnload, function () {
                            if (this.id == localData.Key) {
                                this.isChecked = checked;
                            }
                        });
                    }
                }
            }
            $('input.expchk').on('change', function () {
                $('input.expchk').not(this).prop('checked', false);
            });
            console.log(expIds);
            console.log(subsIdsOnload);
            $('#hdnSubsIds').val(JSON.stringify(subsIdsOnload));
            $('#hdnExpIds').val(JSON.stringify(expIds));
            //checkForExpBtnState(expIds, subsIdsOnload);
            return true; // allow selection
        },
        onPaging: function (pgButton) {
            subsIdsOnload = [];
            expIds = [];
        },
       // multiselect: true,
        pager: '#pagingGrid',
        rowNum: 14,
        rowList: [20, 30, 40],
        viewrecords: true,
        gridview: true,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },
        caption: 'Requests'        
    }); 

}

function checkForExpBtnState(expids, subsIdsOnload) {

    $.each(subsIdsOnload, function () {
        if (this.isChecked == "Yes") {
            $("#btnEsclate").prop('disabled', false);
        }
        else
            $("#btnEsclate").prop('disabled', true);
    });
   
}

function viewMyRequest() {

   //// var userEmail = $("#" + '<%= hdnUserMail.ClientID%>').val();
   // var userEmail = $("#hdnUserMail").val();
   // $("#viewRequest").jqGrid('setGridParam', {
   //     postData: { "filters": '', "currentUser": userEmail }
    // }).trigger('reloadGrid', [{ page: 1 }]);

    $("#viewRequest").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true
    });

    $('#viewRequest').jqGrid('setGridWidth', gridWidth);
    EmptyIdsArrayOnTabswitching();  // empty array when switchng tabs

}


//******************* View All request section ****************************

function GetAllRequest() {

    $("#viewAllRequest").jqGrid({
        url: 'UMS.aspx/GetAllProjectRequests',
        datatype: 'json',
        mtype: 'POST',
       // postData: { filters: '', currentUser: userEmail, newRequest: newpriorRequest },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },

        ajaxGridOptions: { contentType: "application/json" },
       // loadonce: true,
        colNames: ['Key','Project Name', 'Requestor', 'Summary', 'Category', 'Status', 'Priority', 'Assignee', 'Created on', 'Due Date', 'Assignee Email'],
        colModel: [
                { name: 'Key', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'ProjectName', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Requestor', index: 'Requestor', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Summary', index: 'Summary', width: 350, align: 'center', viewable: true, search: false, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.Summary + '"'; } },
                { name: 'Category', index: 'Category', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Status', index: 'Status', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Priority', index: 'Priority', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Assignee', index: 'Assignee', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Created', index: 'Created', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'Duedate', index: 'Duedate', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'AssigneeEmail', index: 'AssigneeEmail', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true, hidden: true, }

        ],
        pager: '#pagingAllGrid',
        rowNum: 14,
        loadonce: true,
        rowList: [20, 30, 40],
        viewrecords: true,
        gridview: true,
        subGrid: true,
        subGridRowExpanded: showChildGrid,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },
        caption: 'Requests'
    });
}

function showChildGrid(parentRowID, parentRowKey) {
    var childGridID = parentRowID + "_table";
    var childGridPagerID = parentRowID + "_pager";

    // send the parent row primary key to the server so that we know which grid to show
   // var childGridURL = parentRowKey + ".json";

    // add a table and pager HTML elements to the parent grid row - we will render the child grid here
    $('#' + parentRowID).append('<table id=' + childGridID + '></table><div id=' + childGridPagerID + ' class=scroll></div>');

    $("#" + childGridID).jqGrid({
        url: 'test.aspx/GetNestedtDatabyKey',
        datatype: 'json',
        mtype: 'POST',
        postData: { filters: '', key: parentRowKey },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },
        ajaxGridOptions: { contentType: "application/json" },
        colNames: ['Key','Bussiness Functions', 'Rank','Product Owner', 'Category'],
        colModel: [
            {name: 'Key', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
            {name: 'FunctionalDomain', index: 'FunctionalDomain', width: 280, align: 'center', viewable: true, search: true, title: false, sortable: true},
            {name: 'PRank', index: 'PRank', width: 100, align: 'center', viewable: true, search: false, title: false, sortable: true},
            {name: 'ProductOwner', index: 'ProductOwner', width: 360, align: 'center', viewable: true, search: true, title: false, sortable: true},
            {name: 'Category', index: 'Category', width: 250, align: 'center', viewable: true, search: true, title: false, sortable: true }
        ],
        loadonce: true,
        width: 500,
        viewrecords: true,
        gridview: true,
        height: '40px !important',
      // pager: "#" + childGridPagerID,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },
    });
    $(".ui-subgrid .ui-jqgrid-view").css('height', '80px');
};

function viewAllRequest() {   
    $("#viewAllRequest").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true
    });
  
    $('#viewAllRequest').jqGrid('setGridWidth', gridWidth);

}


///******************* Prioritization Request tab ********

function GetPrioritizationRequest() {  
   
    var lastsel2 = "";

    $("#prioritizationRequest").jqGrid({
        url: 'UMS.aspx/GetNewRequestsToPrioritize',
        datatype: 'json',
        mtype: 'POST',
      //  postData: { filters: '', newRequest: newpriorRequest },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
        },

        ajaxGridOptions: { contentType: "application/json" },
        loadonce: true,
        colNames: ['Select', 'Key', 'Requestor', 'Summary', 'Project Area', 'Category', 'Buss. Functions', 'Status', 'Priority', 'Rank', 'Product Owner', 'Est.Effort', 'Assign To', 'Due Date', 'Created on', 'Edit'],
        colModel: [
                 {
                     name: 'Select', width: 110, align: 'center', index: 'Select', key: true,
                     edittype: 'checkbox',
                     hidden:true,
                     editoptions: { value: 'Yes:No', defaultValue: 'Yes' },
                     formatoptions: { disabled: false },
                     formatter: function (cellvalue, options, rowObject) {
                         return '<input type="checkbox" id="cbprior-' + rowObject.id +
                             (rowObject.active === true ? '" checked="checked" />' : '" />');
                     }
                 },
                { name: 'Key', width: 220, align: 'center', viewable: true, search: true, title: false, sortable: true ,formatter: jiraLink },
                { name: 'Requestor', index: 'Requestor', width: 300, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'Summary', index: 'Summary', width: 350, align: 'center', viewable: true, search: false, title: false, sortable: true, cellattr: function (rowId, val, rawObject) { return ' title="' + rawObject.Summary + '"'; } },
                { name: 'ProjectArea', index: 'ProjectArea', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true, hidden:true },
                { name: 'Category', index: 'Category', width: 250, align: 'center', viewable: true, search: true, title: false, sortable: true },
                {
                    name: 'FunctionalDomain', index: 'FunctionalDomain', width: 280, align: 'center', viewable: true, search: true, title: false, sortable: true,
                    editable: true,
                    edittype: 'select',
                    editoptions: {
                        value: $('#hdnFunctionalDomain').val(),
                        dataInit: function (element) {
                          //  $(element).select2();
                          //  $(element).attr('style', 'height:32px !important');
                          //  $('.select2-selection__rendered').text('--Select--');
                          //  $(element).attr('style', 'width:130px !important');
                          //  $('.select2-results').attr('style', 'font-size:13px !important');
                        }
                    }
                },
                { name: 'Status', index: 'Status', width: 180, align: 'center', viewable: true, search: true, title: false, sortable: true, editable: true, formatter: 'select', edittype: "select", editoptions: { value: 'New:New;Prioritized:Prioritized;On hold:On hold;Rejected:Rejected', defaultValue: 'New' } },
                { name: 'Priority', index: 'Priority', width: 180, align: 'center', viewable: true, search: true, title: false, sortable: true, editable: true, formatter: 'select', edittype: "select", editoptions: { value: 'Highest:Highest;High:High;Medium:Medium;Low:Low;Lowest:Lowest', defaultValue: 'Medium' } },
                {
                    name: 'PRank', index: 'PRank', width: 100, align: 'center', viewable: true, search: false, title: false, sortable: true, editable: true, formatter: 'select', edittype: "select",
                    editoptions: { value: '1:1;2:2;3:3;4:4;5:5;6:6;7:7;8:8;9:9;10:10;11:11;12:12;13:13;14:14;15:15;16:16;17:17;18:18;19:19;20:20', defaultValue: '1' }
                },
                {
                    name: 'ProductOwner', index: 'ProductOwner', width: 360, align: 'center', viewable: true, search: true, title: false, sortable: true, editable: true, formatter: 'select',
                    edittype: "select",
                    editoptions: {
                        value: $('#hdnOwners').val(),
                        dataInit: function (element) {                         
                        }
                    }
                },                
                {
                    name: 'EffEstimation', index: 'EffEstimation', width: 130, align: 'center', viewable: true, search: false, title: false, sortable: true, editable: true, cellattr: function (rowId, cellValue, rowObject) {
                        return 'title="(eg. 3w 4d 12h)"';
                    }
                },
                {
                    name: 'Assignee', index: 'Assignee', width: 360, align: 'center', viewable: true, search: true, title: false, sortable: true,
                  editable: true,
                  edittype: 'select',
                  editoptions: {
                      value: $('#hdnJiraUsers').val(),
                      dataInit: function (element) {
                          $(element).select2();
                          $('.select2-selection').attr('style', 'height:32px !important');
                          $('.select2-selection__rendered').text('--Select--');
                          $('.select2-container').attr('style', 'width:180px !important');
                          $('.select2-results').attr('style', 'font-size:13px !important');
                      }
                  }
                },
                {name: 'Duedate', index: 'Duedate', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true, editable: true,
                    editoptions: {
                        dataInit: function (element) {
                            $(element).datepicker({
                                id: 'due_datePicker',
                                dateFormat: 'yy-mm-dd',
                                //minDate: new Date(2010, 0, 1),
                                //maxDate: new Date(2020, 0, 1),
                                showOn: 'focus'
                            });
                        }
                    }
                },               
                { name: 'Created', index: 'Created', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                {
                    name: 'Edit', index: 'Edit', width: 120, align: 'center', viewable: true, search: false, title: false, sortable: true, cellattr: function (rowId, cellValue, rowObject) {
                        return " class='editColumn'";
                    },
                 formatter: "actions",
                 formatoptions: {
                    keys: true, // we want use [Enter] key to save the row and [Esc] to cancel editing.
                    onEdit:function(rowid) {
                        // alert("in onEdit: rowid="+rowid+"\nWe don't need return anything");
                        var rowData = $(this).jqGrid('getRowData', rowid);
                    },
                    onSuccess: function (rowid, jqXHR) {
                        var rowData = $(this).jqGrid('getRowData', rowid);
                        return true;
                    },
                    onError:function(rowid, jqXHR, textStatus) {                            
                      //  alert("Onerror");
                    },
                    afterSave: function (rowid) {
                        var rowData = $(this).jqGrid('getRowData', rowid);
                        var dueDate = rowData.Duedate;
                        var assign = rowData.Assignee;
                        if (dueDate && assign == "--Select--") {
                            alert('Please assign someone before setting due date!!');                        
                            $("#prioritizationRequest #" + rowid + " td").eq(12).text('');
                            return false;
                        }                       
                            
                        $("#loading").show();
                        SaveValue(rowData);                      
                    },
                    afterRestore: function (rowid) {
                        var rowData = $(this).jqGrid('getRowData', rowid);
                       // alert("in afterRestore (Cancel): rowid="+rowid+"\nWe don't need return anything");
                    },
                },
              }
        ],
        beforeSelectRow: function (rowid, e) {
            //  if (rowid !== lastsel2) {
            //    $('#prioritizationRequest').jqGrid('restoreRow', lastsel2);
            //    lastsel2 = rowid;
            //}
            //return true;
        },
        inlineEditing: {
            keys: true,
        },
        //ondblClickRow: function (rowid) {
        //    $(this).jqGrid('editRow', rowid, true, null, null, null, {}, function (rowid) {
        //        $(this.rows.namedItem(rowid)).hide();
        //        $(this).focus();
        //    });
        //},
        // multiselect: true,
        editurl: 'clientArray',
        pager: '#pagingPriority',
        rowNum: 14,
        rowList: [20, 30, 40],
        viewrecords: true,
        gridview: true,
        onSelectRow:editRow,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },
        caption: 'Requests'
    });

    function editRow(id) {

        if (id && id !== lastsel2) {
            jQuery('#prioritizationRequest').restoreRow(lastsel2);
            jQuery('#prioritizationRequest').editRow(id, true);
            lastsel2 = id;
        }
    }
}



function jiraLink(cellValue, options, rowObject) {
    var cellHtml = "";
    var lnk = $('#hdnJiraEnv').val() + "/browse/" + cellValue; //$('#hdnJiraEnv').val() + "/" + cellValue;
    if (cellValue !== null) {
        cellHtml = "<a class='lnkClass' href=" + lnk + " target='_blank'>" + cellValue + "</a>";
    }

    return cellHtml;
}

function SaveValue(rowData)
{   

    var jiraobj = {
        Key: rowData.Key.split('>')[1].split('<')[0],
        ProductOwner: rowData.ProductOwner,
        Assignee: rowData.Assignee,
        Priority:rowData.Priority,
        EffEstimation: rowData.EffEstimation,
        EstStartDate: rowData.EstStartDate,
        EstEndDate: rowData.EstEndDate,
        Status:rowData.Status,
        Duedate: rowData.Duedate,
        UATDate: rowData.UATDate,
        PRank: rowData.PRank,
        FunctionalDomain: rowData.FunctionalDomain
    }
    var obj = JSON.stringify(jiraobj);
    if (obj) {
        $.ajax({
            url: 'UMS.aspx/ChangeStatusOfRequests',
            data: "{ 'requestIds': '" + obj + "' }",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataFilter: function (data) { return data; },
            success: function (data) {                                          
                $("#prioritizationRequest").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
                PrioritizationTab();
                $("#loading").hide();
                alert('Requests are Prioritize successfully');
            },
            error: function (error) {
                console.log(JSON.stringify(error));
            }
        });
    }
}

function GetFunctionalDomain() {  
        $.ajax({
            url: 'UMS.aspx/GetFuntionalDomain',
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
            },
            error: function (error) {
                console.log(JSON.stringify(error));
            }
        });
}

function viewPrioritizationRequest() {
    
    //var userEmail = $("#hdnUserMail").val();
    //$("#prioritizationRequest").jqGrid('setGridParam', {
    //    postData: { "filters": '', "currentUser": userEmail }
    //}).trigger('reloadGrid', [{ page: 1 }]);

    $("#prioritizationRequest").jqGrid('filterToolbar', {
        stringResult: true,
        defaultSearch: "cn",
        searchOperators: true
    });

    $('#prioritizationRequest').jqGrid('setGridWidth', gridWidth);
    EmptyIdsArrayOnTabswitching();
}

//****************************  PrioritizationRequest end *********************

function EmptyIdsArrayOnTabswitching()
{
    expIds = []; priorIds = [];
    
}



//*******************************