﻿
$(document).ready(function () {
    $('#btnPrioritize').click(function () {
        $("#loading").show();
        ChangeStatusOfRequests();
    });

    //$('#btnEsclate').click(function () {
    //    ChangeSusbcriptionOfRequests();
    //});
});

function ShowLoading()
{
    $("#loading").show();
}

function ChangeStatusOfRequests() {

    var ids = priorIds.toString();
    if (ids) {
        $.ajax({
            url: 'UMS.aspx/ChangeStatusOfRequests',
            data: "{ 'requestIds': '" + ids + "' }",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataFilter: function (data) { return data; },
            success: function (data) {
                console.log(data);
                alert('Requests are Prioritize successfully');
                window.location = window.location.href;
            },
            error: function (error) {
                console.log(JSON.stringify(error));
            }
        });
    }
}

function ChangeSusbcriptionOfRequests() {

    var ids = JSON.stringify(subsIdsOnload);
    if (ids) {
        $.ajax({
            url: 'UMS.aspx/ChangeSusbcriptionOfRequests',
            data: "{ 'requestIds': '" + ids + "' }",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataFilter: function (data) { return data; },
            success: function (data) {
                console.log(data);
            },
            error: function (error) {
                console.log(JSON.stringify(error));
            }
        });
    }

}

function SendEsclationRequests() {

    var ids = JSON.stringify(subsIdsOnload);
    if (ids) {
        $.ajax({
            url: 'UMS.aspx/ChangeSusbcriptionOfRequests',
            data: "{ 'requestIds': '" + ids + "' }",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataFilter: function (data) { return data; },
            success: function (data) {
                console.log(data);
            },
            error: function (error) {
                console.log(JSON.stringify(error));
            }
        });
    }

}


