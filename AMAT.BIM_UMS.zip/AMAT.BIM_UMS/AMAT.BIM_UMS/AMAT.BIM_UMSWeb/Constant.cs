﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Web;

namespace AMAT.BIM_UMSWeb
{
    public class Constant
    {
        private string userId = Convert.ToString(ConfigurationManager.AppSettings["UserID"]);
        private string password = Convert.ToString(ConfigurationManager.AppSettings["Pwd"]);
        private string jiraUrl = Convert.ToString(ConfigurationManager.AppSettings["JIRAUrl"]);

      //  public const string ProjectIdQA = "12001";    // BIMDB project ID for QA
        public const string ProjectIdQA = "12100";      // BIMDBQA project ID for QA

        public const string BimIssueIdQA = "10302";   // BIMDB  user-story ID QA
        public const string BugIssueIdQA = "10300";   // BIMDB  bug ID QA

        public const string ProjectId = "11601";       // BIMDB project ID for Prod  
      //  public const string ProjectId = "12600";       // BIMDBQA project ID for Prod  
        public const string BimIssueId = "10202";      // e.g: User story Prod
        public const string BugIssueId = "10200";      // e.g: Bug Prod

        public const string EPICField = "customfield_10100";

        public const string BIMEpicNameQA = "BIMDB-14"; // for BIMDB  //"BIM-81" for BIM;
        public const string IssueEpicNameQA = "BIMDB-12";

        public const string BIMEpicName = "BIM-2439";
        public const string IssueEpicName = "BIM-1464";

        public const string COOEpicName = "BIM-5";
        public const string SP3EpicName = "BIM-5";
        public const string BIMAAEpicName = "BIM-5";
        public const string TestEpicName = "Test Epic";

        public const string BIMEpicString = "BIM Request";
        public const string IssueEpicString = "Issues";

        public const string BIMProject = "BIM";
        public const string BIMDBProject = "BIMDB";
        public const string BIMAAProject = "BIMAA";
        public const string COOProject = "COO";
        public const string SP3Project = "SP3";

        public const string BIMDMProject = "BIMDM";
        public const string BIMDAProject = "BIMDA";
        public const string PLProject = "PL";
        public const string BIMSIProject = "BIMSI";
        public const string SSCMProject = "SSCM";
       
        
        
        public const string BIM_SupportFormUserMail = "BIM-Support-GLOBAL-F@amat.com";

        public const string Development = "Development";
        public const string ToDo = "To Do";
        public const string InDevelopment = "In Development";
        public const string UnitTesting = "Unit Testing";
        public const string QAReady = "Ready for QA";
        public const string QA = "QA";
        public const string UAT = "UAT";
        public const string DeploymentReady = "Deployment Ready";
        public const string Resolved = "Resolved";
        public const string Deployed = "Deployed";
        public const string Closed = "Closed";
        public const string Done = "Done";
        public const string Testing = "Testing";
        public const string NewRequest = "New Request";
        public const string ChangeRequest = "Change Request";
        public const string Adhoc = "Adhoc";

        public const string BIM_CatalogList = "BIM_Catalog";
        public const string BIM_ChangeObjectList = "ChangeObjects";
        public const string RMS_UsersList = "RMS_Users";
        public const string FunctionalDomainList = "BIM_FunctionalDomain";
        public const string RMSEmailTemplate = "RMSEmailTemplate";
    
       
        public const string ProductOwnerField = "Product_Owner";
        public const string JIRAField = "JIRA_Users";


         public const string JiraProdLinkUrl = "https://dtr.amat.com";

      //  public const string JiraShortUrlShortQA = "http://dcalqa792:8580";
        //public const string JiraShortUrlShort = "https://dtr.amat.com"; 

        public const string JiraShortUrlShort = "http://dcalpa791:8580";

        public const string JiraShortUrlShortQA = "https://dtr-qa.amat.com";

        // JIRA  internal fields names
        // for QA
         public const string PrioritizationRankQA = "customfield_12801";
         public const string FunctionalDomainQA = "customfield_12800";
         public const string PrioritizationStatusQA = "customfield_10511";        
         public const string ProductOwnerQA = "customfield_12704";

         // for prod
         public const string PrioritizationRank = "customfield_11111";
         public const string FunctionalDomain = "customfield_11006";
         public const string PrioritizationStatus = "customfield_10508";
         public const string ProductOwner = "customfield_11202";
         
         public const string Businessfunction = "Business function";
         public const string ProductOwners = "Product Owner";
         public const string AssignTo = "Assign To";       
         public const string Status = "Status";
         public const string Priorty = "Priorty";
         public const string Rank = "Rank";
         public const string BIMDBQAProject = "BIMDBQA";
         public const string Select = "--Select--";
         public const string Other = "Other";


        public string UserId
        {
            get
            {
                return this.userId;
            }
            set
            {
                this.userId = value;
            }
        }
        public string Password
        {
            get
            {
                return this.password;
            }
            set
            {
                this.password = value;
            }
        }
        public string JiraUrl
        {
            get
            {
                return this.jiraUrl;
            }
            set
            {
                this.jiraUrl = value;
            }
        }

        public const string JiraUrlForCreatingQA  = "https://dtr-qa.amat.com/rest/api/2/issue/";
        public const string JiraUrlForSearchingQA = "https://dtr-qa.amat.com/rest/api/2/search?";

       // public const string JiraUrlForCreatingQA = "http://dcalqa792:8580/rest/api/2/issue/";
      //  public const string JiraUrlForSearchingQA = "http://dcalqa792:8580/rest/api/2/search?";

        //public const string JiraForCreating = "https://dtr.amat.com/rest/api/2/issue/";
        //public const string JiraForSearching = "https://dtr.amat.com/rest/api/2/search?";

        public const string JiraForCreating = "http://dcalpa791:8580/rest/api/2/issue/";
        public const string JiraForSearching = "http://dcalpa791:8580/rest/api/2/search?";

        public const string JiraForCreatemetaQA = "https://dtr-qa.amat.com/rest/api/latest/issue/createmeta?";

        //public const string JiraForCreatemeta = "https://dtr.amat.com/rest/api/latest/issue/createmeta?";

        public const string JiraForCreatemeta = "http://dcalpa791:8580/rest/api/latest/issue/createmeta?";


        public const string ErrorLogList = "ErrorLogList";

        /// <summary>
        /// for logging the errors in list
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="errorMessage"></param>
        /// <param name="stackTrace"></param>
        /// <param name="source"></param>
        /// <param name="method"></param>
        /// <param name="pageName"></param>
        public static void ErrorLog(ClientContext clientContext, string errorMessage, string source, string method, string pageName)
        {

            List logList = clientContext.Web.Lists.GetByTitle(ErrorLogList);
            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
            ListItem item = logList.AddItem(itemCreateInfo);
            item["Message"] = errorMessage;
            item["Source"] = source;
            item["Method"] = method;
            item["PageName"] = pageName;
            item.Update();
            clientContext.ExecuteQuery();

        }
        public static ErrorLogClass ErrorLog(string errorMessage, string source, string method, string pageName)
        {
            ErrorLogClass obj = new ErrorLogClass();
            obj.ErrorMessage = errorMessage;
            obj.Source = source;
            obj.Method = method;
            obj.PageName = pageName;
            obj.ErrorMessage = errorMessage;
            return obj;
        }

        public static List<string> GetADUsers(string username)
        {
            List<string> lstADUsers = new List<string>();
            using (PrincipalContext context = new PrincipalContext(ContextType.Domain))
            {
                UserPrincipal user = new UserPrincipal(context);
                user.DisplayName = username + "*";
                using (PrincipalSearcher srch = new PrincipalSearcher(user))
                {
                    foreach (var result in srch.FindAll())
                    {
                        DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;
                        string usersWithName, employeeID;
                        if (!String.IsNullOrEmpty((String)de.Properties["displayName"].Value))
                        {
                          //  usersWithName = de.Properties["displayName"].Value.ToString();
                          //  lstADUsers.Add(usersWithName);
                            employeeID = de.Properties["sAMAccountName"].Value.ToString();
                            lstADUsers.Add(employeeID);
                        }
                    }
                }
            }
            return lstADUsers;
        }

    }
}