﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AMAT.BIM_UMSWeb
{
    public class JiraClass
    {

    }
    public class GridRow
    {
        public string Key { get; set; }
        public string ProjectName { get; set; }
        public string Requestor { get; set; }
        public string RequestorEmail { get; set; }
        public string Summary { get; set; }
        public string ProjectArea { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }
        public string Priority { get; set; }
        public object Assignee { get; set; }
        public string Created { get; set; }
        public string Duedate { get; set; }
        public string LastModify { get; set; }
        public string Subscribe { get; set; }
        public string AssigneeEmail { get; set; }
        public string EffEstimation { get; set; }
        public string EstStartDate { get; set; }
        public string EstEndDate { get; set; }
        public string UATDate { get; set; }
        public string ProductOwner { get; set; }
        public string PRank { get; set; }
        public string FunctionalDomain { get; set; }
        public int ID { get; set; }

        // Change log fields
        public string DashboardName { get; set; }
        public string CDSName { get; set; }
        public string Owner { get; set; }
        public string BIMOwner { get; set; }
        public string ChangeDescription { get; set; }
        public string ImapctType { get; set; }
        public string ApprovedBy { get; set; }
        public string DeploymentRequestDate { get; set; }
        public string ApprovalDate { get; set; }
        public string ApprovalComments { get; set; }
        public string ApprovalStatus { get; set; }
        public string Issuetype { get; set; }
        public string UATSignOffUser { get; set; }
        public string ProductionLink { get; set; }

        //New fields added
        public string NameOfChangeObject { get; set; } // dashboard/report name
        public string UserCount { get; set; } // user count
        public string BusinessJustification { get; set; } // Business Justification
        public string StrategicInitiative { get; set; } // Strategic Initiative
        public string DashboardSecurity { get; set; } // dashboard Security 
        public string RefreshFrequency { get; set; } // Refresh Frequency
        public string CMOwner { get; set; } // CM Owner
        public string AlternateSolution { get; set; } // Alternate Solution
        public string BusinessOwnerAlignment { get; set; } // Aligned with Business Owner
        public string RequestDescription { get; set; } // Request Description


    }

    public class DashBoardName
    {
        public string id { get; set; }
        public string DashboardName { get; set; }
    }
    public class SubscriptionObject
    {
        public string id { get; set; }
        public string isChecked { get; set; }
    }

    public class EsclateObject
    {
        public string id { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public string CreatedOn { get; set; }
        public string LastModify { get; set; }
    }
    public class Customfield10509
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
    }

    public class AvatarUrls
    {
        public string __invalid_name__48x48 { get; set; }
        public string __invalid_name__24x24 { get; set; }
        public string __invalid_name__16x16 { get; set; }
        public string __invalid_name__32x32 { get; set; }
    }

    public class Assignee
    {
        public string self { get; set; }
        public string name { get; set; }
        public string key { get; set; }
        public string emailAddress { get; set; }
        public AvatarUrls avatarUrls { get; set; }
        public string displayName { get; set; }
        public bool active { get; set; }
        public string timeZone { get; set; }
    }

    public class AvatarUrls2
    {
        public string __invalid_name__48x48 { get; set; }
        public string __invalid_name__24x24 { get; set; }
        public string __invalid_name__16x16 { get; set; }
        public string __invalid_name__32x32 { get; set; }
    }

    public class Reporter
    {
        public string self { get; set; }
        public string name { get; set; }
        public string key { get; set; }
        public string emailAddress { get; set; }
        public AvatarUrls2 avatarUrls { get; set; }
        public string displayName { get; set; }
        public bool active { get; set; }
        public string timeZone { get; set; }
    }

    public class Progress
    {
        public int progress { get; set; }
        public int total { get; set; }
    }

    public class Issuetype
    {
        public string name { get; set; }
        public Fields Fields { get; set; }
    }

    public class AvatarUrls3
    {
        public string __invalid_name__48x48 { get; set; }
        public string __invalid_name__24x24 { get; set; }
        public string __invalid_name__16x16 { get; set; }
        public string __invalid_name__32x32 { get; set; }
    }

    public class Project
    {
        public string self { get; set; }
        public string id { get; set; }
        public string key { get; set; }
        public string name { get; set; }
        public AvatarUrls3 avatarUrls { get; set; }
        public List<Issuetype> Issuetypes { get; set; }
    }

    public class Watches
    {
        public string self { get; set; }
        public int watchCount { get; set; }
        public bool isWatching { get; set; }
    }

    public class Priority
    {
        public string self { get; set; }
        public string iconUrl { get; set; }
        public string name { get; set; }
        public string id { get; set; }
    }

    public class timetracking
    {
        public string originalEstimate { get; set; }
    }

    public class StatusCategory
    {
        public string self { get; set; }
        public int id { get; set; }
        public string key { get; set; }
        public string colorName { get; set; }
        public string name { get; set; }
    }

    public class customfield_12801  // rank qa
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
    }
    public class customfield_11111  //rank prod
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Status
    {
        public string self { get; set; }
        public string description { get; set; }
        public string iconUrl { get; set; }
        public string name { get; set; }
        public string id { get; set; }
        public StatusCategory statusCategory { get; set; }
    }

    public class Customfield10207
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
    }

    public class Customfield10208
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
    }

    public class AvatarUrls4
    {
        public string __invalid_name__48x48 { get; set; }
        public string __invalid_name__24x24 { get; set; }
        public string __invalid_name__16x16 { get; set; }
        public string __invalid_name__32x32 { get; set; }
    }

    public class Creator
    {
        public string self { get; set; }
        public string name { get; set; }
        public string key { get; set; }
        public string emailAddress { get; set; }
        public AvatarUrls4 avatarUrls { get; set; }
        public string displayName { get; set; }
        public bool active { get; set; }
        public string timeZone { get; set; }
    }
    public class customfield_12800    // functional domain QA
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class customfield_11006    // functional domain Prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class AllowedValue
    {
        public string Self { get; set; }
        public string Id { get; set; }
        public string Description { get; set; }
        public string IconUrl { get; set; }
        public string Name { get; set; }
        public bool Subtask { get; set; }
        public string Value { get; set; }
        public bool Disabled { get; set; }
        public string Key { get; set; }
        public string ProjectTypeKey { get; set; }
        public AvatarUrls AvatarUrls { get; set; }
    }
    public class customfield_12704   // product owner qa
    {
        public string name { get; set; }
        public string key { get; set; }
        public string emailAddress { get; set; }
        public string displayName { get; set; }

    }
    public class customfield_11202   // product owner prod
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public string displayName { get; set; }

    }

    public class Aggregateprogress
    {
        public int progress { get; set; }
        public int total { get; set; }
    }

    public class Customfield10438
    {
        public string value { get; set; }
        public string id { get; set; }
    }

    public class Customfield10540  // category for qa
    {
        public string value { get; set; }
        public string id { get; set; }
    }

    public class customfield_12605   // Issue Subscribe for qa
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
    }

    // ********** Change log Production fields**************

    public class customfield_10713  // category for prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class customfield_12207   // Issue Subscribe for prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield12615 // Dashbaord name for prod
    {
        public string self { get; set; }
        public string value { get; set; }
        public string id { get; set; }
        public bool disabled { get; set; }
    }
    public class Customfield12607  // for CDS names in prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield12609   // product owner on approval form for prod
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public AvatarUrls avatarUrls { get; set; }
        public string displayName { get; set; }
    }
    public class Customfield12610   // BIM PM on approval form for prod
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public string displayName { get; set; }
    }
    public class Customfield12605   //impact type in approval form for prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield12702
    {
        public string value { get; set; }
        public string id { get; set; }
    }

    public class Customfield12914   // Approve reject by prod
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public AvatarUrls avatarUrls { get; set; }
        public string displayName { get; set; }

    }

    // ***********  End here **********

    //-- change log for qa

    public class Customfield13000   // BIM owner qa
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public string displayName { get; set; }
    }

    public class Customfield13003 //dashboard name qa
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield13004  // CDS name qa
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield12905 // impact type qa
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield12908
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield10516 // approved by qa
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public string displayName { get; set; }
    }




    public class Fields
    {
        public object resolution { get; set; }
        public object customfield_10510 { get; set; }
        public object customfield_10742 { get; set; }
        public string customfield_10501 { get; set; }
        public object customfield_12700 { get; set; }  // requestor mail QA       
        public string customfield_12208 { get; set; }  // requestor mail prod       
        public List<Customfield12607> customfield_12607 { get; set; } // for CDS Name for prod
        public string customfield_12608 { get; set; }  // for log change desc for prod
                                                       // public string customfield_12704 { get; set; }  // approve date for prod 
        public List<Customfield12615> customfield_12615 { get; set; }// Dashboard name for prod
        public Customfield12605 customfield_12605 { get; set; }  // impact type for prod
        public Customfield12914 customfield_12914 { get; set; } // Approve/reject by prod
        public string customfield_12703 { get; set; } //  deployment reuest date
        public string customfield_12910 { get; set; } // dashboard link for prod
        public string customfield_12913 { get; set; } // Approve date
        public string customfield_12911 { get; set; } // production dashboard Link QA
        public Customfield12702 customfield_12702 { get; set; } //  Approval status, in approval form prod
        public Customfield12609 customfield_12609 { get; set; } // product owner on approval form for prod
        public Customfield12610 customfield_12610 { get; set; } // BIM PM on approval form for prod

        // Change log for QA
        public Customfield13000 customfield_13000 { get; set; } // Product owner qa
        public string customfield_13006 { get; set; } // BIM owner qa
        public List<Customfield13003> customfield_13003 { get; set; } //dashboard name qa
        public List<Customfield13004> customfield_13004 { get; set; } // CDS name qa
        public Customfield12905 customfield_12905 { get; set; } // impact type qa
        public string customfield_12902 { get; set; } // deployment request date qa
        public string customfield_12903 { get; set; } // Approved date qa
      //  public Customfield12908 customfield_12908 { get; set; } // approval status qa
        public string customfield_12904 { get; set; } // Change description
        public List<string> customfield_10504 { get; set; }
        public Customfield10509 customfield_10509 { get; set; }
        public DateTime? lastViewed { get; set; }
        public object customfield_10740 { get; set; }
        public object customfield_10741 { get; set; }
        public object customfield_10731 { get; set; }
        // public double customfield_10733 { get; set; }
        public object customfield_10734 { get; set; }
        public object customfield_10735 { get; set; }
        public object aggregatetimeoriginalestimate { get; set; }
        public object customfield_10736 { get; set; }
        public object customfield_10737 { get; set; }
        public object customfield_10738 { get; set; }
        public object customfield_10739 { get; set; }
        public List<object> issuelinks { get; set; }
        public Assignee assignee { get; set; }
        public object customfield_10171 { get; set; }
        public object customfield_10720 { get; set; }
        public object customfield_10600 { get; set; }
        public object customfield_10601 { get; set; }
        public object customfield_10602 { get; set; }
        public object customfield_10603 { get; set; }
        public List<object> subtasks { get; set; }
        public object customfield_10161 { get; set; }
        public Reporter reporter { get; set; }
        public object customfield_10164 { get; set; }
        public object customfield_10168 { get; set; }
        public object customfield_10169 { get; set; }
        public object customfield_10830 { get; set; }
        public object customfield_10831 { get; set; }
        public object customfield_10710 { get; set; }
        public object customfield_10832 { get; set; }
        public object customfield_10711 { get; set; }
        public object customfield_10833 { get; set; }
        public object customfield_10712 { get; set; }
        public object customfield_10834 { get; set; }
        // public object customfield_10713 { get; set; }
        public customfield_12605 customfield12605 { get; set; }  // requestor mail for QA 
        public customfield_12207 customfield_12207 { get; set; }  // requestor mail for prod 
        public object customfield_10835 { get; set; }
        public object customfield_10714 { get; set; }
        public object customfield_10715 { get; set; }
        public object customfield_10716 { get; set; }
        public object customfield_10717 { get; set; }
        public object customfield_10718 { get; set; }
        public Progress progress { get; set; }
        public object customfield_10719 { get; set; }
        public Issuetype issuetype { get; set; }
        public Project project { get; set; }
        public object customfield_10820 { get; set; }
        public object customfield_10821 { get; set; }
        public object customfield_10700 { get; set; }
        public object customfield_10822 { get; set; }
        public object customfield_10701 { get; set; }
        public object customfield_10702 { get; set; }
        public object customfield_10823 { get; set; }
        public object customfield_10703 { get; set; }
        public object customfield_10824 { get; set; }
        public object customfield_10704 { get; set; }
        public object resolutiondate { get; set; }
        public object customfield_10705 { get; set; }
        public object customfield_10826 { get; set; }
        public object customfield_10827 { get; set; }
        public object customfield_10706 { get; set; }
        public object customfield_10707 { get; set; }
        public object customfield_10829 { get; set; }
        public object customfield_10708 { get; set; }
        public object customfield_10709 { get; set; }
        public Watches watches { get; set; }
        public object customfield_10817 { get; set; }
        public object customfield_10818 { get; set; }
        public object customfield_10819 { get; set; }
        public DateTime updated { get; set; }
        public object timeoriginalestimate { get; set; }
        public string description { get; set; }
        public string summary { get; set; }
        public string customfield_10000 { get; set; }
        public object customfield_10115 { get; set; }
        public object customfield_10116 { get; set; }
        public object environment { get; set; }
        public object customfield_10118 { get; set; }
        public string duedate { get; set; }
        public List<object> fixVersions { get; set; }
        public object customfield_10111 { get; set; }
        public object customfield_10112 { get; set; }
        public object customfield_10104 { get; set; }
        public string customfield_10105 { get; set; }
        public object customfield_10106 { get; set; }
        public object customfield_10107 { get; set; }
        public object customfield_10900 { get; set; }
        public object customfield_10901 { get; set; }
        public object customfield_10902 { get; set; }
        public object customfield_10903 { get; set; }
        public object customfield_10904 { get; set; }
        public object customfield_10905 { get; set; }
        public object customfield_10906 { get; set; }
        public object customfield_10907 { get; set; }
        public Priority priority { get; set; }
        public customfield_12800 customfield_12800 { get; set; }  //functional domain- QA
        public customfield_11006 customfield_11006 { get; set; }  //functional domain- prod
        public object customfield_10100 { get; set; }
        public object timeestimate { get; set; }
        public List<object> versions { get; set; }
        public Status status { get; set; }
        public object customfield_10210 { get; set; }
        public object customfield_10453 { get; set; }
        public object customfield_10454 { get; set; }
        public object customfield_10455 { get; set; }
        public object customfield_10566 { get; set; }
        public object customfield_10446 { get; set; }
        public object customfield_10205 { get; set; }
        public object customfield_10568 { get; set; }
        public object customfield_10447 { get; set; }
        public object customfield_10206 { get; set; }
        public object customfield_10448 { get; set; }
        public object customfield_10569 { get; set; }
        public Customfield10207 customfield_10207 { get; set; }
        public object customfield_10449 { get; set; }
        public object aggregatetimeestimate { get; set; }
        public Customfield10208 customfield_10208 { get; set; }
        public object customfield_10209 { get; set; }
        public Creator creator { get; set; }
        public object customfield_10560 { get; set; }
        public object customfield_10440 { get; set; }
        public Aggregateprogress aggregateprogress { get; set; }
        public object customfield_10441 { get; set; }
        public object customfield_10200 { get; set; }
        public object customfield_10201 { get; set; }
        public object customfield_10564 { get; set; }
        public object customfield_10443 { get; set; }
        public object customfield_10202 { get; set; }
        public object customfield_10565 { get; set; }
        public object customfield_10434 { get; set; }
        public object customfield_10555 { get; set; }
        public object customfield_10556 { get; set; }
        public object customfield_10435 { get; set; }
        public object customfield_10557 { get; set; }
        public object customfield_10436 { get; set; }
        public object customfield_10437 { get; set; }
        public object customfield_10559 { get; set; }
        public Customfield10438 customfield_10438 { get; set; }
        public object customfield_10439 { get; set; }
        public object timespent { get; set; }
        public object customfield_10550 { get; set; }
        public object customfield_10430 { get; set; }
        public object customfield_10551 { get; set; }
        public object aggregatetimespent { get; set; }
        public object customfield_10552 { get; set; }
        public object customfield_10431 { get; set; }
        public object customfield_10432 { get; set; }
        public object customfield_10553 { get; set; }
        public object customfield_10433 { get; set; }
        public object customfield_10554 { get; set; }
        public object customfield_10544 { get; set; }
        public object customfield_10303 { get; set; }
        public object customfield_10545 { get; set; }
        public object customfield_10424 { get; set; }
        public object customfield_10304 { get; set; }
        public object customfield_10546 { get; set; }
        public object customfield_10425 { get; set; }
        public object customfield_10305 { get; set; }
        public object customfield_10547 { get; set; }
        public object customfield_10426 { get; set; }
        public object customfield_10427 { get; set; }
        public object customfield_10548 { get; set; }
        public object customfield_10549 { get; set; }
        public object customfield_10428 { get; set; }
        public object customfield_10429 { get; set; }
        public int workratio { get; set; }
        public DateTime created { get; set; }
        public DateTime update { get; set; }  //Last modify
        public timetracking TimeTracking { get; set; }  // effort Estimate 
        public Customfield10540 customfield_10540 { get; set; }  // category for qa
        public customfield_10713 customfield_10713 { get; set; }  // category for prod
                                                                  // public object customfield_10524 { get; set; }  // start date
        public object customfield_12701 { get; set; } //  End date
                                                      //   public object customfield_12702 { get; set; } //  UAT
                                                      //   public object customfield_12703 { get; set; } //  //  new start date
        public customfield_12704 customfield_12704 { get; set; } //  //  product owner
        public customfield_11202 customfield_11202 { get; set; } //  //  product owner - prod
        public customfield_12801 customfield_12801 { get; set; }  // priortization rank qa
        public customfield_11111 customfield_11111 { get; set; }  // priortization rank prod
        public string customfield_12604 { get; set; }  // UAT sign-off user prod

        public string customfield_12909 { get; set; } // UAT sign-off user QA
        public object customfield_10541 { get; set; }
        public object customfield_10542 { get; set; }
        public object customfield_10543 { get; set; }
        public object customfield_10533 { get; set; }
        public object customfield_10534 { get; set; }
        public object customfield_10535 { get; set; }
        public object customfield_10536 { get; set; }
        public object customfield_10537 { get; set; }
        public object customfield_10538 { get; set; }
        public object customfield_10539 { get; set; }
        public object customfield_10530 { get; set; }
        public object customfield_10531 { get; set; }
        public object customfield_10532 { get; set; }
        public object customfield_10401 { get; set; }
        public object customfield_10522 { get; set; }
        public object customfield_10523 { get; set; }
        public object customfield_10403 { get; set; }
        //  public string customfield_10524 { get; set; }
        public object customfield_10404 { get; set; }
        public string customfield_10525 { get; set; }
        public object customfield_10405 { get; set; }
        public object customfield_10526 { get; set; }
        public object customfield_10527 { get; set; }
        public object customfield_10528 { get; set; }
        public object customfield_10529 { get; set; }
        public object customfield_10520 { get; set; }
        public object customfield_10511 { get; set; }
        public object customfield_10512 { get; set; }
        public Customfield10516 customfield_10516 { get; set; }
        public object customfield_10517 { get; set; }
        public object customfield_10518 { get; set; }
        public object customfield_10519 { get; set; }

        // new Fields added 10-20-21      // for QA and prod
        public string customfield_13400 { get; set; }  // dashboard/report name(QA)
        public string customfield_13401 { get; set; }  // expected count of users(QA)
        public string customfield_13402 { get; set; }  // business justfication(QA), dashboard/report name(Prod)
        public string customfield_13403 { get; set; }  // strategic initiative(QA) , expected count of users(Prod)
        public string customfield_13404 { get; set; }  // dashboard security(QA)  ,  business justfication(Prod)
        public Customfield_13405 customfield_13405 { get; set; }  // refresh frequency(QA) , strategic initiative(Prod)

      //  public string customfield_13405 { get; set; }
        public string customfield_13406 { get; set; }  //  CM owner (QA) ,  dashboard security(Prod)
        public string customfield_13407 { get; set; }  //  best approach(QA) , refresh frequency(Prod)
        public Customfield_13408 customfield_13408 { get; set; }  // align with buss owner(QA), // CM owner (Prod)

        public string customfield_13409 { get; set; }  //  best approach(Prod)
        public Customfield_13410 customfield_13410 { get; set; }  // align with buss owner(Prod)

        public string customfield_12908 { get; set; } // product owner Prod

    }

    public class Customfield_13408  // align with buss owner qa
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield_13410  // align with buss owner Prod
    {
        public string value { get; set; }
        public string id { get; set; }
    }
    public class Customfield_13405  // align with buss owner qa
    {
        public string value { get; set; }
        public string id { get; set; }
    }

    public class Issue
    {
        public string expand { get; set; }
        public string id { get; set; }
        public string self { get; set; }
        public string key { get; set; }
        public Fields fields { get; set; }
    }

    public class RootObject
    {
        public string expand { get; set; }
        public int startAt { get; set; }
        public int maxResults { get; set; }
        public int total { get; set; }
        public List<Issue> issues { get; set; }
    }

    public class Root
    {
        public string Expand { get; set; }

        public string id { get; set; }
        public string self { get; set; }
        public string key { get; set; }
        public Fields fields { get; set; }
        public List<Project> Projects { get; set; }
    }

    //************ Classes for Error Log*************

    public class ErrorLogClass
    {
        public string ErrorMessage { get; set; }
        public string Source { get; set; }
        public string Method { get; set; }
        public string PageName { get; set; }
    }

    public class UserInfo
    {
        //   public string UserId { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
    }
    public class BIMCatalogEntity
    {
        public string ContentType { get; set; }
        public string Name { get; set; }
        public string BusinessOwner { get; set; }


    }
}