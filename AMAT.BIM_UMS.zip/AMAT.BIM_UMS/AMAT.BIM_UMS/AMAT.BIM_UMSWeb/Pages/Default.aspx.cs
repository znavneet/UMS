﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Client;
using System.Net;
using System.IO;
using RestSharp;
using System.Data;
using AMAT.Utilities.ExcelComponent;
using ClosedXML.Excel;
using Newtonsoft.Json.Linq;

namespace AMAT.BIM_UMSWeb
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_PreInit(object sender, EventArgs e)
        {
            Uri redirectUrl;
            switch (SharePointContextProvider.CheckRedirectionStatus(Context, out redirectUrl))
            {
                case RedirectionStatus.Ok:
                    return;
                case RedirectionStatus.ShouldRedirect:
                    Response.Redirect(redirectUrl.AbsoluteUri, endResponse: true);
                    break;
                case RedirectionStatus.CanNotRedirect:
                    Response.Write("An error occurred while processing your request.");
                    Response.End();
                    break;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]  //My Request
        public static List<GridRow> GetMyRequestData(string currentUser)
        {
            Constant obj = new Constant();
            JIRA jira = new JIRA();

            string jiraUrl = obj.JiraUrl;
            jira.JiraUserName = obj.UserId;
            jira.JiraPassword = obj.Password;

            string[] projects = { Constant.BIMDBProject };  // Get issues from listed projects in JIRA

            List<GridRow> rowList = new List<GridRow>();

            for (int j = 0; j < projects.Length; j++)
            {
                if (jiraUrl.Contains("-qa")) // for QA
                {
                    jira.JiraUrl = Constant.JiraUrlForSearchingQA + "jql='project' = '" + projects[j] + "' AND 'Requestor Email' ~ '" + currentUser + "' AND 'From RMS' =Yes&maxResults=1000&fields=customfield_12700,customfield_12605,summary,customfield_10100,customfield_10540,status,priority,assignee,created,updated,duedate&ORDER BY key DESC";

                }
                else // for Prod
                {
                    jira.JiraUrl = Constant.JiraForSearching + "jql='project' = '" + projects[j] + "' AND 'Requestor Email' ~ '" + currentUser + "' AND 'From RMS' =Yes&maxResults=1000&fields=customfield_12208,customfield_12207,summary,customfield_10100,customfield_10713,status,priority,assignee,created,updated,duedate&ORDER BY key DESC";

                }



                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls | System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                var client = new RestClient(jira.JiraUrl);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Basic ZGV2b3BzOkRPQE1hcjIwMTk=");
                request.AddHeader("Cookie", "JSESSIONID=D9D11B7147B17B63F3B00937AD21BD84; atlassian.xsrf.token=BW7W-17I2-H3HO-Q1LQ_cdfacdbd4c909dcbd94031159d60d59a01efcda2_lin");
                IRestResponse response = client.Execute(request);

                RootObject ro = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(response.Content);
                GetRootObjectWithContent(ro, projects[j], jiraUrl, rowList);
            }
            rowList = rowList.OrderByDescending(o => o.ID).ToList();

            return rowList;
        }
        public static GridRow GetRootObjectWithContent(RootObject ro, string projectName, string jiraUrl, List<GridRow> rowList)
        {
            GridRow newRow = null;
            if (ro.issues != null)
            {
                for (int i = 0; i < ro.issues.Count; i++)
                {
                    newRow = new GridRow();
                    if (jiraUrl.Contains("-qa"))
                    {
                        if (ro.issues[i].fields.customfield_10540 != null)
                            newRow.Category = ro.issues[i].fields.customfield_10540.value; //category

                        if (ro.issues[i].fields.customfield_12700 != null)
                            //     newRow.Requestor = GetRequestorName(Convert.ToString(ro.issues[i].fields.customfield_12700)); // requestor mail

                            if (ro.issues[i].fields.customfield_12605 != null)
                                newRow.Subscribe = ro.issues[i].fields.customfield_12605.value;   //issue subscribe

                        if (ro.issues[i].fields.customfield_12800 != null)
                            newRow.FunctionalDomain = ro.issues[i].fields.customfield_12800.value;  // fn domain

                        if (ro.issues[i].fields.customfield_12704 != null)  //Product owner
                            newRow.ProductOwner = ro.issues[i].fields.customfield_12704.displayName;

                        if (ro.issues[i].fields.customfield_12801 != null)  //priortization rank
                            newRow.PRank = ro.issues[i].fields.customfield_12801.value;

                    }
                    else
                    {
                        if (ro.issues[i].fields.customfield_10713 != null)
                            newRow.Category = Convert.ToString(ro.issues[i].fields.customfield_10713.value);  // category

                        if (ro.issues[i].fields.customfield_12208 != null)
                            //  newRow.Requestor = GetRequestorName(Convert.ToString(ro.issues[i].fields.customfield_12208)); // requestor mail

                            if (ro.issues[i].fields.customfield_12207 != null)
                                newRow.Subscribe = ro.issues[i].fields.customfield_12207.value;   //issue subscribe

                        if (ro.issues[i].fields.customfield_11006 != null)
                            newRow.FunctionalDomain = ro.issues[i].fields.customfield_11006.value;  // fn domain

                        if (ro.issues[i].fields.customfield_11202 != null)  //Product owner
                            newRow.ProductOwner = ro.issues[i].fields.customfield_11202.displayName;

                        if (ro.issues[i].fields.customfield_11111 != null)  //priortization rank
                            newRow.PRank = ro.issues[i].fields.customfield_11111.value;
                    }

                    newRow.Key = ro.issues[i].key;
                    newRow.Summary = ro.issues[i].fields.summary;

                    newRow.ProjectName = projectName;
                    //    newRow.Status = GetStatus(ro.issues[i].fields.status.name);
                    newRow.Priority = ro.issues[i].fields.priority.name;
                    newRow.ID = Convert.ToInt32(ro.issues[i].key.Split('-')[1].ToString());

                    string epicName = Convert.ToString(ro.issues[i].fields.customfield_10100);
                    //    newRow.ProjectArea = GetEpicName(epicName);

                    if (ro.issues[i].fields.assignee != null)
                    {
                        newRow.Assignee = ro.issues[i].fields.assignee.displayName;
                        newRow.AssigneeEmail = ro.issues[i].fields.assignee.emailAddress;
                    }
                    if (ro.issues[i].fields.TimeTracking != null) //Effort Est.
                        newRow.EffEstimation = ro.issues[i].fields.TimeTracking.originalEstimate;

                    if (!string.IsNullOrEmpty(ro.issues[i].fields.duedate)) //actual end date
                        //newRow.Duedate = getFormateddate(ro.issues[i].fields.duedate);

                        if (ro.issues[i].fields.updated != null)  // last modify                    
                            // newRow.LastModify = getFormateddate(ro.issues[i].fields.updated.Date.ToString());

                            // newRow.Created = getFormateddate(ro.issues[i].fields.created.Date.ToString());

                            rowList.Add(newRow);
                }
            }
            return newRow;
        }
        public void GetIssue()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string JiraUrl = "https://dtr-qa.amat.com/rest/api/2/search?jql='project'='BIMDB'AND'From RMS'='Yes'&maxResults=10";
                    string responseText = string.Empty;
                    JIRA obj = new JIRA();
                    ServicePointManager.Expect100Continue = true;
                    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

                    var httpWebRequest = (HttpWebRequest)WebRequest.Create(JiraUrl);

                    httpWebRequest.ContentType = "application/json";
                    httpWebRequest.Accept = "application/json";
                    httpWebRequest.Method = "GET";
                    httpWebRequest.Headers.Add("Authorization", "Basic " + obj.GetEncodedCredentials());
                    using (WebResponse response = httpWebRequest.GetResponse())
                    {
                        using (var streamReader = new StreamReader(response.GetResponseStream()))
                        {
                            responseText = streamReader.ReadToEnd();
                            Response.Write(responseText);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "addJiraIssue", "UMS.aspx");
                }
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           // saveData();
            //  GetData();
            UpdateJIRA();
        }

        public void GetData(string url)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls | System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    var client = new RestClient("https://dtr-qa.amat.com/rest/api/2/search?jql='project' = 'BIMDB' AND 'From RMS' ='Yes'&maxResults=10");
                    client.Timeout = -1;
                    var request = new RestRequest(Method.GET);
                    request.AddHeader("Authorization", "Basic ZGV2b3BzOkRPQE1hcjIwMTk=");
                    request.AddHeader("Cookie", "JSESSIONID=D9D11B7147B17B63F3B00937AD21BD84; atlassian.xsrf.token=BW7W-17I2-H3HO-Q1LQ_cdfacdbd4c909dcbd94031159d60d59a01efcda2_lin");
                    IRestResponse response = client.Execute(request);
                    hdntest.Value = response.Content;
                    Response.Write(response.Content);
                }
                catch (Exception ex)
                {
                    hdntest.Value = ex.Message;
                    Response.Write(ex.Message);
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "GetDatabyRestSharp", "Default.aspx");
                }
            }
        }
        public void saveData()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls | System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    var client = new RestClient("https://dtr-qa.amat.com/rest/api/2/issue/");
                    client.Timeout = -1;
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("Authorization", "Basic ZGV2b3BzOkRPQE1hcjIwMTk=");
                    request.AddHeader("Content-Type", "application/json");
                    request.AddHeader("Cookie", "JSESSIONID=BF5BC24438B31D3293BAFB01E572CE97; atlassian.xsrf.token=BW7W-17I2-H3HO-Q1LQ_bd730a26f546601a708cda0a7419c6bb193cf24b_lin");
                    request.AddParameter("application/json", "{\"fields\": {\"project\": { \"id\": \"12001\"}, \"summary\": \"223\",\"description\": \"desc\",\"customfield_10100\": \"BIMDB-14\",\"customfield_10540\": {\"value\": \"New Request\"},\"customfield_10512\": {\"value\": \"Very High (2+ months)\"},\"customfield_12700\": \"Navneet_Sharma@contractor.amat.com\",\"customfield_11107\": {\"value\": \"Yes\"},\"reporter\": {\"name\": \"devops\"},\"issuetype\": {\"id\": \"10001\"},\"customfield_12605\": {\"value\": \"No\"},\"customfield_12800\": {\"value\": \"APG\"}}}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                    hdntest.Value = response.Content;
                    Response.Write(response.Content);
                }
                catch (Exception ex)
                {
                    hdntest.Value = ex.Message;
                    Response.Write(ex.Message);
                    Constant.ErrorLog(clientContext, ex.Message, ex.Source, "saveData", "Default.aspx");
                }
            }
        }

        protected void btnupload_Click(object sender, EventArgs e)
        {
            UpdateMultipleRows();
        }

        public void UpdateMultipleRows()
        {
            DataTable requestDt = ImportExcel();
            string resultTable = string.Empty;
            if (requestDt != null && requestDt.Rows.Count > 0)
            {

                JIRA jira = new JIRA();
                Constant obj = new Constant();
                jira.JiraUserName = obj.UserId;
                jira.JiraPassword = obj.Password;

                resultTable = "<table id='uploadcss'><tr><th>Request Id</th><th>Status</th></tr>";
                for (int i = 0; i < requestDt.Rows.Count; i++)
                {
                    try
                    {
                        string key = Convert.ToString(requestDt.Rows[i]["Key"]);
                        resultTable += "<tr><td>" + key + "</td>";
                        jira.JiraUrl = obj.JiraUrl + key;

                        string jsonStr = GetJSONQuery(requestDt.Rows[i], jira.JiraUrl);

                        JObject jobj = JObject.Parse(jsonStr);
                        string newJsonString = Convert.ToString(jobj);
                        jira.JiraJson = newJsonString;

                        string response = jira.UpdateJiraIssue();
                        string status = JIRAStatus(Convert.ToString(requestDt.Rows[i]["Status"]), jira.JiraUrl);
                        UpdateStatus(status, jira, jira.JiraUrl);
                        resultTable += "<td style='color:Green'>Success</td></tr>";
                    }
                    catch (Exception ex)
                    {
                        resultTable += "<td style='color:Red'>Error</td></tr>";
                        continue;
                    }
                }
               // Response.Write(resultTable);
                hdnresultHTML.Value = resultTable;
            }
          
        }

        public void UpdateStatus(string statusId, JIRA jira, string issueUrl)
        {
            if (!string.IsNullOrEmpty(statusId))
            {
                string jStr = string.Empty;
                string url = jira.JiraUrl + "/transitions";
                jira.JiraUrl = url;

                if (issueUrl.Contains("-qa"))
                {
                    jStr = @"{""transition"": {""id"": """ + statusId + @"""}}";
                }
                else
                {
                    jStr = @"{""transition"": {""id"": """ + statusId + @"""}}";
                }
                JObject jobj = JObject.Parse(jStr);
                string newJsonString = Convert.ToString(jobj);
                jira.JiraJson = newJsonString;

                try
                {
                    string response = jira.addJiraIssue();
                }
                catch (Exception ex)
                {

                }
            }
        }

        public string GetJSONQuery(DataRow row, string jiraUrl)
        {
            string jsonStr = null;
            string productOwner = null;
            string assignTo = null;
            string duedate = null;
            string fnDomain = null;
            string Key = Convert.ToString(row["Key"]);
            string rank = null;
           
            //if (row.ProductOwner == ("--Select--"))
            //    productOwner = "--Select--";
            //else
            if (!string.IsNullOrEmpty(Convert.ToString(row["Product owner"])))
                productOwner = GetUserDetails(Convert.ToString(row["Product owner"])).sAMAccountName;
           
            if (!string.IsNullOrEmpty(Convert.ToString(row["Assign To"])))
                assignTo = GetUserDetails(Convert.ToString(row["Assign To"])).sAMAccountName;
            
            if (!string.IsNullOrEmpty(Convert.ToString(row["Due Date"])))
                duedate = Convert.ToString(row["Due Date"]);

            if (!string.IsNullOrEmpty(Convert.ToString(row["Rank"])))
                rank = Convert.ToString(row["Rank"]);
          
            string priority = Convert.ToString(row["Priority"]);
            string effortEst = Convert.ToString(row["Est.Effort"]);  
            string status = Convert.ToString(row["Status"]);

            if (!string.IsNullOrEmpty(Convert.ToString(row["Business function"])))
                fnDomain = Convert.ToString(row["Business function"]);
            else
                fnDomain = null;

            if (jiraUrl.Contains("-qa")) // QA
            {
                if (rank != null)
                    jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRankQA + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomainQA + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatusQA + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwnerQA + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                else
                    jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.FunctionalDomainQA + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatusQA + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwnerQA + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";

            }
            else //Production string
            {
                if (status.Equals("Prioritized"))
                {
                    if (assignTo.Equals("--Select--"))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatus + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""}}}";
                    }
                    if (assignTo != "--Select--" && string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatus + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                    if (assignTo != "--Select--" && !string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""duedate"": [{""set"": """ + duedate + @"""}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}],""" + Constant.PrioritizationStatus + @""": [{""set"":{""value"":""" + status + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                }
                else
                {
                    if (assignTo.Equals("--Select--"))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""}}}";
                    }
                    if (assignTo != "--Select--" && string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                    if (assignTo != "--Select--" && !string.IsNullOrEmpty(duedate))
                    {
                        jsonStr = @"{""update"":{""priority"": [{""set"":{""name"":""" + priority + @"""}}],""duedate"": [{""set"": """ + duedate + @"""}],""" + Constant.PrioritizationRank + @""": [{""set"":{""value"":""" + rank + @"""}}],""" + Constant.FunctionalDomain + @""": [{""set"":{""value"":""" + fnDomain + @"""}}]},""fields"":{""timetracking"": { ""remainingEstimate"": """ + effortEst + @"""},""" + Constant.ProductOwner + @""": {""name"": """ + productOwner + @"""},""assignee"": {""name"": """ + assignTo + @"""}}}";
                    }
                }
            }

            return jsonStr;
        }


        protected ADMethods.ADAttributes GetUserDetails(string userName)
        {
            ADMethods.ADAttributes ADResult = null;
            bool isUserExists = false;
            ADMethods AD = new ADMethods();

            isUserExists = AD.IsUserExist(userName, ADMethods.AdPrpoertyParameters.displayName);
            if (isUserExists)
                ADResult = AD.GetEmployeeAttributes(userName, ADMethods.AdPrpoertyParameters.displayName);

            return ADResult;
        }
        protected DataTable ImportExcel()
        {
            DataTable dt = new DataTable();

            if (fileUpload.HasFile)
            {              
                string filePath = Server.MapPath("~/Files/") + Path.GetFileName(fileUpload.PostedFile.FileName);
                fileUpload.SaveAs(filePath);

                using (XLWorkbook workbook = new XLWorkbook(filePath))
                {
                    IXLWorksheet worksheet = workbook.Worksheet("Priority Request");
                    bool FirstRow = true;
                    //Range for reading the cells based on the last cell used.  
                    string readRange = "1:1";
                    foreach (IXLRow row in worksheet.RowsUsed())
                    {
                        //If Reading the First Row (used) then add them as column name  
                        if (FirstRow)
                        {
                            //Checking the Last cellused for column generation in datatable  
                            readRange = string.Format("{0}:{1}", 1, row.LastCellUsed().Address.ColumnNumber);
                            foreach (IXLCell cell in row.Cells(readRange))
                            {
                                dt.Columns.Add(cell.Value.ToString());
                            }
                            FirstRow = false;
                        }
                        else
                        {
                            //Adding a Row in datatable  
                            dt.Rows.Add();
                            int cellIndex = 0;
                            //Updating the values of datatable  
                            foreach (IXLCell cell in row.Cells(readRange))
                            {
                                dt.Rows[dt.Rows.Count - 1][cellIndex] = cell.Value.ToString();
                                cellIndex++;
                            }
                        }

                    }

                }
            }
            return dt;
        }

        /// <summary>
        /// ger jira status
        /// </summary>
        /// <param name="trasition"></param>
        /// <param name="envURL"></param>
        /// <returns></returns>
        public string JIRAStatus(string trasition, string envURL)
        {
            string trasitionId = string.Empty;
            if (envURL.Contains("-qa"))
            {
                switch (trasition)
                {
                    case "On Hold":
                        trasitionId = "261";
                        break;
                    case "Rejected":
                        trasitionId = "271";
                        break;
                    case "Prioritized":
                        trasitionId = "211";
                        break;
                }
            }
            else
            {
                switch (trasition)
                {
                    case "ON HOLD":
                        trasitionId = "221";
                        break;
                    case "Rejected":
                        trasitionId = "231";
                        break;
                    case "Prioritized":
                        trasitionId = "281";
                        break;
                }
            }

            return trasitionId;
        }

        public string getFormateddate(string date)
        {
            string dateValue = string.Empty;
            if (!date.Equals("1/1/0001 12:00:00 AM") && !string.IsNullOrEmpty(date))
                dateValue = Convert.ToDateTime(date).ToString("yyyy-MM-dd");
            return dateValue;
        }

        public void UpdateJIRA()
        {
            var client = new RestClient("https://dtr-qa.amat.com/rest/api/2/issue/BIMDB-558");
            client.Timeout = -1;
            var request = new RestRequest(Method.PUT);
            request.AddHeader("Authorization", "Basic ZGV2b3BzOkRPQE1hcjIwMTk=");
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "JSESSIONID=0ED7455455AAB50A04C10A96B5570DB9; atlassian.xsrf.token=BW7W-17I2-H3HO-Q1LQ_8db225256f6998f4394c908c88ae40a2be56d020_lin");
            request.AddParameter("application/json", "\"{\\\"update\\\":{\\\"priority\\\": [{\\\"set\\\":{\\\"name\\\":\\\"High\\\"}}],\\\"customfield_12801\\\": [{\\\"set\\\":{\\\"value\\\":\\\"\\\"}}],\\\"customfield_12800\\\": [{\\\"set\\\":{\\\"value\\\":\\\"Fieldglass\\\"}}]},\\\"fields\\\":{\\\"timetracking\\\": { \\\"remainingEstimate\\\": \\\"\\\"},\\\"customfield_12704\\\": {\\\"name\\\": \\\"\\\"},\\\"assignee\\\": {\\\"name\\\": \\\"NSharmaX099020\\\"}}}\"", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            Response.Write(response.Content);
        }
    }
     
}