﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using MSXML2;
using System.Text;
using Microsoft.SharePoint.Client;
using System.Net.Http;
using System.IO;
using System.Net;
using System.Net.Http.Headers;
using Microsoft.Activities.Messaging;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.SharePoint.Client.Utilities;
using Newtonsoft.Json;
using System.Globalization;
using System.Configuration;
using System.Security;
using RestSharp;

namespace AMAT.BIM_UMSWeb.Pages
{
    public partial class test11 : System.Web.UI.Page
    {
        // static string jiraURL1 = "https://amatjiradev.amat.com/rest/api/2/search?jql='project' = 'DP'";
        // static string jiraURL = "https://amatjiraqa.amat.com/rest/api/2/search?jql='project' = 'DP'&maxResults=10";

        static string jiraURL1 = "https://dcalpa791:8580/rest/api/2/search?jql='project' = 'BIMDB' AND 'From RMS' ='Yes'";
        // static string jiraURL1 = "https://dtr-qa.amat.com/rest/api/2/search?jql='project' = 'BIMDB' AND 'From RMS' ='Yes'";


        protected void Page_Load(object sender, EventArgs e)
        {
           // getResults(jiraURL);
           // getResults(jiraURL1);
            GetUsersRecordsFronJira(jiraURL1);
          
        }

        public void getResults(string url)
        {
            ServicePointManager.Expect100Continue = true;
            System.Net.ServicePointManager.SecurityProtocol =  SecurityProtocolType.Tls12;

            var client = new RestClient(url);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Basic ZGV2b3BzOkRPQE1hcjIwMTk=");
            request.AddHeader("Cookie", "JSESSIONID=599D5D0ECA018AD41FADFDBDEA6EADFD; atlassian.xsrf.token=BWOE-ZIII-QZ7X-3BPI_ecc6cd920f914bd304f08c27db0e4c8691c4824a_lin");
            IRestResponse response = client.Execute(request);
            if (response == null)
                Response.Write("null" + response.ErrorException);
            else
                Response.Write(response.Content);

            Response.Write(response.StatusCode + " == " + response.StatusDescription + " == " + response.IsSuccessful + " == " + response.ErrorException + " == " + response.ErrorMessage + " == " + response.ResponseStatus + " == " + response.ToString());
        }

        public String GetUsersRecordsFronJira(string URL)
        {
            string responseText = string.Empty;
         

            var httpWebRequest = (HttpWebRequest)WebRequest.Create(URL);
            httpWebRequest.KeepAlive = false;
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Accept = "application/json";
            httpWebRequest.Method = "GET";
            httpWebRequest.Headers.Add("Authorization", "Basic " + GetEncodedCredentials());
           //httpWebRequest.Headers.Add("Authorization", "Basic ZGV2b3BzOkRPQE1hcjIwMTk=");

            using (WebResponse response = httpWebRequest.GetResponse())
            {
                using (var streamReader = new StreamReader(response.GetResponseStream()))
                {
                    responseText = streamReader.ReadToEnd();
                }

            }
            Response.Write(jiraURL1 + "<br/><br/><br/><br/>");
            Response.Write(responseText);
            return responseText;
        }

        //[WebMethod]
        //public static List<NewGridRow> GetRequests()
        //{
        //    string response = GetUsersRecordsFronJira();
        //   // RootObject ro = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(response);   

        //    Root1 ro = Newtonsoft.Json.JsonConvert.DeserializeObject<Root1>(response);
        //    List<NewGridRow> rows = GetRootNestedContent(ro);
        //    return rows;
        //}

        //public static List<NewGridRow> GetRootNestedContent(Root1 ro)
        //{
        //    List<NewGridRow> rows = new  List<NewGridRow>();
        //    if (ro != null)
        //    {
        //        for (int i = 0; i < ro.issues.Count; i++)
        //        {
        //            NewGridRow newRow = new NewGridRow();
        //            //  newRow.Key = ro.fields.customfield_12800.id;
        //            newRow.Priority = Convert.ToString(ro.issues[0].fields.priority);
        //            newRow.Requestor = Convert.ToString(ro.issues[0].fields.creator.displayName);
        //            newRow.Summary = Convert.ToString(ro.issues[0].fields.summary);
        //            newRow.Status = Convert.ToString(ro.issues[0].fields.status);
        //            rows.Add(newRow);
        //        }
        //    }
        //    return rows;
        //}
        public string GetEncodedCredentials()
        {
            Constant obj = new Constant();
            string mergedCredentials = string.Format("{0}:{1}", obj.UserId, obj.Password);
            byte[] byteCredentials = UTF8Encoding.UTF8.GetBytes(mergedCredentials);
            return Convert.ToBase64String(byteCredentials);
        }


        public void Addissue()
        {
            JIRA jira = new JIRA();
            jira.JiraUrl = "https://amatjiraqa.amat.com/rest/api/2/issue/";

            string bimTitle = "test Title DP Project";
            string reqDescription = "Description test Title DP Project";
            string duedate = "03-11-2021";
            string requestorId = "devops";
            string jsonStr = @"{""fields"": {""project"": { ""id"": """ + 12609 + @"""}, ""summary"": """ + bimTitle + @""",""description"": """ + reqDescription + @""",""reporter"": {""name"": """ + requestorId + @"""},""issuetype"": {""id"": """ + 10001 + @"""}}}";
           
            jira.JiraJson = ToParseJSON(jsonStr);
            string response = Convert.ToString(createJiraIssue(jira.JiraJson));          
            string key = Convert.ToString(JObject.Parse(response)["key"]);
           // CreateIssuebyRESTClient(jira.JiraJson);
        }

        public String addJiraIssue1(string JiraJson)
        {

            string url = "https://amatjiraqa.amat.com";
            XMLHTTP60 JiraService = new XMLHTTP60();
            // ServerXMLHTTP60 JiraService = new ServerXMLHTTP60();
            JiraService.open("POST", "https://amatjiraqa.amat.com/rest/api/2/issue/");
            JiraService.setRequestHeader("Origin", url);
            JiraService.setRequestHeader("Content-Type", "application/json");
            JiraService.setRequestHeader("Accept", "application/json");
            JiraService.setRequestHeader("Authorization", "Basic " + GetEncodedCredentials());
            JiraService.send(JiraJson);
            String response = JiraService.responseText;
            JiraService.abort();
            return response;
        }
        public string createJiraIssue(string JiraJson)
        {

            string responseText = string.Empty;
            ServicePointManager.Expect100Continue = true;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://amatjiraqa.amat.com/rest/api/2/issue/");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Accept = "application/json";
            httpWebRequest.Method = "POST";
            httpWebRequest.Headers.Add("Authorization", "Basic " + GetEncodedCredentials());
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(JiraJson);
                streamWriter.Flush();
            }
            WebResponse webResponse = (HttpWebResponse)httpWebRequest.GetResponse();

            using (var streamReader = new StreamReader(webResponse.GetResponseStream()))
            {
                responseText = streamReader.ReadToEnd();
            }
            Response.Write(responseText);
            return responseText;
        }

        public string ToParseJSON(string jsonString)
        {
            JObject obj = JObject.Parse(jsonString);
            string newJsonString = Convert.ToString(obj);
            return newJsonString;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Addissue();
        }

        public void CreateIssuebyRESTClient(string jsonString)
        {
            var client = new RestClient("https://amatjiraqa.amat.com/rest/api/2/issue/");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", "Basic " + GetEncodedCredentials());
            request.AddHeader("Content-Type", "application/json");
           // request.AddHeader("Cookie", "JSESSIONID=1D402DD9C6F06EC4A2D0F4008CAE3A7F; TS01728a4d=015ff9733b7ebc3aecf9849687a223a2e88e55c7a43e585539c321c417931dc471d2d9d37edd4bfc57d59bfd99e3a16dd91a81c01645484a04c02f6fac10487d4441a1e0070aec34f5e9d29493813c1bd85794c542; atlassian.xsrf.token=BXMK-ERYN-CKFV-JZFS_6990c4f955ea5d1593059c6d0234db913315811e_lin");
            request.AddParameter("application/json", jsonString, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            Response.Write(response.Content);
        }
    }
    public class NewGridRow
    {
        public string Key { get; set; }
        public string Requestor { get; set; }
        public string RequestorEmail { get; set; }
        public string Summary { get; set; }
        public string Status { get; set; }
        public string Priority { get; set; }
    }
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class AvatarUrls
    {
        public string _48x48 { get; set; }
        public string _24x24 { get; set; }
        public string _16x16 { get; set; }
        public string _32x32 { get; set; }
    }

    public class Creator
    {
        public string self { get; set; }
        public string name { get; set; }
        public string key { get; set; }
        public string emailAddress { get; set; }
        public AvatarUrls avatarUrls { get; set; }
        public string displayName { get; set; }
        public bool active { get; set; }
        public string timeZone { get; set; }
    }

    public class Priority
    {
        public string self { get; set; }
        public string iconUrl { get; set; }
        public string name { get; set; }
        public string id { get; set; }
    }

    public class StatusCategory
    {
        public string self { get; set; }
        public int id { get; set; }
        public string key { get; set; }
        public string colorName { get; set; }
        public string name { get; set; }
    }

    public class Status
    {
        public string self { get; set; }
        public string description { get; set; }
        public string iconUrl { get; set; }
        public string name { get; set; }
        public string id { get; set; }
        public StatusCategory statusCategory { get; set; }
    }

    public class Fields
    {
        public Creator creator { get; set; }
        public Priority priority { get; set; }
        public Status status { get; set; }
        public string summary { get; set; }
    }

    public class Issue
    {
        public string expand { get; set; }
        public string id { get; set; }
        public string self { get; set; }
        public string key { get; set; }
        public Fields fields { get; set; }
    }

    public class Root1
    {
        public string expand { get; set; }
        public int startAt { get; set; }
        public int maxResults { get; set; }
        public int total { get; set; }
        public List<Issue> issues { get; set; }
    }

}