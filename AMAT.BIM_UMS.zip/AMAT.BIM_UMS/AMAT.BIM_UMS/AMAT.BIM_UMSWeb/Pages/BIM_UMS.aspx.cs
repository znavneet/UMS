﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMAT.BIM_UMSWeb.Pages
{
    public partial class BIM_UMS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //[WebMethod]
        //public static List<GridRow> viewMyRequestData(string currentUser)
        //{
        //    Constant obj = new Constant();
        //    JIRA jira = new JIRA();
        //    jira.JiraUrl = Constant.JiraUrlForSearching + "jql='Requester Email' = '" + currentUser + "'";

        //    jira.JiraUserName = obj.UserId;
        //    jira.JiraPassword = obj.Password;

        //    string response = jira.GetUsersRecordsFronJira();
        //    RootObject ro = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(response);
        //    List<GridRow> rowList = new List<GridRow>();

        //    for (int i = 0; i < ro.issues.Count; i++)
        //    {
        //        GridRow newRow = new GridRow();
        //        newRow.Key = ro.issues[i].key;
        //        newRow.Summary = ro.issues[i].fields.summary;
        //        newRow.Category = ro.issues[i].fields.customfield_10540.value;
        //        newRow.Status = ro.issues[i].fields.status.name;
        //        newRow.Priorty = ro.issues[i].fields.priority.name;
        //        string epicName = Convert.ToString(ro.issues[i].fields.customfield_10100);
        //        newRow.ProjectArea = GetEpicName(epicName);

        //        if (ro.issues[i].fields.assignee != null)
        //        {
        //            newRow.Assignee = ro.issues[i].fields.assignee.displayName;
        //            newRow.AssigneeEmail = ro.issues[i].fields.assignee.emailAddress;
        //        }

        //        newRow.Created = ro.issues[i].fields.created.Date.ToString("MM/dd/yyyy");

        //        if (!string.IsNullOrEmpty(ro.issues[i].fields.duedate))
        //            newRow.Duedate = Convert.ToDateTime(ro.issues[i].fields.duedate).ToString("MM/dd/yyyy");


        //        rowList.Add(newRow);
        //    }
        //    return rowList;
          
        //}
        ///// <summary>
        ///// replacing Epic values with BIM-Request, Issues 
        ///// </summary>
        ///// <param name="Values"></param>
        ///// <returns></returns>
        //public static string GetEpicName(string Values)
        //{
        //    if (!string.IsNullOrEmpty(Values))
        //    {
        //        if (Values.Equals(Constant.BIMEpicName))
        //        {
        //            Values = Constant.BIMEpicString;
        //        }
        //        if (Values.Equals(Constant.IssueEpicName))
        //        {
        //            Values = Constant.IssueEpicName;
        //        }
        //    }
        //    return Values;
        //}
    }
}