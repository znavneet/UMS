﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace AMAT.DAL
{
    public class DataAccesslayer
    {
        string connectionString = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnString"].ConnectionString);
        string MSBIConnString = Convert.ToString(ConfigurationManager.ConnectionStrings["MSBIConnString"].ConnectionString);


        public void SaveByPreDispatchTeam(
            string procedureName,
            string Trip_Number,
            string Request_Status,
            string Requestor_Name,
            string Requestor_Id,
            string Planner_Name,
            string Planner_Id,
            string Traveller_Name,
            string Traveller_Id,
            string Traveller_Email,
            string Traveller_Phone,
            string Traveller_Home_Location,
            string Traveller_BU,
            string Traveller_FirstManager,
            string Traveller_SecondtManager,
            string Planned_Start_Date,
            string Planned_End_Date,
            string TravellerOriginCountry,
            string TravellerDestinationCountry,
            string TravellerOriginCity,
            string TravellerDestinationCity,
            string ManagerCost_Center,
            string Travel_Purpose,
            string Tr_Opportunity_Numbers,
            string Traveller_Travel_Objective,
            string Departure_Date,
            string Arrival_Date,
            string FlightDepartureCountry,
            string FlightArrivalCountry,
            string FlightDepartureCity,
            string FlightArrivalCity,
            string DepartureFare,
            string ArrivalFare,
            string Dep_ServiceClass,
            string Arr_ServiceClass,
            string HotelName,
            string HotelCity,
            string HotelCountry,
            string HotelBookedBy,
            string Hotel_CheckInDate,
            string Hotel_CheckoutDate,
            string No_of_Night_Booked,
            string Room_Rate,
            string MDR,
            string IsHotelRateAboveMDR,
            string MRD_Desc,
            string Perdiem,
            string Estimated_Travel_Expense,
            string CreatedDate,
            string ModifiedDate,
            string CreatedBy,
            string ModifiedBy,
            string tripType

           )
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(procedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;

            //Traveller Section
            cmd.Parameters.AddWithValue("@Trip_Number", Trip_Number);
            cmd.Parameters.AddWithValue("@Request_Status", Request_Status);
            cmd.Parameters.AddWithValue("@Requestor_Name", Requestor_Name);
            cmd.Parameters.AddWithValue("@Requestor_Id", Requestor_Id);
            cmd.Parameters.AddWithValue("@Planner_Name", Planner_Name);
            cmd.Parameters.AddWithValue("@Planner_Id", Planner_Id);
            //Opportunity Number
            cmd.Parameters.AddWithValue("@Travel_Purpose", Travel_Purpose);
            cmd.Parameters.AddWithValue("@Tr_Opportunity_Numbers", Tr_Opportunity_Numbers);
            //Traveller Section
            cmd.Parameters.AddWithValue("@Traveller_Name", Traveller_Name);
            cmd.Parameters.AddWithValue("@Traveller_Id", Traveller_Id);
            cmd.Parameters.AddWithValue("@Traveller_Email", Traveller_Email);
            cmd.Parameters.AddWithValue("@Traveller_Phone", Traveller_Phone);
            cmd.Parameters.AddWithValue("@Traveller_Home_Location", Traveller_Home_Location);
            cmd.Parameters.AddWithValue("@Traveller_BU", Traveller_BU);
            cmd.Parameters.AddWithValue("@Traveller_FirstManager", Traveller_FirstManager);
            cmd.Parameters.AddWithValue("@Traveller_SecondManager", Traveller_SecondtManager);

            if (!string.IsNullOrEmpty(Planned_Start_Date))
                cmd.Parameters.AddWithValue("@Planned_Start_Date", Planned_Start_Date);
            else
                cmd.Parameters.AddWithValue("@Planned_Start_Date", DBNull.Value);

            if (!string.IsNullOrEmpty(Planned_End_Date))
                cmd.Parameters.AddWithValue("@Planned_End_Date", Planned_End_Date);
            else
                cmd.Parameters.AddWithValue("@Planned_End_Date", DBNull.Value);

            cmd.Parameters.AddWithValue("@TravellerOriginCountry", TravellerOriginCountry);
            cmd.Parameters.AddWithValue("@TravellerDestinationCountry", TravellerDestinationCountry);
            cmd.Parameters.AddWithValue("@TravellerOriginCity", TravellerOriginCity);
            cmd.Parameters.AddWithValue("@TravellerDestinationCity", TravellerDestinationCity);
            cmd.Parameters.AddWithValue("@Cost_Center", ManagerCost_Center);
            cmd.Parameters.AddWithValue("@Traveller_Travel_Objective", Traveller_Travel_Objective);

            //Flight details
            if (!string.IsNullOrEmpty(Departure_Date))
                cmd.Parameters.AddWithValue("@Departure_Date", Departure_Date);
            else
                cmd.Parameters.AddWithValue("@Departure_Date", DBNull.Value);

            if (!string.IsNullOrEmpty(Arrival_Date))
                cmd.Parameters.AddWithValue("@Arrival_Date", Arrival_Date);
            else
                cmd.Parameters.AddWithValue("@Arrival_Date", DBNull.Value);

            cmd.Parameters.AddWithValue("@FlightDepartureCountry", FlightDepartureCountry);
            cmd.Parameters.AddWithValue("@FlightArrivalCountry", FlightArrivalCountry);
            cmd.Parameters.AddWithValue("@FlightDepartureCity", FlightDepartureCity);
            cmd.Parameters.AddWithValue("@FlightArrivalCity", FlightArrivalCity);
            cmd.Parameters.AddWithValue("@DepartureFare", DepartureFare);
            cmd.Parameters.AddWithValue("@ArrivalFare", ArrivalFare);
            cmd.Parameters.AddWithValue("@Dep_ServiceClass", Dep_ServiceClass);
            cmd.Parameters.AddWithValue("@Arr_ServiceClass", Arr_ServiceClass);
            //Hotel details
            cmd.Parameters.AddWithValue("@HotelName", HotelName);
            cmd.Parameters.AddWithValue("@HotelCountry", HotelCountry);
            cmd.Parameters.AddWithValue("@HotelCity", HotelCity);
            cmd.Parameters.AddWithValue("@HotelBookedBy", HotelBookedBy);

            if (!string.IsNullOrEmpty(Hotel_CheckInDate))
                cmd.Parameters.AddWithValue("@Hotel_CheckInDate", Hotel_CheckInDate);
            else
                cmd.Parameters.AddWithValue("@Hotel_CheckInDate", DBNull.Value);

            if (!string.IsNullOrEmpty(Hotel_CheckoutDate))
                cmd.Parameters.AddWithValue("@Hotel_CheckoutDate", Hotel_CheckoutDate);
            else
                cmd.Parameters.AddWithValue("@Hotel_CheckoutDate", DBNull.Value);

            cmd.Parameters.AddWithValue("@No_of_Night_Booked", No_of_Night_Booked);
            cmd.Parameters.AddWithValue("@Room_Rate", Room_Rate);
            cmd.Parameters.AddWithValue("@MDR", MDR);
            cmd.Parameters.AddWithValue("@IsHotelRateAboveMDR", IsHotelRateAboveMDR);
            cmd.Parameters.AddWithValue("@Hotel_MDR_Desc", MRD_Desc);

            // Estimated expense
            cmd.Parameters.AddWithValue("@Perdiem", Perdiem);
            cmd.Parameters.AddWithValue("@EstimatesTravelExpense", Estimated_Travel_Expense);

            cmd.Parameters.AddWithValue("@CreatedDate", CreatedDate);
            cmd.Parameters.AddWithValue("@ModifiedDate", ModifiedDate);
            cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
            cmd.Parameters.AddWithValue("@ModifiedBy", ModifiedBy);
            cmd.Parameters.AddWithValue("@Triptype", tripType);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        /// <summary>
        /// Data saved by traveller
        /// </summary>
        /// <param name="Actual_StartDate"></param>
        /// <param name="Actual_EndDate"></param>
        /// <param name="Report_Key_Number"></param>
        /// <param name="Expense_Report_Submitted"></param>
        public void SubmitbyTraveller(string Trip_Number, string Request_Status,string Actual_StartDate,string Actual_EndDate, string Report_Key_Number,
            string Expense_Report_Submitted, string IsHotelBookedByDispatch,string travellerHotelName,string travellerHotelCity,string travellerHotelCountry,
            string travellerHotelBkBy, string travellerHotelChkInDt, string travellerHotelChkOutDt, string travellerHotelRate, string travellerComments)
        {


            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("[SaveDataFromPostTraveller]", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Trip_Number", Trip_Number);
            cmd.Parameters.AddWithValue("@Request_Status", Request_Status);

            if (!string.IsNullOrEmpty(Actual_StartDate))
                cmd.Parameters.AddWithValue("@Actual_StartDate", Actual_StartDate);
            else
                cmd.Parameters.AddWithValue("@Actual_StartDate", DBNull.Value);

            if (!string.IsNullOrEmpty(Actual_EndDate))
                cmd.Parameters.AddWithValue("@Actual_EndDate", Actual_EndDate);
            else
                cmd.Parameters.AddWithValue("@Actual_EndDate", DBNull.Value);

            cmd.Parameters.AddWithValue("@Report_Key_Number", Report_Key_Number);
            cmd.Parameters.AddWithValue("@Expense_Report_Submitted_Approved", Expense_Report_Submitted);
            cmd.Parameters.AddWithValue("@IsHotelBookedByDispatch", IsHotelBookedByDispatch);
            cmd.Parameters.AddWithValue("@TravellerHotelName", travellerHotelName);
            cmd.Parameters.AddWithValue("@TravellerHotelCity", travellerHotelCity);
            cmd.Parameters.AddWithValue("@TravellerHotelCountry", travellerHotelCountry);
            cmd.Parameters.AddWithValue("@TravellerHotelBkBy", travellerHotelBkBy);

            if (!string.IsNullOrEmpty(travellerHotelChkInDt))
                cmd.Parameters.AddWithValue("@TravellerHotelChkInDt", travellerHotelChkInDt);
            else
                cmd.Parameters.AddWithValue("@TravellerHotelChkInDt", DBNull.Value);

            if (!string.IsNullOrEmpty(travellerHotelChkOutDt))
                cmd.Parameters.AddWithValue("@TravellerHotelChkOutDt", travellerHotelChkOutDt);
            else
                cmd.Parameters.AddWithValue("@TravellerHotelChkOutDt", DBNull.Value);      

            cmd.Parameters.AddWithValue("@TravellerHotelRate", travellerHotelRate);
            cmd.Parameters.AddWithValue("@TravellerComments", travellerComments);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

    
        
        /// <summary>
        /// Final saved by Dispatch team
        /// </summary>
        /// <param name="Trip_Number"></param>
        /// <param name="Request_Status"></param>
        /// <param name="Reviewed_All"></param>
        /// <param name="actionByDispatch"></param>
        public void SubmitByPostDispatch(string Trip_Number, string Request_Status,string disComments, string finalApproveDt)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("[SaveDataFromPostDispatch]", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Trip_Number", Trip_Number);
            cmd.Parameters.AddWithValue("@Request_Status", Request_Status);
            cmd.Parameters.AddWithValue("@DispatchComments", disComments);
            cmd.Parameters.AddWithValue("@FinalApproveDate", finalApproveDt);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
       
        /// <summary>
        /// this method return data by request no.
        /// </summary>
        /// <param name="reqNum"></param>
        /// <returns></returns>
        public DataTable GetDataByRequestNo(string id,string tabName)
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[GetRequestDetailByRequestNo]", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@tabName", tabName);
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(ds);
                    if (ds.Tables.Count > 0)
                        dt = ds.Tables[0];
                }
            }
            return dt;
        }

        /// <summary>
        /// Get all submitted requests
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllSubmittedRequests(string userName, string userRole)
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[GetAllMainRequest]", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@userName", userName);
                    cmd.Parameters.AddWithValue("@userRole", userRole);
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(ds);
                    if (ds.Tables.Count > 0)
                        dt = ds.Tables[0];
                }
            }
            return dt;
        }

        /// <summary>
      /// Get All draft request data
      /// </summary>
      /// <returns></returns>
        public DataTable GetAllDraftRequest()
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[GetAllDraftRequestData]", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(ds);
                    if (ds.Tables.Count > 0)
                        dt = ds.Tables[0];
                }
            }
            return dt;
        }   

        public DataTable GetRequestHistoryByRequestNo(string requestNo)
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[GetRequestHistoryByRequestNo]", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@requestNo", requestNo);
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(ds);
                    if (ds.Tables.Count > 0)
                        dt = ds.Tables[0];
                }
            }
            return dt;
        }

        /// <summary>
        /// Get Details by Opportunity No
        /// </summary>
        /// <param name="OppoNo"></param>
        /// <returns></returns>
        public DataTable GetDetailByOpportunityNo(string OppoNo)
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(MSBIConnString))
            {
                using (SqlCommand cmd = new SqlCommand("[GetIceDetailsFromOppoNo]", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@OppoNo", OppoNo);
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(ds);
                    if (ds.Tables.Count > 0)
                        dt = ds.Tables[0];
                }
            }
            return dt;
        }

        /// <summary>
        /// Reverting request by manageror by dispatch
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="tripNumber"></param>
        /// <param name="requestStatus"></param>
        /// <param name="revertBy"></param>
        /// <param name="isReportApprroved"></param>
        /// <param name="appClosure"></param>
        /// <param name="apprvComments"></param>
        /// <param name="expnsExceed"></param>
        /// <param name="justification"></param>
        /// <param name="reviewall"></param>
        public void RevertRequest(string procedureName, string tripNumber, string requestStatus, string dispatchComments)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(procedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@requestNo", tripNumber);
            cmd.Parameters.AddWithValue("@requestStatus", requestStatus);      
            cmd.Parameters.AddWithValue("@dispatchComments", dispatchComments);
            
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        /// <summary>
        /// Get Request No 
        /// </summary>
        /// <param name="maxNo"></param>
        /// <returns></returns>
        public string GetRequestNo()
        {
            string requestNo = string.Empty;
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[GetRequestNo]", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(ds);
                    requestNo = Convert.ToString(ds.Tables[0].Rows[0][0]);
                }
            }
            return requestNo;
        }


        public void SubmitByDispatch(string procedureName,
            string Trip_Number,
            string Request_Status,
            string Requestor_Name,
            string Requestor_Id,
            string Planner_Name,
            string Planner_Id,
            string Traveller_Name,
            string Traveller_Id,
            string Traveller_Email,
            string Traveller_Phone,
            string Traveller_Home_Location,
            string Traveller_BU,
            string Traveller_FirstManager,
            string Traveller_SecondtManager,
            string Planned_Start_Date,
            string Planned_End_Date,
            string TravellerOriginCountry,
            string TravellerDestinationCountry,
            string TravellerOriginCity,
            string TravellerDestinationCity,
            string ManagerCost_Center,
            string Travel_Purpose,
            string Tr_Opportunity_Numbers,
            string Traveller_Travel_Objective,
            string Departure_Date,
            string Arrival_Date,
            string FlightDepartureCountry,
            string FlightArrivalCountry,
            string FlightDepartureCity,
            string FlightArrivalCity,
            string DepartureFare,
            string ArrivalFare,
            string Dep_ServiceClass,
            string Arr_ServiceClass,
            string HotelName,
            string HotelCity,
            string HotelCountry,
            string HotelBookedBy,
            string Hotel_CheckInDate,
            string Hotel_CheckoutDate,
            string No_of_Night_Booked,
            string Room_Rate,
            string MDR,
            string IsHotelRateAboveMDR,
            string MRD_Desc,
            string Perdiem,          
            string Estimated_Travel_Expense,
           //string CreatedDate,
            string ModifiedDate,
           //string CreatedBy,
            string ModifiedBy,
            string IsDraft,
            string tripType

           )
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(procedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;

            //Traveller Section
            cmd.Parameters.AddWithValue("@Trip_Number", Trip_Number);
            cmd.Parameters.AddWithValue("@Request_Status", Request_Status);
            //cmd.Parameters.AddWithValue("@Requestor_Name", Requestor_Name);
            //cmd.Parameters.AddWithValue("@Requestor_Id", Requestor_Id);
            cmd.Parameters.AddWithValue("@Planner_Name", Planner_Name);
            cmd.Parameters.AddWithValue("@Planner_Id", Planner_Id);
            //Opportunity Number
            cmd.Parameters.AddWithValue("@Travel_Purpose", Travel_Purpose);
            cmd.Parameters.AddWithValue("@Tr_Opportunity_Numbers", Tr_Opportunity_Numbers);
            //Traveller Section
            cmd.Parameters.AddWithValue("@Traveller_Name", Traveller_Name);
            cmd.Parameters.AddWithValue("@Traveller_Id", Traveller_Id);
            cmd.Parameters.AddWithValue("@Traveller_Email", Traveller_Email);
            cmd.Parameters.AddWithValue("@Traveller_Phone", Traveller_Phone);
            cmd.Parameters.AddWithValue("@Traveller_Home_Location", Traveller_Home_Location);
            cmd.Parameters.AddWithValue("@Traveller_BU", Traveller_BU);
            cmd.Parameters.AddWithValue("@Traveller_FirstManager", Traveller_FirstManager);
            cmd.Parameters.AddWithValue("@Traveller_SecondManager", Traveller_SecondtManager);

            if (!string.IsNullOrEmpty(Planned_Start_Date))
                cmd.Parameters.AddWithValue("@Planned_Start_Date", Planned_Start_Date);
            else
                cmd.Parameters.AddWithValue("@Planned_Start_Date", DBNull.Value);

            if (!string.IsNullOrEmpty(Planned_End_Date))
                cmd.Parameters.AddWithValue("@Planned_End_Date", Planned_End_Date);
            else
                cmd.Parameters.AddWithValue("@Planned_End_Date", DBNull.Value);            
        
            cmd.Parameters.AddWithValue("@TravellerOriginCountry", TravellerOriginCountry);
            cmd.Parameters.AddWithValue("@TravellerDestinationCountry", TravellerDestinationCountry);
            cmd.Parameters.AddWithValue("@TravellerOriginCity", TravellerOriginCity);
            cmd.Parameters.AddWithValue("@TravellerDestinationCity", TravellerDestinationCity);
            cmd.Parameters.AddWithValue("@Cost_Center", ManagerCost_Center);
            cmd.Parameters.AddWithValue("@Traveller_Travel_Objective", Traveller_Travel_Objective);

            //Flight details

            if (!string.IsNullOrEmpty(Departure_Date))
                cmd.Parameters.AddWithValue("@Departure_Date", Departure_Date);
            else
                cmd.Parameters.AddWithValue("@Departure_Date", DBNull.Value);

            if (!string.IsNullOrEmpty(Arrival_Date))
                cmd.Parameters.AddWithValue("@Arrival_Date", Arrival_Date);
            else
                cmd.Parameters.AddWithValue("@Arrival_Date", DBNull.Value);         
      
            cmd.Parameters.AddWithValue("@FlightDepartureCountry", FlightDepartureCountry);
            cmd.Parameters.AddWithValue("@FlightArrivalCountry", FlightArrivalCountry);
            cmd.Parameters.AddWithValue("@FlightDepartureCity", FlightDepartureCity);
            cmd.Parameters.AddWithValue("@FlightArrivalCity", FlightArrivalCity);
            cmd.Parameters.AddWithValue("@DepartureFare", DepartureFare);
            cmd.Parameters.AddWithValue("@ArrivalFare", ArrivalFare);
            cmd.Parameters.AddWithValue("@Dep_ServiceClass", Dep_ServiceClass);
            cmd.Parameters.AddWithValue("@Arr_ServiceClass", Arr_ServiceClass);
            //Hotel details
            cmd.Parameters.AddWithValue("@HotelName", HotelName);
            cmd.Parameters.AddWithValue("@HotelCity", HotelCity);
            cmd.Parameters.AddWithValue("@HotelCountry", HotelCountry);
            cmd.Parameters.AddWithValue("@HotelBookedBy", HotelBookedBy);

            if (!string.IsNullOrEmpty(Hotel_CheckInDate))
                cmd.Parameters.AddWithValue("@Hotel_CheckInDate", Hotel_CheckInDate);
            else
                cmd.Parameters.AddWithValue("@Hotel_CheckInDate", DBNull.Value);

            if (!string.IsNullOrEmpty(Hotel_CheckoutDate))
                cmd.Parameters.AddWithValue("@Hotel_CheckoutDate", Hotel_CheckoutDate);
            else
                cmd.Parameters.AddWithValue("@Hotel_CheckoutDate", DBNull.Value);      
      
            cmd.Parameters.AddWithValue("@No_of_Night_Booked", No_of_Night_Booked);
            cmd.Parameters.AddWithValue("@Room_Rate", Room_Rate);
            cmd.Parameters.AddWithValue("@MDR", MDR);
            cmd.Parameters.AddWithValue("@IsHotelRateAboveMDR", IsHotelRateAboveMDR);
            cmd.Parameters.AddWithValue("@Hotel_MDR_Desc", MRD_Desc);

            // Estimated expense
            cmd.Parameters.AddWithValue("@Perdiem", Perdiem);
            cmd.Parameters.AddWithValue("@EstimatesTravelExpense", Estimated_Travel_Expense);

            //cmd.Parameters.AddWithValue("@CreatedDate", CreatedDate);
            cmd.Parameters.AddWithValue("@ModifiedDate", ModifiedDate);
         //   cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
            cmd.Parameters.AddWithValue("@ModifiedBy", ModifiedBy);
            cmd.Parameters.AddWithValue("@IsDraft", IsDraft);
            cmd.Parameters.AddWithValue("@Triptype", tripType);


            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
