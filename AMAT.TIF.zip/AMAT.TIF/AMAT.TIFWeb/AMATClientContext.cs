﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.SharePoint.Client;
using System.Security;


namespace AMAT.TIFWeb
{
    public class AMATClientContext
    {
        string siteURL = Convert.ToString(ConfigurationManager.AppSettings["SiteURL"]);
        string UserName = Convert.ToString(ConfigurationManager.AppSettings["UserName"]);
        string Password = Convert.ToString(ConfigurationManager.AppSettings["Password"]);

        //public ClientContext GetClientContext(HttpContext httpContext)
        //{
        //    var securePassword = new SecureString();           
        //    string envSiteUrl = string.Empty;
        //    ClientContext clientContext = null;

        //    clientContext = new ClientContext(siteURL);
         
        //    foreach (char c in Password)
        //        securePassword.AppendChar(c);
        //    securePassword.MakeReadOnly();

        //    clientContext.Credentials = new SharePointOnlineCredentials(UserName, securePassword);
                    
        //    return clientContext;
        //}

        public ClientContext GetClientContext(string UserName, string Password)
        {
            HttpContext httpContext = HttpContext.Current;

            return GetClientContext(httpContext, UserName, Password);
        }

        public ClientContext GetClientContext(HttpContext httpContext, string UserName, string Password)
        {
            var securePassword = new SecureString();
            string envSiteUrl = string.Empty;
            ClientContext clientContext = null;

            clientContext = new ClientContext(siteURL);

            foreach (char c in Password)
                securePassword.AppendChar(c);
            securePassword.MakeReadOnly();

            clientContext.Credentials = new SharePointOnlineCredentials(UserName, securePassword);

            return clientContext;
        }

    }
}
