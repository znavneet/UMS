﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMAT.BAL;
using System.Data;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.UserProfiles;
using System.Web.Script.Services;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.IO;
using System.Security;

namespace AMAT.TIFWeb.Pages
{
    public partial class TIF_Form_History : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!string.IsNullOrEmpty(Request.QueryString["tripId"]))
            {
                string tripId = Convert.ToString(Request.QueryString["tripId"]);
                GetTripHistory(tripId);
            }
        }

        /// <summary>
        /// get trip history by trip id
        /// </summary>
        /// <param name="tripId"></param>
        protected void GetTripHistory(string tripId)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    BusinessAccessLayer ba = new BusinessAccessLayer();
                    DataTable dt = ba.GetRequestHistoryByRequestNo(tripId);

                    List<TIFClass> tifObjs = new List<BAL.TIFClass>();
                    foreach (DataRow dr in dt.Rows)
                    {
                        TIFClass tifObj = new BAL.TIFClass();
                        string tripNo = Convert.ToString(dr["Trip_Number"]);
                        tifObj.Trip_Number = tripNo;
                        tifObj.Traveller_Name = Convert.ToString(dr["Traveller_Name"]);
                        tifObj.Tr_Opportunity_Numbers = Convert.ToString(dr["Tr_Opportunity_Numbers"]);

                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Planned_Start_Date"])))
                            tifObj.Planned_Start_Date = Convert.ToDateTime(dr["Planned_Start_Date"]).ToString("MM/dd/yyyy");

                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Planned_End_Date"])))
                            tifObj.Planned_End_Date = Convert.ToDateTime(dr["Planned_End_Date"]).ToString("MM/dd/yyyy");
                 
                        tifObj.CreatedBy = Convert.ToString(dr["CreatedBy"]);
                        tifObj.ModifiedBy = Convert.ToString(dr["ModifiedBy"]);

                        if (!string.IsNullOrEmpty(Convert.ToString(dr["CreatedDate"])))
                            tifObj.CreatedDate = Convert.ToDateTime(dr["CreatedDate"]).ToString("MM/dd/yyyy");

                        if (!string.IsNullOrEmpty(Convert.ToString(dr["ModifiedDate"])))
                            tifObj.ModifiedDate = Convert.ToDateTime(dr["ModifiedDate"]).ToString("MM/dd/yyyy");

                        tifObjs.Add(tifObj);
                    }
                    grdHistory.DataSource = tifObjs;
                    grdHistory.DataBind();

                }
                catch(Exception ex)
                {

                }
            }
        
        }
        
    }
}