﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using AMAT.BAL;
using System.Security;


namespace AMAT.TIFWeb.Pages
{
    /// <summary>
    /// Summary description for TIFWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    [System.Web.Script.Services.ScriptService] 
  
    public class TIFWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string GetPerdiem(string Origin, string Dest, string siteUrl, string UserId, string Pwd)
        {
            string value = string.Empty;
            using (ClientContext clientContext = GetContext(siteUrl, UserId, Pwd))
            {
                try
                {
                    List oList = clientContext.Web.Lists.GetByTitle(Constants.PerDiemList);
                    CamlQuery query = new CamlQuery();
                    query.ViewXml = "<View><Query><Where><And><Eq><FieldRef Name='Title' /><Value Type='Text'>" + Origin + "</Value></Eq><Eq><FieldRef Name='TravelCountry' /><Value Type='Text'>" + Dest + "</Value></Eq></And></Where></Query></View>";

                    ListItemCollection items = oList.GetItems(query);
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null && items.Count > 0)
                    {
                        ListItem item = items[0];
                        value = Convert.ToString(item["Total"]);
                    }
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetPerdiem", "TIFWebService.aspx");
                }
                return value;
            }
        }

        /// <summary>
        /// Get client context by user credentials
        /// </summary>
        /// <param name="siteUrl"></param>
        /// <param name="uid"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        public ClientContext GetContext(string siteUrl, string uid, string pwd)
        {
            ClientContext clientContext = new ClientContext(siteUrl);
            var securePassword = new SecureString();
            foreach (char c in pwd)
                securePassword.AppendChar(c);
            securePassword.MakeReadOnly();

            using (clientContext = new ClientContext(siteUrl))
            {
                clientContext.Credentials = new SharePointOnlineCredentials(uid, securePassword);
            }            
            return clientContext;
        }
    }
}
