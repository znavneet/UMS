﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMAT.BAL;
using System.Data;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.UserProfiles;
using System.Web.Script.Services;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.IO;
using System.Security;
using AMAT.Utilities.ExcelComponent;
using DocumentFormat.OpenXml;
using System.Web.Script.Serialization;


namespace AMAT.TIFWeb.Pages
{
    public partial class TIF : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            CheckPermissionForCurrentUser(); // checking for current user permission.
            if (!Page.IsPostBack)
            {
                GetAllFormData();
                string emailAddress = Convert.ToString(currentLoggedInUser.Value);
                if (!string.IsNullOrEmpty((emailAddress)))
                {
                    ADMethods.ADAttributes ADResult = GetUserDetails(emailAddress);
                    if (ADResult != null)
                    {
                        hdnCurrentUserId.Value = ADResult.employeeId;
                        hdnCurrentUserName.Value = ADResult.displayName;
                        tbRequestor.Text = Convert.ToString(hdnCurrentUserName.Value);
                        tbRequestorID.Text = Convert.ToString(hdnCurrentUserId.Value);
                    }
                }
            }           
        }

        #region Page load functions

        /// <summary>
        /// to Loading all form data in single call from sharepoint
        /// </summary>
        protected void GetAllFormData()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List countrylist = clientContext.Web.Lists.GetByTitle(Constants.CountryList);
                    List trvelTypeList = clientContext.Web.Lists.GetByTitle(Constants.Travel_Type);
                    List accountList = clientContext.Web.Lists.GetByTitle(Constants.TIF_Configuration);               
                    User user = clientContext.Web.CurrentUser;


                    CamlQuery queryCountry = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection countryItems = countrylist.GetItems(queryCountry);

                    CamlQuery trvelQuery = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection travelitems = trvelTypeList.GetItems(trvelQuery);

                    CamlQuery accountQuery = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection cred = accountList.GetItems(accountQuery);

                    //CamlQuery queryAirportLocation = new CamlQuery();
                    //queryAirportLocation.ViewXml = "@<View><Query><Where><Eq><FieldRef Name ='IsCountry' /><Value Type='Choice'>No</Value></Eq></Where></Query><ViewFields><FieldRef Name='Title' /></ViewFields></View>";
                    //Microsoft.SharePoint.Client.ListItemCollection itemsAirLoc = oList.GetItems(queryAirportLocation);

                    clientContext.Load(countryItems);
                    clientContext.Load(travelitems);
                    clientContext.Load(user);
                    clientContext.Load(cred);
                   // clientContext.Load(itemsAirLoc);
                    clientContext.ExecuteQuery();

                    // bind purpose dropdown
                    ddlPurpose.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
                    for (int i = 0; i < travelitems.Count; i++)
                        ddlPurpose.Items.Add(new System.Web.UI.WebControls.ListItem(Convert.ToString(travelitems[i]["Title"]), Convert.ToString(travelitems[i]["ID"])));

                    currentLoggedInUser.Value = Convert.ToString(user.Email);

                    // bind All country dropdown
                    foreach (Microsoft.SharePoint.Client.ListItem item in countryItems)
                    {
                        string text = Convert.ToString(item["Title"]);
                        ddlOriginCountry.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlDestination.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlIterneryCountry1.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlIterneryCountry2.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlHotelCountry.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                    }
                    AddSelectInDropdown(ddlOriginCountry, ddlDestination, ddlIterneryCountry1, ddlIterneryCountry2, ddlHotelCountry);

                    // get userid passport account
                    foreach (Microsoft.SharePoint.Client.ListItem olist in cred)
                    {
                        hdnserviceuser.Value = olist["UserName"].ToString();
                        hdnservicepassword.Value = olist["Password"].ToString();
                    }
                   
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetAllFormData", "TIF.aspx");
                 
                }
            }
        }     

        protected void AddSelectInDropdown(DropDownList ddl1, DropDownList ddl2, DropDownList ddl3, DropDownList ddl4, DropDownList ddl5)
        {
            ddl1.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl2.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl3.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl4.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl5.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
        }    
               
        protected bool GetCurrentUserGroup(string grpName)
        {
            bool isUserExists = false;

            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    Web oWeb = clientContext.Web;
                    GroupCollection oGroups = oWeb.CurrentUser.Groups;

                    clientContext.Load(oGroups, g => g.Include(gi => gi.Title));
                    clientContext.ExecuteQuery();
                    for (int i = 0; i < oGroups.Count; i++)
                    {
                        string currentGrp = oGroups[i].Title;
                        if (currentGrp == grpName)
                        {
                            isUserExists = true;
                        }
                    }
                }
                catch (Exception ex)
                {

                }
            }
            return isUserExists;
        }
        
        protected ADMethods.ADAttributes GetUserDetails(string emailAddress)
        {
            //GetLoggedInUser();
            ADMethods.ADAttributes ADResult = null;
            bool isUserExists = false;
            ADMethods AD = new ADMethods();

            isUserExists = AD.IsUserExist(emailAddress, ADMethods.AdPrpoertyParameters.mail);
            if (isUserExists)
            {
                ADResult = AD.GetEmployeeAttributes(emailAddress, ADMethods.AdPrpoertyParameters.mail);

            }
            return ADResult;
        }


        #endregion

        #region All click Events

        protected void btnRequestSave_Click(object sender, EventArgs e)
        {
             var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
             using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
             {
                 try
                 {
                     string existingRequestNo = txtRequestNum.Text;   
                     BusinessAccessLayer bu = new BAL.BusinessAccessLayer();
                     TIFClass obj = GetPreTravelFormsValue(existingRequestNo);
                     bu.SaveByPreDispatch(obj, existingRequestNo);
                     ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alertmsg", "alert('Trip no " + obj.Trip_Number + " request saved successfully.')", true);
                     ClearFormBoxes(form1);
                 }
                 catch (Exception ex)
                 {
                     Constants.ErrorLog(clientContext, ex.Message, ex.Source, "btnRequestSave_Click", "TIF.aspx");
                 }
             }

        }

        protected void btnRequestSubmit_Click(object sender, EventArgs e)
        {
            
        }
       
        protected void btnExcelExpo_Click(object sender, EventArgs e)
        {
            DataTable dt = null;

            string value = hdnMainTabValue.Value;
            if (value.Equals("Main"))
                dt = (DataTable)Session["AllMainRequest"];

            if (value.Equals("Draft"))
                dt = (DataTable)Session["AllDraftRequest"];

            ExportToExcel(dt);
        }

        #endregion              

        #region  Getting the Pre tavel values in TIF class object

        private TIFClass GetPreTravelFormsValue(string existingRequestNo)
        {
            string requestNo = string.Empty;
            TIFClass obj = new TIFClass();
            BusinessAccessLayer ba = new BAL.BusinessAccessLayer();
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    if (string.IsNullOrEmpty(existingRequestNo))
                        requestNo = ba.GetRequestNo();
                    else
                        requestNo = existingRequestNo;
                      
                    obj.Trip_Number = requestNo;
                    obj.Requestor_Name = tbRequestor.Text.Trim();
                    obj.Requestor_Id = tbRequestorID.Text.Trim();
                    obj.Planner_Id = tbPlannerID.Text.Trim();
                    obj.Planner_Name = txtPlanner.Text.Trim();
                    obj.Travel_Purpose = hdntravelPurpose.Value.Trim();
                    obj.Tr_Opportunity_Numbers = txtoppNo.Text.Trim();
                    obj.Traveller_Name = txtTravellerName.Text.Trim();
                    obj.Traveller_Id = tbTravellerID.Text.Trim();
                    obj.Traveller_Email = tbTravellerEmail.Text;
                    obj.Traveller_Home_Location = txthomeLocation.Text.Trim();
                    obj.Traveller_BU = txtBu.Text.Trim();
                    obj.Traveller_Phone = Convert.ToString(tbTravellerPhone.Text);                  
                    obj.Traveller_FirstManager = tbLevelOneManager.Text;
                    obj.Traveller_SecondManager = tbSecondLevelManager.Text;
                    obj.Planned_Start_Date = tbPlannedStartDate.Text.Trim();
                    obj.Planned_End_Date = tbPlannedEndDate.Text.Trim();

                    if (ddlOriginCountry.SelectedItem.Value !="0")
                    obj.Traveller_Origin_Country = ddlOriginCountry.SelectedItem.Value;//hdnOriginCountry.Value;

                    if (ddlDestination.SelectedItem.Value != "0")
                    obj.Traveller_Destination_Country = ddlDestination.SelectedItem.Value;// hdnDestinationCountry.Value;

                    obj.Traveller_Origin_City = txtOriginCity.Text.Trim();
                    obj.Traveller_Destination_City = txtdestCity.Text.Trim();
                    obj.Cost_Center = tbCostCenter.Text.Trim();
                    obj.Traveller_Travel_Objective = tbTravelObjective.InnerText;
                    obj.TripType = rdTriptype.SelectedItem.Value;

                    obj.Flight_Departure_Date = tbDepartureDate.Text.Trim();
                    obj.Flight_Arrival_Date = tbReturnDate.Text.Trim();

                    if (ddlIterneryCountry1.SelectedItem.Value != "0")
                    obj.Flight_Dep_Country = ddlIterneryCountry1.SelectedItem.Value;

                    if (ddlIterneryCountry2.SelectedItem.Value != "0")
                    obj.Flight_Arr_Country = ddlIterneryCountry2.SelectedItem.Value;
                    obj.Flight_Dep_City = txtIterneryCity1.Text.Trim();
                    obj.Flight_Arr_City = txtIterneryCity2.Text.Trim();

                    obj.Dep_Fare = tbDepartureFare.Text.Trim();
                    obj.Arr_Fare = tbReturnFare.Text.Trim();

                    if (ddDepartureServiceType.SelectedItem.Value != "0")
                    obj.Dep_ServiceClass = ddDepartureServiceType.SelectedItem.Value;

                    if (ddlReturnServiceType.SelectedItem.Value != "0")
                    obj.Arr_ServiceClass = ddlReturnServiceType.SelectedItem.Value;

                    obj.Hotel_Name = tbHotelName.Text.Trim();
                    obj.Hotel_City = txtHotelCity.Text.Trim();

                    if (ddlHotelCountry.SelectedItem.Value != "0")
                    obj.Hotel_Country = ddlHotelCountry.SelectedItem.Value;

                    if (ddlBookedBy.SelectedItem.Value != "0")
                    obj.Hotel_BookedBy = ddlBookedBy.SelectedItem.Value;
                    obj.Hotel_CheckInDate = tbCheckinDate.Text.Trim();
                    obj.Hotel_CheckoutDate = tbCheckoutDate.Text.Trim();
                    obj.No_of_Night_Booked = Request.Form[tbNoOfNights.UniqueID];// tbNoOfNights.Text.Trim();

                    obj.Room_Rate = tbRoomRate.Text.Trim();
                    obj.MDR = txtMdr.Text.Trim();

                    if(ddlHotelRateMDR.SelectedItem.Value != "0")
                    obj.IsHotelRateAboveMDR = ddlHotelRateMDR.SelectedItem.Value;
                    obj.Hotel_MdR_Desc = tbMDRJustification.InnerText;
                 
                    obj.CreatedBy    = tbRequestor.Text.Trim();
                    obj.ModifiedBy   = tbRequestor.Text.Trim();
                    obj.CreatedDate  = DateTime.Now.ToString("MM/dd/yyyy");
                    obj.ModifiedDate = DateTime.Now.ToString("MM/dd/yyyy"); 
                 
                    // estimated Fare calculation
                    //int deptFare = Convert.ToInt32(tbDepartureFare.Text.Trim());
                    //int arrFare = Convert.ToInt32(tbReturnFare.Text.Trim());
                    //int noOfNight = Convert.ToInt32(tbNoOfNights.Text.Trim());
                    //int roomRate = Convert.ToInt32(tbRoomRate.Text.Trim());
                    //roomRate = roomRate * noOfNight;
                    //string TotalFare = Convert.ToString(deptFare + arrFare + roomRate);

                  //  obj.PerDiem = Request.Form[txtPerDiem.UniqueID];

                    obj.PerDiem = txtPerDiem.Text.Trim();
                    obj.Estimated_Travel_Expense = Request.Form[tbEstTravelSpend.UniqueID];

                    obj.Request_Status = Constants.RequestAsDraft;
                   

                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetPreTravelFormsValue()", "TIF.aspx");
                }
            }
            return obj;
        }

       

        #endregion
      
        #region  Getting the post tavel values in PostTravellerClass class object

        private PostTravellerClass GetPostTravelValuesTravaller()
        {
            PostTravellerClass obj = new PostTravellerClass();
             var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
             using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
             {
                 try
                 {
                     obj.Actual_StartDate = txtActualStartDate.Text.Trim();
                     obj.Actual_EndDate = txtActualEndDate.Text.Trim();
                     obj.ExpenseReportSubmitted = ddlExpRptSubAprd.SelectedItem.Text;
                     obj.Report_Key_Number = txtReportKey.Text.Trim();
                 }
                 catch (Exception ex)
                 {
                     Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetPreTravelFormsValue()", "TIF.aspx");
                 }
             }
            return obj;
        }

        #endregion            
   
        #region All Webmethods, All request draft request, user properties for Grid

        [WebMethod]
        public static List<TIFClass> ViewAllRequestData(string userName, string userRole)
        {
            List<TIFClass> tifObjs = null;
            if (!string.IsNullOrEmpty(userRole))
            {
                BusinessAccessLayer obj = new BusinessAccessLayer();
                DataTable dt = new DataTable();

                if (userRole == Constants.TravellerGp || userRole == Constants.InBothRole)
                {
                    //userName = "Katsuyoshi Koda";
                    dt = obj.GetAllSubmittedRequests(userName, userRole);
                }

                if (userRole == Constants.DispatchTeamGp || userRole == Constants.InBothRole)
                    dt = obj.GetAllSubmittedRequests(null, userRole);

                HttpContext.Current.Session["AllMainRequest"] = dt;

                tifObjs = new List<BAL.TIFClass>();
                foreach (DataRow dr in dt.Rows)
                {
                    TIFClass tifObj = new BAL.TIFClass();
                    tifObj.Trip_Number = Convert.ToString(dr["Trip_Number"]);
                    tifObj.Request_Status = Convert.ToString(dr["Request_Status"]);
                    tifObj.Requestor_Name = Convert.ToString(dr["Requestor_Name"]);
                    tifObj.Traveller_Name = Convert.ToString(dr["Traveller_Name"]);
                    tifObj.Traveller_Id = Convert.ToString(dr["Traveller_Id"]);
                    tifObj.Traveller_BU = Convert.ToString(dr["Traveller_BU"]);
                    tifObj.Travel_Purpose = Convert.ToString(dr["Travel_Purpose"]);
                    tifObj.Tr_Opportunity_Numbers = Convert.ToString(dr["Tr_Opportunity_Numbers"]);

                    if (!string.IsNullOrEmpty(Convert.ToString(dr["Planned_Start_Date"])))
                        tifObj.Planned_Start_Date = Convert.ToDateTime(dr["Planned_Start_Date"]).ToString("MM/dd/yyyy");

                    if (!string.IsNullOrEmpty(Convert.ToString(dr["Planned_End_Date"])))
                        tifObj.Planned_End_Date = Convert.ToDateTime(dr["Planned_End_Date"]).ToString("MM/dd/yyyy");

                    tifObj.Traveller_Origin_Country = Convert.ToString(dr["TravellerOriginCountry"]);
                    tifObj.Traveller_Destination_Country = Convert.ToString(dr["TravellerDestinationCountry"]);
                    tifObj.Estimated_Travel_Expense = Convert.ToString(dr["EstimatesTravelExpense"]);
                    tifObj.CreatedDate = Convert.ToDateTime(dr["CreatedDate"]).ToString("MM/dd/yyyy"); ;
                    tifObjs.Add(tifObj);
                }

            }
            return tifObjs;
        }

        [WebMethod(EnableSession = true)]
        public static List<TIFClass> ViewAllDraftRequest()
        {
            BusinessAccessLayer obj = new BusinessAccessLayer();
            DataTable dt = new DataTable();
            dt = obj.GetAllDraftRequest();
            HttpContext.Current.Session["AllDraftRequest"] = dt;           

            List<TIFClass> tifObjs = new List<BAL.TIFClass>();
            foreach (DataRow dr in dt.Rows)
            {
                TIFClass tifObj = new BAL.TIFClass();
                tifObj.Trip_Number = Convert.ToString(dr["Trip_Number"]);
                tifObj.Request_Status = Convert.ToString(dr["Request_Status"]);
                tifObj.Requestor_Name = Convert.ToString(dr["Requestor_Name"]);
                tifObj.Traveller_Name = Convert.ToString(dr["Traveller_Name"]);
                tifObj.Traveller_Id = Convert.ToString(dr["Traveller_Id"]);
                tifObj.Traveller_BU = Convert.ToString(dr["Traveller_BU"]);
                tifObj.Travel_Purpose = Convert.ToString(dr["Travel_Purpose"]);
                tifObj.Tr_Opportunity_Numbers = Convert.ToString(dr["Tr_Opportunity_Numbers"]);

                if (!string.IsNullOrEmpty(Convert.ToString(dr["Planned_Start_Date"])))
                    tifObj.Planned_Start_Date = Convert.ToDateTime(dr["Planned_Start_Date"]).ToString("MM/dd/yyyy");

                if (!string.IsNullOrEmpty(Convert.ToString(dr["Planned_End_Date"])))
                    tifObj.Planned_End_Date = Convert.ToDateTime(dr["Planned_End_Date"]).ToString("MM/dd/yyyy");

                tifObj.Traveller_Origin_Country = Convert.ToString(dr["TravellerOriginCountry"]);
                tifObj.Traveller_Destination_Country = Convert.ToString(dr["TravellerDestinationCountry"]);
                tifObj.Estimated_Travel_Expense = Convert.ToString(dr["EstimatesTravelExpense"]);
                tifObj.CreatedDate = Convert.ToDateTime(dr["CreatedDate"]).ToString("MM/dd/yyyy");
                tifObjs.Add(tifObj);
            }       

            return tifObjs;
            
        }

        [WebMethod]
        public static List<UserProperty> GetADUsers(string username)
        {
            List<UserProperty> lstADUsers = new List<UserProperty>();
         
            if (!string.IsNullOrEmpty(username))
            {
                using (PrincipalContext context = new PrincipalContext(ContextType.Domain))
                {
                    UserPrincipal user = new UserPrincipal(context);
                    user.DisplayName = username + "*";
                    using (PrincipalSearcher srch = new PrincipalSearcher(user))
                    {
                        int i = 0;
                        foreach (var result in srch.FindAll())
                        {

                            DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;
                            if (!String.IsNullOrEmpty((String)de.Properties["displayName"].Value))
                            {
                                i++;
                                UserProperty usp = new BAL.UserProperty();
                                usp.UserName = de.Properties["displayName"].Value.ToString();
                                if (de.Properties["EmployeeId"].Value != null)
                                    usp.EmpId = de.Properties["EmployeeId"].Value.ToString();
                                else
                                    usp.EmpId = string.Empty;

                                lstADUsers.Add(usp);
                                if (i == 7) break;

                            }
                        }
                    }
                }
            }
            return lstADUsers;
        }

        [WebMethod]
        public static List<TIFClass> GetTravellerAdValues(string userId)
        {
            List<TIFClass> lstADUser = new List<TIFClass>();

            TIFClass obj = new BAL.TIFClass();
            if (!string.IsNullOrEmpty(userId))
            {
                ADMethods.ADAttributes ADResult = null;
                ADMethods AD = new ADMethods();
                ADResult = AD.GetEmployeeAttributes(userId, ADMethods.AdPrpoertyParameters.employeeid);
                if (ADResult != null)
                {
                    obj.Traveller_Name = ADResult.displayName;
                    obj.Traveller_Id = ADResult.employeeId;
                    obj.Traveller_Email = ADResult.mail;
                    obj.Traveller_Phone = ADResult.telephoneNumber;
                    obj.Traveller_Home_Location = ADResult.Location;
                    obj.Traveller_BU = ADResult.division;
                    obj.Traveller_FirstManager = ADResult.ManagerDisplayName;
                    lstADUser.Add(obj);
                }
            }
            return lstADUser;
        }

        [WebMethod(EnableSession = true)]
        public static List<Traveller> GetTrvellerDetailsFromOppoNo(string oppoNo)
        {
            BusinessAccessLayer ba = new BusinessAccessLayer();
            List<Traveller> obj = null;
            if (!string.IsNullOrEmpty(oppoNo))
            {
                DataTable dt = ba.GetDetailByOpportunityNo(oppoNo);
                HttpContext.Current.Session["UsersDetails"] = dt;
                obj = ba.GetTravellerName(dt);
            }
            return obj;
        }

        /// <summary>
        /// Filling the user details on bases of selected traveller dropdown
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [WebMethod(EnableSession = true)]
        public static List<TIFClass> GetSingleTravellerDetail(string id)
        {
            BusinessAccessLayer ba = new BusinessAccessLayer();
            DataTable dt = (DataTable)HttpContext.Current.Session["UsersDetails"];
            List<TIFClass> obj = ba.GetTravllerDetails(dt, id);
            return obj;
        }

        [WebMethod(EnableSession = true)]
        public static List<TIFClass> GetPerdiemValue(string home)
        {
            BusinessAccessLayer obj = new BusinessAccessLayer();
            DataTable dt = new DataTable();
            dt = obj.GetAllDraftRequest();
            HttpContext.Current.Session["AllDraftRequest"] = dt;

            List<TIFClass> tifObjs = new List<BAL.TIFClass>();
            foreach (DataRow dr in dt.Rows)
            {
                TIFClass tifObj = new BAL.TIFClass();
                string tripNo = Convert.ToString(dr["Trip_Number"]);// +"-" + Convert.ToString(dr["ID"]);
                tifObj.Trip_Number = tripNo;
                tifObj.Requestor_Name = Convert.ToString(dr["Requestor_Name"]);
                tifObj.Traveller_Name = Convert.ToString(dr["Traveller_Name"]);
                tifObj.Traveller_Id = Convert.ToString(dr["Traveller_Id"]);
                tifObj.Travel_Purpose = Convert.ToString(dr["Travel_Purpose"]);
                tifObj.Tr_Opportunity_Numbers = Convert.ToString(dr["Tr_Opportunity_Numbers"]);
                tifObj.CreatedBy = Convert.ToString(dr["CreatedBy"]);
                tifObj.ModifiedBy = Convert.ToString(dr["ModifiedBy"]);
                tifObj.CreatedDate = Convert.ToDateTime(dr["CreatedDate"]).ToString("MM-dd-yyyy");
                tifObj.ModifiedDate = Convert.ToDateTime(dr["ModifiedDate"]).ToString("MM-dd-yyyy");
                tifObj.VersionsRowId = Convert.ToInt32(dr["ID"]);
                tifObjs.Add(tifObj);
            }


            return tifObjs;
        }

        #endregion

        #region Attachment code

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            string Requestumber = "TIF_000001";
            AddAttachment(Requestumber);
        }

         public void AddAttachment(string requestNumber)
        {
            if(fileUpload.HasFile)
            {
                createFolder(requestNumber);
                string filenamewithoutext = Path.GetFileNameWithoutExtension(fileUpload.FileName);
                string filename = Path.GetFileName(fileUpload.FileName);
                string fileExtension = Path.GetExtension(fileUpload.FileName);
                MemoryStream mStream = new MemoryStream(fileUpload.FileBytes);
                UploadDocument(mStream, filename, Constants.TIF_Documents, requestNumber);

                //DataTable dt = AttachementTable();
                //WriteDTHTML(dt);
            }
        }

        /// <summary>
        /// Create Folder in Doc library with request name
        /// </summary>
        /// <param name="requestNumber"></param>
        public void createFolder(string requestNumber)
        {
            ///create folder
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                //check folder exist//
                List list = clientContext.Web.Lists.GetByTitle(Constants.TIF_Documents);
                FolderCollection folders = list.RootFolder.Folders;
                clientContext.Load(folders, fl => fl.Include(ct => ct.Name).Where(ct => ct.Name == requestNumber));
                clientContext.ExecuteQuery();
                int existingFolder = folders.Count();
                if (existingFolder == 0)
                {
                    ListItemCreationInformation newItemInfo = new ListItemCreationInformation();
                    newItemInfo.UnderlyingObjectType = FileSystemObjectType.Folder;
                    newItemInfo.LeafName = requestNumber;
                    Microsoft.SharePoint.Client.ListItem newListItem = list.AddItem(newItemInfo);
                    newListItem["Title"] = requestNumber;
                    newListItem.Update();
                    clientContext.ExecuteQuery();
                }                
            }
        }

        public void UploadDocument1(MemoryStream memoryStream, string fileName, string fullFileName, string documentLibrary)
        {
            try
            {
                var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
                using (var clientContext = spContext.CreateUserClientContextForSPHost())
                {
                    Web web = clientContext.Web;
                    List docs = web.Lists.GetByTitle(documentLibrary);
                    clientContext.Load(web, wb => wb.ServerRelativeUrl);  
                    clientContext.Load(docs);
                    clientContext.ExecuteQuery();

                    FileCreationInformation newFile = new FileCreationInformation();
                    newFile.Content = fileUpload.FileBytes;
                    newFile.Url = fileName;

                    Microsoft.SharePoint.Client.File uploadFile = docs.RootFolder.Files.Add(newFile);
                    clientContext.Load(uploadFile);
                    clientContext.ExecuteQuery();
                   
                }
            }
            catch(Exception ex)
            { 
                throw;
            }
        }

        /// <summary>
        /// Get user name and password to upload the docement
        /// </summary>
        public void GetServiceAccount()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                List RoleList = clientContext.Web.Lists.GetByTitle(Constants.TIF_Configuration);

                CamlQuery query = CamlQuery.CreateAllItemsQuery();

               //GetRoleQuery.ViewXml = @"<View><Query><Where><Eq><FieldRef Name='Title'  /><Value Type='Text'>UserName</Value></Eq></Where></Query></View>";

                Microsoft.SharePoint.Client.ListItemCollection cred = RoleList.GetItems(query);
                clientContext.Load(cred);

                clientContext.ExecuteQuery();

                foreach (Microsoft.SharePoint.Client.ListItem olist in cred)
                {
                    hdnserviceuser.Value = olist["UserName"].ToString();
                    hdnservicepassword.Value = olist["Password"].ToString();
                }
            }
        }

        
        public void UploadDocument(MemoryStream memoryStream, string fileName, string documentLibrary,string requestNo)
        {
            string username = hdnserviceuser.Value;
            string password = hdnservicepassword.Value;

            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    Web web = clientContext.Web;
                    User user = web.CurrentUser;
                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIF_Documents);
                    clientContext.Load(web, wb => wb.ServerRelativeUrl); 
                    clientContext.Load(list.RootFolder);
                    clientContext.Load(user);
                    clientContext.ExecuteQuery();
                 
                    SecureString passWord = new SecureString();
                    foreach (char c in password.ToCharArray()) passWord.AppendChar(c);
                    clientContext.Credentials = new SharePointOnlineCredentials(username, passWord);
                    clientContext.ExecuteQuery();
                    ViewState["documents"] = "https://team.amat.com" + web.ServerRelativeUrl.ToString();

                  //  Microsoft.SharePoint.Client.File.SaveBinaryDirect(clientContext, web.ServerRelativeUrl + "/" + documentLibrary + "/" + fileName, memoryStream, true);
                    Microsoft.SharePoint.Client.File.SaveBinaryDirect(clientContext, list.RootFolder.ServerRelativeUrl.ToString() + "/" + requestNo + "/" + fileName, memoryStream, true);

                    Microsoft.SharePoint.Client.File uploadFile = clientContext.Web.GetFileByServerRelativeUrl(web.ServerRelativeUrl + "/" + documentLibrary + "/" + requestNo + "/" + fileName);

                    clientContext.Load(uploadFile);
                    clientContext.ExecuteQuery();

                    Microsoft.SharePoint.Client.ListItem item = uploadFile.ListItemAllFields;                  

                    clientContext.Load(item);
                    clientContext.ExecuteQuery();

                    uploadFile.ListItemAllFields["Title"] = fileName;
                    uploadFile.ListItemAllFields["CreatedBy"] = user.Title;

                    string fileNameHtml = "<li>" + fileName + "</li>";
                    string allfileNames = Convert.ToString(Session["fileName"]);
                    allfileNames = allfileNames + fileNameHtml;
                    Session["fileName"] = allfileNames;

                    uploadFile.ListItemAllFields.Update();
                    clientContext.ExecuteQuery();
                    fileNames.InnerHtml = Convert.ToString(Session["fileName"]);
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alert1", "alert('The file has uploaded successfully.!')", true);

                }
                catch (Exception Ex)
                {
                    throw Ex;
                }
            }


        }

        //[WebMethod(EnableSession = true)]
        //public static DataTable AttachementTable()
        //{
        //    DataTable fileDt = (DataTable)HttpContext.Current.Session["FilesList"];
        //    if (fileDt == null)
        //    {
        //        fileDt = new DataTable();
        //        fileDt.Columns.Add("Id");
        //        fileDt.Columns.Add("FileName");
        //        fileDt.Columns.Add("FileContent");
        //    }

        //    DataRow row = fileDt.NewRow();

        //    if (fileDt.Rows.Count == 0)
        //        row["Id"] = fileDt.Rows.Count + 1;
        //    else
        //        row["Id"] = fileDt.Rows.Count;

        //    row["FileName"] = Path.GetFileName(fileUpload.FileName);
        //    row["FileContent"] = fileUpload.FileBytes;  // This is File Byte stream
        //    fileDt.Rows.Add(row);

        //    ViewState["FilesList"] = fileDt;
        //    DataTable dt = (DataTable)ViewState["FilesList"];
        //    WriteDTHTML(dt);
        //    return dt;
        //}

        //public static void WriteDTHTML(DataTable dt)
        //{
        //    string tableHtml = "<table class='table table-responsive ags-access-table'><tr>";
        //    for (int i = 0; i < dt.Columns.Count; i++)
        //        tableHtml += "<th>" + dt.Columns[i].ColumnName + "</th>";

        //    tableHtml += "</tr>";
        //    int index = 0;
        //     for (int i = 0; i < dt.Rows.Count; i++)
        //     {
        //         tableHtml += "<tr>";
        //         for (int j = 0; j < dt.Columns.Count; j++)
        //         {
        //             tableHtml += "<td>" + dt.Rows[i][j] + "</td>";
        //             index = Convert.ToInt32(dt.Rows[i][0]);
        //         }                 
        //         tableHtml += "<td>&nbsp;&nbsp;<a href='#' onclick='DeleteRow(" + index + ");' id=" + index + " class='btn btn-primary btn-md'><i class='fa fa-trash'></i> Delete</a></td>";
        //         tableHtml += "<tr>";
        //     }
            
        //      tableHtml += "</table>";

        //      filesDiv.InnerHtml = tableHtml;

            


        //}

        public void GetAttachments(string requestNo)
        {
            try
            {
                string folderName = "TIF_" + requestNo;

                var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
                using (var clientContext = spContext.CreateUserClientContextForSPHost())
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIF_Documents);
                    CamlQuery query = new CamlQuery();
                    Web web = clientContext.Web;
                    clientContext.Load(web);
                    clientContext.Load(web, wb => wb.ServerRelativeUrl);
                    clientContext.ExecuteQuery();

                    Folder folder = web.GetFolderByServerRelativeUrl(web.ServerRelativeUrl + "/" + Constants.TIF_Documents + "/" + folderName + "/");
                    clientContext.Load(folder);
                    clientContext.ExecuteQuery();

                    CamlQuery camlQuery = new CamlQuery();
                    camlQuery.ViewXml = @"<View Scope='Recursive'>
                                     <Query>
                                     </Query>
                                 </View>";
                    camlQuery.FolderServerRelativeUrl = folder.ServerRelativeUrl;
                    Microsoft.SharePoint.Client.ListItemCollection listItems = list.GetItems(camlQuery);
                    clientContext.Load(listItems);
                    clientContext.ExecuteQuery();

                }

            }
            catch(Exception ex)
            {

            }
        }


        //public void SaveDataFromPreDispatch()
        //{
        //     var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
        //     using (var clientContext = spContext.CreateUserClientContextForSPHost())
        //     {
        //         try
        //         {
        //             TIFClass objTif = LoadPreTravelValues();
        //             BusinessAccessLayer obj = new BusinessAccessLayer();
        //             if (Request.QueryString["reqID"] == null || Request.QueryString["reqID"] == string.Empty)
        //             {
        //                 objTif.Trip_Number = "0";
        //             }
        //             if (Request.QueryString["reqID"] != null && Request.QueryString["reqID"] != string.Empty)
        //             {
        //                 objTif.Trip_Number = Convert.ToString(txtRequestNum.Text);
        //             }
        //             string requestID = obj.SavingDataToVersionTable(objTif);
        //             string redirectURL = Convert.ToString(Request.Url);
        //             Page.ClientScript.RegisterStartupScript(GetType(), "msgbox", "alert('FiveDot File uploaded successfully'); alert('TwoDot File uploaded successfully');", true);
        //             Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", "giveAlert(); ", true);
        //             Page.ClientScript.RegisterClientScriptBlock(GetType(), "Javascript", "giveAlert(); ", true);
        //             ScriptManager.RegisterStartupScript(this, typeof(string), "Javascript", "Loadinganimationshow();", true);
        //             if (Request.QueryString["reqID"] == null || Request.QueryString["reqID"] == string.Empty)
        //             {
        //                 redirectURL += "&reqID=" + requestID;
        //             }
        //             Response.Redirect(redirectURL, false);

        //         }
        //         catch (Exception ex)
        //         {
        //             Constants.ErrorLog(clientContext, ex.Message, ex.Source, "SaveRequest", "TIF.aspx");
        //         }
        //     }
        //}
 
        #endregion                          

        #region Common Function

        protected void ClearFormBoxes(Control p1)
        {
            foreach (Control ctrl in p1.Controls)
            {
                if (ctrl is TextBox)
                {
                    TextBox t = ctrl as TextBox;
                    if (t != null)
                    {
                        if (t.ID == "tbRequestor" || t.ID == "tbRequestorID")
                            continue;
                        else
                            t.Text = String.Empty;
                    }
                }
                if (ctrl is DropDownList)
                {
                    DropDownList ddl = ctrl as DropDownList;

                    if (ddl != null)
                    {
                        ddl.SelectedIndex = 0;
                    }
                }

            }
        }

        public void ExportToExcel(DataTable dt)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                dt.Columns.Remove("IsFinalSubmit");
                dt.AcceptChanges();
                string entitlementID = "TIF_Excel";
                ExcelWriter ew = new ExcelWriter();
                MemoryStream ms = ew.ExportDataTable(dt);
                //Convert the memorystream to an array of bytes.
                byte[] byteArray = ms.ToArray();
                //Clean up the memory stream
                ms.Flush();
                ms.Close();
                // Clear all content output from the buffer stream
                Response.ClearContent();
                Response.ClearHeaders();
                Response.AddHeader("Content-Disposition", "attachment; filename=" + entitlementID + ".xlsx");
                Response.AddHeader("Content-Length", Convert.ToString(byteArray.Length));
                // Set the HTTP MIME type of the output stream
                Response.ContentType = "Application/octet-stream";
                // Write the data out to the client.
                Response.BinaryWrite(byteArray);
                Response.Flush();
            }

            Session.Remove("Reportdt");
            dt.Clear();
        }

        /// <summary>
        /// Get current user gourp
        /// </summary>
        /// <returns></returns>
        protected string CheckPermissionForCurrentUser()
        {
            string isMemberOf = string.Empty;

            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    User user = clientContext.Web.CurrentUser;
                    clientContext.Load(user);
                    clientContext.ExecuteQuery();
                    string userName = user.Title;

                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIFRoleConfiguration);
                    CamlQuery query = new CamlQuery();
                    query.ViewXml = "<View><Query><Where><Eq><FieldRef Name='User' LookupId='False' /><Value Type='Lookup'>" + userName + "</Value></Eq></Where></Query></View>";
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);

                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null && items.Count > 0)
                    {
                        isMemberOf = Convert.ToString(items[0]["Role"]);
                        hdnCurrentUsergroup.Value = isMemberOf;
                    }
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "CheckPermissionForCurrentUser", "TiF-Form.aspx");
                }
            }
            return isMemberOf;
        }

        /// <summary>
        /// Get current user gourp
        /// </summary>
        /// <returns></returns>
        //protected string CheckForPermissionCurrentUserGroup()
        //{
        //    string isMemberOf = string.Empty;

        //    var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
        //    using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
        //    {
        //        try
        //        {
        //            Web oWeb = clientContext.Web;
        //            GroupCollection userGroups = oWeb.CurrentUser.Groups;
        //            clientContext.Load(userGroups);
        //            clientContext.ExecuteQuery();
        //            for (int i = 0; i < userGroups.Count; i++)
        //            {
        //                string currentGrp = userGroups[i].Title;

        //                if (currentGrp == Constants.DispatchTeamGroup)
        //                {
        //                    isMemberOf = Constants.DispatchTeamGroup;
        //                    break;
        //                }                       
        //                if (currentGrp == Constants.TravellerGroup)
        //                {
        //                    isMemberOf = Constants.TravellerGroup;
        //                    break;
        //                }
        //            }

        //            hdnCurrentUsergroup.Value = isMemberOf;

        //        }
        //        catch (Exception ex)
        //        {
        //            Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetCurrentUserGroup", "TiF-Form.aspx");
        //        }
        //    }
        //    return isMemberOf;
        //} 

        #endregion
    }
}