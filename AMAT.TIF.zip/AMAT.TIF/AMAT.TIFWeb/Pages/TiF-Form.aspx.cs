﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMAT.BAL;
using System.Data;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.UserProfiles;
using System.Web.Script.Services;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.IO;
using System.Security;
using Microsoft.SharePoint.Client.Utilities;
using System.Configuration;


namespace AMAT.TIFWeb.Pages
{
    public partial class TiF_Form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {          
        
            if (!Page.IsPostBack)
            {
               
                if ((!string.IsNullOrEmpty(Request.QueryString["formId"]) && (!string.IsNullOrEmpty(Request.QueryString["ReferBy"]))))
                {
                    string id = Convert.ToString(Request.QueryString["formId"]);
                    string tabName = Convert.ToString(Request.QueryString["ReferBy"]);
                    PageLoadFunction(id, tabName);
                    GetAttachments(lblReqNo.Text.Trim()); Session["FilesList"] = null;
                    filesDiv.InnerHtml = string.Empty;
                }
            }

            string buttonCausedPostBack = Page.Request.Params.Get("__EVENTTARGET");
            if (!string.IsNullOrEmpty(buttonCausedPostBack) && (buttonCausedPostBack.Equals("btnAdd") || buttonCausedPostBack.Equals("btnUpload")))
            {
                if ((!string.IsNullOrEmpty(Request.QueryString["formId"]) && (!string.IsNullOrEmpty(Request.QueryString["ReferBy"]))))
                {
                    string id = Convert.ToString(Request.QueryString["formId"]);
                    string tabName = Convert.ToString(Request.QueryString["ReferBy"]);
                    PageLoadFunction(id, tabName);
                  
                }
            }
          
           
        }

        protected void PageLoadFunction(string id, string tabName)
        {
            GetAllFormData();
            currentTabName.Value = tabName;
            GetRequestDetails(id, tabName);
            CheckForPostTravelSubmitButton(tabName);
           
        }

        /// <summary>
        /// Check from where page is comming e.g( from email link or from TIF popoup page
        /// </summary>
        /// <param name="travelerName"></param>
        /// <param name="tabName"></param>
        /// <returns></returns>
        public bool CheckUserPermissionfromEmailpage(string travelerName, string tabName)
        {
            bool Isfalse = false;
            ViewState["PageFormEmail"] = false;

            if (Request.UrlReferrer != null)
            {
                string url = Request.UrlReferrer.AbsolutePath;
                if(url.Contains("TiF-Form"))
                {

                }
                ViewState["PageFormEmail"] = true;
                if (currentUsername.Value == travelerName && tabName == Constants.MainRequestType)
                    Isfalse = true;
            }
            else
            {

                Isfalse = true;
            }

            return Isfalse;
        }

        protected void GetRequestDetails(string id, string tabName)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
               try
                {
                    BusinessAccessLayer ba = new BusinessAccessLayer();
                    if (!string.IsNullOrEmpty(id))
                    {
                        DataTable requestDt = ba.GetDatabyRequestNo(id, tabName);

                        if (requestDt.Rows.Count > 0)
                        {
                            DataRow row = requestDt.Rows[0];

                            string travName = Convert.ToString(row["Traveller_Name"]);
                         //   if (CheckUserPermissionfromEmailpage(travName,tabName))
                          //  {
                                txtTravellerName.Text = travName;
                                ViewState["TravellerName"] = travName;

                                lblReqNo.Text = Convert.ToString(row["Trip_Number"]);

                                lblReqStatus.Text = Convert.ToString(row["Request_Status"]);
                                hdnRequestStatus.Value = Convert.ToString(row["Request_Status"]);
                                tbRequestor.Text = Convert.ToString(row["Requestor_Name"]);

                                tbRequestorID.Text = Convert.ToString(row["Requestor_Id"]);

                                tbPlannerID.Text = Convert.ToString(row["Planner_Id"]);
                                txtPlanner.Value = Convert.ToString(row["Planner_Name"]);

                                ddlPurpose.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["Travel_Purpose"])))
                                    ddlPurpose.Items.FindByText(Convert.ToString(row["Travel_Purpose"])).Selected = true;

                                txtoppNo.Text = Convert.ToString(row["Tr_Opportunity_Numbers"]);



                                tbTravellerID.Text = Convert.ToString(row["Traveller_Id"]);
                                ViewState["TravellerId"] = Convert.ToString(row["Traveller_Id"]);

                                tbTravellerEmail.Text = Convert.ToString(row["Traveller_Email"]);
                                txthomeLocation.Text = Convert.ToString(row["Traveller_Home_Location"]);
                                txtBu.Text = Convert.ToString(row["Traveller_BU"]);
                                tbTravellerPhone.Text = Convert.ToString(row["Traveller_Phone"]);
                                tbLevelOneManager.Text = Convert.ToString(row["Traveller_FirstManager"]);
                                tbSecondLevelManager.Text = Convert.ToString(row["Traveller_SecondManager"]);

                                if (!string.IsNullOrEmpty(Convert.ToString(row["Planned_Start_Date"])))
                                    tbPlannedStartDate.Text = Convert.ToDateTime(row["Planned_Start_Date"]).ToString("MM/dd/yyyy");

                                if (!string.IsNullOrEmpty(Convert.ToString(row["Planned_End_Date"])))
                                    tbPlannedEndDate.Text = Convert.ToDateTime(row["Planned_End_Date"]).ToString("MM/dd/yyyy");

                                ddlOriginCountry.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["TravellerOriginCountry"])))
                                    ddlOriginCountry.Items.FindByText(Convert.ToString(row["TravellerOriginCountry"])).Selected = true;

                                ddlDestination.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["TravellerDestinationCountry"])))
                                    ddlDestination.Items.FindByText(Convert.ToString(row["TravellerDestinationCountry"])).Selected = true;

                                txtOriginCity.Text = Convert.ToString(row["TravellerOriginCity"]);
                                txtdestCity.Text = Convert.ToString(row["TravellerDestinationCity"]);
                                tbCostCenter.Text = Convert.ToString(row["Cost_Center"]);
                                tbTravelObjective.InnerText = Convert.ToString(row["Traveller_Travel_Objective"]);

                                rdTriptype.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["Triptype"])))
                                    rdTriptype.Items.FindByValue(Convert.ToString(row["Triptype"])).Selected = true;

                                if (!string.IsNullOrEmpty(Convert.ToString(row["Departure_Date"])))
                                    tbDepartureDate.Text = Convert.ToDateTime(row["Departure_Date"]).ToString("MM/dd/yyyy");

                                if (!string.IsNullOrEmpty(Convert.ToString(row["Arrival_Date"])))
                                    tbReturnDate.Text = Convert.ToDateTime(row["Arrival_Date"]).ToString("MM/dd/yyyy");

                                ddlIterneryCountry1.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["FlightDepartureCountry"])))
                                    ddlIterneryCountry1.Items.FindByText(Convert.ToString(row["FlightDepartureCountry"])).Selected = true;

                                ddlIterneryCountry2.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["FlightArrivalCountry"])))
                                    ddlIterneryCountry2.Items.FindByText(Convert.ToString(row["FlightArrivalCountry"])).Selected = true;

                                txtIterneryCity1.Text = Convert.ToString(row["FlightDepartureCity"]);
                                txtIterneryCity2.Text = Convert.ToString(row["FlightArrivalCity"]);

                                tbDepartureFare.Text = Convert.ToString(row["DepartureFare"]);
                                tbReturnFare.Text = Convert.ToString(row["ArrivalFare"]);

                                ddDepartureServiceType.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["Dep_ServiceClass"])))
                                    ddDepartureServiceType.Items.FindByText(Convert.ToString(row["Dep_ServiceClass"])).Selected = true;

                                ddlReturnServiceType.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["Arr_ServiceClass"])))
                                    ddlReturnServiceType.Items.FindByText(Convert.ToString(row["Arr_ServiceClass"])).Selected = true;

                                tbHotelName.Text = Convert.ToString(row["HotelName"]);
                                txtHotelCity.Text = Convert.ToString(row["HotelCity"]);

                                ddlHotelCountry.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["HotelCountry"])))
                                    ddlHotelCountry.Items.FindByText(Convert.ToString(row["HotelCountry"])).Selected = true;

                                ddlBookedBy.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["HotelBookedBy"])))
                                    ddlBookedBy.Items.FindByText(Convert.ToString(row["HotelBookedBy"])).Selected = true;

                                if (!string.IsNullOrEmpty(Convert.ToString(row["Hotel_CheckInDate"])))
                                    tbCheckinDate.Text = Convert.ToDateTime(row["Hotel_CheckInDate"]).ToString("MM/dd/yyyy");

                                if (!string.IsNullOrEmpty(Convert.ToString(row["Hotel_CheckoutDate"])))
                                    tbCheckoutDate.Text = Convert.ToDateTime(row["Hotel_CheckoutDate"]).ToString("MM/dd/yyyy");

                                tbNoOfNights.Text = Convert.ToString(row["No_of_Night_Booked"]);
                                tbRoomRate.Text = Convert.ToString(row["Room_Rate"]);

                                txtMdr.Text = Convert.ToString(row["MDR"]);

                                ddlHotelRateMDR.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["IsHotelRateAboveMDR"])))
                                    ddlHotelRateMDR.Items.FindByText(Convert.ToString(row["IsHotelRateAboveMDR"])).Selected = true;

                                tbMDRJustification.InnerText = Convert.ToString(row["Hotel_MDR_Desc"]);

                                txtPerDiem.Text = Convert.ToString(row["PerDiem"]);
                                tbEstTravelSpend.Text = Convert.ToString(row["EstimatesTravelExpense"]);


                                if (!string.IsNullOrEmpty(Convert.ToString(row["Actual_StartDate"])))
                                    txtActualStartDate.Text = Convert.ToDateTime(row["Actual_StartDate"]).ToString("MM/dd/yyyy");

                                if (!string.IsNullOrEmpty(Convert.ToString(row["Actual_EndDate"])))
                                    txtActualEndDate.Text = Convert.ToDateTime(row["Actual_EndDate"]).ToString("MM/dd/yyyy");


                                ddlExpRptSubAprd.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["Expense_Report_Submitted_Approved"])))
                                    ddlExpRptSubAprd.Items.FindByText(Convert.ToString(row["Expense_Report_Submitted_Approved"])).Selected = true;

                                txtReportKey.Text = Convert.ToString(row["Report_Key_Number"]);

                                ddlHotelstayed.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["IsHotelBookedByDispatch"])))
                                    ddlHotelstayed.Items.FindByText(Convert.ToString(row["IsHotelBookedByDispatch"])).Selected = true;
                                
                                txthotelNamebyTrav.Text = Convert.ToString(row["TravellerHotelName"]);
                                txtHotelCityByTrav.Text = Convert.ToString(row["TravellerHotelCity"]);

                                ddlHotelCountryTrav.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["TravellerHotelCountry"])))
                                    ddlHotelCountryTrav.Items.FindByText(Convert.ToString(row["TravellerHotelCountry"])).Selected = true;

                                ddlHotelCountryTrav.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["TravellerHotelCountry"])))
                                    ddlHotelCountryTrav.Items.FindByText(Convert.ToString(row["TravellerHotelCountry"])).Selected = true;

                                ddlHtlBkByTrav.ClearSelection();
                                if (!string.IsNullOrEmpty(Convert.ToString(row["TravellerHotelBkBy"])))
                                    ddlHtlBkByTrav.Items.FindByText(Convert.ToString(row["TravellerHotelBkBy"])).Selected = true;

                                if (!string.IsNullOrEmpty(Convert.ToString(row["TravellerHotelChkInDt"])))
                                    txtCheckinDateTrav.Text = Convert.ToDateTime(row["TravellerHotelChkInDt"]).ToString("MM/dd/yyyy");

                                if (!string.IsNullOrEmpty(Convert.ToString(row["TravellerHotelChkOutDt"])))
                                    txtChkOutByTrav.Text = Convert.ToDateTime(row["TravellerHotelChkOutDt"]).ToString("MM/dd/yyyy");

                                txtRmrateByTrav.Text = Convert.ToString(row["TravellerHotelRate"]);

                                travelerComments.Value = Convert.ToString(row["TravellerComments"]);
                                dispatchComments.InnerText = Convert.ToString(row["DispatchComments"]);


                            //}
                            //else
                            //{                             
                            //    clientContext.Load(clientContext.Web, web => web.Url);
                            //    clientContext.ExecuteQuery();
                            //    string webUrl = clientContext.Web.Url + "/Pages/TIF.aspx";
                            //    Response.Redirect(webUrl);
                            //}
                        }
                        //else
                        //{
                        //    clientContext.Load(clientContext.Web, web => web.Url);
                        //    clientContext.ExecuteQuery();
                        //    string webUrl = clientContext.Web.Url + "/Pages/TIF.aspx";
                        //    Response.Redirect(webUrl);
                        //}
                   
                    }

                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetRequestDetails", "TIF-Form.aspx");
                }
            }
        }

        #region Page load functions

        
        /// <summary>
        /// to Loading all form data in single call from sharepoint
        /// </summary>
        protected void GetAllFormData()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List countrylist = clientContext.Web.Lists.GetByTitle(Constants.CountryList);
                    List trvelTypeList = clientContext.Web.Lists.GetByTitle(Constants.Travel_Type);
                    List accountList = clientContext.Web.Lists.GetByTitle(Constants.TIF_Configuration);                 
                    User user = clientContext.Web.CurrentUser;

                    CamlQuery queryCountry = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection countryItems = countrylist.GetItems(queryCountry);

                    CamlQuery trvelQuery = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection travelitems = trvelTypeList.GetItems(trvelQuery);

                    CamlQuery query = CamlQuery.CreateAllItemsQuery();
                    Microsoft.SharePoint.Client.ListItemCollection cred = accountList.GetItems(query);
                   
                    clientContext.Load(countryItems);
                    clientContext.Load(travelitems);
                    clientContext.Load(cred);
                    clientContext.Load(user);

                    clientContext.ExecuteQuery();

                    // bind purpose dropdown
                    ddlPurpose.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
                    for (int i = 0; i < travelitems.Count; i++)
                        ddlPurpose.Items.Add(new System.Web.UI.WebControls.ListItem(Convert.ToString(travelitems[i]["Title"]), Convert.ToString(travelitems[i]["ID"])));

                    currentLoggedInUser.Value = Convert.ToString(user.Email);
                    currentUsername.Value = Convert.ToString(user.Title);
                   // bind All country dropdown
                    foreach (Microsoft.SharePoint.Client.ListItem item in countryItems)
                    {
                        string text = Convert.ToString(item["Title"]);
                        ddlOriginCountry.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlDestination.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlIterneryCountry1.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlIterneryCountry2.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlHotelCountry.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                        ddlHotelCountryTrav.Items.Add(new System.Web.UI.WebControls.ListItem(text, text));
                    }
                    AddSelectInDropdown(ddlOriginCountry, ddlDestination, ddlIterneryCountry1, ddlIterneryCountry2, ddlHotelCountry, ddlHotelCountryTrav);

                    // get userid passport account
                    foreach (Microsoft.SharePoint.Client.ListItem item in cred)
                    {
                        hdnserviceuser.Value = item["UserName"].ToString();
                        hdnservicepassword.Value = item["Password"].ToString();
                    }
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetAllFormData", "TIF.aspx");
                }
            }
        }

        protected void AddSelectInDropdown(DropDownList ddl1, DropDownList ddl2, DropDownList ddl3, DropDownList ddl4, DropDownList ddl5, DropDownList ddl6)
        {
            ddl1.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl2.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl3.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl4.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl5.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
            ddl6.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select", "0"));
        }

        protected ADMethods.ADAttributes GetUserDetails(string emailAddress)
        {
            //GetLoggedInUser();
            ADMethods.ADAttributes ADResult = null;
            bool isUserExists = false;
            ADMethods AD = new ADMethods();

            isUserExists = AD.IsUserExist(emailAddress, ADMethods.AdPrpoertyParameters.mail);
            if (isUserExists)
            {
                ADResult = AD.GetEmployeeAttributes(emailAddress, ADMethods.AdPrpoertyParameters.mail);

            }
            return ADResult;
        }

        #endregion

        #region All button click Events code 

        protected void btnRequestSave_Click(object sender, EventArgs e)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string existingRequestNo = lblReqNo.Text;
                    BusinessAccessLayer bu = new BAL.BusinessAccessLayer();
                    TIFClass obj = GetPreTravelFormsValue(existingRequestNo,"Save");
                    bu.SaveByPreDispatch(obj, existingRequestNo);
                    string result = string.Empty;
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alertmsg", "SaveRequestMsg('" + existingRequestNo + "')", true);
                 
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "btnRequestSave_Click", "TiF-Form.aspx");
                }
            }
        }
        /// <summary>
        /// Submit form by dispatch
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRequestSubmit_Click(object sender, EventArgs e)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string existingRequestNo = lblReqNo.Text.Trim();
                    BusinessAccessLayer bu = new BAL.BusinessAccessLayer();
                    TIFClass obj = GetPreTravelFormsValue(existingRequestNo,"Submit");
                    bu.SubmitByPreDispatch(obj, Constants.MainRequestType);
        
                    string result = string.Empty;
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alertmsg", "SubmitRequestMsgPreTrvl('" + existingRequestNo + "')", true);             
                    AddUsersToRelatedRoletoList(existingRequestNo);
                    SendMailonforDifferentActions(Constants.SubmitByDispatch);
                            
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "btnRequestSave_Click", "TIF.aspx");
                }
            }
        }

        protected void btnRequestCancel_Click(object sender, EventArgs e)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    ManagerClass objMng = new ManagerClass();
                    objMng.RequestNo = lblReqNo.Text.Trim();
                    objMng.RequestStatus = Constants.RequestCancelled; // cancelling the request
                    BusinessAccessLayer ba = new BusinessAccessLayer();
                    ba.RevertRequest(objMng);  // cancelling the request

                    clientContext.Load(clientContext.Web, web => web.Url);
                    clientContext.ExecuteQuery();
                    string navigateUrl = clientContext.Web.Url + "/Pages/TIF.aspx";
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "cancelmsg", "CancelledRequestMsg('" + lblReqNo.Text.Trim() + "','" + navigateUrl + "')", true);
                    SendMailonforDifferentActions(Constants.RequestCancelledAction);
                   
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "btnRequestCancel_Click", "TiF-Form.aspx");
                }
            }
        }

        /// <summary>
        /// submit by trveller
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmitTraveller_Click(object sender, EventArgs e)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    BusinessAccessLayer ba = new BusinessAccessLayer();
                    PostTravellerClass obj = new PostTravellerClass();
                    obj.Actual_StartDate = txtActualStartDate.Text.Trim();
                    obj.Actual_EndDate = txtActualEndDate.Text.Trim();

                    if (ddlExpRptSubAprd.SelectedValue != "0")
                        obj.ExpenseReportSubmitted = ddlExpRptSubAprd.SelectedItem.Value;
                    obj.Report_Key_Number = txtReportKey.Text.Trim();

                    if (ddlHotelCountryTrav.SelectedValue != "0")
                        obj.TravellerHotelCountry = ddlHotelCountryTrav.SelectedItem.Value;
                    obj.Report_Key_Number = txtReportKey.Text.Trim();

                    if (ddlHotelstayed.SelectedValue != "0")
                        obj.IsHotelBookedByDispatch = ddlHotelstayed.SelectedItem.Value;
                    obj.Report_Key_Number = txtReportKey.Text.Trim();

                    if (ddlHtlBkByTrav.SelectedValue != "0")
                        obj.TravellerHotelBkBy = ddlHtlBkByTrav.SelectedItem.Value;

                    obj.Report_Key_Number = txtReportKey.Text.Trim();

                    obj.TravellerHotelName = txthotelNamebyTrav.Text.Trim();
                    obj.TravellerHotelCity = txtHotelCityByTrav.Text.Trim();

                    obj.TravellerHotelChkInDt = txtCheckinDateTrav.Text.Trim();
                    obj.TravellerHotelChkOutDt = txtChkOutByTrav.Text.Trim();
                    obj.TravellerHotelRate = txtRmrateByTrav.Text.Trim();

                    obj.TravellerComments = travelerComments.Value.Trim();
                    obj.RequestStatus = Constants.RequestPendingWithDispatch;
                    obj.RequestNo = lblReqNo.Text.Trim();
                    ba.SubmitByTraveller(obj);
                    string result = string.Empty;
                    SendMailOnTravellerSubmission();

                    clientContext.Load(clientContext.Web, web => web.Url);
                    clientContext.ExecuteQuery();
                    string navigateUrl = clientContext.Web.Url + "/Pages/TIF.aspx";
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alertmsg", "SubmitRequestMsg('" + lblReqNo.Text.Trim() + "','" + navigateUrl + "')", true);
         
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "btnSubmitTraveller_Click", "TiF-Form.aspx");
                }
            }
        }

        protected void btnDispatchSubmit_Click(object sender, EventArgs e)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    BusinessAccessLayer ba = new BusinessAccessLayer();

                    string requestStatus = Constants.RequestCompleted;
                    string requestNo = lblReqNo.Text.Trim();
                    string dispatchComnts = dispatchComments.InnerText;
                    string approveDate = DateTime.Now.ToString("MM/dd/yyyy");

                    ba.SubmitByPostDispatch(requestNo, requestStatus, dispatchComnts, approveDate);
                    SendMailonforDifferentActions(Constants.RequestCompletedAction);

                    clientContext.Load(clientContext.Web, web => web.Url);
                    clientContext.ExecuteQuery();
                    string navigateUrl = clientContext.Web.Url + "/Pages/TIF.aspx";
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alertmsg", "ApprovedRequestMsg('" + lblReqNo.Text.Trim() + "','" + navigateUrl + "')", true);
                  
                  
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "btnDispatchSubmit_Click", "TiF-Form.aspx");
                }
            }

        }

        protected void btnRevertDispatch_Click(object sender, EventArgs e)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    ManagerClass objMng = new ManagerClass();
                    objMng.RequestNo = lblReqNo.Text.Trim();
                    objMng.RequestStatus = Constants.RequestRevertedToTraveller;

                    objMng.DispatchComments = dispatchComments.InnerText;

                    BusinessAccessLayer ba = new BusinessAccessLayer();
                    ba.RevertRequest(objMng);

                    SendMailonforDifferentActions(Constants.RevertToTraveller);

                    clientContext.Load(clientContext.Web, web => web.Url);
                    clientContext.ExecuteQuery();
                    string navigateUrl = clientContext.Web.Url + "/Pages/TIF.aspx";              

                      ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alertmsg", "RevertRequestMsg('" + lblReqNo.Text.Trim() + "','" + navigateUrl + "')", true);
                   // ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alertmsg", "RevertRequestMsg('" + lblReqNo.Text.Trim() + "','" + navigateUrl + "')", true);
                  //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "Navigate('" + navigateUrl + "')", true);
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "btnRevertDispatch_Click", "TiF-Form.aspx");
                }
            }

        }       

        #endregion

        #region  Getting the Pre tavel values in TIF class object

        private TIFClass GetPreTravelFormsValue(string existingRequestNo,string buttonEvent)
        {
            string requestNo = string.Empty;
            TIFClass obj = new TIFClass();
            BusinessAccessLayer ba = new BAL.BusinessAccessLayer();
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    if (string.IsNullOrEmpty(existingRequestNo))
                        requestNo = ba.GetRequestNo();
                    else
                        requestNo = existingRequestNo;

                    obj.Trip_Number = requestNo;
                    obj.Requestor_Name = tbRequestor.Text.Trim();
                    obj.Requestor_Id = tbRequestorID.Text.Trim();
                    obj.Planner_Id = tbPlannerID.Text.Trim();
                    obj.Planner_Name = txtPlanner.Value.Trim();
                    //obj.Travel_Purpose = hdntravelPurpose.Value.Trim();
                    obj.Travel_Purpose = ddlPurpose.SelectedItem.Text;
                    obj.Tr_Opportunity_Numbers = txtoppNo.Text.Trim();
                    obj.Traveller_Name = txtTravellerName.Text.Trim();
                    obj.Traveller_Id = tbTravellerID.Text.Trim();
                    obj.Traveller_Email = tbTravellerEmail.Text;
                    obj.Traveller_Home_Location = txthomeLocation.Text.Trim();
                    obj.Traveller_BU = txtBu.Text.Trim();
                    obj.Traveller_Phone = Convert.ToString(tbTravellerPhone.Text);
                    obj.Traveller_FirstManager = tbLevelOneManager.Text;
                    obj.Traveller_SecondManager = tbSecondLevelManager.Text;
                    obj.Planned_Start_Date = tbPlannedStartDate.Text.Trim();
                    obj.Planned_End_Date = tbPlannedEndDate.Text.Trim();

                    //  obj.Traveller_Origin_Country = hdnOriginCountry.Value;
                    obj.Traveller_Origin_Country = ddlOriginCountry.SelectedItem.Text;
                    // obj.Traveller_Destination_Country = hdnDestinationCountry.Value;
                    obj.Traveller_Destination_Country = ddlDestination.SelectedItem.Text;
                    obj.Traveller_Origin_City = txtOriginCity.Text.Trim();
                    obj.Traveller_Destination_City = txtdestCity.Text.Trim();
                    obj.Cost_Center = tbCostCenter.Text.Trim();
                    obj.Traveller_Travel_Objective = tbTravelObjective.InnerText;
                    obj.TripType = rdTriptype.SelectedItem.Value;

                    obj.Flight_Departure_Date = tbDepartureDate.Text.Trim();
                    obj.Flight_Arrival_Date = tbReturnDate.Text.Trim();
                   
                    if (ddlIterneryCountry1.SelectedItem.Value != "0")
                        obj.Flight_Dep_Country = ddlIterneryCountry1.SelectedItem.Text;
              
                    if (ddlIterneryCountry2.SelectedItem.Value != "0")
                        obj.Flight_Arr_Country = ddlIterneryCountry2.SelectedItem.Text;
                    obj.Flight_Dep_City = txtIterneryCity1.Text.Trim();
                    obj.Flight_Arr_City = txtIterneryCity2.Text.Trim();

                    obj.Dep_Fare = tbDepartureFare.Text.Trim();
                    obj.Arr_Fare = tbReturnFare.Text.Trim();

                    // obj.Dep_ServiceClass = hdnDeptClass.Value.Trim();
                    if (ddDepartureServiceType.SelectedItem.Value != "0")
                        obj.Dep_ServiceClass = ddDepartureServiceType.SelectedItem.Text;

                    // obj.Arr_ServiceClass = hdnArrClass.Value.Trim();
                    if (ddlReturnServiceType.SelectedItem.Value != "0")
                        obj.Arr_ServiceClass = ddlReturnServiceType.SelectedItem.Text;

                    obj.Hotel_Name = tbHotelName.Text.Trim();
                    obj.Hotel_City = txtHotelCity.Text.Trim();

                    // obj.Hotel_Country = hdnHotelCountry.Value.Trim();

                    if (ddlHotelCountry.SelectedItem.Value != "0")
                    obj.Hotel_Country = ddlHotelCountry.SelectedItem.Text;

                    //  obj.Hotel_BookedBy = hdnhotelBookedBy.Value.Trim();

                    if (ddlBookedBy.SelectedItem.Value != "0")
                    obj.Hotel_BookedBy = ddlBookedBy.SelectedItem.Text;

                    obj.Hotel_CheckInDate = tbCheckinDate.Text.Trim();
                    obj.Hotel_CheckoutDate = tbCheckoutDate.Text.Trim();
                    obj.No_of_Night_Booked = Request.Form[tbNoOfNights.UniqueID];// tbNoOfNights.Text.Trim();

                    obj.Room_Rate = tbRoomRate.Text.Trim();
                    obj.MDR = txtMdr.Text.Trim();

                    if (ddlHotelRateMDR.SelectedItem.Value != "0")
                    obj.IsHotelRateAboveMDR = ddlHotelRateMDR.SelectedValue;
                    obj.Hotel_MdR_Desc = tbMDRJustification.InnerText;
                
                    obj.CreatedBy = tbRequestor.Text.Trim();
                    obj.ModifiedBy = currentUsername.Value.Trim();
                    obj.CreatedDate = DateTime.Now.ToString("MM/dd/yyyy");
                    obj.ModifiedDate = DateTime.Now.ToString("MM/dd/yyyy");

                   // obj.PerDiem = Request.Form[txtPerDiem.UniqueID];
                    obj.PerDiem = txtPerDiem.Text.Trim();
                    obj.Estimated_Travel_Expense = Request.Form[tbEstTravelSpend.UniqueID];

                    if (buttonEvent.Equals("Submit"))
                        obj.Request_Status = Constants.Requestsubimtted;
                    else
                        obj.Request_Status = Constants.RequestAsDraft;               


                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetPreTravelFormsValue()", "TIF.aspx");
                }
            }
            return obj;
        }

        #endregion

        #region  Getting the post tavel values in PostTravellerClass class object

        private PostTravellerClass GetPostTravelValuesTravaller()
        {
            PostTravellerClass obj = new PostTravellerClass();
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    obj.Actual_StartDate = txtActualStartDate.Text.Trim();
                    obj.Actual_EndDate = txtActualEndDate.Text.Trim();
                    obj.ExpenseReportSubmitted = ddlExpRptSubAprd.SelectedItem.Text;
                    obj.Report_Key_Number = txtReportKey.Text.Trim();
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetPreTravelFormsValue()", "TIF.aspx");
                }
            }
            return obj;
        }

     
        #endregion

        #region All Webmethods, All request draft request, user properties for Grid

       

        [WebMethod]
        public static List<UserProperty> GetADUsers(string username)
        {
            List<UserProperty> lstADUsers = new List<UserProperty>();

            if (!string.IsNullOrEmpty(username))
            {
                using (PrincipalContext context = new PrincipalContext(ContextType.Domain))
                {
                    UserPrincipal user = new UserPrincipal(context);
                    user.DisplayName = username + "*";
                    using (PrincipalSearcher srch = new PrincipalSearcher(user))
                    {
                        int i = 0;
                        foreach (var result in srch.FindAll())
                        {

                            DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;
                            if (!String.IsNullOrEmpty((String)de.Properties["displayName"].Value))
                            {
                                i++;
                                UserProperty usp = new BAL.UserProperty();
                                usp.UserName = de.Properties["displayName"].Value.ToString();
                                if (de.Properties["EmployeeId"].Value != null)
                                    usp.EmpId = de.Properties["EmployeeId"].Value.ToString();
                                else
                                    usp.EmpId = string.Empty;

                                lstADUsers.Add(usp);
                                if (i == 7) break;

                            }
                        }
                    }
                }
            }
            return lstADUsers;
        }

        [WebMethod]
        public static List<TIFClass> GetTravellerAdValues(string userId)
        {
            List<TIFClass> lstADUser = new List<TIFClass>();

            TIFClass obj = new BAL.TIFClass();
            if (!string.IsNullOrEmpty(userId))
            {
                ADMethods.ADAttributes ADResult = null;
                ADMethods AD = new ADMethods();
                ADResult = AD.GetEmployeeAttributes(userId, ADMethods.AdPrpoertyParameters.employeeid);
                if (ADResult != null)
                {
                    obj.Traveller_Name = ADResult.displayName;
                    obj.Traveller_Id = ADResult.sAMAccountName;
                    obj.Traveller_Email = ADResult.mail;
                    obj.Traveller_Phone = ADResult.telephoneNumber;
                    obj.Traveller_Home_Location = ADResult.Location;
                    obj.Traveller_BU = ADResult.division;
                    obj.Traveller_FirstManager = ADResult.ManagerDisplayName;
                    lstADUser.Add(obj);
                }
            }
            return lstADUser;
        }

        [WebMethod(EnableSession = true)]
        public static List<Traveller> GetTrvellerDetailsFromOppoNo(string oppoNo)
        {
            BusinessAccessLayer ba = new BusinessAccessLayer();
            List<Traveller> obj = null;
            if (!string.IsNullOrEmpty(oppoNo))
            {
                DataTable dt = ba.GetDetailByOpportunityNo(oppoNo);
                HttpContext.Current.Session["UsersDetails"] = dt;
                obj = ba.GetTravellerName(dt);
            }
            return obj;
        }

        /// <summary>
        /// Filling the user details on bases of selected traveller dropdown
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [WebMethod(EnableSession = true)]
        public static List<TIFClass> GetSingleTravellerDetail(string id)
        {
            BusinessAccessLayer ba = new BusinessAccessLayer();
            DataTable dt = (DataTable)HttpContext.Current.Session["UsersDetails"];
            List<TIFClass> obj = ba.GetTravllerDetails(dt, id);
            return obj;
        }

        #endregion

        #region Attachment code

        //Final upload
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            string Requestumber = lblReqNo.Text.Trim();
            AddAttachment(Requestumber);
           
        }

        /// <summary>
        /// Add Files to temp table
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            AttachementTable();
          
        }

        public void AddAttachment(string requestNumber)
        {
            createFolder(requestNumber);   // create folder with request no.

            DataTable dt = (DataTable)Session["FilesList"];
            dt = RowIds(dt);
            if (dt != null && dt.Rows.Count > 0)
                UploadFiles(dt, requestNumber);

            Session["FilesList"] = null;
            filesDiv.InnerHtml = string.Empty;
            GetAttachments(requestNumber);

        }

        /// <summary>
        /// Create Folder in Doc library with request name
        /// </summary>
        /// <param name="requestNumber"></param>
        public void createFolder(string requestNumber)
        {
            string username = hdnserviceuser.Value;
            string password = hdnservicepassword.Value;
            ///create folder
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    SecureString passWord = new SecureString();
                    foreach (char c in password.ToCharArray()) passWord.AppendChar(c);
                    clientContext.Credentials = new SharePointOnlineCredentials(username, passWord);
                    clientContext.ExecuteQuery();

                    //check folder exist//
                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIF_Documents);
                    FolderCollection folders = list.RootFolder.Folders;
                    clientContext.Load(folders, fl => fl.Include(ct => ct.Name).Where(ct => ct.Name == requestNumber));
                    clientContext.ExecuteQuery();
                    int existingFolder = folders.Count();
                    if (existingFolder == 0)
                    {
                        ListItemCreationInformation newItemInfo = new ListItemCreationInformation();
                        newItemInfo.UnderlyingObjectType = FileSystemObjectType.Folder;
                        newItemInfo.LeafName = requestNumber;
                        Microsoft.SharePoint.Client.ListItem newListItem = list.AddItem(newItemInfo);
                        newListItem["Title"] = requestNumber;
                        newListItem.Update();
                        clientContext.Credentials = new SharePointOnlineCredentials(username, passWord);
                        clientContext.ExecuteQuery();
                    }
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "createFolder", "TiF-Form.aspx");
                }
            }
        }      
        
        /// <summary>
        /// Upload doc to sharepoint library
        /// </summary>
        /// <param name="memoryStream"></param>
        /// <param name="fileName"></param>
        /// <param name="documentLibrary"></param>
        /// <param name="requestNo"></param>
        /// <param name="IsDeleted"></param>
        public void UploadDocument(MemoryStream memoryStream, string fileName, string documentLibrary, string requestNo, string IsDeleted)
        {
            string username = hdnserviceuser.Value;
            string password = hdnservicepassword.Value;

            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    Web web = clientContext.Web;
                    User user = web.CurrentUser;
                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIF_Documents);
                    clientContext.Load(web, wb => wb.ServerRelativeUrl);
                    clientContext.Load(list.RootFolder);
                    clientContext.Load(user);
                    clientContext.ExecuteQuery();

                    SecureString passWord = new SecureString();
                    foreach (char c in password.ToCharArray()) passWord.AppendChar(c);
                    clientContext.Credentials = new SharePointOnlineCredentials(username, passWord);
                    clientContext.ExecuteQuery();
                  
                    //  Microsoft.SharePoint.Client.File.SaveBinaryDirect(clientContext, web.ServerRelativeUrl + "/" + documentLibrary + "/" + fileName, memoryStream, true);
                    Microsoft.SharePoint.Client.File.SaveBinaryDirect(clientContext, list.RootFolder.ServerRelativeUrl.ToString() + "/" + requestNo + "/" + fileName, memoryStream, true);

                    Microsoft.SharePoint.Client.File uploadFile = clientContext.Web.GetFileByServerRelativeUrl(web.ServerRelativeUrl + "/" + documentLibrary + "/" + requestNo + "/" + fileName);

                    clientContext.Load(uploadFile);
                    clientContext.ExecuteQuery();

                    Microsoft.SharePoint.Client.ListItem item = uploadFile.ListItemAllFields;

                    SecureString passWord1 = new SecureString();
                    foreach (char c in password.ToCharArray()) passWord1.AppendChar(c);
                    clientContext.Credentials = new SharePointOnlineCredentials(username, passWord1);

                    clientContext.Load(uploadFile);
                    clientContext.ExecuteQuery();

                    uploadFile.ListItemAllFields["Title"] = fileName;
                    uploadFile.ListItemAllFields["CreatedBy"] = user.Title;
                    string fileNameHtml = "<li>" + fileName + "</li>";
                    string allfileNames = Convert.ToString(Session["fileName"]);
                   // uploadFile.ListItemAllFields["IsDeleted"] = IsDeleted;
                    allfileNames = allfileNames + fileNameHtml;
                    Session["fileName"] = allfileNames;

                    SecureString passWord2 = new SecureString();
                    foreach (char c in password.ToCharArray()) passWord2.AppendChar(c);
                    clientContext.Credentials = new SharePointOnlineCredentials(username, passWord2);
                    clientContext.Load(uploadFile);
                    uploadFile.ListItemAllFields.Update();
                    clientContext.ExecuteQuery();
                    // fileName.InnerHtml = Convert.ToString(Session["fileName"]);
                    hdnFileTable.Value = "Files";
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "alertmsg", "FileUploadMsg()", true);

                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "UploadDocument", "TiF-Form.aspx");
                }
            }


        }
            
        public DataTable AttachementTable()
        {
            DataTable dt = null;
            if (fileUpload.HasFile)
            {
                DataTable fileDt = (DataTable)Session["FilesList"];
                if (fileDt == null)
                {
                    fileDt = new DataTable();
                    fileDt.Columns.Add("Sn");
                    fileDt.Columns.Add("FileName");
                    fileDt.Columns.Add("FileContent", System.Type.GetType("System.Byte[]"));
                }

                DataRow row = fileDt.NewRow();

                if (fileDt.Rows.Count == 0)
                    row["Sn"] = fileDt.Rows.Count + 1;
                else
                    row["Sn"] = fileDt.Rows.Count + 1;

                row["FileName"] = Path.GetFileName(fileUpload.FileName);

                MemoryStream ms = new MemoryStream(fileUpload.FileBytes);
                row["FileContent"] = ms.ToArray();  // This is File Byte stream
                fileDt.Rows.Add(row);

                Session["FilesList"] = fileDt;
                dt = (DataTable)Session["FilesList"];
                WriteDTHTML(dt);

                if (fileDt != null && fileDt.Rows.Count > 0)
                {
                    btnUpload.Enabled = true;
                    hdnfileUpload.Value = "File";
                }
                else
                {
                    btnUpload.Enabled = false;
                    hdnfileUpload.Value = "";
                }
                
            }
            
            return dt;
        }

        public void UploadFiles(DataTable dt,string requestNumber)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                byte[] buffer = (byte[])(dt.Rows[i]["FileContent"]);
                MemoryStream ms = new MemoryStream(buffer);
                string value = hdnfileTRno.Value;
                if (value == i.ToString())
                     UploadDocument(ms, Convert.ToString(dt.Rows[i]["FileName"]), Constants.TIF_Documents, requestNumber,"Yes");
                else
                    UploadDocument(ms, Convert.ToString(dt.Rows[i]["FileName"]), Constants.TIF_Documents, requestNumber, "No");
            }
        }

        public void WriteDTHTML(DataTable dt)
        {
            string tableHtml = "<table class='table table-responsive ags-access-table' style='line-height:10px;min-width:70%'><tr>";
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if (dt.Columns[i].ColumnName == "FileContent")
                    tableHtml += "<th style='display:none'>" + dt.Columns[i].ColumnName + "</th>";
                else if (dt.Columns[i].ColumnName == "FileName")
                {
                    tableHtml += "<th width='90%'>" + dt.Columns[i].ColumnName + "</th>";
                }
                else
                {
                    tableHtml += "<th width='10%'>" + dt.Columns[i].ColumnName + "</th>";
                }
            }

            tableHtml += "<th>&nbsp;&nbsp;</th>";  

            tableHtml += "</tr>";
            int index = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                int k = i + 1;
                tableHtml += "<tr id='" + k + "'>";
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    if (dt.Columns[j].ColumnName == "FileContent")
                        tableHtml += "<td style='display:none'>" + dt.Rows[i][j] + "</td>";
                    else
                        tableHtml += "<td>" + dt.Rows[i][j] + "</td>";

                    index = Convert.ToInt32(dt.Rows[i][0]);
                }
                tableHtml += "<td style='padding-top: 6px;'>&nbsp;&nbsp;<a href='#' onclick='DeleteRow(" + k + ");' ><img src='../css/images/trash.png' height='20px' /></a></td>";
                tableHtml += "</tr>";
            }

            tableHtml += "</table>";

            filesDiv.InnerHtml = tableHtml;
            hdnFileTable.Value = "Files";

        }

        /// <summary>
       /// Deleting the rows from Ssesstion file table from ids geeting from hidden fields.
       /// </summary>
       /// <param name="dt"></param>
       /// <returns></returns>
        public DataTable RowIds(DataTable dt)
        {
            string[] ids = hdnfileTRno.Value.Split('-');
            foreach (string id in ids)
            {
                if (!string.IsNullOrEmpty(id))
                {
                    DataRow row = dt.Select("Sn=" + id + "").FirstOrDefault();
                    row.Delete();
                    dt.AcceptChanges();
                }
            }
            return dt;
        }       

        /// <summary>
        /// Get attachment of requests
        /// </summary>
        /// <param name="folderName"></param>
        public void GetAttachments(string folderName)
        {
            try
            {
                
                var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
                using (var clientContext = spContext.CreateUserClientContextForSPHost())
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIF_Documents);
                    CamlQuery query = new CamlQuery();
                    Web web = clientContext.Web;
                    clientContext.Load(web);
                    clientContext.Load(web, wb => wb.ServerRelativeUrl);
                    clientContext.ExecuteQuery();

                    Folder folder = web.GetFolderByServerRelativeUrl(web.ServerRelativeUrl + "/" + Constants.TIF_Documents + "/" + folderName + "/");
                    clientContext.Load(folder);
                    clientContext.ExecuteQuery();

                    CamlQuery camlQuery = new CamlQuery();
                    camlQuery.ViewXml = @"<View Scope='Recursive'>
                                     <Query>
                                     </Query>
                                 </View>";
                    camlQuery.FolderServerRelativeUrl = folder.ServerRelativeUrl;
                    Microsoft.SharePoint.Client.ListItemCollection listItems = list.GetItems(camlQuery);
                    clientContext.Load(listItems);
                    clientContext.ExecuteQuery();

                    List<Files> listobj = new List<Files>();
                    string siteURL = Convert.ToString(ConfigurationManager.AppSettings["SiteURL"]);
                    string path = siteURL + "/" + Constants.TIF_Documents + "/" + folderName + "/";
                    for(int i=0; i<listItems.Count;i++)
                    {
                        Files obj = new Files();
                        obj.Sn_No = (i + 1).ToString();
                        obj.FileName = Convert.ToString(listItems[i]["Title"]);
                        obj.FilePath = path + Convert.ToString(listItems[i]["Title"]);
                        obj.Created_By = Convert.ToString(listItems[i]["CreatedBy"]);
                        obj.Created_Date = Convert.ToDateTime(listItems[i]["Created"]).ToString("MM-dd-yyyy");
                        listobj.Add(obj);

                    }
                    grdAttachments.DataSource = listobj;
                    grdAttachments.DataBind();

                }

            }
            catch (Exception ex)
            {

            }
        }        

        #endregion                      

        #region Email Section all functions

        /// <summary>
        /// Get Email of dispatch team
        /// </summary>
        /// <returns></returns>
        //public List<string> GetDispatchUsersEmail()
        //{

        //    List<string> userEmailsObj = new List<string>();

        //    var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
        //    using (var clientContext = spContext.CreateUserClientContextForSPHost())
        //    {
        //        try
        //        {
        //            string username = hdnserviceuser.Value;
        //            string password = hdnservicepassword.Value;

        //            SecureString passWord = new SecureString();
        //            foreach (char c in password.ToCharArray()) passWord.AppendChar(c);
        //            clientContext.Credentials = new SharePointOnlineCredentials(username, passWord);
        //           // clientContext.ExecuteQuery();

        //            GroupCollection collGroup = clientContext.Web.SiteGroups;
        //            Group getDispatch = collGroup.GetByName(Constants.DispatchTeamGroup);
        //            UserCollection dispatchUsers = getDispatch.Users;

        //            //SecureString passWord1 = new SecureString();
        //            //foreach (char c in password.ToCharArray()) passWord1.AppendChar(c);
        //            //clientContext.Credentials = new SharePointOnlineCredentials(username, passWord1);

        //            clientContext.Load(dispatchUsers);
        //            clientContext.ExecuteQuery();
               
        //            foreach (User user in dispatchUsers)
        //            {
        //                clientContext.Load(user);
        //                clientContext.ExecuteQuery();
        //                userEmailsObj.Add(user.Email);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            Constants.ErrorLog(clientContext, ex.Message, ex.Source, "btnDispatchSubmit_Click", "TiF-Form.aspx");
        //        }
        //    }
        //    return userEmailsObj;
        //}

        /// <summary>
        /// Get Email of dispatch team
        /// </summary>
        /// <returns></returns>
        public List<string> GetDispatchUsersMail()
        {
            List<string> userEmailsObj = new List<string>();
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIFRoleConfiguration);
                    CamlQuery query = new CamlQuery();
                    query.ViewXml = "<View><Query><Where><Contains><FieldRef Name='Role' /><Value Type='Choice'>Dispatch</Value></Contains></Where></Query></View>";
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                                    
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null)
                    {
                        foreach(Microsoft.SharePoint.Client.ListItem item in items )
                        {
                            FieldUserValue flduser = item["User"] as FieldUserValue;
                            User user  = clientContext.Web.GetUserById(flduser.LookupId);
                            clientContext.Load(user);
                            clientContext.ExecuteQuery();
                            userEmailsObj.Add(user.Email);

                        }
                    }
                }
                catch(Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetDispatchUsersMail", "TiF-Form.aspx");
                }
            }
            return userEmailsObj;
        }

        /// <summary>
        /// Common function for sending email for all action
        /// </summary>
        /// <param name="action"></param>
        /// <param name="requestNo"></param>
        /// <param name="name"></param>
        /// <param name="toEmail"></param>
        /// <param name="ccEmail"></param>
        public void SendMail(string action,string requestNo, string name, List<string> toEmail,List<string> ccEmail)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    List list = clientContext.Web.Lists.GetByTitle(Constants.EmailConfiguration);
                    CamlQuery query = new CamlQuery();
                    query.ViewXml = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + action + "</Value></Eq></Where></Query></View>";
                    Microsoft.SharePoint.Client.ListItemCollection items=  list.GetItems(query);
                
                    clientContext.Load(clientContext.Web, web => web.Url);                   
                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                   // string linkUrl = HttpContext.Current.Request.Url.AbsoluteUri;
                    string linkUrl = clientContext.Web.Url + "/Pages/TIF_Form.aspx?formId=" + requestNo + "&ReferBy=Main";
                    
                    string requestUrl = "<a href = '" + linkUrl + "'>" + requestNo + "</a>";

                    if(items !=null)
                    {
                        Microsoft.SharePoint.Client.ListItem item = items[0];
                        string body = Convert.ToString(item["Body"]);                     
                        body = body.Replace("<<Name>>", name);
                        body = body.Replace("<<space>>", "</br>");
                        body = body.Replace("<<RequestNo>>", requestUrl);

                        string subject = Convert.ToString(item["Subject"]);
                        subject = subject.Replace("<<RequestNo>>", requestNo);
                        subject = subject.Replace("<<Name>>", name);

                        bool sendMail = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["SendMail"]);
                        if (clientContext != null && sendMail)
                        {
                            var emailp = new EmailProperties();
                            emailp.To = toEmail;
                            emailp.CC = ccEmail;
                            emailp.From = Constants.BIM_SupportFormUserMail;
                            emailp.Body = body;
                            emailp.Subject = subject;
                            Utility.SendEmail(clientContext, emailp);
                            clientContext.ExecuteQuery();

                         
                        }
                    }
                   
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "SendMail", "TiF-Form.aspx");
                }
            }

        }

        /// <summary>
        /// Sending Mail when form submitted/reverted/completed/cancelled
        /// </summary>
        /// <param name="requestNo"></param>
        public void SendMailonforDifferentActions(string SubmitOrRevert)
        {
            string travellerName = Convert.ToString(ViewState["TravellerName"]);
            string travellerId = Convert.ToString(ViewState["TravellerId"]);
            ADMethods AD = new ADMethods();
            ADMethods.ADAttributes ADResult = AD.GetEmployeeAttributes(travellerId, ADMethods.AdPrpoertyParameters.employeeid);
       
            string travellerEmail = ADResult.mail;
            List<string> travellerToEmailList = new List<string>();
            travellerToEmailList.Add(travellerEmail);

            string managerEmail = ADResult.ManagerEmail;
            List<string> dispatchCCMails = GetDispatchUsersMail();    

            dispatchCCMails.Add(managerEmail);        
            SendMail(SubmitOrRevert, lblReqNo.Text.Trim(), travellerName, travellerToEmailList, dispatchCCMails);
        }

        /// <summary>
        /// Send mail for traveller submission
        /// </summary>
        protected void SendMailOnTravellerSubmission()
        {
            ADMethods AD = new ADMethods();

            string travellerName = Convert.ToString(ViewState["TravellerName"]);
            string travellerId = Convert.ToString(ViewState["TravellerId"]);
            ADMethods.ADAttributes ADResult = AD.GetEmployeeAttributes(travellerId, ADMethods.AdPrpoertyParameters.employeeid);
          
            string travellerEmail = ADResult.mail;
            List<string> travellerCCEmailList = new List<string>();
            travellerCCEmailList.Add(travellerEmail);

            string managerEmail = ADResult.ManagerEmail;
            travellerCCEmailList.Add(managerEmail);   // CC manager

            List<string> dispatchToMails = GetDispatchUsersMail();
            SendMail(Constants.SubmitByTraveller, lblReqNo.Text.Trim(), travellerName, dispatchToMails, travellerCCEmailList);     
        }

         #endregion

        #region Common Function       

      

        protected void MessagePopup(string msgType, string msg)
        {
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), msgType, "alert('" + msg + "')", true);
        }

        /// <summary>
        /// Adding Traveller and manager into related group on form submission
        /// </summary>
        public void AddUsersToRelatedGroup()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string trvallername = txtTravellerName.Text.Trim();
                    string trvgroupName = Constants.TravellerGroup;

                    if (!string.IsNullOrEmpty(trvallername))
                    {
                        var trvuser = clientContext.Web.EnsureUser(trvallername);
                        clientContext.Load(trvuser);
                        Group trvgroup = clientContext.Web.SiteGroups.GetByName(trvgroupName);

                        trvgroup.Users.AddUser(trvuser);
                        clientContext.ExecuteQuery();
                    }
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "AddUsersToRelatedGroup", "TiF-Form.aspx");
                }
            }

        }

        public void AddUsersToRelatedRoletoList(string requestNo)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    AddUsersToRelatedGroup();
                    if (!CheckForUserExistInRolelist())
                    {
                        string trvallername = txtTravellerName.Text.Trim();
                        var user = clientContext.Web.EnsureUser(trvallername);
                        clientContext.Load(user);
                        clientContext.ExecuteQuery();

                        List list = clientContext.Web.Lists.GetByTitle(Constants.TIFRoleConfiguration);
                        ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();

                        Microsoft.SharePoint.Client.ListItem newItem = list.AddItem(itemCreateInfo);

                        FieldUserValue userValue = new FieldUserValue();
                        userValue.LookupId = user.Id;
                        newItem["Title"] = requestNo;
                        newItem["User"] = userValue;
                        newItem["Role"] = Constants.TravellerGp;
                        newItem.Update();
                        clientContext.ExecuteQuery();

                    }
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "AddUsersToRelatedGroup", "TiF-Form.aspx");
                }
            }
        }

        protected bool CheckForUserExistInRolelist()
        {
            bool isUserExists = false;
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string trvallername = txtTravellerName.Text.Trim();                 

                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIFRoleConfiguration);
                    CamlQuery query = new CamlQuery();
                    query.ViewXml = "<View><Query><Where><Eq><FieldRef Name='User' LookupId='False' /><Value Type='Lookup'>" + trvallername + "</Value></Eq></Where></Query></View>";
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);

                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null && items.Count >0)
                    {
                        isUserExists = true;
                    }
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "CheckPermissionForCurrentUser", "TiF-Form.aspx");
                }
            }
            return isUserExists;
        }

        /// <summary>
        /// Get current user gourp
        /// </summary>
        /// <returns></returns>
        protected string CheckForPermissionCurrentUserGroup()
        {
            string isMemberOf = string.Empty;

            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    Web oWeb = clientContext.Web;
                    GroupCollection userGroups = oWeb.CurrentUser.Groups;
                    clientContext.Load(userGroups);
                    clientContext.ExecuteQuery();
                    for (int i = 0; i < userGroups.Count; i++)
                    {
                        string currentGrp = userGroups[i].Title;

                        if (currentGrp == Constants.DispatchTeamGroup)
                        {
                            isMemberOf = Constants.DispatchTeamGroup;
                            break;
                        }

                        if (currentGrp == Constants.TravellerGroup)
                        {
                            isMemberOf = Constants.TravellerGroup;
                            break;
                        }
                    }

                    hdnCurrentUsergroup.Value = isMemberOf;

                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "GetCurrentUserGroup", "TiF-Form.aspx");
                }
            }
            return isMemberOf;
        }

        /// <summary>
        /// Get current user role as dispatch/Traveller from SharePoint list TIFRoles
        /// </summary>
        /// <returns></returns>
        protected string CheckPermissionForCurrentUser()
        {
            string isMemberOf = string.Empty;

            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    User user = clientContext.Web.CurrentUser;
                    clientContext.Load(user);
                    clientContext.ExecuteQuery();
                    string userName = user.Title;

                    List list = clientContext.Web.Lists.GetByTitle(Constants.TIFRoleConfiguration);
                    CamlQuery query = new CamlQuery();
                    query.ViewXml = "<View><Query><Where><Eq><FieldRef Name='User' LookupId='False' /><Value Type='Lookup'>" + userName + "</Value></Eq></Where></Query></View>";
                    Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);

                    clientContext.Load(items);
                    clientContext.ExecuteQuery();

                    if (items != null)
                    {
                        isMemberOf = Convert.ToString(items[0]["Role"]);
                        hdnCurrentUsergroup.Value = isMemberOf;
                    }
                }
                catch (Exception ex)
                {
                    Constants.ErrorLog(clientContext, ex.Message, ex.Source, "CheckPermissionForCurrentUser", "TiF-Form.aspx");
                }
            }
            return isMemberOf;
        }

        /// <summary>
        /// checking for submit button enable/disable in post travel use cases
        /// </summary>
        /// <param name="tabName"></param>
        public void CheckForPostTravelSubmitButton(string tabName)
        {

            if (tabName.Equals(Constants.MainRequestType))
            {
                DateTime? plannedEndDate = null;
                // string role = CheckForPermissionCurrentUserGroup();
                string role = CheckPermissionForCurrentUser();
                DateTime currdate = DateTime.Now.Date;

                if (!String.IsNullOrEmpty(Convert.ToString(tbPlannedStartDate.Text)))
                    plannedEndDate = Convert.ToDateTime(tbPlannedStartDate.Text).Date; //new DateTime(2019, 4, 29).Date;

                int value = DateTime.Compare(new DateTime(2019, 4, 29), currdate);
                string requestStatus = lblReqStatus.Text.Trim();

                if ((role == Constants.TravellerGp || role == Constants.InBothRole) && (Constants.Requestsubimtted == requestStatus || Constants.RequestRevertedToTraveller == requestStatus))
                {
                    if (currdate >= plannedEndDate)
                    {
                        string enableButton = "TravellerEnable";
                        hdnButtonEnable.Value = enableButton;
                        btnUpload.Enabled = true;                    
                    }
                    currentUserRole.Value = Constants.TravellerGp;
                }


                if ((role == Constants.DispatchTeamGp || role == Constants.InBothRole) && Constants.RequestPendingWithDispatch == requestStatus)
                {
                    string enableButton = "DispatchEnable";
                    hdnButtonEnable.Value = enableButton;
                    btnUpload.Enabled = true;
                    currentUserRole.Value = Constants.DispatchTeamGp;

                }
                if ((role == Constants.DispatchTeamGp || role == Constants.InBothRole) && Constants.Requestsubimtted == requestStatus)
                {
                    currentUserRole.Value = Constants.DispatchTeamGp;  // for cancel button logic for hodden field
                }

            }
          
        }

        #endregion           
    }
}