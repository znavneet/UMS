﻿using AMAT.BAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMAT.TIFWeb.Pages
{
    public partial class Test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static DataTable GetTrvellerDetailsFromOppoNo(string oppoNo)
        {
            DataTable dt = new DataTable();
            BusinessAccessLayer ba = new BAL.BusinessAccessLayer();
            if (!string.IsNullOrEmpty(oppoNo))
            {
                dt = ba.GetDetailByOpportunityNo(oppoNo);
            }
            return dt;
        }
          [WebMethod]
        public static DataTable GetCities(string oppoNo)
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            string connectionString = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnString"].ConnectionString);
            using (SqlConnection con = new SqlConnection(connectionString))
            {
               
                using (SqlCommand cmd = new SqlCommand("select * from Cities", con))
                {
                    cmd.CommandType = CommandType.Text;

                   
                    SqlDataAdapter ad = new SqlDataAdapter(cmd);
                    ad.Fill(ds);
                    if (ds.Tables.Count > 0)
                        dt = ds.Tables[0];
                }
            }
           
            //DataTable dt = new DataTable();
            //BusinessAccessLayer ba = new BAL.BusinessAccessLayer();
            //if (!string.IsNullOrEmpty(oppoNo))
            //{
            //    dt = ba.GetDetailByOpportunityNo(oppoNo);
            //}
            return dt;
        }
    }
}