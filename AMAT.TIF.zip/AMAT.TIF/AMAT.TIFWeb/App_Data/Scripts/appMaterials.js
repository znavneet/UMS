﻿
// variable used for cross site CSOM calls
var context;
// peoplePicker variable needs to be globally scoped as the generated html contains JS that will call into functions of this class
var peoplePicker;
var pplRequestorName;

//suresh to add second people picker

//var pplCostCenterMgr;

//Wait for the page to load
$(document).ready(function () {

    //Get the URI decoded SharePoint site url from the SPHostUrl parameter.
    var spHostUrl = decodeURIComponent(getQueryStringParameter('SPHostUrl'));
    var appWebUrl = decodeURIComponent(getQueryStringParameter('SPAppWebUrl'));
    var spLanguage = decodeURIComponent(getQueryStringParameter('SPLanguage'));

    //Build absolute path to the layouts root with the spHostUrl
    var layoutsRoot = spHostUrl + '/_layouts/15/';
   
    //load all appropriate scripts for the page to function
    $.getScript(layoutsRoot + 'SP.Runtime.js',
        function () {
            $.getScript(layoutsRoot + 'SP.js',
                function () {
                    $.getScript(layoutsRoot + 'SP.UI.Controls.js', renderSPChrome);
                    $.getScript(layoutsRoot + 'SP.RequestExecutor.js', function () {
                        context = new SP.ClientContext(appWebUrl);
                        var factory = new SP.ProxyWebRequestExecutorFactory(appWebUrl);
                        context.set_webRequestExecutorFactory(factory);                     
                        
                        pplAGSContact = getPeoplePickerInstance(context, $('#spanAGSContact'), $('#txtAGSContact'), $('#divAGSContactSearch'), $('#hdnAGSContact'), "pplAGSContact", spLanguage);
                        pplMaterialProjectManager = getPeoplePickerInstance(context, $('#spanMaterialProjectManager'), $('#txtMaterialProjectManager'), $('#divMaterialProjectManagerSearch'), $('#hdnMaterialProjectManager'), "pplMaterialProjectManager", spLanguage);
                        pplLTBPoOriginalBuyer = getPeoplePickerInstance(context, $('#spanLTBPOOriginalBuyer'), $('#txtLTBPOOriginalBuyer'), $('#divLTBPOOriginalBuyerSearch'), $('#hdnLTBPOOriginalBuyer'), "pplLTBPoOriginalBuyer", spLanguage);
                    });

                });
        });
});


//function to get a parameter value by a specific key
function getQueryStringParameter(urlParameterKey) {
    var params = document.URL.split('?')[1].split('&');
    var strParams = '';
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split('=');
        if (singleParam[0] == urlParameterKey)
            return singleParam[1];
    }
}


function getPeoplePickerInstance(context, spanControl, inputControl, searchDivControl, hiddenControl, variableName, spLanguage) {
    var newPicker;
    newPicker = new CAMControl.CsomPeoplePicker('workbench.aspx/GetPeoplePickerData', context, spanControl, inputControl, searchDivControl, hiddenControl);

    newPicker.InstanceName = variableName;   
    newPicker.Language = spLanguage;  
    newPicker.MaxEntriesShown = 5;   
    newPicker.AllowDuplicates = false;
    newPicker.ShowLoginName = false;
    newPicker.ShowTitle = true;
    newPicker.PrincipalType = 1;
    newPicker.MaxUsers = 5;
    newPicker.MinimalCharactersBeforeSearching = 2;
    newPicker.Initialize();
    return newPicker;



}
