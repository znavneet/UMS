﻿var resultsSingle = 'Showing {0} result';
var resultsTooMany = 'Showing {0} of {1} results. <B>Please refine further</B>';
var resultsMany = 'Showing {0} results';
var resultsSearching = 'Searching...';
var deleteUser = 'Remove person or group {0}';