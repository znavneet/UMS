﻿$(document).ready(function () {    

    DateValidationForPlanStartEndDt();
    DateValidationForCheckInOut();
    DateValidationForDeptArrDate();
    DateValidationForTravChkInOutDt();
    DateValidationForActualStEndDt();
   
});

function DateValidationForCheckInOut() {
    $(".chkInOut").on("dp.change", function (e) {
        var dt1 = new Date($('#tbCheckinDate').val());
        var dt2 =  new Date($('#tbCheckoutDate').val());
        var curDate = moment(new Date()).format("MM/DD/YYYY");

        if (dt1 && dt2 && dt2 != curDate) {
            if (dt1 > dt2) {
                alert("Checkout Date cannot be less than check-in date");
                $('#tbCheckoutDate').val('');
            }
        }

        var start = new Date($('#tbCheckoutDate').val());
        var end = new Date($('#tbCheckinDate').val());
        var days = (start - end) / (1000 * 60 * 60 * 24);

        if (days)
            $('#tbNoOfNights').val(days);

    });
}

function DateValidationForPlanStartEndDt() {
    $(".planStend").on("dp.change", function (e) {
        var dt1 =  new Date($('#tbPlannedStartDate').val());
        var dt2 =  new Date($('#tbPlannedEndDate').val());
        var curDate = moment(new Date()).format("MM/DD/YYYY");

        if (dt1 && dt2 && dt2 != curDate) {
            if (dt1 > dt2) {
                alert("Planned end date cannot be less than Planned start date");
                $('#tbPlannedEndDate').val('');
            }
        }
        
    });
}

function DateValidationForDeptArrDate() {
    $(".depArriDate").on("dp.change", function (e) {
        var dt1 =  new Date($('#tbDepartureDate').val());
        var dt2 =  new Date($('#tbReturnDate').val());
        var curDate = moment(new Date()).format("MM/DD/YYYY");

        if (dt1 && dt2 && dt2 != curDate) {
            if (dt1 > dt2) {
                alert("Arrival Date cannot be less than departure date");
                $('#tbReturnDate').val('');
            }
        }
       
    });
}

function DateValidationForTravChkInOutDt() {
    $(".trvChkInOut").on("dp.change", function (e) {
        var dt1 =  new Date($('#txtCheckinDateTrav').val());
        var dt2 =  new Date($('#txtChkOutByTrav').val());
        var curDate = moment(new Date()).format("MM/DD/YYYY");

        if (dt1 && dt2 && dt2 != curDate) {
            if (dt1 > dt2) {
                alert("Checkout Date cannot be less than check-in date");
                $('#txtChkOutByTrav').val('');
            }
        }
       
    });
}

function DateValidationForActualStEndDt() {
    $(".trvactualStEndDt").on("dp.change", function (e) {
        var dt1 =  new Date($('#txtActualStartDate').val());
        var dt2 =  new Date($('#txtActualEndDate').val());
        var curDate = moment(new Date()).format("MM/DD/YYYY");

        if (dt1 && dt2 && dt2 != curDate) {
            if (dt1 > dt2) {
                alert("Actual end date cannot be less than actual start date");
                $('#txtActualEndDate').val('');
            }
        }
    });
}






