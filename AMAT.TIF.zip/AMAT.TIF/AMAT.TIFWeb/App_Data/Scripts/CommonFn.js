﻿
$(document).ready(function () {
    getPerdiem();
});
function getPerdiem()
{
    $('#ddlDestination').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var destination = this.value;
        var origin = $('#ddlOriginCountry').val();
        var siteUrl = decodeURIComponent(getQueryStringParameter('SPHostUrl'));

        var obj = {
            Origin: origin,
            Dest: destination,
            siteUrl: siteUrl
        }
        var newObj = JSON.stringify(obj);
        if (origin != "0" && destination != "0") {

            $.ajax({
                type: "POST",
                url: "TIFWebService.asmx/GetPerdiem",
                data: newObj,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    CalculateTotalExpense(data);
                },
                error: function (error) {
                    alert(JSON.stringify(error));
                }

            });
        }

    });
}

var totalPerdiemExpse;
function CalculateTotalExpense(data) {
    $('#txtPerDiem').val(data.d);
    var perDiem = parseInt(data.d);
    var start = new Date($('#tbPlannedEndDate').val());
    var end = new Date($('#tbPlannedStartDate').val());
    var days = (start - end) / (1000 * 60 * 60 * 24);
   
    days = parseInt(days);
    totalPerdiemExpse = perDiem * days;
    // $('#tbEstTravelSpend').val(toltalExp);
    return totalPerdiemExpse;
}


function TotalFareExpencecalculation() {
    var totalExp
    if (totalPerdiemExpse)
        totalExp = totalPerdiemExpse;//parseInt($('#tbEstTravelSpend').val()); // totla expense from plan start date an end date
    else
    {
        totalExp = parseInt($('#txtPerDiem').val());
        var start = new Date($('#tbPlannedEndDate').val());
        var end = new Date($('#tbPlannedStartDate').val());
        var days = (start - end) / (1000 * 60 * 60 * 24);
        totalExp = totalExp * days;
    }
       

    var dep = $("#tbDepartureFare").val(); // dep fare
    var arr = $("#tbReturnFare").val();  // arr fare
    var hotelExpse = parseInt($('#tbRoomRate').val());  //room rate
    var noOfNight = parseInt($('#tbNoOfNights').val()); // total nights
    
    var airFareSum = parseInt(dep) + parseInt(arr);
    var totalhotelExpse = parseInt(hotelExpse) * parseInt(noOfNight);
    var texp = parseInt(totalExp) + parseInt(airFareSum) + parseInt(totalhotelExpse);

    $('#tbEstTravelSpend').val(texp);
}