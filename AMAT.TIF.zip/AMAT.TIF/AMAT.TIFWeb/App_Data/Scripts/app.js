﻿if (!window.location.origin) {
    window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');
}
var baseUrl = (window.location.origin.indexOf("localhost") > -1) ? window.location.origin : window.location.origin + "/RT";
// variable used for cross site CSOM calls
var context;
// peoplePicker variable needs to be globally scoped as the generated html contains JS that will call into functions of this class
var QRPeoplePicker;
var CoreTeamLeaderPeoplePicker;

//Wait for the page to load
$(document).ready(function () {

    //Get the URI decoded SharePoint site url from the SPHostUrl parameter.
    var spHostUrl = decodeURIComponent(getQueryStringParameter('SPHostUrl'));
    //var appWebUrl = decodeURIComponent(getQueryStringParameter('SPAppWebUrl'));
    var spLanguage = decodeURIComponent(getQueryStringParameter('SPLanguage'));
    //var spHostUrl = "https://sp13appstoredev.amat.com/sites/DevApps/PTO";
    //var appWebUrl = "http://sp13appstoredev.amat.com/sites/apps";
    //debugger;
    var appWebUrl = "https://spqaappweb.amat.com/gll_qa";

   // var spHostUrl = "https://team.amat.com/sites/appdev/TIF";
    //var appWebUrl = "http://apps-760a69a857a96a.spdevappstore.com/sites/DevApps/RT/AMAT.ReliabilityTool";
    //var appWebUrl = "http://sp13appstoredev.amat.com/sites/apps";

    //var spHostUrl = "https://ppespcollab.amat.com/sites/RT/";
    //var appWebUrl = "https://ppespcollab.amat.com/sites/app";

    // var spHostUrl = decodeURIComponent(getQueryStringParameter('SPHostUrl'));
    //var appWebUrl = decodeURIComponent(getQueryStringParameter('SPAppWebUrl'));

    var spLanguage = "en-US";
    //Build absolute path to the layouts root with the spHostUrl
    var layoutsRoot = spHostUrl + '/_layouts/15/';

    $.getScript(layoutsRoot + 'SP.Runtime.js',
        function () {
            $.getScript(layoutsRoot + 'SP.js',
                function () {
                    $.getScript(layoutsRoot + 'SP.RequestExecutor.js', function () {
                        context = new SP.ClientContext(appWebUrl);
                        var factory = new SP.ProxyWebRequestExecutorFactory(appWebUrl);
                        context.set_webRequestExecutorFactory(factory);
                        //QR Field
                        //if ($('#spanCsomQR').length > 0 && $('#tbPlanner').length > 0 && $('#divCsomQRSearch').length > 0 && $('#hdnPlanner').length > 0)
                        //    QRPeoplePicker = getPeoplePickerInstance(baseUrl + '/Dispatch.aspx/GetPeoplePickerData', spHostUrl, $('#spanCsomQR'), $('#tbPlanner'), $('#divCsomQRSearch'), $('#hdnPlanner'), "QRPeoplePicker", spLanguage, false, 1, $('#txtPMEmail'));
                        if ($('#spanCsomQR').length > 0 && $('#tbPlanner').length > 0 && $('#divCsomQRSearch').length > 0 && $('#hdnPlanner').length > 0)
                            QRPeoplePicker = getPeoplePickerInstance(baseUrl + '/Report.aspx/GetPeoplePickerData', spHostUrl, $('#spanCsomQR'), $('#tbPlanner'), $('#divCsomQRSearch'), $('#hdnPlanner'), "QRPeoplePicker", spLanguage, false, 1, $('#txtPMEmail'));

                        ////Core Team Leader Field
                        //if ($('#spanCsomCoreTeamLeader').length > 0 && $('#tbTravellerName').length > 0 && $('#divCsomCoreTeamLeaderSearch').length > 0 && $('#hdnTravellerName').length > 0)
                        //    CoreTeamLeaderPeoplePicker = getPeoplePickerInstance(baseUrl + '/Dispatch.aspx/GetPeoplePickerData', spHostUrl, $('#spanCsomCoreTeamLeader'), $('#tbTravellerName'), $('#divCsomCoreTeamLeaderSearch'), $('#hdnTravellerName'), "CoreTeamLeaderPeoplePicker", spLanguage, false, 1, $('#txtPMEmail'));
                    });
                    if ($('#spanCsomCoreTeamLeader').length > 0 && $('#tbTravellerName').length > 0 && $('#divCsomCoreTeamLeaderSearch').length > 0 && $('#hdnTravellerName').length > 0)
                        CoreTeamLeaderPeoplePicker = getPeoplePickerInstance(baseUrl + '/Report.aspx/GetPeoplePickerData', spHostUrl, $('#spanCsomCoreTeamLeader'), $('#tbTravellerName'), $('#divCsomCoreTeamLeaderSearch'), $('#hdnTravellerName'), "CoreTeamLeaderPeoplePicker", spLanguage, false, 1, $('#txtPMEmail'));
                });
        });

    function getPeoplePickerInstance(webMethodUrl, spHosUrl, spanControl, inputControl, searchDivControl, hiddenControl, variableName, spLanguage, MultipleEntryAllowed, maxUser, controlToActivate) {
        var newPicker;
        newPicker = new CAMControl.CsomPeoplePicker('Dispatch.aspx/GetPeoplePickerData', spHosUrl, spanControl, inputControl, searchDivControl, hiddenControl, MultipleEntryAllowed);
        // required to pass the variable name here!
        newPicker.InstanceName = variableName;
        // Pass current language, if not set defaults to en-US. Use the SPLanguage query string param or provide a string like "nl-BE"
        // Do not set the Language property if you do not have foreseen javascript resource file for your language
        newPicker.Language = spLanguage;
        // optionally show more/less entries in the people picker dropdown, 4 is the default
        newPicker.MaxEntriesShown = 5;
        // Can duplicate entries be selected (default = false)
        newPicker.AllowDuplicates = false;
        // Show the user loginname
        newPicker.ShowLoginName = false;
        // Show the user title
        newPicker.ShowTitle = true;
        // Set principal type to determine what is shown (default = 1, only users are resolved). 
        // See http://msdn.microsoft.com/en-us/library/office/microsoft.sharepoint.client.utilities.principaltype.aspx for more details
        // Set ShowLoginName and ShowTitle to false if you're resolving groups
        newPicker.PrincipalType = 1;
        // start user resolving as of 2 entered characters (= default)
        newPicker.MinimalCharactersBeforeSearching = 2;
        //set max users in people control
        newPicker.MaxUsers = maxUser;
        //Control To Blur
        newPicker.controlToActivate = controlToActivate;
        // Hookup everything
        newPicker.Initialize();

        return newPicker;
    }
});
//function to get a parameter value by a specific key
function getQueryStringParameter(urlParameterKey) {
    var params = document.URL.split('?')[1].split('&');
    var strParams = '';
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split('=');
        if (singleParam[0] == urlParameterKey)
            return singleParam[1];
    }


}
