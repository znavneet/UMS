$(document).ready(function() {
    jQuery('.tabs .tab-links a').on('click', function(e)  {
        var currentAttrValue = jQuery(this).attr('href');
 
        // Show/Hide Tabs
      //  jQuery('.tabs ' + currentAttrValue).show().siblings().hide(); /* normal */
		
	//	jQuery('.tabs ' + currentAttrValue).fadeIn(400).siblings().hide(); /*fade in*/		
		
	//	jQuery('.tabs ' + currentAttrValue).siblings().slideUp(400); /* slide 1 */
	//	jQuery('.tabs ' + currentAttrValue).delay(400).slideDown(400); /* slide 1 */
		
		jQuery('.tabs ' + currentAttrValue).slideDown(400).siblings().slideUp(400); /* slide 2*/
		
		
 
        // Change/remove current tab to active
        jQuery(this).parent('li').addClass('active').siblings().removeClass('active');
 
        e.preventDefault();
    });	
	
});