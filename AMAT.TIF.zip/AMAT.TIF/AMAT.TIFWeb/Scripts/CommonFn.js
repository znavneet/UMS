﻿
$(document).ready(function () {
    getPerdiem();
});
function getPerdiem()
{
    $('#ddlDestination').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var destination = this.value;
        var origin = $('#ddlOriginCountry').val();
        var siteUrl = decodeURIComponent(getQueryStringParameter('SPHostUrl'));
        var userId = $('#hdnserviceuser').val();
        var password = $('#hdnservicepassword').val();

        var obj = {
            Origin: origin,
            Dest: destination,
            siteUrl: siteUrl,
            UserId: userId,
            Pwd: password
        }
        var newObj = JSON.stringify(obj);
        if (origin != "0" && destination != "0") {

            $.ajax({
                type: "POST",
                url: "TIFWebService.asmx/GetPerdiem",
                data: newObj,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    CalculateTotalExpense(data);
                },
                error: function (error) {
                    alert(JSON.stringify(error));
                }

            });
        }

    });
}

var totalPerdiemExpse;
function CalculateTotalExpense(data) {
    $('#txtPerDiem').val(data.d);
    var perDiem = parseInt(data.d);
    var start = new Date($('#tbPlannedEndDate').val());
    var end = new Date($('#tbPlannedStartDate').val());
    var days = (start - end) / (1000 * 60 * 60 * 24);

    if (parseInt(days) == 0) {
        days = 1;
    }
   
    days = parseInt(days);
    totalPerdiemExpse = perDiem * days; 
    return totalPerdiemExpse;
}


function TotalFareExpencecalculation() {
    var perDiemtotalExp = ""; var total = "";

    if (totalPerdiemExpse)
        perDiemtotalExp = totalPerdiemExpse;//parseInt($('#tbEstTravelSpend').val()); // totla expense from plan start date an end date
    else
    {
        perDiemtotalExp = parseInt($('#txtPerDiem').val());
        if (perDiemtotalExp) {
            var start = new Date($('#tbPlannedEndDate').val());
            var end = new Date($('#tbPlannedStartDate').val());
            var days = (start - end) / (1000 * 60 * 60 * 24);
            perDiemtotalExp = perDiemtotalExp * days;
        }      
    }
       

    var dep = $("#tbDepartureFare").val(); // dep fare
    var arr = $("#tbReturnFare").val();  // arr fare
    var hotelExpse = parseInt($('#tbRoomRate').val());  //room rate
    var noOfNight = parseInt($('#tbNoOfNights').val()); // total nights
    
    var airFareSum = parseInt(dep) + parseInt(arr);
    var totalhotelExpse = parseInt(hotelExpse) * parseInt(noOfNight);
   
    if (perDiemtotalExp)
        total = parseInt(perDiemtotalExp) + parseInt(airFareSum) + parseInt(totalhotelExpse);
    else
        if(airFareSum)
            total = parseInt(airFareSum) + parseInt(totalhotelExpse);
        else
            total = parseInt(totalhotelExpse);

    $('#tbEstTravelSpend').val(total);
}