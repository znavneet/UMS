﻿$(document).ready(function () {    

    DateValidationForPlanStartEndDt();
    DateValidationForCheckInOut();
    DateValidationForDeptArrDate();
    DateValidationForTravChkInOutDt();
    DateValidationForActualStEndDt();
   
});

function DateValidationForCheckInOut() {
    var i = 0;
    $(".chkInOut").on("dp.change", function (e) {
        var dt1 = new Date($('#tbCheckinDate').val());
        var dt2 =  new Date($('#tbCheckoutDate').val());
        var curDate = new Date();

        if (dt1 !== dt2) {
            if (i !== 2) {
                if (dt1 && dt2) {
                    if (dt1 > dt2) {
                        alert("Checkout Date cannot be less than check-in date");
                        $('#tbNoOfNights').removeAttr("disabled");
                        $('#tbNoOfNights').val('');
                        $('#tbNoOfNights').attr("disabled", "disabled");
                        $('#tbCheckoutDate').val('');
                    }
                }
            }
            i++;
        }

        var start = new Date($('#tbCheckoutDate').val());
        var end = new Date($('#tbCheckinDate').val());
        var days = (start - end) / (1000 * 60 * 60 * 24);      

        if (days)
            $('#tbNoOfNights').val(days);

    });
}

function DateValidationForPlanStartEndDt() {
    var i = 0;
    $(".planStend").on("dp.change", function (e) {
        var dt1 = new Date($('#tbPlannedStartDate').val());
        var dt2 = new Date($('#tbPlannedEndDate').val());
        var curDate = new Date();

        if (dt1 !== dt2) {
            if (i !== 2) {
                if (dt1 && dt2) {
                    if (dt1 > dt2) {
                        alert("Planned end date cannot be less than Planned start date");
                        $('#tbPlannedEndDate').val('');
                    }
                }
            }
            i++;
        }

    });
}

function DateValidationForDeptArrDate() {
    var i = 0;
    $(".depArriDate").on("dp.change", function (e) {
        var dt1 = new Date($('#tbDepartureDate').val());
        var dt2 = new Date($('#tbReturnDate').val());

        if (dt1 !== dt2) {
            if (i !== 2) {
                if (dt1 && dt2) {
                    if (dt1 > dt2) {
                        alert("Arrival Date cannot be less than departure date");
                        $('#tbReturnDate').val('');
                    }
                }
            }
            i++;
        }

    });
}

function DateValidationForTravChkInOutDt() {
    var i = 0;
    $(".trvChkInOut").on("dp.change", function (e) {
        var dt1 = new Date($('#txtCheckinDateTrav').val());
        var dt2 = new Date($('#txtChkOutByTrav').val());
        var curDate = new Date();

        if (dt1 !== dt2) {
            if (i !== 2) {
                if (dt1 && dt2) {
                    if (dt1 > dt2) {
                        alert("Checkout Date cannot be less than check-in date");
                        $('#txtChkOutByTrav').val('');
                    }
                }
            }
            i++;
        }
    });
}   


function DateValidationForActualStEndDt() {
    var i = 0;
    $(".trvactualStEndDt").on("dp.change", function (e) {
        var dt1 = new Date($('#txtActualStartDate').val());
        var dt2 = new Date($('#txtActualEndDate').val());
        var curDate = new Date();

        if (dt1 !== dt2) {
            if (i !== 2) {
                if (dt1 && dt2) {
                    if (dt1 > dt2) {
                        alert("Actual end date cannot be less than actual start date");
                        $('#txtActualEndDate').val('');
                    }
                }
            }
            i++;
        }
    });
}






