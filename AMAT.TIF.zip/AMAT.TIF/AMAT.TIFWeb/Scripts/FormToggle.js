﻿

$(document).ready(function () {
    
    $("#loading").hide();      
    ToggleEvent();
    TravelChangeDDl();
    SetHiddenCtrlFromDDL();   
    HotelDetailsByTraveller();  /// hotel details booked by traval. 
    TripTypwRadioBtn();        

   // PostTrvDisableControls(); // disable post travel controls

    DisabledControls($("#currentTabName").val());   
});

function ToggleEvent()
{
    $('#step2').hide();
    $('#step3').hide();
    $('#step4').hide();
    $('#traveller a').addClass("active");
    $('#traveller a').attr('aria-selected', true);

    $('#traveller').click(function () {
        $('#step1').show();
        $('#step2').hide();
        $('#step3').hide();
        $('#step4').hide();

    });
    $('#itinary').click(function () {
        $('#step1').hide();
        $('#step2').show();
        $('#step3').hide();
        $('#step4').hide();

    });
    $('#post').click(function () {
        $('#step1').hide();
        $('#step2').hide();
        $('#step3').show();
        $('#step4').hide();

    });
    $('#attachment').click(function () {
        $('#step1').hide();
        $('#step2').hide();
        $('#step3').hide();
        $('#step4').show();
    });

    // events for main tabs, View all/draft/create new

    $('#hdnMainTabValue').val('Main');

    $('#linkTab1').click(function () {
        $('#lnkExport').show();
        $('#hdnMainTabValue').val('Main');
    });
    $('#linkTab2').click(function () {
        $('#lnkExport').show();
        $('#hdnMainTabValue').val('Draft');
    });
    $('#linkTab3').click(function () {
        $('#lnkExport').hide();
    });

    
}


function TravelChangeDDl() {

    $('.requesterIds input').attr("disabled", "disabled");
    $('.travellerSection input').attr("disabled", "disabled");

    // Enable these fields as per the discussion

    $("#tbCostCenter").removeAttr("disabled");
    $("#txtOriginCity").removeAttr("disabled");
    $("#txtdestCity").removeAttr("disabled");
    

    var ddlvalue = $('#ddlPurpose option:selected').text();
    $('#hdntravelPurpose').val(ddlvalue);

    var valueSelected = $('#ddlPurpose option:selected').val();

    SetPurposeDDLValues(valueSelected);

    $('#ddlPurpose').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        SetPurposeDDLValues(valueSelected);

        var text = optionSelected.text();
        $('#hdntravelPurpose').val(text);     
      
    });  
}

function SetPurposeDDLValues(valueSelected)
{
    if (valueSelected !== "0") {
        $("#tbPlannedStartDate").removeAttr("disabled");
        $("#tbPlannedEndDate").removeAttr("disabled");
        $("#txtTravellerName").removeAttr("disabled");
    }
    else {
        $("#tbPlannedStartDate").attr("disabled", "disabled");
        $("#tbPlannedEndDate").attr("disabled", "disabled");
        $("#txtTravellerName").attr("disabled", "disabled");
    }
}

function PostTrvDisableControls()
{
    var currRequestStatus = $('#hdnRequestStatus').val();

    if (currRequestStatus === "Draft") {

        $('.postTravelform  input[type=text]').attr("disabled", "disabled");
        $('.postTravelform select').attr("disabled", "disabled");
        $('.postTravelform textarea').attr("disabled", "disabled");
        $('.btnDisClass').hide(); // hiding button apprive reject       
        $('.postDispatch textarea').attr("disabled", "disabled");
        $("#btnSubmitTraveller").attr("style", "display:none");  //traveller button

        $("#tbCostCenter").removeAttr("disabled");      

           
    }
    else
        $(".totalexpense").hide();
    
}

function SetHiddenCtrlFromDDL()
{  
    $('#ddlOriginCountry').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnOriginCountry').val(text);
    });
    $('#ddlDestination').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnDestinationCountry').val(text);
    });

    $('#ddlDepartureAirport').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnAirDestLocation').val(text);
    });
    $('#ddlReturnAirport').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnAirArrLocation').val(text);
    });

    $('#ddlIterneryCountry1').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnFlighDestCountry').val(text);
    });

    $('#ddlIterneryCountry2').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnFlighArrCountry').val(text);
    });

    $('#ddDepartureServiceType').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnDeptClass').val(text);
    });
    $('#ddlReturnServiceType').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnArrClass').val(text);
    });

    $('#ddlHotelCountry').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnHotelCountry').val(text);
    });

    $('#ddlBookedBy').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        var text = optionSelected.text();
        $('#hdnhotelBookedBy').val(text);
    });

    $('.JustBox').hide();
    $('#ddlHotelRateMDR').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        if (valueSelected == "Yes")
            $('.JustBox').show();
        else
            $('.JustBox').hide();

    }); 
   
    
}

function EnableBoxes(value) {
    $('#loading').show();
    if (value === "Boxfalse") {
        $('.travellerSection input').removeAttr("disabled");
        $('.requestor input').removeAttr("disabled");
    }
    else {
        $('.travellerSection input').attr("disabled", "disabled");
        $('.requestor input').attr("disabled", "disabled");
    }

}


function DisabledControls(tabName) {   

    var value = $('#hdnButtonEnable').val();

    if (tabName === "Main") {
        var role = $('#currentUserRole').val();
        $('.formContent input').attr("disabled", "disabled");
        $('.formContent select').attr("disabled", "disabled");
        $('.formContent textarea').attr("disabled", "disabled");
        $(".tripType input").attr('disabled', 'disabled');
        $('.formContent input[type=submit]').removeAttr("disabled");
        $('.formContent input[type=submit]').css("display", "none");
        $('.formContent input[type=button]').css("display", "none");
        $('#btnRequestCancel').show();
        $('#btnAdd').hide();
        $('#fileUpload').attr("disabled", "disabled");
        $(".totalexpense").hide();

        if (value === "TravellerEnable") {
            $('.postTravel input').removeAttr("disabled");
            $('.postTravel select').removeAttr("disabled");
            $('#btnSubmitTraveller').css("display", "block");
            $('#btnSubmitTraveller').removeAttr("disabled");
            $("#btnSubmitTraveller").attr('style', 'background:#85c446');
            $('#fileUpload').removeAttr("disabled");
            $('#btnUpload').removeAttr("disabled");
            $('#btnRequestCancel').hide();
            $('#btnAdd').show();        
            $('#travelerComments').removeAttr("disabled");
            
        }

        if (value === "DispatchEnable") {
            $('.postDispatch input').removeAttr("disabled");
            $('.postDispatch select').removeAttr("disabled");
            $('#btnDispatchSubmit').css("display", "block");
            $('#btnDispatchSubmit').removeAttr("disabled");
            $("#btnDispatchSubmit").attr('style', 'background:#85c446');
            $('#btnRevertDispatch').css("display", "block");
            $('#btnRevertDispatch').removeAttr("disabled");
            $("#btnRevertDispatch").attr('style', 'background:#85c446');
            $('#fileUpload').removeAttr("disabled");
            $('#btnAdd').removeAttr("disabled");
            $('#btnUpload').removeAttr("disabled");
            $('.btnDisClass').show();
            $('#btnRequestCancel').hide();
            $('#btnAdd').show();
            $('#dispatchComments').removeAttr("disabled");

        }

     
    }
    else {
        PostTrvDisableControls();
    }
    

    var value = $('#hdnfileUpload').val();
    if (value)
        $('#btnUpload').show();          // $('#btnUpload').attr('style', 'background:##85c446');
    else
        $('#btnUpload').hide();         // $('#btnUpload').attr('style', 'background:#d3d3d3');

    var currRequestStatus = $('#hdnRequestStatus').val();
    var currentUserRole = $('#currentUserRole').val();
    if ((currRequestStatus == "Request Submitted" || currRequestStatus == "Draft") && currentUserRole =="Dispatch")   // Hiding request cancel button
        $('#btnRequestCancel').show();
    else
        $('#btnRequestCancel').hide();

}


function TripTypwRadioBtn() {
    var value = $(".tripType input:checked").val();

    if (value == "Round Trip") {
        $("#tbReturnFare").attr("disabled", "disabled");
        $("#ddlReturnServiceType").attr("disabled", "disabled");
        $("#tbReturnFare").val("0");
        $("#ddlReturnServiceType").val('0');
    }
    //else {
    //    $("#tbReturnFare").removeAttr("disabled");
    //    $("#ddlReturnServiceType").removeAttr("disabled");
    //}
    if (value == "None") {
        flightCtrlDisabled();
    }
    if (value == "One way") {
        flightCtrlEnabled();
    }

    $(".tripType").change(function () {

        value = $(this).text();
        if (value == "Round Trip") {
            flightCtrlEnabled();
            $("#tbReturnFare").attr("disabled", "disabled");
            $("#ddlReturnServiceType").attr("disabled", "disabled");
            $("#tbReturnFare").val("0");
            $("#ddlReturnServiceType").val('0');
        }

        if (value == "None") {
            flightCtrlDisabled();
        }
        if (value == "One way") {
            flightCtrlEnabled();
        }      

    });
}

function flightCtrlEnabled(){
    $(".FlightDetails").removeAttr("disabled");
    $('.FlightDetails input[type=text]').removeAttr("disabled");
    $('.FlightDetails input[type=number]').removeAttr("disabled");
    $('.FlightDetails select').removeAttr("disabled");
}

function flightCtrlDisabled() {
  //  $(".FlightDetails").attr("disabled", "disabled");
    $('.FlightDetails input[type=text]').attr("disabled", "disabled");
    $('.FlightDetails input[type=number]').attr("disabled", "disabled");
    $('.FlightDetails select').attr("disabled", "disabled");
}

function DateDifference()
{
    var start = new Date($('#tbCheckoutDate').val());
    var end = new Date($('#tbCheckinDate').val());
    days = (start - end) / (1000 * 60 * 60 * 24);
    $('#tbNoOfNights').val(days);
}

function HotelDetailsByTraveller()
{
    var valueSelected = $('#ddlHotelstayed').val();
    if (valueSelected === "No") {
        $("#hotelByTravel1").show();
        $("#hotelByTravel2").show();
    }
    else {
        $("#hotelByTravel1").hide();
        $("#hotelByTravel2").hide();
    }


    $('#ddlHotelstayed').on('change', function (e) {
        var optionSelected = $("option:selected", this);
        valueSelected = this.value;
        if(valueSelected === "No"){
            $("#hotelByTravel1").show();
            $("#hotelByTravel2").show();
        }
        else{
            $("#hotelByTravel1").hide();
            $("#hotelByTravel2").hide();
        }

    });    
}

function CompareDates1(startDate, endDate, obj) {

    if (startDate >= endDate) {
        obj.value = "";
        alert("Please choose a later date");
        return false;
    }
    else if (startDate < endDate) {

        return true;
    }
    return false;
}

function SubmitFormValidation(value)
{
   
    var txtPlanner = $('#txtPlanner').val();
    var txtTravellerName = $('#txtTravellerName').val();
    var ddlOriginCountry = $('#ddlOriginCountry').val();
    var ddlDestination = $('#ddlDestination').val();
    var txtOriginCity = $('#txtOriginCity').val();
    var txtdestCity = $('#txtdestCity').val();

    var tbPlannedStartDate = $('#tbPlannedStartDate').val();
    var tbPlannedEndDate = $('#tbPlannedEndDate').val();

    var tbDepartureDate = $('#tbDepartureDate').val();
    var tbReturnDate = $('#tbReturnDate').val();

    var hotelName = $('#tbHotelName').val();
    var hotelCity = $('#txtHotelCity').val();
    var hotelCountry = $('#ddlHotelCountry').val();
    var hotelBookedBy = $('#ddlBookedBy').val();
    var hotelChkIn = $('#tbCheckinDate').val();
    var hotelChkOut = $('#tbCheckoutDate').val();
    var NoOfNgt = $('#tbNoOfNights').val();
    var hotelRate = $('#tbRoomRate').val();
    var hotelMdr = $('#txtMdr').val();
    var hotelIfMDRAbv = $('#ddlHotelRateMDR').val();
    var mdrJust = $('#tbMDRJustification').val();
    var totalexpense = $('#tbEstTravelSpend').val();
    
    
    var tripType = $(".tripType input:checked").val();

    if (txtPlanner == "" || txtTravellerName == "" || ddlOriginCountry == "0" || ddlDestination == "0" || txtOriginCity == "" || txtdestCity == "" || tbPlannedStartDate == "" || tbPlannedEndDate == "" || totalexpense == "") {
        alert("Please enter all required details values.");
        $("#loading").hide();
        return false;      
    }
    
    if (tripType == "One way" || tripType == "Round Trip")
    {
        if(tbDepartureDate == "" || tbReturnDate == "" )
        {
            alert("Please enter flight details values.");
            $("#loading").hide();
            return false;
        }
    }

    if (hotelName == "" || hotelCity == "" || hotelChkIn == "" || hotelChkOut == "" || hotelBookedBy == "0" || hotelCountry == "0" || NoOfNgt == "" || hotelRate == "0" || hotelMdr == "0" || hotelIfMDRAbv == "0" ) {
        alert("Please enter all required Hotel details values.");
        $("#loading").hide();
        return false;
       
    }

    if (hotelIfMDRAbv == "Yes") {
        if (mdrJust == "") {
            alert("Please enter justification.");
            $("#loading").hide();
            return false;
        }
     
    }

    EnableBoxes(value);
}

function TravellerSectionValidation()
{
    $("#loading").show();
    var actualStartdt = $('#txtActualStartDate').val();
    var actualEnddt = $('#txtActualEndDate').val();
    var isReportApp = $('#ddlExpRptSubAprd').val();
    var reportKey = $('#txtReportKey').val();
    var ifBookedByDispatch = $('#ddlHotelstayed').val();

    if (actualStartdt == "" || actualEnddt == "" || isReportApp == "0" || ifBookedByDispatch == "0") {
        alert("Please enter all required details.");
        $("#loading").hide();
        return false;
    }
    else {
        if (ifBookedByDispatch == 'No') {
            var hotelName = $('#txthotelNamebyTrav').val();
            var hotelCity = $('#txtHotelCityByTrav').val();
            var hotelCountry = $('#ddlHotelCountryTrav').val();
            var bookedBy = $('#ddlHtlBkByTrav').val();
            var chkindt = $('#txtCheckinDateTrav').val();
            var chkoutdt = $('#txtChkOutByTrav').val();
            var hotelRate = $('#txtRmrateByTrav').val();

            if (hotelName == "" || hotelCity == "" || chkindt == "" || chkoutdt == "" || hotelRate == "" || hotelCountry == "0" || bookedBy == "0") {
                alert("Please enter all required details.");
                $("#loading").hide();
                return false;
            }
        }
    }

    
}


function DispatchPostValidation() {

    $("#loading").show();
    var disComments = $('#dispatchComments').val();
    if (disComments == "") {
        alert("Please enter comments.");
        $("#loading").hide();
        return false;
    }
}
