﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    public class TIFClass
    {
        public string Trip_Number { get; set; }
        public string Request_Status { get; set; }
        public string Requestor_Name { get; set; }
        public string Requestor_Id { get; set; }
        public string Planner_Name { get; set; }
        public string Planner_Id { get; set; }
        public string Travel_Purpose { get; set; }
        public string Tr_Opportunity_Numbers { get; set; }
        public string Traveller_Name { get; set; }
        public string Traveller_Id { get; set; }
        public string Traveller_Email { get; set; }
        public string Traveller_Phone { get; set; }
        public string Traveller_Home_Location { get; set; }
        public string Traveller_BU { get; set; }
        public string Traveller_FirstManager { get; set; }
        public string Traveller_SecondManager { get; set; }
        public string Planned_Start_Date { get; set; }
        public string Planned_End_Date { get; set; }
        public string Traveller_FirstManager_Email { get; set; }
        public string Traveller_SecondManager_Email { get; set; }
        public string Traveller_Origin_Country { get; set; }
        public string Traveller_Destination_Country { get; set; }
        public string Traveller_Origin_City { get; set; }
        public string Traveller_Destination_City { get; set; }
        public string Cost_Center { get; set; }      
        public string Traveller_Travel_Objective { get; set; }
        public string TripType { get; set; }
        public string Flight_Departure_Date { get; set; }
        public string Flight_Arrival_Date { get; set; }
        public string Dept_Airport_Location { get; set; }
        public string Arr_Airport_Location { get; set; }
        public string Flight_Dep_Country { get; set; }
        public string Flight_Arr_Country { get; set; }
        public string Flight_Dep_City { get; set; }
        public string Flight_Arr_City { get; set; }
        public string Dep_Fare { get; set; }
        public string Arr_Fare { get; set; }
        public string Dep_ServiceClass { get; set; }
        public string Arr_ServiceClass { get; set; }
        
        public string Hotel_Name { get; set; }
        public string Hotel_City { get; set; }
        public string Hotel_Country { get; set; }
        public string Hotel_BookedBy { get; set; }
        public string Hotel_CheckInDate { get; set; }
        public string Hotel_CheckoutDate { get; set; }
        public string No_of_Night_Booked { get; set; }
        public string Room_Rate { get; set; }
        public string MDR { get; set; }
        public string IsHotelRateAboveMDR { get; set; }
        public string PerDiem { get; set; }
        public string Hotel_MdR_Desc { get; set; }
        public string Estimated_Travel_Expense { get; set; }
        public Int32  VersionsRowId { get; set; }
        public string CreatedDate { get; set; }      
        public string CreatedBy { get; set; }
        public string ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
     
        
    }
      public class PostTravellerClass
      {
          public string RequestNo { get; set; }
          public string RequestStatus { get; set; }
          public string Actual_StartDate { get; set; }
          public string Actual_EndDate { get; set; }
          public string ExpenseReportSubmitted { get; set; }
          public string Report_Key_Number { get; set; }
          public string TravellerComments { get; set; }
          public string IsHotelBookedByDispatch { get; set; }
          public string TravellerHotelName { get; set; }
          public string TravellerHotelCity { get; set; }
          public string TravellerHotelCountry { get; set; }
          public string TravellerHotelBkBy { get; set; }
          public string TravellerHotelChkInDt { get; set; }
          public string TravellerHotelChkOutDt { get; set; }
          public string TravellerHotelRate { get; set; }
          public string ModifiedDate { get; set; }
          public string ModifiedBy { get; set; }
         

      }

      public class ManagerClass
      {
          public string RequestNo { get; set; }
          public string RequestStatus { get; set; }
          public string DispatchComments { get; set; }
          public string ApproveDate { get; set; }
          public string ModifiedDate { get; set; }
          public string ModifiedBy { get; set; }
      }


    public class UserProperty
    {
     
        public string UserName { get; set; }
        public string Email { get; set; }
        public string EmpId { get; set; }
    }

    public class Traveller
    {
        public string TravellerName { get; set; }
        public string RowId { get; set; }
    }

    public class Files
    {
        public string Sn_No { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string Created_By { get; set; }
        public string Created_Date { get; set; }
    }
    

}
