﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    public class TIFClass
    {
        public string Trip_Number { get; set; }
        public string Requestor_Name { get; set; }
        public string Requestor_Id { get; set; }
        public string Planner_Name { get; set; }
        public string Planner_Id { get; set; }
        public string Traveller_Name { get; set; }
        public string Traveller_Id { get; set; }
        public string Traveller_Email { get; set; }
        public string Traveller_Phone { get; set; }
        public string Traveller_Home_Location { get; set; }
        public string Traveller_BU { get; set; }
        public string Traveller_FirstManager { get; set; }
        public string Traveller_SecondManager { get; set; }
        public string Traveller_FirstManager_Email { get; set; }
        public string Traveller_SecondManager_Email { get; set; }
        public string Cost_Center { get; set; }
        public string Travel_Purpose { get; set; }
        public string Tr_Opportunity_Numbers { get; set; }
        public string Traveller_Travel_Objective { get; set; }
        public DateTime Planned_Start_Date { get; set; }
        public DateTime Planned_End_Date { get; set; }
        public string Origin { get; set; }
        public string Destination { get; set; }
        public DateTime Departure_Date { get; set; }
        public string Dept_Airport_Location { get; set; }
        public Int64 Dep_Fare { get; set; }
        public string Oneday_Roundtrip { get; set; }
        public string Dep_ServiceClass { get; set; }
        public DateTime Return_Date { get; set; }
        public string Return_Airport_Location { get; set; }
        public Int64 Return_Fare { get; set; }
        public string Return_ServiceClass { get; set; }
        public string Hotel_Name { get; set; }
        public int No_of_Night_Booked { get; set; }
        public DateTime Hotel_CheckInDate { get; set; }
        public DateTime Hotel_CheckoutDate { get; set; }
        public int Room_Rate { get; set; }
        public int Hotel_Rate_MDR { get; set; }
        public string Rental_Car_Company { get; set; }
        public string Car_Company_Address { get; set; }
        public DateTime Car_Rental_StartDate { get; set; }
        public DateTime Car_Rental_EndDate { get; set; }
        public int Car_Rent_PerDay { get; set; }
        public int Estimated_Travel_Expense { get; set; }
        public DateTime Actual_StartDate { get; set; }
        public DateTime Actual_EndDate { get; set; }
        public string Post_Opportunity_Number { get; set; }
        public string Report_Key_Number { get; set; }
        public string FilesNames_Submitted { get; set; }
        public string PM_Decision { get; set; }
        public string PM_Justification { get; set; }
        public string Dispatcher_Decision { get; set; }
        public string Request_Status { get; set; }
        public string Hotel_Address { get; set; }
        public string Hotel_Country { get; set; }
        public string MDR_Justification { get; set; }
        public int Expense_Report_Submitted_Approved { get; set; }
        public int Expense_Rpt_Approved_PM { get; set; }
        public int Exceeded_Est_Tr_Spend { get; set; }
        public string Justification { get; set; }
    }
}
