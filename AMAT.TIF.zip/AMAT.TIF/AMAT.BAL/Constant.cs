﻿using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    public static class Constants
    {
        public enum EXCEPTION_LOGTYPE
        {
            ERROR = 0,
            DEBUG = 1,
            INFO = 2
        };

        public static string CONNECTIONSTRING_iTeams = "DBConnString";
        public const string ErrorLogList = "ErrorLogList";
        public const string CountryList = "CountryList";
        public const string TIF_Documents = "TIF_Documents";
        public const string TIF_Configuration = "TIF_Configuration";
        public const string LocationCity = "Location";
        public const string PerDiemList = "PerDiemMapping";
        public const string EmailConfiguration = "EmailConfiguration";
        public const string TIFRoleConfiguration = "TIFRoleConfiguration";
        

        public const string Travel_Type = "Travel_Type";
        public const string ProcedureForVersionTB = "[SaveDataFromDispatchTeam]";
        public const string ProcedureFormainTB = "[SaveDataFromDispatchTeamMainTb]";
        public const string SubmitProcedureFormainTB = "[SubmitDataFromDispatchTeam]";
        public const string RevertRequestProcedure = "[RevertRequest]";


        
        
        public const string MainRequestType = "Main";
        public const string DraftRequestType = "Draft";

        public const string BIM_SupportFormUserMail = "BIM-Support-GLOBAL-F@amat.com";
      
        #region roles
        public const string User = "User";
        public const string Requestor = "Requestor";
    

        public const string TravellerGroup = "AGS_TIF_Traveller";   
        public const string DispatchTeamGroup = "AGS_TIF_Dispatch_Team";

        public const string TravellerGp = "Traveler";
        public const string DispatchTeamGp = "Dispatch";
        public const string InBothRole = "Dispatch,Traveler";


       //Request Status
        public const string RequestAsDraft = "Draft";
        public const string Requestsubimtted= "Request Submitted";
        public const string RequestPendingWithTraveller = "Pending With Traveler";
        public const string RequestRevertedToTraveller = "Reverted to Traveler";
      
        public const string RequestPendingWithDispatch = "Pending With Dispatch";
        public const string RequestCompleted = "Completed";
        public const string RequestCancelled = "Cancelled";

        public const string RequestApproved = "Approved";
        public const string RequestRejected = "Approved";

        //Email action

        public const string SubmitByDispatch = "SubmitByDispatch";
        public const string SubmitByTraveller = "SubmitByTraveler";
        public const string RevertToTraveller = "RevertToTraveler";
        public const string RequestCompletedAction = "RequestCompleted";
        public const string RequestCancelledAction = "RequestCancelled";

      
        #endregion


        /// <summary>
        /// for logging the errors in list
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="errorMessage"></param>
        /// <param name="stackTrace"></param>
        /// <param name="source"></param>
        /// <param name="method"></param>
        /// <param name="pageName"></param>
        public static void ErrorLog(ClientContext clientContext, string errorMessage, string source, string method, string pageName)        {

            List logList = clientContext.Web.Lists.GetByTitle(Constants.ErrorLogList);
            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
            ListItem item = logList.AddItem(itemCreateInfo);
            item["Message"] = errorMessage;
            item["Source"] = source;
            item["Method"] = method;
            item["PageName"] = pageName;
            item.Update();
            clientContext.ExecuteQuery();

        }

        static byte[] bytes = ASCIIEncoding.ASCII.GetBytes("ZeroCool");
        public static string Encrypt(string originalString)
        {
         
            if (String.IsNullOrEmpty(originalString))
            {
                throw new ArgumentNullException
                       ("The string which needs to be encrypted can not be null.");
            }
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream,cryptoProvider.CreateEncryptor(bytes, bytes), CryptoStreamMode.Write);
            StreamWriter writer = new StreamWriter(cryptoStream);
            writer.Write(originalString);
            writer.Flush();
            cryptoStream.FlushFinalBlock();
            writer.Flush();
            return Convert.ToBase64String(memoryStream.GetBuffer(), 0, (int)memoryStream.Length);
        }

        /// <summary>
        /// Decrypt a crypted string.
        /// </summary>
        /// <param name="cryptedString">The crypted string.</param>
        /// <returns>The decrypted string.</returns>
        /// <exception cref="ArgumentNullException">This exception will be thrown when the crypted string is null or empty.</exception>
        public static string Decrypt(string cryptedString)
        {
            if (String.IsNullOrEmpty(cryptedString))
            {
                throw new ArgumentNullException("The string which needs to be decrypted can not be null.");
            }

            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(cryptedString));
            CryptoStream cryptoStream = new CryptoStream(memoryStream, cryptoProvider.CreateDecryptor(bytes, bytes), CryptoStreamMode.Read);
            StreamReader reader = new StreamReader(cryptoStream);

            return reader.ReadToEnd();
        }

    }
}
