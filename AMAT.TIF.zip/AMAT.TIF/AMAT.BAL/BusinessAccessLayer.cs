﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.DAL;
using Microsoft.SharePoint.Client;

namespace AMAT.BAL
{
    public class BusinessAccessLayer
    { 
        

        // first time saving data to both table, version and main table based on request id is exists or not 
        public void SaveByPreDispatch(TIFClass objTIF, string existingRequestNo)
        {
            DataAccesslayer da = new DataAccesslayer();

            string[] procedureArray = new string[2] { Constants.ProcedureForVersionTB, Constants.ProcedureFormainTB };

            if (string.IsNullOrEmpty(existingRequestNo)) //saving data to version table first time
            {
                foreach (string str in procedureArray)
                {                   
                    da.SaveByPreDispatchTeam(str, objTIF.Trip_Number, objTIF.Request_Status, objTIF.Requestor_Name,
                    objTIF.Requestor_Id, objTIF.Planner_Name, objTIF.Planner_Id, objTIF.Traveller_Name, objTIF.Traveller_Id, objTIF.Traveller_Email, objTIF.Traveller_Phone, objTIF.Traveller_Home_Location, objTIF.Traveller_BU,
                    objTIF.Traveller_FirstManager, objTIF.Traveller_SecondManager, objTIF.Planned_Start_Date, objTIF.Planned_End_Date,
                    objTIF.Traveller_Origin_Country, objTIF.Traveller_Destination_Country, objTIF.Traveller_Origin_City, objTIF.Traveller_Destination_City,
                    objTIF.Cost_Center, objTIF.Travel_Purpose, objTIF.Tr_Opportunity_Numbers, objTIF.Traveller_Travel_Objective,
                    objTIF.Flight_Departure_Date, objTIF.Flight_Arrival_Date,objTIF.Flight_Dep_Country, objTIF.Flight_Arr_Country, objTIF.Flight_Dep_City, objTIF.Flight_Arr_City,
                    objTIF.Dep_Fare, objTIF.Arr_Fare, objTIF.Dep_ServiceClass, objTIF.Arr_ServiceClass, objTIF.Hotel_Name,
                    objTIF.Hotel_City, objTIF.Hotel_Country, objTIF.Hotel_BookedBy, objTIF.Hotel_CheckInDate, objTIF.Hotel_CheckoutDate,
                    objTIF.No_of_Night_Booked, objTIF.Room_Rate, objTIF.MDR,objTIF.IsHotelRateAboveMDR, objTIF.Hotel_MdR_Desc,
                    objTIF.PerDiem, objTIF.Estimated_Travel_Expense, objTIF.CreatedDate, objTIF.ModifiedDate, objTIF.CreatedBy, objTIF.ModifiedBy, objTIF.TripType
                    );
                    
                }
            }
            else
            {
                // if request id available then, need to update main table and insert into version table

                da.SaveByPreDispatchTeam(Constants.ProcedureForVersionTB, objTIF.Trip_Number, objTIF.Request_Status, objTIF.Requestor_Name,
                objTIF.Requestor_Id, objTIF.Planner_Name, objTIF.Planner_Id, objTIF.Traveller_Name, objTIF.Traveller_Id, objTIF.Traveller_Email, objTIF.Traveller_Phone, objTIF.Traveller_Home_Location, objTIF.Traveller_BU,
                objTIF.Traveller_FirstManager, objTIF.Traveller_SecondManager, objTIF.Planned_Start_Date, objTIF.Planned_End_Date,
                objTIF.Traveller_Origin_Country, objTIF.Traveller_Destination_Country, objTIF.Traveller_Origin_City, objTIF.Traveller_Destination_City,
                objTIF.Cost_Center, objTIF.Travel_Purpose, objTIF.Tr_Opportunity_Numbers, objTIF.Traveller_Travel_Objective,
                objTIF.Flight_Departure_Date, objTIF.Flight_Arrival_Date,objTIF.Flight_Dep_Country, objTIF.Flight_Arr_Country, objTIF.Flight_Dep_City, objTIF.Flight_Arr_City,
                objTIF.Dep_Fare, objTIF.Arr_Fare, objTIF.Dep_ServiceClass, objTIF.Arr_ServiceClass, objTIF.Hotel_Name,
                objTIF.Hotel_City, objTIF.Hotel_Country, objTIF.Hotel_BookedBy, objTIF.Hotel_CheckInDate, objTIF.Hotel_CheckoutDate,
                objTIF.No_of_Night_Booked, objTIF.Room_Rate, objTIF.MDR, objTIF.IsHotelRateAboveMDR, objTIF.Hotel_MdR_Desc,
                objTIF.PerDiem, objTIF.Estimated_Travel_Expense, objTIF.CreatedDate, objTIF.ModifiedDate, objTIF.CreatedBy, objTIF.ModifiedBy,objTIF.TripType
                );

                //update to main table
                SubmitByPreDispatch(objTIF, Constants.DraftRequestType);
            }
           
        }


        /// <summary>
        /// Submit data to main table
        /// </summary>
        /// <param name="objTIF"></param>
        /// <param name="existingRequestNo"></param>
        public void SubmitByPreDispatch(TIFClass objTIF, string IsDraftOrMain)
        {
            DataAccesslayer da = new DataAccesslayer();

            da.SubmitByDispatch(Constants.SubmitProcedureFormainTB, objTIF.Trip_Number, objTIF.Request_Status, objTIF.Requestor_Name,
                 objTIF.Requestor_Id, objTIF.Planner_Name, objTIF.Planner_Id, objTIF.Traveller_Name, objTIF.Traveller_Id, objTIF.Traveller_Email, objTIF.Traveller_Phone, objTIF.Traveller_Home_Location, objTIF.Traveller_BU,
                 objTIF.Traveller_FirstManager, objTIF.Traveller_SecondManager, objTIF.Planned_Start_Date, objTIF.Planned_End_Date,
                 objTIF.Traveller_Origin_Country, objTIF.Traveller_Destination_Country, objTIF.Traveller_Origin_City, objTIF.Traveller_Destination_City,
                 objTIF.Cost_Center, objTIF.Travel_Purpose, objTIF.Tr_Opportunity_Numbers, objTIF.Traveller_Travel_Objective,
                 objTIF.Flight_Departure_Date, objTIF.Flight_Arrival_Date, objTIF.Flight_Dep_Country, objTIF.Flight_Arr_Country, objTIF.Flight_Dep_City, objTIF.Flight_Arr_City,
                 objTIF.Dep_Fare, objTIF.Arr_Fare, objTIF.Dep_ServiceClass, objTIF.Arr_ServiceClass, objTIF.Hotel_Name,
                 objTIF.Hotel_City, objTIF.Hotel_Country, objTIF.Hotel_BookedBy, objTIF.Hotel_CheckInDate, objTIF.Hotel_CheckoutDate,
                 objTIF.No_of_Night_Booked, objTIF.Room_Rate, objTIF.MDR, objTIF.IsHotelRateAboveMDR, objTIF.Hotel_MdR_Desc,
                 objTIF.PerDiem, objTIF.Estimated_Travel_Expense,objTIF.ModifiedDate, objTIF.ModifiedBy, IsDraftOrMain,objTIF.TripType);

        }

        public string GetRequestNo()
        {
            DataAccesslayer da = new DataAccesslayer();
            string requestNo = da.GetRequestNo();
            return requestNo;
        }

        /// <summary>
        /// Submitting data to main table
        /// </summary>
        /// <param name="objTIF"></param>
        /// <returns></returns>
        //public string SaveDataFromDispatch(TIFClass objTIF)
        //{
        //    string requestID = string.Empty;
        //    DataAccesslayer obj = new DataAccesslayer();
        //    obj.SubmitByPreDispatchTeam();
        //    return requestID;
        //}

        /// <summary>
        /// Return all trip data from DB
        /// </summary>
        /// <param name="requestNo"></param>
        /// <returns></returns>
        public DataTable GetAllSubmittedRequests(string userName, string userRole)
        {
            DataTable dt = new DataTable();
            DataAccesslayer obj = new DataAccesslayer();
            dt = obj.GetAllSubmittedRequests(userName, userRole);
            return dt;
        }

        /// <summary>
        /// get All draft request
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllDraftRequest()
        {
            DataTable dt = new DataTable();
            DataAccesslayer obj = new DataAccesslayer();
            dt = obj.GetAllDraftRequest();
            return dt;
        }

        /// <summary>
        /// Return all trip version data from DB
        /// </summary>
        /// <param name="requestNo"></param>
        /// <returns></returns>
        public DataTable GetDatabyRequestNo(string id,string tabName)
        {
            DataTable dt = new DataTable();
            DataAccesslayer obj = new DataAccesslayer();
            dt = obj.GetDataByRequestNo(id, tabName);
            return dt;
        }

        /// <summary>
        /// Get all Traveller details based on Oppo no.
        /// </summary>
        /// <param name="OppoNo"></param>
        /// <returns></returns>
        public DataTable GetDetailByOpportunityNo(string OppoNo)
        {
            DataTable dt = new DataTable();
            DataAccesslayer obj = new DataAccesslayer();
            dt = obj.GetDetailByOpportunityNo(OppoNo);
            dt.Columns.Add("Id", typeof(Int32)).SetOrdinal(0);

            for (int i = 0; i <dt.Rows.Count; i++)
                dt.Rows[i]["Id"] = i;

            return dt;

        }

        /// <summary>
        /// Get travellor by oppo no
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public List<Traveller> GetTravellerName(DataTable dt)
        {
            List<Traveller> trvList = new List<Traveller>();
            foreach(DataRow row in dt.Rows)
            {
                Traveller trvlr = new Traveller();
                trvlr.TravellerName = Convert.ToString(row["TravelerName"]);
                trvlr.RowId = Convert.ToString(row["Id"]);
                trvList.Add(trvlr);
            }
            return trvList;
        }

        public List<TIFClass> GetTravllerDetails(DataTable dt, string filterValue)
        {
            List<TIFClass> trvList = new List<TIFClass>();
            if (dt != null && !string.IsNullOrEmpty(filterValue))
            {
                DataRow row = dt.Select("Id=" + filterValue + "").FirstOrDefault();

                if (row != null)
                {
                    TIFClass trvlr = new TIFClass();
                    trvlr.Traveller_Name = Convert.ToString(row["TravelerName"]);
                    trvlr.Traveller_Id = Convert.ToString(row["TravelerID"]);
                    trvlr.Traveller_Email = Convert.ToString(row["TravelerEmailID"]);
                    trvlr.Traveller_Phone = Convert.ToString(row["TravelerPhoneNumber"]);
                    trvlr.Traveller_Home_Location = Convert.ToString(row["HomeLocation"]);
                    trvlr.Traveller_BU = Convert.ToString(row["BusinessUnit"]);
                    trvlr.Traveller_FirstManager = Convert.ToString(row["ResourceManager"]);
                    trvlr.Planned_Start_Date = Convert.ToDateTime(row["PlannedStartDate"]).ToString("MM/dd/yyyy");
                    trvlr.Planned_End_Date = Convert.ToDateTime(row["PlannedEndDate"]).ToString("MM/dd/yyyy"); ;
                    trvlr.Traveller_Home_Location = Convert.ToString(row["HomeLocation"]);
                    trvlr.Traveller_Destination_City = Convert.ToString(row["Destination"]);
                    trvList.Add(trvlr);
                }
            }

            return trvList;
        }
       
        /// <summary>
        /// Get reqyest history on row click
        /// </summary>
        /// <param name="requestNo"></param>
        /// <returns></returns>
        public DataTable GetRequestHistoryByRequestNo(string requestNo)
        {
            DataTable dt = new DataTable();
            DataAccesslayer obj = new DataAccesslayer();
            dt = obj.GetRequestHistoryByRequestNo(requestNo);
            return dt;
        }

        /// <summary>
        /// save post traveller values
        /// </summary>
        /// <param name="requestNo"></param>
        /// <param name="requestStatus"></param>
        /// <param name="actualStartdate"></param>
        /// <param name="actualEnddate"></param>
        /// <param name="reportkeyNo"></param>
        /// <param name="expReportsubmitted"></param>
        public void SubmitByTraveller(PostTravellerClass obj)
        {
           DataAccesslayer da = new DataAccesslayer();
           da.SubmitbyTraveller(obj.RequestNo, obj.RequestStatus, obj.Actual_StartDate, obj.Actual_EndDate, obj.Report_Key_Number, obj.ExpenseReportSubmitted,
               obj.IsHotelBookedByDispatch, obj.TravellerHotelName, obj.TravellerHotelCity, obj.TravellerHotelCountry, obj.TravellerHotelBkBy,
               obj.TravellerHotelChkInDt, obj.TravellerHotelChkOutDt, obj.TravellerHotelRate, obj.TravellerComments);
        }       

        /// <summary>
        /// revert by Manager
        /// </summary>
        /// <param name="objmng"></param>
        public void RevertRequest(ManagerClass objmng)
        {
            DataAccesslayer da = new DataAccesslayer();
            da.RevertRequest(Constants.RevertRequestProcedure, objmng.RequestNo, objmng.RequestStatus, objmng.DispatchComments);
        }

        public void SubmitByPostDispatch(string requestNo, string requestStatus,string disComments, string finalApproveDate)
        {
            DataAccesslayer da = new DataAccesslayer();
            da.SubmitByPostDispatch(requestNo, requestStatus, disComments, finalApproveDate);
        }



        ///// <summary>
        ///// Get current user group
        ///// </summary>
        ///// <param name="userGroups"></param>
        ///// <returns></returns>
        //public String GetCurrentUserGroup(Microsoft.SharePoint.Client.GroupCollection userGroups)
        //{
        //    string isMemberOf = string.Empty;
        //    for (int i = 0; i < userGroups.Count; i++)
        //    {
        //        string currentGrp = userGroups[i].Title;

        //        if (currentGrp == Constants.DispatchTeamGroup)
        //        {
        //            isMemberOf = Constants.DispatchTeamGroup;
        //            break;
        //        }
        //        if (currentGrp == Constants.ManagerGroup)
        //        {
        //            isMemberOf = Constants.ManagerGroup;
        //            break;
        //        }
        //        if (currentGrp == Constants.TravellerGroup)
        //        {
        //            isMemberOf = Constants.DispatchTeamGroup;
        //            break;
        //        }
        //    }
        //    return isMemberOf;
        //}



    }



    
}
