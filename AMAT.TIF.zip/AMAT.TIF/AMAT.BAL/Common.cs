﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    class Common
    {
        
        /// <summary>
        /// Get Email from User list
        /// </summary>
        /// <param name="strUser"></param>
        /// <returns></returns>
        public static string GetUserEmailID(string strUser)
        {
            string strEmailID = string.Empty;
            if (!string.IsNullOrEmpty(strUser) && strUser != "[]")
            {
                string[] stringSeparators = new string[] { "\"Email\":\"" };
                string[] strArray = strUser.Split(stringSeparators, StringSplitOptions.None);
                string[] strUName = strArray[1].Split('"');
                if (strUName.Length > 0)
                {
                    strEmailID = strUName[0];
                }
            }
            return strEmailID;
        }

        /// <summary>
        /// Get Name from User List
        /// </summary>
        /// <param name="strUser"></param>
        /// <returns></returns>
        public static string GetUserName(string strUser)
        {
            string strName = string.Empty;
            if (!string.IsNullOrEmpty(strUser) && strUser != "[]")
            {
                string[] stringSeparators = new string[] { "\"Name\":\"" };
                string[] strArray = strUser.Split(stringSeparators, StringSplitOptions.None);
                string[] strUName = strArray[1].Split('"');
                if (strUName.Length > 0)
                {
                    strName = strUName[0].Replace("&apos;", "'"); ;
                }
            }
            return strName;
        }

        /// <summary>
        /// Get Name from User List
        /// </summary>
        /// <param name="strUser"></param>
        /// <returns></returns>
        public static string GetUserID(string strUser)
        {
            string strName = string.Empty;
            if (!string.IsNullOrEmpty(strUser) && strUser != "[]")
            {
                string[] stringSeparators = new string[] { "\"Login\":\"" };
                string[] strArray = strUser.Split(stringSeparators, StringSplitOptions.None);
                string[] strUName = strArray[1].Split('"');
                if (strUName.Length > 0)
                {
                    strName = strUName[0];
                }
            }
            return strName;
        }

        /// <summary>
        /// Send Mail
        /// </summary>


        /// <summary>
        /// This method Gets Email Subject And Body
        /// </summary>
        public static string[] GetEmailSubAndBody(string keySearch, ClientContext clientContext)
        {
            string[] emailBox = new string[2];


            Microsoft.SharePoint.Client.ListItemCollection listItemCollection = null;
            CamlQuery query = new CamlQuery();

            query.ViewXml = @"<View><Query><Where><Eq><FieldRef Name='EmailType'/><Value Type='Text'>" + keySearch + "</Value></Eq></Where></Query></View>";

            List lstEmail = clientContext.Web.Lists.GetByTitle("EmailTemplate");
            clientContext.Load(lstEmail);
            listItemCollection = lstEmail.GetItems(query);
            clientContext.Load(listItemCollection);
            clientContext.ExecuteQuery();

            if (listItemCollection[0]["Body"] != null)
                emailBox[0] = listItemCollection[0]["Body"].ToString();

            if (listItemCollection[0]["Subject"] != null)
                emailBox[1] = listItemCollection[0]["Subject"].ToString();


            return emailBox;
        }

       
    }
}
