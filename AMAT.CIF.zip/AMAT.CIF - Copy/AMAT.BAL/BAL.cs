
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    public class BLL
    {
        DAL dalObj = new DAL();
        /// <summary>
        /// Gwet All GetAll Equipment No with desc
        /// </summary>
        /// <returns></returns>
        /// 
        public DataTable GetAllEquipmentNo(string numbers)
        {
            DataTable dt = dalObj.GetAllEquipmentNo(numbers);
            return dt;
        }
        public DataTable GetAllEquipmentNoSearch(string numbers)
        {
            DataTable dt = dalObj.GetAllEquipmentNoSearch(numbers);
            return dt;
        }

        public DataTable GetAllCID_ID(string numbers, string valueType)
        {
            DataTable dt = dalObj.GetAllCID_ID(numbers, valueType);
            return dt;
        }

        public DataTable GetSearchResults(string cifId, string toolId, string products, string procName, string viewAll, string region, string bluebook, string greenbook)
        {
            DataTable dt = dalObj.GetSearchResults(cifId, toolId, products, procName, viewAll, region, bluebook, greenbook);
            return dt;
        }
        public DataSet GetCIFDetailBySearch(string CifNumber)
        {
            DataSet ds = dalObj.GetCIFDetailBySearch(CifNumber);
            return ds;
        }
        public DataTable GetMaterialNo(string numbers)
        {
            DataTable dt = dalObj.GetMaterialNo(numbers);
            return dt;
        }
        public DataTable GetContractID(string numbers)
        {
            DataTable dt = dalObj.GetContractId(numbers);
            return dt;
        }

        public DataTable GetFabLocation(string numbers, string valueType)
        {
            DataTable dt = dalObj.GetFabLocation(numbers, valueType);
            return dt;
        }

        public DataTable GetTambaDetails(string tambaNos)
        {
            DataTable dt = dalObj.GetTambaDetails(tambaNos);
            return dt;
        }


        public DataTable GetEquipmentDetailsFromToolSerialNo(string assemblyNo)
        {
            DataTable dt = dalObj.GetEquipmentDetailsFromToolSerialNo(assemblyNo);
            return dt;
        }
        public DataTable GetEquipmentDetailFromToolSerialinUpdatemode(string assemblyNo)
        {
            DataTable dt = dalObj.GetEquipmentDetailFromToolSerialinUpdatemode(assemblyNo);
            return dt;
        }

        /// <summary>
        /// Ger Tamba  no. details
        /// </summary>
        /// <returns></returns>
        public DataTable GetTambNos(string bu, string product)
        {
            DataTable dt = dalObj.GetTambaNos(bu, product, Common.GetTambaProcName);
            return dt;
        }

        public DataTable GetTambaNoMultiSelectProuct(string products)
        {
            DataTable dt = dalObj.GetTambaNoMultiSelectProuct(products);
            return dt;
        }
        public DataTable GetBUDetail()
        {
            DataTable dt = dalObj.GetBUDetail(Common.BUProcName);
            return dt;
        }
        public DataTable GetProductDetail(string bu)
        {
            DataTable dt = dalObj.GetProductDetail(bu, Common.ProductNameWithMultipleBu);
            return dt;
        }
        public DataTable GetAllAmatProduct()
        {
            DataTable dt = dalObj.GetAllAmatProduct();
            return dt;
        }

        public string GetNewCIFId()
        {
            return dalObj.GetNewCIFId();
        }

        /// <summary>
        /// Inserting contract id data
        /// </summary>
        /// <param name="CIF_Id"></param>
        /// <param name="values"></param>
        public void InsertContractIdData(string CIF_Id, string values)
        {
            dalObj.InsertDataInOtherTable(CIF_Id, values, Common.ContractIdProcedure);
        }

        /// <summary>
        ///  Inserting CIF tool id data
        /// </summary>
        /// <param name="CIF_Id"></param>
        /// <param name="values"></param>
        public void InsertToolData(string CIF_Id, string values)
        {
            dalObj.InsertDataInOtherTable(CIF_Id, values, Common.EquipmentToopIdProcedure);
        }

        /// <summary>
        /// Inserting CIF tamba id data
        /// </summary>
        /// <param name="CIF_Id"></param>
        /// <param name="values"></param>
        public void InsertTambaData(string CIF_Id, string values)
        {
            dalObj.InsertDataInOtherTable(CIF_Id, values, Common.TambaIdProcedure);
        }



        /// <summary>
        /// Deleting records
        /// </summary>
        /// <param name="CIF_Id"></param>
        public void DeleteRecord(string CIF_Id)
        {
            dalObj.DeleteRecord(CIF_Id);
        }


        /// <summary>
        /// Inserting tamba ids
        /// </summary>
        /// <param name="CIF_Id"></param>
        /// <param name="supplierType"></param>
        /// <param name="suplierValue"></param>
        public void InsertSupplierData(string CIF_Id, string supplierType, string suplierValue)
        {
            dalObj.InsertSupplierData(CIF_Id, supplierType, suplierValue);
        }

        public void DeleteDatabeforeUpdating(string CIF_Id)
        {
            dalObj.DeleteDatabeforeUpdating(CIF_Id);
        }

        public void UpdateEquipmentPlanned_HCValues(string toolSerialNo, string Planned_SBU_HC, string Planned_FSO_HC, string Planned_FV_HC, string Planned_SPD_HC, string Planned_OCE_HC, string CIF_ID)
        {
            dalObj.UpdateEquipmentPlanned_HCValues(toolSerialNo, Planned_SBU_HC, Planned_FSO_HC, Planned_FV_HC, Planned_SPD_HC, Planned_OCE_HC, CIF_ID);
        }

        public void InsertUpdateCIFData
        (
            string CIF_ID,
            string CIFBenefitsYield,
            string CIFBenifitsOutput,
            string CIFBenifitsCost,
            string FY20CIFStatus,
            string CIFTypeNew,
            string CIFStartDate,
            string CIFActualClosuredate,
            string CIFBudget,
            string FabLocation,
            string ELSNPI,
            string ToolChamberShipped,
            string ToolShipDate,
            string ServiceWin,
            string CoOModelExists,
            string SRRExists,
            string SRRtype,
            string CoOModelNeedDate,
            string FSSatMTC,
            string FSSConAllowCustomer,
            string IsthereDCP,
            string FSSStatus,
            string IsCleanSupplierExists,
            string IsRepairSupplierExists,
            string IsRefurbSupplierExists,
            string IsGPSTSupplierExists,
            string NetworkOfExperts,
            string EmployeeName,
            string currentDate,
            string FSSBasicFeatures,
            string FSSAdvancedFeatures,
            string Dashboards,
            string HandheldMetro,
            string SensorWafers,
            string Cleaningmethod,
            string Coating,
            string Texturing,
            string InspectionMetrology,
            string insertUpdateprocedureName,
            string CIF_ProjectName,
            string DefWinning,
            string SBU_Owner,
            string FSO_Owner,
            string GFG_Owner,
            string BU_Owner,
            string PlannedInventryInvest,
            string ProjectObjective,
            string Status,
            string InternalFundednumber,
            string InternalOrdernumber,
            string cooCommitStatus,
            string toolASP

        )
        {
            dalObj.InsertUpdateCIFData
             (
                             CIF_ID,
                             CIFBenefitsYield,
                             CIFBenifitsOutput,
                             CIFBenifitsCost,
                             FY20CIFStatus,
                             CIFTypeNew,
                             CIFStartDate,
                             CIFActualClosuredate,
                             CIFBudget,
                             FabLocation,
                             ELSNPI,
                             ToolChamberShipped,
                             ToolShipDate,
                             ServiceWin,
                             CoOModelExists,
                             SRRExists,
                             SRRtype,
                             CoOModelNeedDate,
                             FSSatMTC,
                             FSSConAllowCustomer,
                             IsthereDCP,
                             FSSStatus,
                             IsCleanSupplierExists,
                             IsRepairSupplierExists,
                             IsRefurbSupplierExists,
                             IsGPSTSupplierExists,
                             NetworkOfExperts,
                             EmployeeName,
                             currentDate,
                             FSSBasicFeatures,
                             FSSAdvancedFeatures,
                             Dashboards,
                             HandheldMetro,
                             SensorWafers,
                             Cleaningmethod,
                             Coating,
                             Texturing,
                             InspectionMetrology,
                             insertUpdateprocedureName,
                             CIF_ProjectName,
                             DefWinning,
                             SBU_Owner,
                             FSO_Owner,
                             GFG_Owner,
                             BU_Owner,
                             PlannedInventryInvest,
                             ProjectObjective,
                             Status,
                             InternalFundednumber,
                             InternalOrdernumber,
                             cooCommitStatus,
                             toolASP
             );
        }

        //******** new changes feb 2021 **********

        /// <summary>
        /// Adding assenbly info  
        /// </summary>
        /// <param name="CIF_Id"></param>
        /// <param name="assemblyInfo"></param>
        /// <param name="toolInfo"></param>   // Added on feb 2021
        public void InsertAssemblyInfo(string CIF_Id, string assemblyInfo, string toolInfo)
        {
            dalObj.InsertAssemblyInfo(CIF_Id, assemblyInfo, toolInfo);
        }

        // get all books
        public DataSet GetAllBooks(string empId)
        {
            DataSet ds = dalObj.GetAllBooks(empId);           
            return ds;
        }
       
        public DataTable GetIOnumberByIFPnumber(string ifpnumber)
        {
            DataTable dt = dalObj.GetIOnumberByIFPnumber(ifpnumber);
            return dt;
        }
        public DataTable GetInternalFundednumber()
        {
            DataTable dt = dalObj.GetInternalFundednumber();
            return dt;
        }

        //**************** New Security Implementation As par the RAM DB *****************

        //Get RAM URL
        public string RAMURL
        {
            get
            {
                return this.dalObj.RAMUrl;
            }
            set
            {
                this.dalObj.RAMUrl = value;
            }
        }

        // Get all PGB for an employee
        public DataTable GetPBGforEmplpyee(string employeeId)
        {
            return dalObj.GetPBGforEmplpyee(employeeId);
        }

        // Get all Customers for an employee from RAM DB
        public DataTable GetCustomersByEmployeeId(string employeeId)
        {
            return dalObj.GetCustomersByEmployeeId(employeeId);
        }
        public DataTable CheckIfUserExistsInRAM(string employeeId)
        {
            return dalObj.IsUserExistsInRAMDB(employeeId);
        }


       
    }   
}
