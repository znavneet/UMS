using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    public class DAL
    {
        string connection = ConfigurationManager.ConnectionStrings["DBConnString"].ConnectionString;
        string RAMconnection = ConfigurationManager.ConnectionStrings["RAMDBConnString"].ConnectionString;
        public string RAMUrl = Convert.ToString(ConfigurationManager.AppSettings["RAMUrl"]);

        public string APIUrl = Convert.ToString(ConfigurationManager.AppSettings["APIUrl"]);
        
        public DataTable GetAllEquipmentNo(string numbers)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetEquipmentNo", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@values", numbers);
                     SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }
        public DataTable GetAllEquipmentNoSearch(string numbers)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetEquipmentNoSearch", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@values", numbers);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetAllCID_ID(string numbers, string valueType)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("[GetCIF_ID]", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@values", numbers);
                    cmd.Parameters.AddWithValue("@valueType", valueType);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// getting search details by clicking on cif id
        /// </summary>
        /// <param name="CifNumbers"></param>
        /// <returns></returns>
        public DataSet GetCIFDetailBySearch(string CifNumbers)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetCIFDetailBySearch", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@values", CifNumbers);                
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(ds);
                }
            }
            return ds;
        }

        public DataTable GetSearchResults(string cifId, string toolId, string products, string procedureName, string viewAll, string region, string bluebook, string greenbook)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(procedureName, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@cifId", cifId);
                    cmd.Parameters.AddWithValue("@toolId", toolId);
                    cmd.Parameters.AddWithValue("@product", products);
                    cmd.Parameters.AddWithValue("@region", region);
                    cmd.Parameters.AddWithValue("@bluebook", bluebook);
                    cmd.Parameters.AddWithValue("@greenbook", greenbook);
                    cmd.Parameters.AddWithValue("@viewAll", viewAll);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetMaterialNo(string numbers)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetMaterialNo", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 300;
                    cmd.Parameters.AddWithValue("@values", numbers);                  
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetContractId(string numbers)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetContractID", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@values", numbers);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetFabLocation(string numbers, string valueType)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetFabLocation", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@values", numbers);
                    cmd.Parameters.AddWithValue("@valueType", valueType);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetAllAmatProduct()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetAllAMATProducts", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetTambaDetails(string tambaNo)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetAllTambaDetail", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@tambaNo", tambaNo);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetTambaNoMultiSelectProuct(string products)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand("GetTambaNosOnMultiselectProduct", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@products", products);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetTambaNos(string bu, string product, string procedureName)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand(procedureName, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@bu", bu);
                cmd.Parameters.AddWithValue("@product", product);
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetProductDetail(string bu, string procedureName)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand(procedureName, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@bu", bu);
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetBUDetail(string procedureName)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand(procedureName, con);
                cmd.CommandType = CommandType.StoredProcedure;
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    sda.Fill(dt);
                }
            }
            return dt;
        }
    
        /// <summary>
        /// Generating new CIFID
        /// </summary>
        /// <returns></returns>
        public string GetNewCIFId()
        {
            DataTable dt = new DataTable();
            string CIF_Id = string.Empty;
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("GetNewCIF_ID", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                CIF_Id = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            return CIF_Id;
        }

        public DataTable GetEquipmentDetailsFromToolSerialNo(string assemblyNo)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("GetEquipmentDetailFromToolSerialNo", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@assemblyNo", assemblyNo);
               // cmd.Parameters.AddWithValue("@toolDesc", toolDesc);
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        public DataTable GetEquipmentDetailFromToolSerialinUpdatemode(string assemblyNo)
        {
            DataTable dt = new DataTable();
            DataTable newDt = new DataTable();
            string[] assemblyNos = assemblyNo.Split(',');
            for (int i = 0; i < assemblyNos.Length; i++)
            {
                string assemNo = assemblyNos[i];
                if (!string.IsNullOrEmpty(assemNo))
                {
                    using (SqlConnection con = new SqlConnection(connection))
                    {
                        SqlCommand cmd = new SqlCommand("GetEquipmentDetailFromToolSerialNo", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@assemblyNo", assemNo);
                        // cmd.Parameters.AddWithValue("@toolDesc", toolDesc);
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                  
                }
            }
            return dt;
        }
       

        public void DeleteRecord(string id)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("DeleteRecord", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        public void InsertSupplierData(string CIF_Id, string supplierType, string suplierValue)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("[InsertSupplierData]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CIF_ID", CIF_Id);
                cmd.Parameters.AddWithValue("@supplierType", supplierType);
                cmd.Parameters.AddWithValue("@suplierValue", suplierValue);             

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        public void DeleteDatabeforeUpdating(string CIF_Id)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("DeleteRowsBeforeUpdatingData", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CIF_ID", CIF_Id);            
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        /// <summary>
        ///  insert data in contract, equipment and tamba
        /// </summary>
        /// <param name="CIF_Id"></param>
        /// <param name="values"></param>
        /// <param name="procedureName"></param>
        public void InsertDataInOtherTable(string CIF_Id, string values, string procedureName)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand(procedureName, con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CIF_ID", CIF_Id);
                cmd.Parameters.AddWithValue("@values", values);
          
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }


        /// <summary>
        /// Updating equipment dynamic table
        /// </summary>
        /// <param name="CIF_Id"></param>
        /// <param name="Planned_SBU_HC"></param>
        /// <param name="Planned_FSO_HC"></param>
        /// <param name="Planned_FV_HC"></param>
        /// <param name="Planned_SPD_HC"></param>
        /// <param name="Planned_OCE_HC"></param>
        public void UpdateEquipmentPlanned_HCValues(string toolSerialNo, string Planned_SBU_HC, string Planned_FSO_HC, string Planned_FV_HC, string Planned_SPD_HC, string Planned_OCE_HC, string CIF_ID)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("UpdateEquipmentPlanned_HCNo", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@toolSerialNo", toolSerialNo);
                cmd.Parameters.AddWithValue("@Planned_SBU_HC", Planned_SBU_HC);
                cmd.Parameters.AddWithValue("@Planned_FSO_HC", Planned_FSO_HC);
                cmd.Parameters.AddWithValue("@Planned_FV_HC", Planned_FV_HC);
                cmd.Parameters.AddWithValue("@Planned_SPD_HC", Planned_SPD_HC);
                cmd.Parameters.AddWithValue("@Planned_OCE_HC", Planned_OCE_HC);
                cmd.Parameters.AddWithValue("@CIF_ID", CIF_ID);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        
        public void InsertUpdateCIFData(
            string CIF_ID,
            string CIFBenefitsYield,
            string CIFBenifitsOutput,
            string CIFBenifitsCost,
            string FY20CIFStatus,
            string CIFTypeNew,
            string CIFStartDate,
            string CIFActualClosuredate,
            string CIFBudget,
            string FabLocation,
            string ELSNPI,
            string ToolChamberShipped,
            string ToolShipDate,
            string ServiceWin,
            string CoOModelExists,
            string SRRExists,
            string SRRtype,
            string CoOModelNeedDate,
            string FSSatMTC,
            string FSSConAllowCustomer,
            string IsthereDCP,
            string FSSStatus,           
            string IsCleanSupplierExists,
            string IsRepairSupplierExists,
            string IsRefurbSupplierExists,
            string IsGPSTSupplierExists,
            string NetworkOfExperts,
            string EmployeeName,
            string currentDate,
            string FSSBasicFeatures,
            string FSSAdvancedFeatures,
            string Dashboards,
            string HandheldMetro,
            string SensorWafers,
            string Cleaningmethod,
            string Coating,
            string Texturing,
            string InspectionMetrology,
            string insertUpdateprocedureName,
            string CIF_ProjectName,
            string DefWinning,
            string SBU_Owner,
            string FSO_Owner,
            string GFG_Owner,
            string BU_Owner,
            string PlannedInventryInvest,
            string ProjectObjective,
            string Status,
            string InternalFundednumber,
            string InternalOrdernumber,
            string cooCommitStatus,
            string toolASP
            )
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand(insertUpdateprocedureName, con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CIF_ID", CIF_ID);
                cmd.Parameters.AddWithValue("@CIFBenefitsYield", CIFBenefitsYield);
                cmd.Parameters.AddWithValue("@CIFBenifitsOutput", CIFBenifitsOutput);
                cmd.Parameters.AddWithValue("@CIFBenifitsCost", CIFBenifitsCost);
                cmd.Parameters.AddWithValue("@FY20CIFStatus", FY20CIFStatus);
                cmd.Parameters.AddWithValue("@CIFTypeNew", CIFTypeNew);

                if (string.IsNullOrEmpty(CIFStartDate))
                    cmd.Parameters.AddWithValue("@CIFStartDate", null);
                else
                    cmd.Parameters.AddWithValue("@CIFStartDate", CIFStartDate);

                if (string.IsNullOrEmpty(CIFActualClosuredate))
                    cmd.Parameters.AddWithValue("@CIFActualClosuredate", null);
                else
                    cmd.Parameters.AddWithValue("@CIFActualClosuredate", CIFActualClosuredate);

                cmd.Parameters.AddWithValue("@CIFBudget", CIFBudget);
                cmd.Parameters.AddWithValue("@FabLocation", FabLocation);
                cmd.Parameters.AddWithValue("@ELSNPI", ELSNPI);
                cmd.Parameters.AddWithValue("@ToolChamberShipped", ToolChamberShipped);

                if (string.IsNullOrEmpty(ToolShipDate))
                    cmd.Parameters.AddWithValue("@ToolShipDate", null);
                else
                    cmd.Parameters.AddWithValue("@ToolShipDate", ToolShipDate);

                cmd.Parameters.AddWithValue("@ServiceWin", ServiceWin);
                cmd.Parameters.AddWithValue("@CoOModelExists", CoOModelExists);
                cmd.Parameters.AddWithValue("@SRRExists", SRRExists);
                cmd.Parameters.AddWithValue("@SRRtype", SRRtype);

                if (string.IsNullOrEmpty(CoOModelNeedDate))
                    cmd.Parameters.AddWithValue("@CoOModelNeedDate", null);
                else
                    cmd.Parameters.AddWithValue("@CoOModelNeedDate", CoOModelNeedDate);
                cmd.Parameters.AddWithValue("@FSSatMTC", FSSatMTC);
                cmd.Parameters.AddWithValue("@FSSConAllowCustomer", FSSConAllowCustomer);
                cmd.Parameters.AddWithValue("@IsthereDCP", IsthereDCP);
                cmd.Parameters.AddWithValue("@FSSStatus", FSSStatus);
                cmd.Parameters.AddWithValue("@IsCleanSupplierExists", IsCleanSupplierExists);
                cmd.Parameters.AddWithValue("@IsRepairSupplierExists", IsRepairSupplierExists);
                cmd.Parameters.AddWithValue("@IsRefurbSupplierExists", IsRefurbSupplierExists);
                cmd.Parameters.AddWithValue("@IsGPSTSupplierExists", IsGPSTSupplierExists);
                cmd.Parameters.AddWithValue("@NetworkOfExperts", NetworkOfExperts);
                cmd.Parameters.AddWithValue("@EmployeeName", EmployeeName);
                cmd.Parameters.AddWithValue("@currentDate", currentDate);
                cmd.Parameters.AddWithValue("@FSSBasicFeatures", FSSBasicFeatures);
                cmd.Parameters.AddWithValue("@FSSAdvancedFeatures", FSSAdvancedFeatures);
                cmd.Parameters.AddWithValue("@Dashboards", Dashboards);
                cmd.Parameters.AddWithValue("@HandheldMetro", HandheldMetro);
                cmd.Parameters.AddWithValue("@SensorWafers", SensorWafers);
                cmd.Parameters.AddWithValue("@Cleaningmethod", Cleaningmethod);
                cmd.Parameters.AddWithValue("@Coating", Coating);
                cmd.Parameters.AddWithValue("@Texturing", Texturing);
                cmd.Parameters.AddWithValue("@InspectionMetrology", InspectionMetrology);

                cmd.Parameters.AddWithValue("@CIF_ProjectName", CIF_ProjectName);
                cmd.Parameters.AddWithValue("@DefWinning ", DefWinning);
                cmd.Parameters.AddWithValue("@SBU_Owner", SBU_Owner);
                cmd.Parameters.AddWithValue("@FSO_Owner", FSO_Owner);
                cmd.Parameters.AddWithValue("@GFG_Owner", GFG_Owner);
                cmd.Parameters.AddWithValue("@BU_Owner", BU_Owner);
                cmd.Parameters.AddWithValue("@PlannedInventryInvest", PlannedInventryInvest);
                cmd.Parameters.AddWithValue("@ProjectObjective", ProjectObjective);
                cmd.Parameters.AddWithValue("@Status", Status);
                cmd.Parameters.AddWithValue("@InternalFundednumber", InternalFundednumber);
                cmd.Parameters.AddWithValue("@InternalOrdernumber", InternalOrdernumber);

                cmd.Parameters.AddWithValue("@CoO_Commit_Status", cooCommitStatus);
                cmd.Parameters.AddWithValue("@Tool_ASP", toolASP);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }


        // *************************  New changes Feb 2021*********************************************

        /// <summary>
        /// Adding assembly info // added in feb 2021
        /// </summary>
        /// <param name="CIF_Id"></param>
        /// <param name="assemblyInfo"></param>
        /// <param name="toolInfo"></param>
        public void InsertAssemblyInfo(string CIF_Id, string assemblyInfo, string toolInfo)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand(Common.InsertAssemblyInfo, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@cifId", CIF_Id);
                cmd.Parameters.AddWithValue("@assemblyNo", assemblyInfo);
               // cmd.Parameters.AddWithValue("@toolNo", toolInfo);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        //get All books (black,blue and green book) in single procedure with position in dataset at 0,1,3 at respective book
        public DataSet GetAllBooks(string empId)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(RAMconnection))
            {
                using (SqlCommand cmd = new SqlCommand(Common.GetAllbooksByEmployeeIdProc, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@employeeId", empId);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(ds);
                }
            }
            return ds;
        }

        /// <summary>
        /// Get Internal order number by IFP number
        /// </summary>
        /// <param name="IFPnumbers"></param>
        /// <param name="procName"></param>
        /// <returns></returns>
        public DataTable GetIOnumberByIFPnumber(string IFPnumbers)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(Common.GetIOnumberByIFPnumber, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;                 
                    cmd.Parameters.AddWithValue("@ifpNo", IFPnumbers);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }
        /// <summary>
        /// Get IFP number
        /// </summary>
        /// <param name="IFPnumbers"></param>
        /// <returns></returns>
        public DataTable GetInternalFundednumber()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(Common.GetInternalFundedOrderNumber, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;              
                    cmd.CommandTimeout = 300;         
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }


        //**************** New Security Implementation As par the RAM DB *****************

        public DataTable IsUserExistsInRAMDB(string employeeId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(RAMconnection))
            {
                using (SqlCommand cmd = new SqlCommand(Common.CheckUserExistInRAM, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@employeeId", employeeId);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        // Get all PBG for an employee from RAM DB
        public DataTable GetPBGforEmplpyee(string employeeId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(RAMconnection))
            {
                using (SqlCommand cmd = new SqlCommand(Common.GetPBGByEmployeeId, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@employeeId", employeeId);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

        // Get all Customers for an employee from RAM DB
        public DataTable GetCustomersByEmployeeId(string employeeId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(RAMconnection))
            {
                using (SqlCommand cmd = new SqlCommand(Common.GetCustomersByEmployeeId, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@employeeId", employeeId);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                }
            }
            return dt;
        }

    }     
}
