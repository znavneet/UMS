using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.BAL
{
    public class Common
    {
        public const string DigitalTool = "Digital Tools";
        public const string SurfaceTechnology = "Surface Technology";
        public const string DashboardList = "DashboardList";
        public const string SecurityList = "CIF_SecurityList";
        public const string ImportantLinks = "Important_Links";

        public const string CleanSupplier = "CleanSupplier";
        public const string RepairSupplier = "RepairSupplier";
        public const string RefurbSupplier = "RefurbSupplier";
        public const string GPSTSupplier = "GPSTSupplier";
        public const string Others = "Others";
        public const string ContractIdProcedure = "InsertContractId";
        public const string EquipmentToopIdProcedure = "InsertEquipmentNo";
        public const string TambaIdProcedure = "InsertTambaNo";

        public const string UpdateSupplierData = "UpdateSupplierData";
       // public const string UpdateContractData = "UpdateContractId";
        public const string UpdateToolData = "UpdateEquipmentNo";
        public const string UpdateTambaData = "UpdateTambaNo";
      

        public const string BUProcName = "GetAllBU";
        public const string ProductProcName = "GetProduct";
        public const string ProductNameWithMultipleBu = "GetProductOnMultiselectBU";
        public const string GetTambaProcName = "GetTambaDetail";

        //public const string ProcWith_SBU_FSO_Security = "GetSearchResultWithSecurity";
     //  public const string ProcGetAllResult = "GetAllSearchResult";
        public const string ProcGetAllResult = "GetAllSearchResult1";
        //public const string ProcViewAllResults = "GetViewAllSearchResult";


        public const string InsertAssemblyInfo = "InsertAssemblyInfo";
        public const string InsertCIFData = "InsertCIFData";
        public const string UpdateCIFData = "UpdateCIFData";

        public const string CIFEngineers = "CIF-Engineers";
        public const string SBURole = "SBU";
        public const string FSORole = "FSO";
        public const string BURole = "BU";
        public const string All = "All";



        public const string GetIOnumberByIFPnumber = "GetIOnumberByIFPnumber";
        public const string GetInternalFundedOrderNumber = "GetInternalFundedOrderNumber";       

        public const string GetRegionProc = "GetRegions";
        public const string GetBluebookProc = "GetBluebook";
        public const string GetGreenbookProc = "GetGreenbook";


        //*********** New procedure details **********
        public const string GetAllbooksByEmployeeIdProc = "USP_GetAllbooksByEmployeeId";
        public const string GetPBGByEmployeeId = "USP_GetPBGByEmployeeId";
        public const string GetCustomersByEmployeeId = "USP_GetCustomersByEmployeeId";
        public const string CheckUserExistInRAM = "USP_CheckRAMProfileForUser";

        //*********** API URLs **********
        public const string GetCustomers = "/apps/GetCustomersByEmployeeId/";
        public const string GetAllBooks = "/apps/GetAllbooksByEmployeeId/";
        public const string CheckRAMProfile = "/apps/CheckRAMProfileForUser/";
        public const string GetPBG = "/apps/GetPBGByEmployeeId/";


        /// <summary>
        /// Get ids from comma separated values 
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public static string GetIDfromString(string values)
        {
            string fnVal = string.Empty;
            if (!string.IsNullOrEmpty(values))
            {
                string[] fnValArr = values.Split(',');
                foreach (string str in fnValArr)
                {
                    fnVal += str.Split(':')[0] + ',';
                }
                fnVal = fnVal.Remove(fnVal.Length - 1);
            }
            return fnVal;
        }
        public static string GetAssemblyString(string values)
        {
            string fnVal = string.Empty; string val=string.Empty;
            if (!string.IsNullOrEmpty(values))
            {
                string[] assemblyString = values.Split('|');

                foreach (string str in assemblyString)
                {
                    if (!string.IsNullOrEmpty(str))
                    {
                        if (str.IndexOf(',') == 0)
                            val = str.Remove(0, 1);
                        else
                            val = str;

                        fnVal += val.Split(':')[0] + '|';
                    }
                }
                fnVal = fnVal.Remove(fnVal.Length - 1);
            }
            return fnVal;
        }
        public static string GetToolString(string values)
        {
            string fnVal = string.Empty;
            if (!string.IsNullOrEmpty(values))
            {
                string[] toolString = values.Split('|');

                foreach (string str in toolString)
                {
                    if (!string.IsNullOrEmpty(str))
                        fnVal += str.Split(':')[1] + ',';
                }
                fnVal = fnVal.Remove(fnVal.Length - 1);
            }
            return fnVal;
        }
    }
    public class TambaDetails
    {
        public string TAMBA_ID { get; set; }
        public string BusinessUnit { get; set; }
        public string AmatProduct { get; set; }
        public string TAMBAStatus { get; set; }
        public string PTORDate { get; set; }
        public string ManagedAccount { get; set; }
    }
    public class EquipmentsIDs
    {
        public string Equipment_ID { get; set; }
        public string EquipmentDesc { get; set; }
    }
    public class DashboardName
    {
        public string Name { get; set; }
        public string URL { get; set; }
    }
    public class UserProperty
    {
        public string Email { get; set; }
        public string EmpId { get; set; }
        public string UserName { get; set; }
    }
    public class EquipmentDetails    {

        public string MajorAssembly { get; set; }  
        public string SerialNo { get; set; }   
        public string Customer { get; set; }
        public string Fab { get; set; }
        public string PBG { get; set; }
        public string KPU { get; set; }
        public string Region { get; set; }
        public string ToolShipDate { get; set; }
        public string Contract { get; set; }
        public string Platform { get; set; }
      
    }

    public class InternalOrder
    {
        public string IFPNumber { get; set; }
        public string IONumber { get; set; }   
    }

}
