﻿
$(document).ready(function () {
   
   // ToolAutoCompleteSearch();
  //  GetInternalOrderNo();
});


function GetToolSearhResults(data)
{
    $.each(data, function (val, text) {
        if (text)
            $('#ddlToolSearchResult').append($('<option></option>').val(val).html(text))
    });

  //  CreateSearchResultDropdown();
}

//function CreateSearchResultDropdown()
//{
//    $("#ddlToolSearchResult").attr("multiple", "multiple");
//    $('#ddlToolSearchResult').multiselect({
//        includeSelectAllOption: false,
//        enableFiltering: true,
//        enableCaseInsensitiveFiltering: true,
//        maxHeight: 200,
//        buttonWidth: '220px',
//        onChange: function (option, checked) {
//           // var value = $('#ddlToolSearchResult').val().toString();
//            // $("#hdnFSSBasicFeatures").val(value);
//        }
//    });
//    $("#ddlToolSearchResult").multiselect('clearSelection');
//}


function GetInternalOrderNo() {
    $('#txtInternalOrder').autocomplete({
        minLength: 3,
        source: function (request, response) {
            $('#loadingInternalOrder').show();
            $.ajax({
                url: 'CIF-Form.aspx/GetInterOrderFieldsData',
                data: "{ 'values': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        return {
                            value: item
                        }
                    }))
                    $('#loadingInternalOrder').hide();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loadingInternalOrder').hide();
                    alert("Not Available.");
                }
            });
        }
    });
}
    

    //var internalOrder = $('#hdnInternalOrder').val();
    //if (internalOrder != "") {
    //    $('#txtInternalOrder').tokenfield('setTokens', internalOrder);
    //}







