﻿

jQuery(document).ready(function () {
    $('#ddlProduct').next().attr('style', 'width:253px');

    $('#txtCIF_Id').tokenfield({
        autocomplete: {
            minLength: 3,
            source: function (request, response) {
                $('#loadingCIFID').show();
                $.ajax({
                    url: 'Search.aspx/GetCIF_IDs',
                    data: "{ 'values': '" + request.term + "' }",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    dataFilter: function (data) { return data; },
                    success: function (data) {
                        response($.map(data.d, function (item) {
                            return {
                                value: item
                            }
                        }))
                        $('#loadingCIFID').hide();
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $('#loadingCIFID').hide();
                        alert("Not Available.");

                    }
                });
            }
        }
    });
    $('#txtTool_ID').tokenfield({
        autocomplete: {
            minLength: 3,
            source: function (request, response) {
                $('#loadingToolID').show();
                $.ajax({
                    url: 'Search.aspx/GetEquipmentNumbersOnSearch',
                    data: "{ 'values': '" + request.term + "' }",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    dataFilter: function (data) { return data; },
                    success: function (data) {
                        response($.map(data.d, function (item) {
                            return {
                                value: item
                            }
                        }))
                        $('#loadingToolID').hide();
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $('#loadingToolID').hide();
                        alert("Not Available.");

                    }
                });
            }
        }
    });

    $("#ddlProduct").attr("multiple", "multiple");
    $('#ddlProduct').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var value = $('#ddlProduct').val().toString();
            $("#hdnProducts").val(value);
        }

    });
    $("#ddlProduct").multiselect('clearSelection');
    $('.multiselect-clear-filter').css('display', 'none');
    $('.multiselect-search').css('width', '97%');
});
function loading() {
    $('#loading').show();
}
