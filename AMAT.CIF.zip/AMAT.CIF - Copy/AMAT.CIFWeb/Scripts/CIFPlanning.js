﻿
// for tokenfields implementation help:  http://sliptree.github.io/bootstrap-tokenfield/#examples

var cols = ["Tool Serial", "Customer", "Planned SBU HC", "Planned FSO HC", "Planned FV HC", "Planned BSA/TEE HC", "Planned OCE HC"];
var colShorts = ["Cust", "Tool", "SBU", "FSO", "FV", "SPD", "OCE"];
var equipmentCols = ["Tool Serial", "Platform", "Customer", "Region", "Fab", "PBG", "KPU", "Ship Date", "Contract"];
var toolSerial = []; var customer = []; var equipmentDetail = []; // ["Micron", "Samsung"]; 

    $(document).ready(function () {    

        $('#txtCIFToolId').tokenfield({
            autocomplete: {
                minLength: 3,
                source: function (request, response) {
                    $('#loadingCIF').show();
                    $.ajax({
                        url: 'CIF-Form.aspx/GetEquipmentNumbers',
                        data: "{ 'values': '" + request.term + "' }",
                        dataType: "json",
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataFilter: function (data) { return data; },
                        success: function (data) {
                            response($.map(data.d, function (item) {
                                return {
                                    value: item
                                }
                            }))
                            $('#loadingCIF').hide();
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $('#loadingCIF').hide();
                            alert("Not Available.");

                        }
                    });
                }
            }
        });


   
    // function, trigger when adding new tool no.
    $('#txtCIFToolId').on('tokenfield:createtoken', function (e) {

        // var serial = e.attrs.value.split(':')[0];  var serial = e.attrs.value.split(':')[0];
        // var serialDesc = e.attrs.value.split(':')[1];
        var serial = e.attrs.value.split('-')[0];
        var serialDesc = e.attrs.value.substring(e.attrs.value.indexOf('-') + 1);
       
        //  setTimeout(function () { GetCustomerNameFromToolSerialNo(value); }, 1000);     

        var toolId = $('#hdnCIFToolID').val();   // check for update mode, when no data saved first time for planning grid, then need to create the fresh grid for planning
          
        if ($("#hdnUpdateMode").val() == "UpdateMode" && toolId != "") {
            setTimeout(function () { GetEquipmentFromToolSerialNoUpdateMode(serial, serialDesc); }, 1000);          
        }
        else {   
            toolSerial.push(serial);
            GetEquipmentFromToolSerialNo(serial, serialDesc);    // for new new CIF creation mode
        }
       
    });

    // function, trigger when removing the added tool no.
    $('#txtCIFToolId').on('tokenfield:removedtoken', function (e) {
       // var id = e.attrs.value.split(':')[0];
        var id = e.attrs.value.split('-')[0];
        $("#" + id).parent().remove();
        $("#tool" + id).parent().remove();

        var index = toolSerial.indexOf(id);   // getting customer array index for removing the value from array, just like in toolserial array.
        var custId = customer[index];

        // removing tool from array
        toolSerial = $.grep(toolSerial, function (value) {
            return value != id;
        });

        // removing customer from customer array
        customer = $.grep(customer, function (value) {
            return value != custId;
        });

        // removing equipment obj from equipment object array
         equipmentDetail = $.grep(equipmentDetail, function (v) {
             return v.SerialNo != id;
        });

        if (toolSerial.length == 0) {
            $('#tableDiv').html("");
            $('#toolDetailtableDiv').html("");
        }

    })

    // function for binding dynamic planned values in updat mode
    if ($("#hdnUpdateMode").val() == "UpdateMode") {
        GetDynamicTableOnUpdate();
    }

    
});

function GetDynamicTableOnUpdate() {
    var toolId = $('#hdnCIFToolID').val();
    var customerName = $('#hdnCustomerName').val();

    if (toolId != "") {
        if (toolId)
            toolSerial = GetIdsOnly(toolId);
        if (customerName)
            customer = customerName.split(',')
        CreateDynamicTable(customer, toolSerial);
        BindPlannedInputValuesOnUpdateMode();
        $('#txtCIFToolId').tokenfield('setTokens', toolId);
        $("#hdnUpdateMode").val('');
    }
    
}



function BindPlannedInputValuesOnUpdateMode() {
    var plannedValues = $('#hdnUpdateModePlannedValues').val().split('|');
    for (var i = 1; i < plannedValues.length; i++) {
        var colValues = plannedValues[i-1].split(':');
        if (colValues.length > 0) {
            var serialTable = $('#inputTable tr').eq(i).children().eq(0).text();
            var hdnSerial = plannedValues[i-1].split(':')[0];
            if (GetForToolEntry(serialTable, hdnSerial, plannedValues)) {
                if (arrIndex != "")
                    colValues = plannedValues[arrIndex].split(':');

                for (var j = 2, k = 0; j < 7, k < colValues.length; j++, k++) {
                    var ids = (i).toString() + j.toString();
                    $('#txt_' + ids).val(colValues[k+1]);
                    console.log(ids + "--" + colValues[k]);
                }
            }
        }
    }
}

function GetEquipmentFromToolSerialNo(serialNo, serialDesc) {
    var toolserialNo = "";
    var dataObj = { values: serialNo, toolDesc: serialDesc };
    dataObj = JSON.stringify(dataObj);

    $.ajax({
        url: 'CIF-Form.aspx/GetEquipmentDetailfromToolSerialNo',
        //data: "{ 'values': '" + serialNo + "' }",
        data:dataObj,
        dataType: "json",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            console.log(data.d);          
            $('#toolDetailtableDiv').html("");
           
            for (var i = 0; i < data.d.length; i++) {

                var newObj = {
                    SerialNo: data.d[i].SerialNo,
                    Platform: data.d[i].Platform,
                    Customer: data.d[i].Customer,
                    Region: data.d[i].Region,
                    Fab: data.d[i].Fab,
                    PBG: data.d[i].PBG,
                    KPU: data.d[i].KPU,
                    ToolShipDate: data.d[i].ToolShipDate,
                    Contract: data.d[i].Contract
                };
                equipmentDetail.push(newObj);
                customer.push(data.d[i].Customer);
            }
            CreateEquipmentDetailsTable(equipmentDetail);
            $('#tableDiv').html("");
            CreateDynamicTable(customer, toolSerial);
            if ($('#hdnCIFToolID').val() != "") {
                BindPlannedInputValuesOnUpdateMode();
            }
           
        },
        error: function (error) {
            var msg = "Please try typing the tool serial no. or description!";
            alert(msg);
        }
    });
}

function GetArrayFromObjectArray(equipmentDetailArray) {
    var objArary = [];
   // for (var i = 0; i < equipmentDetailArray.length; i++)
    {
        objArary.push(equipmentDetailArray.SerialNo);
        objArary.push(equipmentDetailArray.Platform);
        objArary.push(equipmentDetailArray.Customer);      
        objArary.push(equipmentDetailArray.Region);
        objArary.push(equipmentDetailArray.Fab);
        objArary.push(equipmentDetailArray.PBG);
        objArary.push(equipmentDetailArray.KPU);
        objArary.push(equipmentDetailArray.ToolShipDate.split(" ")[0]);
        objArary.push(equipmentDetailArray.Contract);
               
    }
    return objArary;
}

function CreateEquipmentDetailsTable(equipmentDetail)
{
    $('#toolDetailtableDiv').val('');
     
    var table_body = "<table id='euipmentTable' class='dynamicTb'><tbody><tr>";

    for (var i = 0; i < equipmentCols.length; i++) {
        table_body += "<th width='110px' class='dynamicTbTD'>" + equipmentCols[i] + "</th>";
    }
    
    table_body += "</tr>";  

    for (var i = 0; i < equipmentDetail.length; i++) {
        table_body += "<tr>";

        var arrayNew = GetArrayFromObjectArray(equipmentDetail[i]);

        for (var j = 0; j < arrayNew.length; j++) {
            if (j == 0) {
                table_body += "<td width='120px' class='dynamicTbTD' id='tool" + arrayNew[j] + "'>";
            }
            else
                table_body += "<td  width='120px' class='dynamicTbTD'>";

            table_body += arrayNew[j];
            table_body += "</td>";
        }      
        table_body += "</tr>";
        objArary = [];
    }
    table_body += '</table>';
    $('#toolDetailtableDiv').html(table_body);
}

function GetEquipmentFromToolSerialNoUpdateMode(serialNo, serialDesc) {
    var toolserialNo = "";
    var dataObj = { values: serialNo, toolDesc: serialDesc };
    dataObj = JSON.stringify(dataObj);
    $.ajax({
        url: 'CIF-Form.aspx/GetEquipmentDetailfromToolSerialNo',
        //data: "{ 'values': '" + serialNo + "' }",
        data: dataObj,
        dataType: "json",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            console.log(data.d);
            $('#toolDetailtableDiv').html("");

            for (var i = 0; i < data.d.length; i++) {

                var newObj = {
                    SerialNo: data.d[i].SerialNo,
                    Platform: data.d[i].Platform,
                    Customer: data.d[i].Customer,
                    Region: data.d[i].Region,
                    Fab: data.d[i].Fab,
                    PBG: data.d[i].PBG,
                    KPU: data.d[i].KPU,
                    ToolShipDate: data.d[i].ToolShipDate,
                    Contract: data.d[i].Contract
                };
                equipmentDetail.push(newObj);               
            }
            CreateEquipmentDetailsTable(equipmentDetail);

        },
        error: function (error) {
            var msg = "Please try typing the tool serial no. or description!";
            alert(msg);
        }

    });

}

function CreateDynamicTable(customer, toolSerial)
{
    var table_body = "<table id='inputTable' class='dynamicTb'><tbody><tr>";

    for (var i = 0; i < cols.length; i++)    
        table_body += "<th class='dynamicTbTD'>" + cols[i] + "</th>";
    
    table_body += "</tr>";

    for (var i = 0; i < toolSerial.length; i++) {
        table_body += "<tr>";
        for (var j = 0; j < cols.length; j++) {
         
            if (j == 0 || j == 1) {
                if (j == 1) {
                    table_body += "<td class='dynamicTbTD'>";
                    if (customer[i])
                        table_body += customer[i];
                }
                if (j == 0) {
                    table_body += "<td class='dynamicTbTD' id='" + toolSerial[i] + "'>";
                    table_body += toolSerial[i];
                }
            }
            else {
                table_body += "<td class='dynamicTbTD'><input id=txt_" + (i+1).toString()+j.toString() + "  type='text' class='form-control' placeholder='' spellcheck='false' onkeypress='return isNumberKey(event)'/>";
               // table_body += colsValue[j];
            }

            table_body += "</td>";
        }
        table_body += "</tr>";
    }
    table_body += '</table>';
    $('#tableDiv').html(table_body);
}

var arrIndex = "";
function GetForToolEntry(serialTable, hdnSerial, plannedValues)
{
    arrIndex = "";
    var newArr = []; 
    for (var i = 0; i < plannedValues.length; i++)
        newArr.push(plannedValues[i].split(':')[0]);
    
    if (serialTable == hdnSerial)
        return true;    
    else if (newArr.indexOf(serialTable) > -1) {
        arrIndex = newArr.indexOf(serialTable);
        return true;
    }
    else
        return false;
}

function FieldsValidation(sender) {
    var isvalid = true;
    var cifType = $("#ddlCIFType").val();
    var startDate = $("#txtCIFStartDate").val();
    var actualDate = $("#txtActCloseDate").val();
    var cifStatus = $("#ddlCIFStatus").prop('selectedIndex');

    if (cifType === "Select" || startDate === "" || actualDate === "" || cifStatus === 0) {
        alert("Please fill the mandatory fields *.");
        isvalid = false;
    }
    if (sender == "update"){   // logic for update button only
        RemoveQueryString();
    }
    if (isvalid) {
        GetInputValues();  //getting input values from planned 5 box in a string 
    }

    return isvalid;
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        alert("Please enter the numbers only");
        $("#txtBudget").val("");
        return false;
    }
    return true;
}

function ResetCheck() {
    var qryString = window.location.href.indexOf('ID');
    var IsPowerUser = $('#hdnIsPowerUser').val();
    var frameURL = window.location.href.split('&ID')[0];

    if (qryString > -1 && IsPowerUser != "") {

        var retVal = confirm("Do you want discard your changes ?");
        if (retVal == true) {
            $('#form1').attr('action', frameURL);
            function preventBack() { window.history.forward(); }
            setTimeout("preventBack()", 0);
            window.onunload = function () { null };
            return true;
        } else {
            return false;
        }
    }
}

function RemoveQueryString() {
    var qryString = window.location.href.indexOf('ID');
    if (qryString > -1) {
        var frameURL = window.location.href.split('&ID')[0];
        // $('#form1').attr('action', frameURL);
    }
}

/// get values from input box for dymanic generating  2box
var txtValues = "";
function GetInputValues() {
    txtValues = "";
    if (toolSerial.length > 0) {
        var table = document.getElementById("inputTable");
        var count = table.rows.length;
        for (var i = 0; i < count; i++) {
            if (i > 0) {
                var row = table.rows[i];
                for (var j = 0; j < 7; j++) {
                    if (j > 1) {
                        txtValues += colShorts[j] + ":" + row.cells[j].children[0].value + "_";
                    }
                }
                txtValues += "|";
            }
        }
        console.log(txtValues);
    }

    $('#hdnPlannedValues').val(txtValues);
 
    return false;
}

///get ids only from comple string;
function GetIdsOnly(values) {
    var oldValue = []; var newValue = [];
    if(values)
    {
        oldValue = values.split(',');
        for (var i = 0; i < oldValue.length; i++) {
            var val = oldValue[i].split(':')[0];
            newValue.push(val);
        }
        return newValue;
    }
}
