﻿
// for tokenfields implementation help:  http://sliptree.github.io/bootstrap-tokenfield/#examples

var cols = ["Tool Serial", "Customer", "Planned SBU HC", "Planned FSO HC", "Planned FV HC", "Planned BSA/TEE HC", "Planned OCE HC"];
var colShorts = ["Cust", "Tool", "SBU", "FSO", "FV", "SPD", "OCE"];
var equipmentCols = ["Major Assembly","Tool Serial", "Platform", "Customer", "Region", "Fab", "PBG", "KPU", "Ship Date", "Contract","Delete"];
var toolSerial = []; var assemblyNos = []; var assemblyInfo = []; var customer = []; var equipmentDetail = []; // ["Micron", "Samsung"]; 
var assArr="";

$(document).ready(function () {

    // this is for tool search new function with multiselect choice
    ToolAutoCompleteSearch();

    // this function is for binding all data on search/update mode
    if ($("#hdnUpdateMode").val() == "UpdateMode") {
        GetDynamicTableOnUpdate();
    }
    $("#txtCIFToolId").on('keyup', function (e) {
        if (e.which == 8) {
           $('#ddlToolSearchResult').multiselect('destroy');        
        }
    });

    $('#ddlToolSearchResult').multiselect({
        buttonWidth: '360px',
    });

    DisableControlsEditAccessrRole(); //check for edit access role,
});

// ********** CIF tool multiselect search box  ********************************************

// tool search function with multiselect dropdown
function ToolAutoCompleteSearch() {

    $('#txtCIFToolId').autocomplete({
        minLength: 3,
        source: function (request, response) {
            $('#loadingCIF').show();
            $('#result').text('');
            $.ajax({
                url: 'CIF-Form.aspx/GetEquipmentNumbers',
                data: "{ 'values': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        //return {                                   
                        //    value: item                                  
                        //}
                    }))
                    GetToolSearhResults(data.d);
                    CreateSearchResultDropdown();
                    $('#loadingCIF').hide();                   
                    $('#result').text(data.d.length+ " result found.");
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loadingCIF').show();
                    alert("Not Available.");
                }
            });
        }
    });
}

function GetToolSearhResults(data) {
    $("#ddlToolSearchResult").empty();
    $('#ddlToolSearchResult').multiselect('destroy');
    $.each(data, function (val, text) {    
        if (text)
            $('#ddlToolSearchResult').append($('<option></option>').val(text).html(text));
    });
}

// search result dropdown on change event, capturing the tool and assembly id and removing on uncheck
function CreateSearchResultDropdown() {
    $("#ddlToolSearchResult").attr("multiple", "multiple");
    $('#ddlToolSearchResult').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '360px',
        onChange: function (option, checked) {
            var toolserialNo = option[0].label.split(':')[1];
            var assemblyNo = option[0].label.split('-')[0]

            if (checked) {
                if (assemblyNos.length == 0) {
                    assemblyNos.push(assemblyNo);  // adding assembly no to array assemblyNos 
                    GetEquipmentFromToolSerialNo(assemblyNo);
                }
                else {
                    if ($.inArray(assemblyNo, assemblyNos) == -1) {
                        assemblyNos.push(assemblyNo);        // check after if assemblyNos already exist  
                        GetEquipmentFromToolSerialNo(assemblyNo);
                    }
                }
            }
            else {

                // removing assembly from array
                assemblyNos = $.grep(assemblyNos, function (value) {
                    return value != assemblyNo;
                });

                // removing equipment obj from equipment object array
                equipmentDetail = $.grep(equipmentDetail, function (v) {
                    return v.AssemblyNo.split('-')[0] != assemblyNo;
                });

                var index = toolSerial.indexOf(toolserialNo);  // getting customer array index for removing the value from array, just like in toolserial array.
                var custId = customer[index];

                // removing tool from array                
                var rows = $(equipmentDetail).filter(function (idx) {
                    return equipmentDetail[idx].SerialNo === toolserialNo;
                });

                if (rows.length == 0) {
                    toolSerial = $.grep(toolSerial, function (value) {
                        return value != toolserialNo;
                    });
                    // removing customer from customer array
                    customer = $.grep(customer, function (value) {
                        return value != custId;
                    });

                    $("#" + toolserialNo).parent().remove();
                }
                $("#tool" + assemblyNo).parent().remove();

                if (equipmentDetail.length == 0) {
                    $('#tableDiv').html("");
                    $('#toolDetailtableDiv').html("");
                    toolSerial = [];
                }
             
                assemblyInfo = $.grep(assemblyInfo, function (v) {
                    return v.split('-')[0] != assemblyNo;
                });
                $("#hdnAssemblyNos").val(assemblyInfo.toString());
                $("#hdnCIFToolID").val(toolSerial.toString());
            }
        }
    });
    $("#ddlToolSearchResult").multiselect('clearSelection');
    $('.multiselect-clear-filter').css('display', 'none');
    $('.multiselect-search').css('width', '97%');
}

//******************* End search tool multiselect search box***********************************


//********************* On Update mode functions*************************************
function GetDynamicTableOnUpdate() {
    var toolId = $('#hdnCIFToolID').val();
    var assemblyIds = $('#hdnAssemblyNos').val();
    var customerName = $('#hdnCustomerName').val();

    if (toolId != "") {
        if (toolId)
            toolSerial = GetIdsOnly(toolId);
        if (customerName)
            customer = customerName.split(',')
        CreateDynamicTable(customer, toolSerial);
        BindPlannedInputValuesOnUpdateMode();

        // setTimeout(function () { GetEquipmentFromToolSerialNoUpdateMode(toolSerial, ""); }, 1000);
        var toolids="";
        for (var i = 0; i < toolSerial.length; i++)
        {
            toolids += toolSerial[i] + ",";
        }
        GetEquipmentFromToolSerialNoUpdateMode(assemblyIds);

       // $('#txtCIFToolId').tokenfield('setTokens', toolId);
        $("#hdnUpdateMode").val('');
    }

}

function BindPlannedInputValuesOnUpdateMode() {
    var plannedValues = $('#hdnUpdateModePlannedValues').val().split('|');
    for (var i = 1; i < plannedValues.length; i++) {
        var colValues = plannedValues[i - 1].split(':');
        if (colValues.length > 0) {
            var serialTable = $('#inputTable tr').eq(i).children().eq(0).text();
            var hdnSerial = plannedValues[i - 1].split(':')[0];
            if (GetForToolEntry(serialTable, hdnSerial, plannedValues)) {
                if (arrIndex != "")
                    colValues = plannedValues[arrIndex].split(':');

                for (var j = 2, k = 0; j < 7, k < colValues.length; j++, k++) {
                    var ids = (i).toString() + j.toString();
                    $('#txt_' + ids).val(colValues[k + 1]);
                  //  console.log(ids + "--" + colValues[k]);
                }
            }
        }
    }
}

function GetEquipmentFromToolSerialNoUpdateMode(assemblyNo) {
   
    var dataObj = { assemblyNo: assemblyNo };
    dataObj = JSON.stringify(dataObj);
    $.ajax({
        url: 'CIF-Form.aspx/GetEquipmentDetailfromToolSerialNoInUpdateMode',      
        data: dataObj,
        dataType: "json",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
           // console.log(data.d);
            $('#toolDetailtableDiv').html("");

            for (var i = 0; i < data.d.length; i++) {

                var newObj = {
                    AssemblyNo: data.d[i].MajorAssembly,
                    SerialNo: data.d[i].SerialNo,
                    Platform: data.d[i].Platform,
                    Customer: data.d[i].Customer,
                    Region: data.d[i].Region,
                    Fab: data.d[i].Fab,
                    PBG: data.d[i].PBG,
                    KPU: data.d[i].KPU,
                    ToolShipDate: data.d[i].ToolShipDate,
                    Contract: data.d[i].Contract
                };
                equipmentDetail.push(newObj);
                assemblyNos.push(data.d[i].MajorAssembly.split('-')[0]);
                assemblyInfo.push(data.d[i].MajorAssembly + ":" + data.d[i].SerialNo + "|");  // getting assembly no + description
            }
            $("#hdnAssemblyNos").val(assemblyInfo.toString());
            CreateEquipmentDetailsTable(equipmentDetail);
           
        },
        error: function (error) {
            var msg = "Please try typing the tool serial no. or description!";
            alert(msg);
        }

    });

}

//********************* End Update mode functions*************************************


//********************** Assembly/Tool info grid operation************************************

function GetEquipmentFromToolSerialNo(assemblyNo) {
    var toolserialNo = "";
    var dataObj = { assemblyNo: assemblyNo };
    dataObj = JSON.stringify(dataObj);

    $.ajax({
        url: 'CIF-Form.aspx/GetEquipmentDetailfromToolSerialNo',
        data: dataObj,
        dataType: "json",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
           // console.log(data.d);
            $('#toolDetailtableDiv').html("");

            for (var i = 0; i < data.d.length; i++) {

                var newObj = {
                    AssemblyNo: data.d[i].MajorAssembly,
                    SerialNo: data.d[i].SerialNo,
                    Platform: data.d[i].Platform,
                    Customer: data.d[i].Customer,
                    Region: data.d[i].Region,
                    Fab: data.d[i].Fab,
                    PBG: data.d[i].PBG,
                    KPU: data.d[i].KPU,
                    ToolShipDate: data.d[i].ToolShipDate,
                    Contract: data.d[i].Contract
                };
                equipmentDetail.push(newObj);               

                if (toolSerial.length == 0) {
                    toolSerial.push(data.d[i].SerialNo);  // add element for first time tool 
                    customer.push(data.d[i].Customer);
                }
                else {
                    if ($.inArray(data.d[i].SerialNo, toolSerial) == -1) {
                        toolSerial.push(data.d[i].SerialNo);       // check after if tool already exist  
                        customer.push(data.d[i].Customer);
                    }
                }
                assemblyInfo.push(data.d[i].MajorAssembly + ":" + data.d[i].SerialNo + "|");  // getting assembly no + description
            }
             
            $("#hdnAssemblyNos").val(assemblyInfo.toString());
            $("#hdnCIFToolID").val(toolSerial.toString());

            CreateEquipmentDetailsTable(equipmentDetail);
            $('#tableDiv').html("");
            CreateDynamicTable(customer, toolSerial);
            if ($('#hdnCIFToolID').val() != "") {
                BindPlannedInputValuesOnUpdateMode();
            }
         //   var assemblyIds = searchInArray("AssemblyNo", equipmentDetail);

        },
        error: function (error) {
            var msg = "Please try typing the tool serial no. or description!";
            alert(msg);
        }
    });
}

function GetArrayFromObjectArray(equipmentDetailArray) {
    var objArary = [];
    // for (var i = 0; i < equipmentDetailArray.length; i++)
    {
        objArary.push(equipmentDetailArray.AssemblyNo);
        objArary.push(equipmentDetailArray.SerialNo);
        objArary.push(equipmentDetailArray.Platform);
        objArary.push(equipmentDetailArray.Customer);
        objArary.push(equipmentDetailArray.Region);
        objArary.push(equipmentDetailArray.Fab);
        objArary.push(equipmentDetailArray.PBG);
        objArary.push(equipmentDetailArray.KPU);
        objArary.push(equipmentDetailArray.ToolShipDate.split(" ")[0]);
        objArary.push(equipmentDetailArray.Contract);

    }
    return objArary;
}

function CreateEquipmentDetailsTable(equipmentDetail) {
    $('#toolDetailtableDiv').val('');
    if (equipmentDetail.length == 0)
        return;

    var table_body = "<table id='euipmentTable' class='dynamicTb'><tbody><tr>";

    for (var i = 0; i < equipmentCols.length; i++) {
        table_body += "<th width='110px' class='dynamicTbTD'>" + equipmentCols[i] + "</th>";
    }

    table_body += "</tr>";

    for (var i = 0; i < equipmentDetail.length; i++) {
        table_body += "<tr>";

        var arrayNew = GetArrayFromObjectArray(equipmentDetail[i]);
        arrayNew.push('Delete');

        for (var j = 0; j < arrayNew.length; j++) {
            if (j == 0) {
                table_body += "<td width='120px' class='dynamicTbTD' id='tool" + arrayNew[j].split('-')[0] + "'>" + arrayNew[j] + "</td>";
            }
            else {
                if (j == arrayNew.length-1) {
                    table_body += "<td  width='90px'  class='dynamicTbTD'><a href='#' class='deleteClass' onclick=javascript:DeleteRow('" + arrayNew[0].split('-')[0] + "','" + arrayNew[1] + "')>Delete</a></td>";;
                }
                else {
                    table_body += "<td  width='120px' class='dynamicTbTD'>" + arrayNew[j] + "</td>";
                }
            }

           // table_body += arrayNew[j];
           // table_body += "</td>";
        }
        table_body += "</tr>";
        objArary = [];
    }
    table_body += '</table>';

    $('#toolDetailtableDiv').html(table_body);


    if ($('#hdnUserCanEdit').val() == "true" || $('#hdnIsPowerUser').val() == "true") {

        if ($('#hdnEdituser').val() == "true")
            $('.deleteClass').css('display', 'none');
        else
            $('.deleteClass').css('display', 'block');
    }
    else
        $('.deleteClass').css('display', 'none');
    
}

// delete row function on grid
function DeleteRow(assemblyNo, toolserialNo)
{
    //var isEditTrue = $('#hdnEdituser').val();
    //if (isEditTrue) {
    //    alert('You dont have access to delete this!!');
    //    return;
    //}
    let confirmBox = confirm("Are you sure, you want remove this?");
    if (confirmBox) {
        var index = toolSerial.indexOf(toolserialNo);
        var custId = customer[index];

        // removing assembly from array
        assemblyNos = $.grep(assemblyNos, function (value) {
            return value != assemblyNo;
        });

        //// removing customer from customer array
        //customer = $.grep(customer, function (value) {
        //    return value != custId;
        //});

        // removing equipment obj from equipment object array
        equipmentDetail = $.grep(equipmentDetail, function (v) {
            return v.AssemblyNo.split('-')[0] != assemblyNo;
        });

        var index = toolSerial.indexOf(toolserialNo);  // getting customer array index for removing the value from array, just like in toolserial array.
        var custId = customer[index];

        // removing tool from array                
        var rows = $(equipmentDetail).filter(function (idx) {
            return equipmentDetail[idx].SerialNo === toolserialNo;
        });

        if (rows.length == 0) {
            toolSerial = $.grep(toolSerial, function (value) {
                return value != toolserialNo;
            });
            // removing customer from customer array
            customer = $.grep(customer, function (value) {
                return value != custId;
            });
            $("#" + toolserialNo).parent().remove();
        }

        var assembly = $("#tool" + assemblyNo).text() + ":" + toolserialNo;
        $('#ddlToolSearchResult').multiselect('deselect', [assembly])

        $("#tool" + assemblyNo).parent().remove();


        if (equipmentDetail.length == 0) {
            $('#tableDiv').html("");
            $('#toolDetailtableDiv').html("");
            toolSerial = [];
        }

        assemblyInfo = $.grep(assemblyInfo, function (v) {
            return v.split('-')[0] != assemblyNo;
        });
        $("#hdnAssemblyNos").val(assemblyInfo.toString());
        $("#hdnCIFToolID").val(toolSerial.toString());
    }
}

function CreateDynamicTable(customer, toolSerial) {
    var table_body = "<table id='inputTable' class='dynamicTb'><tbody><tr>";

    for (var i = 0; i < cols.length; i++)
        table_body += "<th class='dynamicTbTD'>" + cols[i] + "</th>";

    table_body += "</tr>";

    for (var i = 0; i < toolSerial.length; i++) {
        table_body += "<tr>";
        for (var j = 0; j < cols.length; j++) {

            if (j == 0 || j == 1) {
                if (j == 1) {
                    table_body += "<td class='dynamicTbTD'>";
                    if (customer[i])
                        table_body += customer[i];
                }
                if (j == 0) {
                    table_body += "<td class='dynamicTbTD' id='" + toolSerial[i] + "'>";
                    table_body += toolSerial[i];
                }
            }
            else {
                table_body += "<td class='dynamicTbTD'><input id=txt_" + (i + 1).toString() + j.toString() + "  type='text' class='form-control' placeholder='' spellcheck='false' onkeypress='return isNumberKey(event)'/>";
                // table_body += colsValue[j];
            }

            table_body += "</td>";
        }
        table_body += "</tr>";
    }
    table_body += '</table>';
    $('#tableDiv').html(table_body);
}

//********************** End grid ************************************

var arrIndex = "";
function GetForToolEntry(serialTable, hdnSerial, plannedValues) {
    arrIndex = "";
    var newArr = [];
    for (var i = 0; i < plannedValues.length; i++)
        newArr.push(plannedValues[i].split(':')[0]);

    if (serialTable == hdnSerial)
        return true;
    else if (newArr.indexOf(serialTable) > -1) {
        arrIndex = newArr.indexOf(serialTable);
        return true;
    }
    else
        return false;
}

function FieldsValidation(sender) {
    var isvalid = true;
    var cifType = $("#ddlCIFType").val();
    var startDate = $("#txtCIFStartDate").val();
    var actualDate = $("#txtActCloseDate").val();
    var cifStatus = $("#ddlCIFStatus").prop('selectedIndex');

    if (cifType === "Select" || startDate === "" || actualDate === "" || cifStatus === 0) {
        alert("Please fill the mandatory fields *.");
        isvalid = false;
    }
    if (sender == "update") {   // logic for update button only
        RemoveQueryString();
    }
    if (isvalid) {
        GetInputValues();  //getting input values from planned 5 box in a string 
    }

    EnableDisableControlonUpdate();// this is for particular role for edit certain section in cif portal not all form ( CIF engineer)
    if (isvalid)      
            $('#loading').show();
      
    return isvalid;
}

//check for edit access role, can edit only Service info and FSS info
function DisableControlsEditAccessrRole() {

    var isEditTrue = $('#hdnEdituser').val();
    if (isEditTrue) {
        $(".container :input").attr("disabled", true);
        $("#collapseFour :input").removeAttr("disabled");
        $("#collapseFive :input").removeAttr("disabled");
        $("#btnPnl :input").removeAttr("disabled");
    }
}

// Enable controls on update and then disabled after update
function EnableDisableControlonUpdate() {
    $(".container :input").removeAttr("disabled");
}


function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        alert("Please enter the numbers only");
        $("#txtBudget").val("");
        return false;
    }
    return true;
}

function ResetCheck() {
    var qryString = window.location.href.indexOf('ID');
    var IsPowerUser = $('#hdnIsPowerUser').val();
    var frameURL = window.location.href.split('&ID')[0];

    if (qryString > -1 && IsPowerUser != "") {

        var retVal = confirm("Do you want discard your changes ?");
        if (retVal == true) {
            $('#form1').attr('action', frameURL);
            function preventBack() { window.history.forward(); }
            setTimeout("preventBack()", 0);
            window.onunload = function () { null };
            return true;
        } else {
            return false;
        }
    }
}

function RemoveQueryString() {
    var qryString = window.location.href.indexOf('ID');
    if (qryString > -1) {
        var frameURL = window.location.href.split('&ID')[0];
        // $('#form1').attr('action', frameURL);
    }
}

/// get values from input box for dymanic generating  2box
var txtValues = "";
function GetInputValues() {
    txtValues = "";
    if (toolSerial.length > 0) {
        var table = document.getElementById("inputTable");
        var count = table.rows.length;
        for (var i = 0; i < count; i++) {
            if (i > 0) {
                var row = table.rows[i];
                for (var j = 0; j < 7; j++) {
                    if (j > 1) {
                        txtValues += colShorts[j] + ":" + row.cells[j].children[0].value + "_";
                    }
                }
                txtValues += "|";
            }
        }
       // console.log(txtValues);
    }

    $('#hdnPlannedValues').val(txtValues);

    return false;
}

///get ids only from comple string;
function GetIdsOnly(values) {
    var oldValue = []; var newValue = [];
    if (values) {
        oldValue = values.split(',');
        for (var i = 0; i < oldValue.length; i++) {
            var val = oldValue[i].split(':')[0];
            newValue.push(val);
        }
        return newValue;
    }
}


