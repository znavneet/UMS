﻿
$(document).ready(function () {   


    $('#txtCleansupplier').tokenfield({
        autocomplete: {
            minLength: 3,
            source: function (request, response) {
                $('#loadingCleansupplier').show();
             $.ajax({
                 url: 'CIF-Form.aspx/GetMaterialNumbers',
                    data: "{ 'values': '" + request.term + "' }",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    dataFilter: function (data) { return data; },
                    success: function (data) {
                        response($.map(data.d, function (item) {
                            return {
                                value: item
                            }
                        }))
                        $('#loadingCleansupplier').hide();
                    },
                    error: function (XMLHttpRequest, textStatus, error) {
                        $('#loadingCleansupplier').hide();
                        alert("Not Available.");
                    }
                });
            }
        }
    });

    var CleanSupplier = $('#hdnCleanSupplier').val();
    if (CleanSupplier != "") {
        $('#txtCleansupplier').tokenfield('setTokens', CleanSupplier);
    }

    $('#txtRepairSupplier').tokenfield({
        autocomplete: {
            minLength: 3,
            source: function (request, response) {
                $('#loadingRepairSupplier').show();
                $.ajax({
                    url: 'CIF-Form.aspx/GetMaterialNumbers',
                    data: "{ 'values': '" + request.term + "' }",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    dataFilter: function (data) { return data; },
                    success: function (data) {
                        response($.map(data.d, function (item) {
                            return {
                                value: item
                            }
                        }))
                        $('#loadingRepairSupplier').hide();
                       
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $('#loadingRepairSupplier').hide();
                        alert("Not Available.");
                    }
                });
            }
        }
    });

    var hdnRepairSupplier = $('#hdnRepairSupplier').val();
    if (hdnRepairSupplier != "") {
        $('#txtRepairSupplier').tokenfield('setTokens', hdnRepairSupplier);
    }

    $('#txtRefurbSupplier').tokenfield({
        autocomplete: {
            minLength: 3,
            source: function (request, response) {
                $('#loadingRefurbSupplier').show();
                $.ajax({
                    url: 'CIF-Form.aspx/GetMaterialNumbers',
                    data: "{ 'values': '" + request.term + "' }",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    dataFilter: function (data) { return data; },
                    success: function (data) {
                        response($.map(data.d, function (item) {
                            return {
                                value: item
                            }
                        }))
                        $('#loadingRefurbSupplier').hide();
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $('#loadingRefurbSupplier').hide();
                        alert("Not Available.");
                    }
                });
            }
        }
    });

    var hdnRefurbSupplier = $('#hdnRefurbSupplier').val();
    if (hdnRefurbSupplier != "") {
        $('#txtRefurbSupplier').tokenfield('setTokens', hdnRefurbSupplier);
    }

    $('#txtGPSTSupplier').tokenfield({
        autocomplete: {
            minLength: 3,
            source: function (request, response) {
                $('#loadingGPSTSupplier').show();
                $.ajax({
                    url: 'CIF-Form.aspx/GetMaterialNumbers',
                    data: "{ 'values': '" + request.term + "' }",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    dataFilter: function (data) { return data; },
                    success: function (data) {
                        response($.map(data.d, function (item) {
                            return {
                                value: item
                            }
                        }))
                        $('#loadingGPSTSupplier').hide();
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $('#loadingGPSTSupplier').hide();
                        alert("Not Available.");

                    }
                });
            }
        }
    });

    var hdnGPSTSupplier = $('#hdnGPSTSupplier').val();
    if (hdnGPSTSupplier != "") {
        $('#txtGPSTSupplier').tokenfield('setTokens', hdnGPSTSupplier);
    }

    $('#txtContractID').tokenfield({
        autocomplete: {
            minLength: 3,
            source: function (request, response) {
                $('#loadingContractID').show();
                $.ajax({
                    url: 'CIF-Form.aspx/GetContractId',
                    data: "{ 'values': '" + request.term + "' }",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    dataFilter: function (data) { return data; },
                    success: function (data) {
                        response($.map(data.d, function (item) {
                            return {
                                value: item
                            }
                        }))
                        $('#loadingContractID').hide();
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $('#loadingContractID').hide();
                        alert("Not Available.");
                    }
                });
            }
        }
    });

    var hdnContractID = $('#hdnContractID').val();
    if (hdnContractID != "") {
        $('#txtContractID').tokenfield('setTokens', hdnContractID);
    }
    
    
 //   GetInternalFundedOrderNo();

    GetAllOwners();

});  /// document ready braces

//function GetInternalFundedOrderNo()
//{
//    $('#txtFundedNumber').autocomplete({
//        minLength: 3,
//        source: function (request, response) {
//            $('#loadingIFP').show();
//            $.ajax({
//                url: 'CIF-Form.aspx/GetInternalFundedOrderNo',
//                data: "{ 'ifpNo': '" + request.term + "' }",
//                dataType: "json",
//                type: "POST",
//                contentType: "application/json; charset=utf-8",
//                dataFilter: function (data) { return data; },
//                success: function (data) {
//                    response($.map(data.d, function (item) {
//                        return {                         
//                            value: item.IFPNumber
//                        }
//                    }))
                    
//                   // $('#loadingIFP').txtInternalOrder
//                    $('#loadingIFP').hide();

//                },
//                error: function (XMLHttpRequest, textStatus, errorThrown) {
//                    $('#loadingIFP').hide();
//                    alert("Not Available.");
//                }
//            });
//        }
//    });
//}

function GetAllOwners()
{
    //for SBU owner
    $('#txtSbuOwner').autocomplete({
        minLength: 3,
        source: function (request, response) {
            $('#loadingSBUOwner').show();
            $.ajax({
                url: 'CIF-Form.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        return {
                            value: item.UserName
                        }
                    }))
                    // $('#hdnfabLocation').val();
                    $('#loadingSBUOwner').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loadingSBUOwner').hide();
                    alert("Not found.");
                }
            });
        }
    });

    //for FSO owner
    $('#txtFsoOwner').autocomplete({
        minLength: 3,
        source: function (request, response) {
            $('#loadingFSOOwner').show();
            $.ajax({
                url: 'CIF-Form.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        return {
                            value: item.UserName
                        }
                    }))
                    // $('#hdnfabLocation').val();
                    $('#loadingFSOOwner').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loadingFSOOwner').hide();
                    alert("Not found.");
                }
            });
        }
    });

    //for GFG owner
    $('#txtGfgOwner').autocomplete({
        minLength: 3,
        source: function (request, response) {
            $('#loadingGFGOwner').show();
            $.ajax({
                url: 'CIF-Form.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        return {
                            value: item.UserName
                        }
                    }))
                    // $('#hdnfabLocation').val();
                    $('#loadingGFGOwner').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loadingGFGOwner').hide();
                    alert("Not found.");
                }
            });
        }
    });


    //for BU owner
    $('#txtBUOwner').autocomplete({
        minLength: 3,
        source: function (request, response) {
            $('#loadingBUGOwner').show();
            $.ajax({
                url: 'CIF-Form.aspx/GetADUsers',
                data: "{ 'username': '" + request.term + "' }",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data.d, function (item) {
                        return {
                            value: item.UserName
                        }
                    }))
                    // $('#hdnfabLocation').val();
                    $('#loadingBUGOwner').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('#loadingBUGOwner').hide();
                    alert("Not found.");
                }
            });
        }
    });

}



//$('#txtFabLocation').autocomplete({
//    minLength: 3,
//    source: function (request, response) {
//        $('#loadingFabLocation').show();
//        $.ajax({
//            url: 'CIF-Form.aspx/GetFabLocation',
//            data: "{ 'values': '" + request.term + "' }",
//            dataType: "json",
//            type: "POST",
//            contentType: "application/json; charset=utf-8",
//            dataFilter: function (data) { return data; },
//            success: function (data) {
//                response($.map(data.d, function (item) {
//                    return {
//                        value: item
//                    }
//                }))
//               // $('#hdnfabLocation').val();
//                $('#loadingFabLocation').hide();

//            },
//            error: function (XMLHttpRequest, textStatus, errorThrown) {
//                $('#loadingFabLocation').hide();
//                alert("Not Available.");
//            }
//        });
//    }
//});




