﻿

$(document).ready(function () {

    $('.datetimepicker').datetimepicker({
        format: 'MM/DD/YYYY'
    });

    //********ddlBu*********
    $("#ddlBu").attr("multiple", "multiple");
    $('#ddlBu').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var bu = $("#ddlBu").val();
            bindProductonUpdateMode(bu);
        }

    });
    $("#ddlBu").multiselect('clearSelection');
    $('.multiselect-clear-filter').css('display', 'none');
    $('.multiselect-search').css('width', '97%');

    updateMode(); // binding existing data from db for update
});


function bindProductonUpdateMode(bu) {
    $.ajax({
        url: 'CIF-Form.aspx/GetProduct',
        data: "{ 'values': '" + bu + "' }",
        dataType: "json",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $("#ddlProduct").empty();
            $('#ddlProduct').multiselect('destroy');
            $.each(data.d, function () {
                $("#ddlProduct").append($("<option/>").val(this.toString()).text(this.toString()));
            });
                       
            MultiselectProductDDL();// making pruduct dropdown as multiselect
            var isEditTrue = $('#hdnEdituser').val();
            if (isEditTrue) {
                $(".multiselect").attr("disabled", true);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

            alert("Not Available.");

        }
    });
}

function MultiselectProductDDL() {

    $("#ddlProduct").attr("multiple", "multiple");
    $('#ddlProduct').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var products = $("#ddlProduct").val();
            $("#hdnTambaIds").val("");           
            fillTambaDropdown(products);
        }
    });

    var product = $("#hdnProducts").val();
    if (product != "") {
        var arrObj = product.split(',');
        $('#ddlProduct').multiselect('select', arrObj);
    }
    var ddlproduct = $("#ddlProduct").val();
    if ($("#hdnUpdateMode").val() !== "UpdateMode") {
        $("#ddlProduct").multiselect('clearSelection');
    }
    $('.multiselect-clear-filter').css('display', 'none');
    $('.multiselect-search').css('width', '97%');
}
    

//-- filling tamba dropdown
function fillTambaDropdown(values) {
    $("#ddlTambaNo").multiselect('destroy');
    $('#viewTambaDetails').jqGrid('GridUnload');

    $.ajax({
        url: 'CIF-Form.aspx/GetTambaNoMultiselectProduct',
        data: "{ 'values': '" + values + "' }",
        dataType: "json",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $("#ddlTambaNo").empty();
            $('#ddlTambaNo').multiselect('destroy');
            $.each(data.d, function () {
                $("#ddlTambaNo").append($("<option/>").val(this.toString()).text(this.toString()));
            });

            $("#ddlTambaNo").attr("multiple", "multiple");
            $('#ddlTambaNo').multiselect({
                includeSelectAllOption: false,
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true,
                maxHeight: 200,
                buttonWidth: '220px',
                onChange: function (option, checked) {
                    var value = $('#ddlTambaNo').val().toString();
                    $('#hdnTambaIds').val(value);
                    GetTambaDetails(value);
                }

            });
            $("#ddlTambaNo").multiselect('clearSelection');
            $('.multiselect-clear-filter').css('display', 'none');

            var tambaValues = $("#hdnTambaIds").val();
            if (tambaValues != "") {
                var arrObj = tambaValues.split(',');
                $('#ddlTambaNo').multiselect('select', arrObj);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

            alert("Not Available.");

        }
    });
}

/// bind tamba grid details
function GetTambaDetails(values) {
  
    $('#viewTambaDetails').jqGrid('GridUnload');

    $("#viewTambaDetails").jqGrid({
        url: 'CIF-Form.aspx/GetTambaBuProductDetails',
        datatype: 'json',
        mtype: 'POST',
        search: true,
        postData: { filters: '', values: values },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
            $('#hdnTambaIds').val();
        },

        ajaxGridOptions: { contentType: "application/json" },
        loadonce: true,
        colNames: ['TAMBA ID', 'Business Unit', 'AMAT Product', 'TAMBA Status', 'PTOR Date','Managed Account'],
        colModel: [
                { name: 'TAMBA_ID', index: 'TAMBA_ID', width: 168, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'BusinessUnit', index: 'BusinessUnit', width: 168, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'AmatProduct', index: 'AmatProduct', width: 168, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'TAMBAStatus', index: 'TAMBAStatus', width: 168, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'PTORDate', index: 'PTORDate', width: 168, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'ManagedAccount', index: 'ManagedAccount', width: 168, align: 'center', viewable: true, search: true, title: false, sortable: true }
  
        ],
        pager: '#pagingDraftGrid',
        rowNum: 5,
        rowList: [5, 10, 15],
        rownumbers: true,
        viewrecords: true,
        gridview: true,
        shrinkToFit: false,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },

    });

    //var gridWidth = $("#navHome").width();
    //$('#viewAllRequest').jqGrid('setGridWidth', gridWidth);

}


//**********--Update mode--*********

function updateMode()
{
    if ($("#hdnUpdateMode").val() == "UpdateMode")
    {
        var bUs = $("#hdnBU").val();      
        if (bUs != "") {
            var arrObj = bUs.split(',');
            $('#ddlBu').multiselect('select', arrObj);
        }
      
        bindProductonUpdateMode(bUs);
        //  Update mode for details
        if ($("#hdnUpdateMode").val() == "UpdateMode") {
            var products = $("#hdnProducts").val();
            if (products != "") {
                var arrObj = products.split(',');

                $('#ddlProduct').multiselect('select', arrObj);
              
                fillTambaDropdown(products);   //filling tanba dropdown

                var tambaValues = $("#hdnTambaIds").val();
                if (tambaValues != "") {
                         GetTambaDetails(tambaValues);  //filling tamba grid
                }               
            }
        }
    }
}

