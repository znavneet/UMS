﻿
          //********ddlTambaNo*********
$(document).ready(function () {

    $('.datetimepicker').datetimepicker({
        format: 'MM/DD/YYYY'
    }); 

    $("#ddlBu").change(function () {
        if ($("#ddlBu").val() != "Select") {

            var bu = $(this).val();
            if ($("#hdnUpdateMode").val() == "UpdateMode")
                $('#viewTambaDetails').clearGridData();

            $("#hdnTambaIds").val("");
            $("#hdnUpdateMode").val("");
            $("#ddlTambaNo").multiselect('disable');

            bindProductonUpdateMode(bu);
        }
    });

    $("#ddlProduct").change(function () {

        if ($("#ddlProduct").val() == "Select") {
            $('#viewTambaDetails').clearGridData();
            $("#hdnTambaIds").val("");
        }
      
        $("#ddlTambaNo").multiselect('enable');
        $("#ddlTambaNo").multiselect('destroy');
        var bu = $("#ddlBu option:selected").text();
        var product = $(this).val();
        var newData = { BU: bu, Product: product };
        newData = JSON.stringify(newData);

        $.ajax({
            url: 'CIF-Form.aspx/GetTambaDetail',
            data: newData,
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                $("#ddlTambaNo").empty();
                $.each(data.d, function () {
                    $("#ddlTambaNo").append($("<option/>").val(this.toString()).text(this.toString()));
                });

             
                $("#ddlTambaNo").attr("multiple", "multiple");
                $('#ddlTambaNo').multiselect({
                    includeSelectAllOption: false,
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true,
                    maxHeight: 200,
                    buttonWidth: '220px',
                    onChange: function (option, checked) {
                        var value = $('#ddlTambaNo').val().toString();
                        $('#hdnTambaIds').val(value);
                        GetTambaDetails(value);
                    }

                });
                $("#ddlTambaNo").multiselect('clearSelection');
                $('.multiselect-clear-filter').css('display', 'none');
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

                alert("Not Available.");

            }
        });
    });

   // BindTambaDDLonUpdateMode();

    var Bu = $("#hdnBU").val();
    if (Bu != "") {
        bindProductonUpdateMode(Bu);
    }

});

//bing product dropdown on update mode
function bindProductonUpdateMode(bu) {
    $.ajax({
        url: 'CIF-Form.aspx/GetProduct',
        data: "{ 'values': '" + bu + "' }",
        dataType: "json",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $("#ddlProduct").empty();
            $("#ddlProduct").append($("<option/>").val("0").text("Select"));
            $.each(data.d, function () {
                $("#ddlProduct").append($("<option/>").val(this.toString()).text(this.toString()));
            });
            var value = $("#hdnProduct").val();

            if ($("#hdnUpdateMode").val() == "UpdateMode")
                $("select[name^='ddlProduct'] option[value='" + value + "']").attr("selected", "selected");

            $("#ddlTambaNo").multiselect('clearSelection');

            BindTambaDDLonUpdateMode();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

            alert("Not Available.");

        }
    });
}

//bind tamba ddl on update mode
function BindTambaDDLonUpdateMode() {

    // Binding data in update mode
    var TambaIds = $("#hdnTambaIds").val();
    var arrObj = [];
    if (TambaIds != "") {
        arrObj = TambaIds.split(',');
        $.each(arrObj, function () {
            $("#ddlTambaNo").append($("<option/>").val(this.toString()).text(this.toString()));
        });
    }
    else
        $("#ddlTambaNo").multiselect('clearSelection');

    //********ddlCoating*********
    $("#ddlTambaNo").attr("multiple", "multiple");
    $('#ddlTambaNo').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '250px',
        onChange: function (option, checked) {
            var value = $('#ddlTambaNo').val().toString();
            $('#hdnTambaIds').val(value);
            GetTambaDetails(value);
        }
    });

    $('#ddlTambaNo').multiselect('select', arrObj);
    $('.multiselect-clear-filter').css('display', 'none');

    var value = "";
    for (var i = 0; i < arrObj.length; i++) {
        value += arrObj[i] + ",";     
    }
    value = value.substring(0, value.length - 1);
    GetTambaDetails(value);
}

/// bind tamba grid details
function GetTambaDetails(values) {
    $('#viewTambaDetails').jqGrid('GridUnload');

    $("#viewTambaDetails").jqGrid({
        url: 'CIF-Form.aspx/GetTambaBuProductDetails',
        datatype: 'json',
        mtype: 'POST',
        search: true,
        postData: { filters: '', values: values },
        serializeGridData: function (postData) {
            return JSON.stringify(postData);
            $('#hdnTambaIds').val();
        },

        ajaxGridOptions: { contentType: "application/json" },
        loadonce: true,
        colNames: ['TAMBA ID', 'Business Unit', 'AMAT Product', 'TAMBA Status', 'PTOR Date'],
        colModel: [
                { name: 'TAMBA_ID', index: 'TAMBA_ID', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'BusinessUnit', index: 'BusinessUnit', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'AmatProduct', index: 'AmatProduct', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true },
                { name: 'TAMBAStatus', index: 'TAMBAStatus', width: 200, align: 'center', viewable: true, search: false, title: false, sortable: true },
                { name: 'PTORDate', index: 'PTORDate', width: 200, align: 'center', viewable: true, search: true, title: false, sortable: true }

        ],
        pager: '#pagingDraftGrid',
        rowNum: 5,
        rowList: [5, 10, 15],
        rownumbers: true,
        viewrecords: true,
        gridview: true,
        shrinkToFit: false,
        jsonReader: {
            page: function (obj) { return 1; },
            total: function (obj) { return 1; },
            records: function (obj) { return obj.d.length; },
            root: function (obj) { return obj.d; },
            repeatitems: false,
            id: "0"
        },

    });

    //var gridWidth = $("#navHome").width();
    //$('#viewAllRequest').jqGrid('setGridWidth', gridWidth);

}
