﻿
$(document).ready(function () {
    GetDashboardList();

    $("#subMenu li").click(function () {
        $(this).addClass("active");
        $(this).siblings().removeClass("active");
    });
   

});
    function GetDashboardList() {
        $.ajax({
            url: 'Dashboard.aspx/GetDashboardList',
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                BuildHTML(data)
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    }

    function BuildHTML(data) {
        var divHtml = "<ul id='sideUl'>";
        for (var i = 0; i < data.d.length; i++) {
            divHtml += "<li> <a href=javascript:Refreshdashboard('" + data.d[i].URL + "')>" + data.d[i].Name + "</a></li>";
        }
        divHtml += "</ul>";
        $('#subMenu').append(divHtml);
    }

    function Refreshdashboard(url)
    {
        $('#frameReport').prop('src', '');
        $('#frameReport').prop('src', url);
    }

    //$('#sideMenu li').click(function () {
    //    $('#sideMenu li').attr('class', removeClass('activeLi');
    //    $(this).addClass('activeLi');
    //});

function leftPanel() {
   // fas fa - times
}

   
   