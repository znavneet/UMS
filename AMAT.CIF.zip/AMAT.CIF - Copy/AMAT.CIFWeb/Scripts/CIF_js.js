﻿

jQuery(document).ready(function () {

   
    LoadMultiSelectDropdownJS();

    if ($("#hdnUpdateMode").val() == "")
        $("#IsupdateMode").css('display', 'none');
    else
        $("#IsupdateMode").css('display', 'block');

  //  Getprofile();
});



function LoadMultiSelectDropdownJS() {

    //********ddlFSSfeatures***************             

    $("#ddlFSSfeatures").attr("multiple", "multiple");
    $('#ddlFSSfeatures').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var value = $('#ddlFSSfeatures').val().toString();
            $("#hdnFSSBasicFeatures").val(value);
        }          
    });
    $("#ddlFSSfeatures").multiselect('clearSelection');

    // Binding data in update mode
    var FSSBasicFeatures = $("#hdnFSSBasicFeatures").val();
    if (FSSBasicFeatures != "") {
        var arrObj = FSSBasicFeatures.split(',');
        $('#ddlFSSfeatures').multiselect('select', arrObj); 
    }    
    

    //********ddlFSSAdvFeatures***************

    $("#ddlFSSAdvFeatures").attr("multiple", "multiple");
    $('#ddlFSSAdvFeatures').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var value = $('#ddlFSSAdvFeatures').val().toString();
            $("#hdnFSSAdvancedFeatures").val(value);
        },
        onDropdownHide: function (event) {
            //   alert('onDropdownHide!');
        }
    });
    $("#ddlFSSAdvFeatures").multiselect('clearSelection');

    // Binding data in update mode
    var FSSAdvFeatures = $("#hdnFSSAdvancedFeatures").val();
    if (FSSAdvFeatures != "") {
        var arrObj = FSSAdvFeatures.split(',');
        $('#ddlFSSAdvFeatures').multiselect('select', arrObj);
    }
   

    //********dllDashboard***************

    $("#dllDashboard").attr("multiple", "multiple");
    $('#dllDashboard').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 150,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var value = $('#dllDashboard').val().toString();
            $("#hdnDashboards").val(value);
        }

    });
    $("#dllDashboard").multiselect('clearSelection');

    // Binding data in update mode
    var Dashboards = $("#hdnDashboards").val();
    if (Dashboards != "") {
        var arrObj = Dashboards.split(',');
        $('#dllDashboard').multiselect('select', arrObj);
    }
       

    //********ddlMetro*********

    $("#ddlMetro").attr("multiple", "multiple");
    $('#ddlMetro').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 180,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var value = $('#ddlMetro').val().toString();
            $("#hdnHandheldMetro").val(value);
        }

    });

    $("#ddlMetro").multiselect('clearSelection');

    // Binding data in update mode
    var HandheldMetro = $("#hdnHandheldMetro").val();
    if (HandheldMetro != "") {
        var arrObj = HandheldMetro.split(',');
        $('#ddlMetro').multiselect('select', arrObj);
    }
  
    //********ddlSensorWafers*********

    $("#ddlSensorWafers").attr("multiple", "multiple");
    $('#ddlSensorWafers').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 120,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var value = $('#ddlSensorWafers').val().toString();
            $("#hdnSensorWafers").val(value);
        }

    });
    $("#ddlSensorWafers").multiselect('clearSelection');

    // Binding data in update mode
    var SensorWafers = $("#hdnSensorWafers").val();
    if (SensorWafers != "") {
        var arrObj = SensorWafers.split(',');
        $('#ddlSensorWafers').multiselect('select', arrObj);
    }
 
    //********ddlCleaningMethod*********
    $("#ddlCleaningMethod").attr("multiple", "multiple");
    $('#ddlCleaningMethod').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var value = $('#ddlCleaningMethod').val().toString();
            $("#hdnCleaningMethod").val(value);
        }

    });
    $("#ddlCleaningMethod").multiselect('clearSelection');

    // Binding data in update mode
    var CleaningMethod = $("#hdnCleaningMethod").val();
    if (CleaningMethod != "") {
        var arrObj = CleaningMethod.split(',');
        $('#ddlCleaningMethod').multiselect('select', arrObj);
    }
  

    //********ddlCoating*********
    $("#ddlCoating").attr("multiple", "multiple");
    $('#ddlCoating').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '250px',
        onChange: function (option, checked) {
            var value = $('#ddlCoating').val().toString();
            $("#hdnCoating").val(value);
        }

    });
    $("#ddlCoating").multiselect('clearSelection');

    // Binding data in update mode
    var Coating = $("#hdnCoating").val();
    if (Coating != "") {
        var arrObj = Coating.split(',');
        $('#ddlCoating').multiselect('select', arrObj);
    }
        

    //********ddlInspectionMetrology*********
    $("#ddlInspectionMetrology").attr("multiple", "multiple");
    $('#ddlInspectionMetrology').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '220px',
        onChange: function (option, checked) {
            var value = $('#ddlInspectionMetrology').val().toString();
            $("#hdnInspectionMetrology").val(value);
        }

    });
    $("#ddlInspectionMetrology").multiselect('clearSelection');

    // Binding data in update mode
    var InspectionMetrology = $("#hdnInspectionMetrology").val();
    if (InspectionMetrology != "") {
        var arrObj = InspectionMetrology.split(',');
        $('#ddlInspectionMetrology').multiselect('select', arrObj);
    }

    //********ddlTexturing*********
    $("#ddlTexturing").attr("multiple", "multiple");
    $('#ddlTexturing').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '250px',
        onChange: function (option, checked) {
            var value = $('#ddlTexturing').val().toString();
            $("#hdnTexturing").val(value);
        }

    });
    $("#ddlTexturing").multiselect('clearSelection');

    // Binding data in update mode
    var Texturing = $("#hdnTexturing").val();
    if (Texturing != "") {
        var arrObj = Texturing.split(',');
        $('#ddlTexturing').multiselect('select', arrObj);
    }       

    //********ddlNetworkExpert*********
    $("#ddlNetworkExpert").attr("multiple", "multiple");
    $('#ddlNetworkExpert').multiselect({
        includeSelectAllOption: false,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        buttonWidth: '250px',
        onChange: function (option, checked) {
            var value = $('#ddlNetworkExpert').val().toString();
            $("#hdnNetworkExpert").val(value);
        }

    });
    $("#ddlNetworkExpert").multiselect('clearSelection');

    // Binding data in update mode
    var NetworkExpert = $("#hdnNetworkExpert").val();
    if (NetworkExpert != "") {
        var arrObj = NetworkExpert.split(',');
        $('#ddlNetworkExpert').multiselect('select', arrObj);
    }   

    // CSS for hiding the search icon on search button
   // $('.input-group-addon').css('display', 'none');
    $('.multiselect-clear-filter').css('display', 'none');
   // $('.caret').css('display', 'none');
    $('.multiselect-search').css('width', '97%');
}



function Getprofile() {
   
    $.ajax({ 
        url: "https://server-nodejs-api-rsm-dev.apps.ocp.amat.com/SMAPI/apps/CheckRAMProfileForUser/X099020",
        type: "GET",
        headers: {
            "accept": "application/json;odata=verbose",
        },
        success: function (data) {
            console.log(data);
        },
        error: function (error) {
            alert(JSON.stringify(error) + "Getprofile");
        }
    });
}

