﻿using AMAT.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMAT.CIFWeb.Pages
{
    public partial class Test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static List<string> GetEquipmentNumbers(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {
                BLL obj = new BLL();
                DataTable dtEquipment = obj.GetAllEquipmentNo(values);

                foreach (DataRow row in dtEquipment.Rows)
                {
                    objlist.Add(Convert.ToString(row["AssemblyInfo"]));
                }
            }
            return objlist;
        }

    }
}