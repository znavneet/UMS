﻿using AMAT.BAL;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMAT.CIFWeb.Pages
{
    public partial class ImportantLinks : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           // UserSecurityCheck();
            GetImpLinks();
        }


        public void GetImpLinks()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                Web web = clientContext.Web;
                clientContext.Load(web);
                clientContext.ExecuteQuery();
                clientContext.Load(web.CurrentUser);
                clientContext.ExecuteQuery();
                userName.InnerText = web.CurrentUser.Title;

                List listDashbaord = clientContext.Web.Lists.GetByTitle(Common.ImportantLinks);
                CamlQuery query = CamlQuery.CreateAllItemsQuery();
                Microsoft.SharePoint.Client.ListItemCollection items = listDashbaord.GetItems(query);
                clientContext.Load(items);
                clientContext.ExecuteQuery();

                if (items != null && items.Count > 0)
                {
                    List<DashboardName> objList = new List<DashboardName>();

                    string liHTML = "<ul>";

                    for (int i = 0; i < items.Count; i++)
                    {
                        string name = Convert.ToString(items[i]["Name"]);
                        string URL = Convert.ToString(items[i]["URL"]);

                        liHTML += "<li><a href='" + URL + "' target='_blank'>" + name + "</a></li>";

                        //if (i % 3 == 0 && i > 0)
                        //{
                        //    liHTML += "</ul><ul>";
                        //    implinks.InnerHtml = liHTML;

                        //}
                        

                    }
                    liHTML += "</ul>";
                    implinks.InnerHtml = liHTML;
                }

            }
        }
        protected void lnkCif_Click(object sender, EventArgs e)
        {
            string path = "../Pages/CIF-Form.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void lnkSearch_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Search.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void lnkDashboard_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Dashboard.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void btnDashboard_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Dashboard.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }
        //public void UserSecurityCheck()
        //{
        //    var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
        //    using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
        //    {
        //        Web web = clientContext.Web;
        //        User user = web.CurrentUser;
        //        clientContext.Load(web);
        //        clientContext.ExecuteQuery();
        //        clientContext.Load(user);
        //        clientContext.ExecuteQuery();
        //        string username = user.Title;
        //        userName.InnerText = username;

        //        if (!string.IsNullOrEmpty(username))
        //        {
        //            List list = web.Lists.GetByTitle(Common.SecurityList);
        //            var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Employee' /><Value Type='User'>" + username + "</Value></Eq></Where></Query></View>" };
        //            Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
        //            clientContext.Load(items);
        //            clientContext.ExecuteQuery();

        //            if (items != null && items.Count > 0)
        //            {
        //                mainPnl.Visible = true;
        //                AccessSpan.Visible = false;
        //                foreach (Microsoft.SharePoint.Client.ListItem item in items)
        //                {
        //                    bool isPowerAccess = Convert.ToBoolean(item["CreateUpdateDelete"]);
        //                    if (isPowerAccess)
        //                    {

        //                        lnkCif.Visible = true;
        //                        lnkDashboard.Visible = true;
        //                        lnkSearch.Visible = true;
        //                        break;
        //                    }

        //                    bool isViewAccess = Convert.ToBoolean(item["View"]);
        //                    bool isDashbaordAccess = Convert.ToBoolean(item["Dashboard"]);
        //                    if (isViewAccess && isDashbaordAccess)
        //                    {
        //                        lnkCif.Visible = false;

        //                    }
        //                    if (isViewAccess && !isDashbaordAccess)
        //                    {
        //                        lnkCif.Visible = false;
        //                        lnkDashboard.Visible = false;

        //                    }
        //                    if (!isViewAccess && isDashbaordAccess)
        //                    {
        //                        lnkCif.Visible = false;
        //                        lnkSearch.Visible = false;
        //                        lnkDashboard.Visible = true;

        //                    }
        //                }
        //            }
        //            else
        //            {
        //                mainPnl.Visible = false;
        //                AccessSpan.Visible = true;
        //                hdnAccessValidation.Value = "true";
        //            }
        //        }

        //    }
        //}

        protected void lnkLinks_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Default.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }
       
    }
}