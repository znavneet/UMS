﻿using AMAT.BAL;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMAT.CIFWeb.Pages
{
    public partial class Dashboard : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            UserSecurityCheck();
            GetDasboardsList();
        }
        [WebMethod]
        public static List<DashboardName> GetDashboardList()
        {
            List<DashboardName> objList = (List<DashboardName>)HttpContext.Current.Session["DashboardObj"];
            return objList;
        }

        public void GetDasboardsList()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                Web web = clientContext.Web;
                clientContext.Load(web);
                clientContext.ExecuteQuery();
                clientContext.Load(web.CurrentUser);
                clientContext.ExecuteQuery();
                userName.InnerText = web.CurrentUser.Title;

                List listDashbaord = clientContext.Web.Lists.GetByTitle(Common.DashboardList);
                CamlQuery query = CamlQuery.CreateAllItemsQuery();
                Microsoft.SharePoint.Client.ListItemCollection items = listDashbaord.GetItems(query);
                clientContext.Load(items);
                clientContext.ExecuteQuery();
                
                if (items != null && items.Count > 0)
                {
                    List<DashboardName> objList = new List<DashboardName>();
                 
                    string liHTML = "<ul><li class='header-menu'></li>";
                    liHTML += "<li class='header-menu'><a href='#'><i class='fa fa-tachometer-alt'></i><span>Dashbaord</span></a>";
                    liHTML += "<div class='sidebar-submenu' style='display: block;'><ul>";

                    Microsoft.SharePoint.Client.ListItem itemfirst = items[0];
                    frameReport.Src = Convert.ToString(itemfirst["URL"]);

                    foreach (Microsoft.SharePoint.Client.ListItem item in items)
                    {
                        string name = Convert.ToString(item["Title"]);
                        string URL = Convert.ToString(item["URL"]);

                        liHTML += "<li><a href='Javascript:RefreshDashboard(" + URL + ")'>" + name + "</a></li>";
                        
                        DashboardName obj = new DashboardName();
                        obj.Name = name;
                        obj.URL = URL;
                        objList.Add(obj);                      

                    }
                    Session["DashboardObj"] = objList; 
                    liHTML += "</ul>";
                  //  sideMenu.InnerHtml = liHTML;
                }
              
            }
        }
        protected void lnkCif_Click(object sender, EventArgs e)
        {
            string path = "../Pages/CIF-Form.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void lnkSearch_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Search.aspx?";

            if (Page.ClientQueryString.Contains("ID"))
            {
                int position = Page.ClientQueryString.IndexOf("ID") - 1;
                string qrystring = Page.ClientQueryString.Remove(position);
                path = "../Pages/Search.aspx?" + qrystring;
            }
            else
            {
                path += Page.ClientQueryString;
            }
            Response.Redirect(path);
        }

        protected void lnkDashboard_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Dashboard.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }
        protected void imgLogobtn_Click(object sender, ImageClickEventArgs e)
        {
            string path = "../Pages/Default.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }
        public void UserSecurityCheck()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                Web web = clientContext.Web;
                User user = web.CurrentUser;
                clientContext.Load(web);
                clientContext.ExecuteQuery();
                clientContext.Load(user);
                clientContext.ExecuteQuery();
                string username = user.Title;
                userName.InnerText = username;

                DataTable roleDt = IsUserProfileExistsInRAM(username);
                if (roleDt != null && roleDt.Rows.Count > 0)
                {
                    string roleName = Convert.ToString(roleDt.Rows[0]["ROLENAME"]);

                    if (!string.IsNullOrEmpty(username))
                    {
                        List list = web.Lists.GetByTitle(Common.SecurityList);
                        var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Roles' /><Value Type='Text'>" + roleName + "</Value></Eq></Where></Query></View>" };

                        Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                        clientContext.Load(items);
                        clientContext.ExecuteQuery();

                        if (items != null && items.Count > 0)
                        {
                            foreach (Microsoft.SharePoint.Client.ListItem item in items)
                            {
                                bool isCreateAccess = Convert.ToBoolean(item["Create_x0020_Access"]);
                                bool isViewAccess = Convert.ToBoolean(item["View"]);                              
                                bool isDashbaordAccess = Convert.ToBoolean(item["Dashboard"]);
                               
                                if (isViewAccess && isDashbaordAccess)
                                {
                                    CIF_li.Visible = false;
                                }
                                if (isViewAccess && !isDashbaordAccess)
                                {
                                    CIF_li.Visible = false;
                                    dashboard_li.Visible = false;
                                }
                                if (!isViewAccess && isDashbaordAccess)
                                {
                                    CIF_li.Visible = false;
                                    search_li.Visible = false;

                                }
                                if (isCreateAccess)
                                {
                                    CIF_li.Visible = true;
                                    dashboard_li.Visible = true;
                                    search_li.Visible = true;
                                   
                                }
                            }
                        }
                    }

                }
            }
        }


        /// <summary>
        /// New security implementation change.
        /// </summary>
        /// <param name="employeeName"></param>
        /// <returns></returns>
        /// 
        public DataTable IsUserProfileExistsInRAM(string employeeName)
        {
            ADMethods adObj = new ADMethods();
            BLL objBal = new BLL();
            ADMethods.ADAttributes attributes = adObj.GetEmployeeAttributes(employeeName, ADMethods.AdPrpoertyParameters.displayName);
            string empId = attributes.employeeId;
            return objBal.CheckIfUserExistsInRAM(empId);
        }
    }
}