﻿using AMAT.BAL;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMAT.CIFWeb.Pages
{
    public partial class Search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UserSecurityCheck();
            if (!IsPostBack)
                GetSearchDropDown();
        }

        #region All Main function, check permision, bind search etc

        public void GetSearchDropDown()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    BLL obj = new BLL();
                    DataTable dtproduct = obj.GetAllAmatProduct();

                    ddlProduct.DataTextField = "AMAT_Product";
                    ddlProduct.DataValueField = "AMAT_Product";
                    ddlProduct.DataSource = dtproduct;
                    ddlProduct.DataBind();

                    DataSet ds = obj.GetAllBooks(hdnEmpId.Value);

                    DataTable dtblackbook = ds.Tables[0]; //Blackbook region
                    ddlblackbook.DataTextField = "BLACKBOOK";
                    ddlblackbook.DataValueField = "BLACKBOOK";
                    ddlblackbook.DataSource = dtblackbook;
                    ddlblackbook.DataBind();
                    ddlblackbook.Items.Insert(0, "--Select--");

                    DataTable dtBluebook = ds.Tables[1]; //Bluebook
                    ddlbluebook.DataTextField = "BLUEBOOK";
                    ddlbluebook.DataValueField = "BLUEBOOK";
                    ddlbluebook.DataSource = dtBluebook;
                    ddlbluebook.DataBind();
                    ddlbluebook.Items.Insert(0, "--Select--");

                    DataTable dtgreenkbook = ds.Tables[2]; //Greenbook
                    ddlGreen.DataTextField = "GREENBOOK";
                    ddlGreen.DataValueField = "GREENBOOK";
                    ddlGreen.DataSource = dtgreenkbook;
                    ddlGreen.DataBind();
                    ddlGreen.Items.Insert(0, "--Select--");



                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "GetSearchDropDown", "Search.aspx");
                }
            }
        }

        public void BindSearchResult()
        {
            string isViewAll = string.Empty;
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    string region = ddlblackbook.SelectedIndex == 0 ? string.Empty : ddlblackbook.SelectedItem.Text;
                    string bluebook = ddlbluebook.SelectedIndex == 0 ? string.Empty : ddlbluebook.SelectedItem.Text;
                    string greenbook = ddlGreen.SelectedIndex == 0 ? string.Empty : ddlGreen.SelectedItem.Text;
                    string CIF_ID = txtCIF_Id.Value;
                    string tool_ID = Common.GetIDfromString(txtTool_ID.Value);
                    string products = hdnProducts.Value;

                    if (string.IsNullOrEmpty(region) && string.IsNullOrEmpty(bluebook) && string.IsNullOrEmpty(greenbook) && string.IsNullOrEmpty(CIF_ID) &&
                        string.IsNullOrEmpty(tool_ID) && string.IsNullOrEmpty(products))
                        isViewAll = "Yes";
                    else
                        isViewAll = "No";

                    DataTable filterdt = CheckForUserAccess(CIF_ID, tool_ID, products, isViewAll, region, bluebook, greenbook); // check for user permission
                    gridDiv.Visible = true;
                    grdHistory.DataSource = filterdt;
                    grdHistory.DataBind();
                    Session["Filterdt"] = filterdt;

                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "BindSearchResult", "Search.aspx");
                }
            }
        }

        public void UserSecurityCheck()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                Web web = clientContext.Web;
                User user = web.CurrentUser;
                clientContext.Load(web);
                clientContext.ExecuteQuery();
                clientContext.Load(user);
                clientContext.ExecuteQuery();
                string username = user.Title;
                userName.InnerText = username;

                DataTable roleDt = IsUserProfileExistsInRAM(username);
                if (roleDt != null && roleDt.Rows.Count > 0)
                {
                    string roleName = Convert.ToString(roleDt.Rows[0]["ROLENAME"]);
                    ViewState["Role"] = roleName;

                    if (!string.IsNullOrEmpty(username))
                    {
                        List list = web.Lists.GetByTitle(Common.SecurityList);
                        var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Roles' /><Value Type='Text'>" + roleName + "</Value></Eq></Where></Query></View>" };
                        Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                        clientContext.Load(items);
                        clientContext.ExecuteQuery();

                        if (items != null && items.Count > 0)
                        {
                            foreach (Microsoft.SharePoint.Client.ListItem item in items)
                            {
                                Session["DeleteAccess"] = false;

                                bool isCreateAccess = Convert.ToBoolean(item["Create_x0020_Access"]);
                                bool isViewAccess = Convert.ToBoolean(item["View"]);
                                bool isEditAccess = Convert.ToBoolean(item["Edit_x0020_Access"]);
                                bool isDashbaordAccess = Convert.ToBoolean(item["Dashboard"]);


                                if (isViewAccess && isDashbaordAccess)
                                {
                                    CIF_li.Visible = false;
                                    dashboard_li.Visible = true;
                                }
                                if (isViewAccess && !isDashbaordAccess)
                                {
                                    CIF_li.Visible = false;
                                    dashboard_li.Visible = false;
                                }
                                if (!isViewAccess && isDashbaordAccess)
                                {
                                    CIF_li.Visible = false;
                                    search_li.Visible = false;
                                    dashboard_li.Visible = true;
                                }

                                if (isCreateAccess)
                                {
                                    CIF_li.Visible = true;
                                    search_li.Visible = true;
                                    Session["DeleteAccess"] = true;

                                }
                            }

                            BLL obj = new BLL();
                            DataTable PBGtable = obj.GetPBGforEmplpyee(hdnEmpId.Value);
                            DataTable accountstable = obj.GetCustomersByEmployeeId(hdnEmpId.Value); //("X0103784");
                            Session["PBGTable"] = PBGtable;
                            Session["AccountsTable"] = accountstable;
                        }
                    }
                }
                else
                {
                    string path = "../Pages/Default.aspx?" + Page.ClientQueryString;
                    Response.Redirect(path);
                }

            }
        }

        public DataTable IsUserProfileExistsInRAM(string employeeName)
        {
            ADMethods adObj = new ADMethods();
            BLL objBal = new BLL();
            ADMethods.ADAttributes attributes = adObj.GetEmployeeAttributes(employeeName, ADMethods.AdPrpoertyParameters.displayName);
            string empId = attributes.employeeId;
            hdnEmpId.Value = empId;
            return objBal.CheckIfUserExistsInRAM(empId);
        }

        public DataTable CheckForUserAccess(string CIF_ID, string tool_ID, string products, string isViewAll, string region, string bluebook, string greenbook)
        {
            BLL obj = new BLL();
            DataTable filterTable = null;
            DataRow[] rows = null;
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {

                    string roleName = Convert.ToString(ViewState["Role"]).ToLower();

                    if (roleName == Common.SBURole.ToLower())
                    {
                        string buNamefilter = CheckforMultiplePBG((DataTable)Session["PBGTable"]);  // PBG filter        

                        filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook);
                        rows = filterTable.Select();

                        //if (buNamefilter == "-1")
                        //{
                        //    filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook);
                        //    rows = filterTable.Select();
                        //}
                        //else
                        //{
                        //    filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook); // filteringa and matching the user bu results, if BU and null, show results
                        //    rows = filterTable.Select("BU='" + buNamefilter + "' OR BU is Null");
                        //}
                    }
                    else
                    {
                        if (roleName == Common.FSORole.ToLower())
                        {
                            DataTable dt = (DataTable)Session["AccountsTable"];
                            filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook);

                            if (dt.Rows.Count > 500)
                            {
                                rows = filterTable.Select();
                            }
                            else
                            {
                                string accountFiter = CheckManagedAccount((DataTable)Session["AccountsTable"]);  //customer or managed account filter
                                rows = filterTable.Select(accountFiter);
                            }
                           
                            
                        }
                        else
                        {
                            string buNamefilter = CheckforMultiplePBG((DataTable)Session["PBGTable"]);  // PBG filter                                                                                                       
                            filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook);
                            rows = filterTable.Select("BU is Not Null");
                        }

                    }
                    //  filterTable.DefaultView.Sort = "BU desc";

                    filterTable = RemoveDuplicateRows(rows, filterTable);
                    filterTable.DefaultView.Sort = "CIF_ID desc";
                    filterTable = filterTable.DefaultView.ToTable();
                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "CheckForUserAccess", "Search.aspx");
                }
            }


            return filterTable;
        }

        public void ResetForm()
        {
            ddlProduct.SelectedIndex = 0;
            ddlblackbook.SelectedIndex = 0;
            ddlbluebook.SelectedIndex = 0;
            ddlGreen.SelectedIndex = 0;

            txtCIF_Id.Value = string.Empty;
            txtTool_ID.Value = string.Empty;
            hdnProducts.Value = string.Empty;
            grdHistory.DataSource = null;
            grdHistory.DataBind();
            gridDiv.Visible = false;
        }

        #endregion

        #region Web methods to populate Cif ids and equipment no
        [WebMethod]
        public static List<string> GetCIF_IDs(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {
                bool isNumber = Regex.IsMatch(values, @"^\d+$");
                BLL obj = new BLL();
                DataTable dtEquipment = obj.GetAllCID_ID(values, isNumber.ToString());
                foreach (DataRow row in dtEquipment.Rows)
                {
                    objlist.Add(Convert.ToString(row["CIF_ID"]));
                }
            }
            return objlist;
        }

        [WebMethod]
        public static List<string> GetEquipmentNumbersOnSearch(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {
                BLL obj = new BLL();
                DataTable dtEquipment = obj.GetAllEquipmentNoSearch(values);
                foreach (DataRow row in dtEquipment.Rows)
                {
                    objlist.Add(Convert.ToString(row["EquipmentDesc"]));
                }
            }
            return objlist;
        }

        #endregion

        //protected void lnkdelete_Click(object sender, EventArgs e)
        //{
        //    LinkButton lnk = (LinkButton)sender;
        //    string id = Convert.ToString(lnk.CommandArgument);
        //    BLL obj = new BLL();
        //    obj.DeleteRecord(id);
        //    if (Convert.ToString(Session["ViewAll"]) == "Yes")
        //        BindSearchResult("Yes");
        //    else
        //        BindSearchResult("No");
        //}

        #region  PBG Filter managed account/ Customer filter common fn
        public string CheckforMultiplePBG(DataTable userPBG)
        {
            string filter = string.Empty;
            foreach (DataRow row in userPBG.Rows)
            {
                string sbuValue = Convert.ToString(row["PBG"]);
                if (!string.IsNullOrEmpty(sbuValue))
                    filter += "BU like '" + sbuValue + "' or ";
            }
            // string filter = "BU like 'dcvd' or BU like 'etch' Or BU like'mdp' or BU is Null";     

            if (!string.IsNullOrEmpty(filter))
            {
                filter = filter.Remove(filter.Length - 3, 3);
                filter += "BU is Null";
            }
            return filter.TrimEnd();
        }

        //managed account/ Customer filter
        public string CheckManagedAccount(DataTable accounts)
        {
            string filter = string.Empty;
            foreach (DataRow row in accounts.Rows)
            {
                string accountValue = Convert.ToString(row["Customer"]);
                if (!string.IsNullOrEmpty(accountValue))
                {
                    if (accountValue.Contains('\''))
                    {
                        accountValue = accountValue.Replace("'", "");
                    }

                    filter += "Managed_Account like '" + accountValue + "' or ";
                }
            }
            if (!string.IsNullOrEmpty(filter))
                filter = filter.Remove(filter.Length - 3, 3);

            return filter.TrimEnd();
        }

        public DataTable RemoveDuplicateRows(DataRow[] dt, DataTable resultDt)
        {
            DataTable filterTable = new DataTable();
            filterTable = resultDt.Clone();
            foreach (DataRow row in dt)
            {
                string id = Convert.ToString(row["CIF_ID"]);
                DataRow[] rows = filterTable.Select("CIF_ID='" + id + "'");
                if (rows.Length == 0)
                {
                    filterTable.ImportRow(row);
                }
            }
            return filterTable;
        }
        #endregion

        #region All Button events

        protected void lnkCif_Click(object sender, EventArgs e)
        {
            string path = "../Pages/CIF-Form.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void lnkSearch_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Search.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void lnkDashboard_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Dashboard.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void lnkNavbtn_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            string id = Convert.ToString(lnk.CommandArgument);
            string cifPage = "../Pages/CIF-Form.aspx?" + Page.ClientQueryString + "&ID=" + Convert.ToString(id);
            Response.Redirect(cifPage);
        }

        protected void imgLogobtn_Click(object sender, ImageClickEventArgs e)
        {
            if (Page.Request.QueryString["ID"] != null)
            {
                string path = "../Pages/Default.aspx?" + Page.ClientQueryString;
                if (path.Contains("ID"))
                {
                    path = path.Split('_')[0];
                    path = path.Substring(0, path.Length - 7);
                    Response.Redirect(path);
                }
            }
            else
            {
                string path = "../Pages/Default.aspx?" + Page.ClientQueryString;
                Response.Redirect(path);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Session["ViewAll"] = "No";
            //  BindSearchResult("No");
            BindSearchResult();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        protected void grdHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdHistory.PageIndex = e.NewPageIndex;
            DataTable dt = (DataTable)Session["Filterdt"];
            grdHistory.DataSource = dt;
            grdHistory.DataBind();
            //if (Convert.ToString(Session["ViewAll"]) == "Yes")
            //    BindSearchResult("Yes");
            //else
            //    BindSearchResult("No");
        }

        #endregion

        public void ErrorLog(ClientContext clientContext, string errorMessage, string source, string method, string pageName)
        {

            List logList = clientContext.Web.Lists.GetByTitle("ErrorLogList");
            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
            Microsoft.SharePoint.Client.ListItem item = logList.AddItem(itemCreateInfo);
            item["Message"] = errorMessage;
            item["Source"] = source;
            item["Method"] = method;
            item["PageName"] = pageName;
            item.Update();
            clientContext.ExecuteQuery();

        }

        //protected void grdHistory_RowCreated(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
        //    {
        //        bool delAccessCheck = Convert.ToBoolean(Session["DeleteAccess"]);
        //        if (delAccessCheck)
        //            e.Row.Cells[6].Visible = true; // hides the delete column
        //        else
        //            e.Row.Cells[6].Visible = false;
        //    }
        //}



        //public DataTable CheckForGroupPermission(string CIF_ID, string tool_ID, string products, string isViewAll, string region, string bluebook, string greenbook)
        //{
        //    DataTable filterTable = null;
        //    var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
        //    using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
        //    {
        //        try
        //        {
        //            DataTable userPermission = (DataTable)Session["PBGTable"];
        //            if (userPermission != null && userPermission.Rows.Count > 0)
        //            {
        //                // filterTable = CheckForUserInMultipleRole(userPermission, CIF_ID, tool_ID, products, isViewAll, region, bluebook, greenbook);
        //                filterTable = CheckForUserAccess(userPermission, CIF_ID, tool_ID, products, isViewAll, region, bluebook, greenbook);


        //                //if (userPermission.Rows.Count > 1)
        //                //{
        //                //    filterTable = CheckForUserInMultipleRole(userPermission, CIF_ID, tool_ID, products, isViewAll, region, bluebook, greenbook);
        //                //}
        //                //else
        //                //{
        //                //    filterTable = CheckForUserInSingleRole(userPermission, CIF_ID, tool_ID, products, isViewAll, region, bluebook, greenbook);
        //                //}

        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            ErrorLog(clientContext, ex.Message, ex.Source, "CheckForPermission", "Search.aspx");
        //        }
        //        return filterTable;
        //    }
        //}




        //public DataTable CheckForUserInSingleRole(DataTable userPermission, string CIF_ID, string tool_ID, string products, string isViewAll, string region, string bluebook, string greenbook)
        //{
        //    BLL obj = new BLL();
        //    DataTable filterTable = null;
        //    DataTable allResults = null;
        //    string group = Convert.ToString(userPermission.Rows[0]["Group"]).ToLower();
        //    string sbuName = Convert.ToString(userPermission.Rows[0]["SBUNames"]).ToLower();
        //    string account = Convert.ToString(userPermission.Rows[0]["ManagedAccount"]).ToLower();

        //    if (group == Common.SBURole.ToLower() || group == Common.FSORole.ToLower() || group == Common.BURole.ToLower())
        //    {

        //        if (group == Common.SBURole.ToLower() || group == Common.BURole.ToLower())
        //        {
        //            if (sbuName == Common.All.ToLower())
        //            {
        //                filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook); // getting all results ans filtering it with view all no option 
        //                DataRow[] rows = filterTable.Select();
        //                filterTable = RemoveDuplicateRows(rows, filterTable);
        //            }
        //            else
        //            {
        //                allResults = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook); // filteringa and matching the user bu results, if BU and null, show results
        //                DataRow[] filterRows = allResults.Select("BU='" + sbuName + "' OR BU is Null");
        //                filterTable = RemoveDuplicateRows(filterRows, allResults);
        //            }
        //        }
        //        else if (group == Common.FSORole.ToLower())
        //        {
        //            allResults = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook);
        //            DataRow[] filterRows = allResults.Select("Managed_Account='" + account + "'");
        //            filterTable = RemoveDuplicateRows(filterRows, allResults);
        //        }
        //    }
        //    else
        //    {
        //        filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook);
        //        DataRow[] rows = filterTable.Select("BU is Not Null");
        //        filterTable = RemoveDuplicateRows(rows, filterTable);
        //    }

        //  //  filterTable.DefaultView.Sort = "BU desc";
        //    filterTable.DefaultView.Sort = "CIF_ID desc";
        //    filterTable = filterTable.DefaultView.ToTable();

        //    return filterTable;
        //}


        //public DataTable CheckForUserInMultipleRole(DataTable userPermission, string CIF_ID, string tool_ID, string products, string isViewAll, string region, string bluebook, string greenbook)
        //{
        //    DataTable filterTable = null;
        //    DataTable allResults = null;
        //    string buNamefilter = CheckforMultiplePBG(userPermission);
        //    BLL obj = new BLL();
        //    string group = Convert.ToString(ViewState["Role"]).ToLower();
        //    // string sbuName = Convert.ToString(userPermission.Rows[0]["SBUNames"]).ToLower();
        //    // string account = Convert.ToString(userPermission.Rows[0]["ManagedAccount"]).ToLower();



        //    if (group == Common.SBUGroup.ToLower() || group == Common.FSOGroup.ToLower() || group == Common.BUGroup.ToLower() || group == Common.GFGGroup.ToLower())
        //    {
        //        if (group == Common.SBUGroup.ToLower() || group == Common.BUGroup.ToLower())
        //        {
        //            if (buNamefilter.Contains(Common.All.ToLower()))
        //            {
        //                filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook); // getting all results ans filtering it with view all no option 
        //                DataRow[] rows = filterTable.Select();
        //                filterTable = RemoveDuplicateRows(rows, filterTable);
        //            }
        //            else
        //            {
        //                allResults = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook); // filteringa and matching the user bu results, if BU and null, show results
        //                DataRow[] filterRows = allResults.Select(buNamefilter);
        //                filterTable = RemoveDuplicateRows(filterRows, allResults);
        //            }
        //        }
        //        else if (group == Common.FSOGroup.ToLower() || group == Common.GFGGroup.ToLower())
        //        {
        //            string mngAccountfilter = CheckforMultipleManagedAccount(userPermission);
        //            allResults = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook);
        //            DataRow[] filterRows = allResults.Select(mngAccountfilter);
        //            filterTable = RemoveDuplicateRows(filterRows, allResults);
        //        }
        //    }
        //    else
        //    {
        //        filterTable = obj.GetSearchResults(CIF_ID, tool_ID, products, Common.ProcGetAllResult, isViewAll, region, bluebook, greenbook);
        //        DataRow[] rows = filterTable.Select("BU is Not Null");
        //        filterTable = RemoveDuplicateRows(rows, filterTable);
        //    }

        //   // filterTable.DefaultView.Sort = "BU desc";
        //    filterTable = filterTable.DefaultView.ToTable();

        //    return filterTable;
        //}




        //protected void btnViewAll_Click(object sender, EventArgs e)
        //{
        //    Session["ViewAll"] = "Yes";
        //    ResetForm();
        //    BindSearchResult("Yes");
        //}




    }
}