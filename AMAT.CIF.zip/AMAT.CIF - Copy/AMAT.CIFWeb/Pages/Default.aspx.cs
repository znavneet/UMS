﻿using AMAT.BAL;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.UserProfiles;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AMAT.CIFWeb
{
    public partial class Default : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            UserSecurityCheck();
        }

        //protected void btnSearch_Click(object sender, EventArgs e)
        //{
        //    string path = "../Pages/Search.aspx?" + Page.ClientQueryString;
        //    Response.Redirect(path);
        //}

        //protected void btnCif_Click(object sender, EventArgs e)
        //{
        //    string path = "../Pages/CIF-Form.aspx?" + Page.ClientQueryString;
        //    Response.Redirect(path);
        //}
        protected void lnkCif_Click(object sender, EventArgs e)
        {
            string path = "../Pages/CIF-Form.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void lnkSearch_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Search.aspx?";

            if (Page.ClientQueryString.Contains("ID"))
            {
                int position = Page.ClientQueryString.IndexOf("ID") - 1;
                string qrystring = Page.ClientQueryString.Remove(position);
                path = "../Pages/Search.aspx?" + qrystring;
            }
            else
            {
                path += Page.ClientQueryString;
            }
            Response.Redirect(path);
        }

        protected void lnkDashboard_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Dashboard.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void btnDashboard_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Dashboard.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }
        public void UserSecurityCheck()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                Web web = clientContext.Web;
                User user = web.CurrentUser;
                clientContext.Load(web);
                clientContext.ExecuteQuery();
                clientContext.Load(user);
                clientContext.ExecuteQuery();
                string username = user.Title;
                userName.InnerText = username;
                DataTable roleDt = IsUserProfileExistsInRAM(username);
                if (roleDt !=null && roleDt.Rows.Count > 0)
                {
                    string roleName = Convert.ToString(roleDt.Rows[0]["ROLENAME"]);

                    if (!string.IsNullOrEmpty(username))
                    {
                        List list = web.Lists.GetByTitle(Common.SecurityList);
                        // var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Employee' /><Value Type='User'>" + username + "</Value></Eq></Where></Query></View>" };
                        var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Roles' /><Value Type='Text'>" + roleName + "</Value></Eq></Where></Query></View>" };

                        CamlQuery query1 = CamlQuery.CreateAllItemsQuery();  // get all items

                        Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                        Microsoft.SharePoint.Client.ListItemCollection items1 = list.GetItems(query1);
                        clientContext.Load(items);
                        clientContext.Load(items1);
                        clientContext.ExecuteQuery();

                        if (items != null && items.Count > 0)
                        {
                            mainPnl.Visible = true;
                            AccessSpan.Visible = false;
                            RAMDiv.Visible = false;
                            //DataTable accessDt = GetAccessTable();
                            foreach (Microsoft.SharePoint.Client.ListItem item in items)
                            {
                                bool isCreateAccess = Convert.ToBoolean(item["Create_x0020_Access"]);
                                bool isViewAccess = Convert.ToBoolean(item["View"]);
                                bool isEditAccess = Convert.ToBoolean(item["Edit_x0020_Access"]);
                                bool isDashbaordAccess = Convert.ToBoolean(item["Dashboard"]);

                                if (isViewAccess && isDashbaordAccess)
                                {
                                    lnkCif.Visible = false;
                                }
                                if (isViewAccess && !isDashbaordAccess)
                                {
                                    lnkCif.Visible = false;
                                    lnkDashboard.Visible = false;
                                }
                                if (!isViewAccess && isDashbaordAccess)
                                {
                                    lnkCif.Visible = false;
                                    lnkSearch.Visible = false;
                                    lnkDashboard.Visible = true;
                                }                               
                                if (!isCreateAccess && isEditAccess && isViewAccess)
                                {
                                    lnkCif.Visible = false;
                                    lnkSearch.Visible = true;                                 
                                    lnkDashboard.Visible = true;                                    
                                }
                                if (isCreateAccess)
                                {
                                    lnkCif.Visible = true;
                                    lnkSearch.Visible = true;
                                }
                                if (!isViewAccess && !isDashbaordAccess && !isCreateAccess)
                                {
                                    mainPnl.Visible = false;
                                    AccessSpan.Visible = true;
                                    hdnAccessValidation.Value = "true";
                                }

                                //DataRow row = accessDt.NewRow(); 
                                //row["Role"] = roleName;
                                //row["Create"] = isCreateAccess;
                                //row["Edit"] = isEditAccess;
                                //row["View"] = isViewAccess;
                                //row["Dashboard"] = isDashbaordAccess;
                                //accessDt.Rows.Add(row);

                            }
                          
                        }
                        else
                        {
                            mainPnl.Visible = false;
                            AccessSpan.Visible = true;
                            RAMDiv.Visible = false;
                            hdnAccessValidation.Value = "true";
                        }
                    }
                }
                else
                {
                    mainPnl.Visible = false;
                    AccessSpan.Visible = false;
                    RAMDiv.Visible = true;
                }
            }
        }

       
        //public DataTable GetAccessTable()
        //{
        //    DataTable accessDt = new DataTable();
        //    accessDt.Columns.Add("Role");
        //    accessDt.Columns.Add("Create");
        //    accessDt.Columns.Add("Edit");
        //    accessDt.Columns.Add("View");
        //    accessDt.Columns.Add("Dashboard");
        //    return accessDt;
        //}
        /// <summary>
        /// New security implementation change.
        /// </summary>
        /// <param name="employeeName"></param>
        /// <returns></returns>
        public DataTable IsUserProfileExistsInRAM(string employeeName)
        {           
            ADMethods adObj = new ADMethods();
            BLL objBal = new BLL();
            ramUrl.HRef = objBal.RAMURL;
            ADMethods.ADAttributes attributes = adObj.GetEmployeeAttributes(employeeName, ADMethods.AdPrpoertyParameters.displayName);
            string empId = attributes.employeeId;
            

            return objBal.CheckIfUserExistsInRAM(empId);           
        }

        protected void lnkLinks_Click(object sender, EventArgs e)
        {
            string path = "../Pages/ImportantLinks.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        
    }
}