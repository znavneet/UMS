﻿using AMAT.BAL;
using Microsoft.SharePoint.Client;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Services;
using System.Web.UI;


namespace AMAT.CIFWeb.Pages
{
    public partial class CIF_Form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                UserSecurityCheck();
                LoadAGSPillersSurfaceDropdown();
                BindBUDropdown();
                GetInternalFundedOrderNo();

                if (Page.Request.QueryString["ID"] != null)
                {
                    string cifId = Page.Request.QueryString["ID"];
                    btnUpdate.Visible = true;
                    btnDiscard.Visible = true;
                    btnSubmit.Visible = false;
                    btnReset.Visible = false;
                    UpdateMode(cifId);
                }
                else
                {
                    GetNewCiFId();
                }
            }

        }

        public void LoadAGSPillersSurfaceDropdown()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                List listDigital = clientContext.Web.Lists.GetByTitle(Common.DigitalTool);
                List listSurface = clientContext.Web.Lists.GetByTitle(Common.SurfaceTechnology);
                CamlQuery query1 = CamlQuery.CreateAllItemsQuery();
                CamlQuery query2 = CamlQuery.CreateAllItemsQuery();
                Microsoft.SharePoint.Client.ListItemCollection items1 = listDigital.GetItems(query1);
                Microsoft.SharePoint.Client.ListItemCollection items2 = listSurface.GetItems(query2);

                clientContext.Load(items1);
                clientContext.Load(items2);
                clientContext.ExecuteQuery();
                clientContext.ExecuteQuery();

                hdnSiteUrl.Value = clientContext.Url;

                if (items1 != null)
                {
                    ddlFSSfeatures.Items.Clear();
                    ddlFSSAdvFeatures.Items.Clear();
                    dllDashboard.Items.Clear();
                    ddlMetro.Items.Clear();
                    ddlSensorWafers.Items.Clear();
                    foreach (Microsoft.SharePoint.Client.ListItem item in items1)
                    {

                        string fSSBasicFeatures = Convert.ToString(item["Title"]);
                        if (!string.IsNullOrEmpty(fSSBasicFeatures))
                            ddlFSSfeatures.Items.Add(new System.Web.UI.WebControls.ListItem(fSSBasicFeatures, fSSBasicFeatures));

                        string fSSAdvFeatures = Convert.ToString(item["FSS_x0020_Advanced_x0020_Feature"]);
                        if (!string.IsNullOrEmpty(fSSAdvFeatures))
                            ddlFSSAdvFeatures.Items.Add(new System.Web.UI.WebControls.ListItem(fSSAdvFeatures, fSSAdvFeatures));

                        string Dashboards = Convert.ToString(item["Dashboards"]);
                        if (!string.IsNullOrEmpty(Dashboards))
                            dllDashboard.Items.Add(new System.Web.UI.WebControls.ListItem(Dashboards, Dashboards));

                        string HandheldMetro = Convert.ToString(item["Handheld_x0020_Metro"]);
                        if (!string.IsNullOrEmpty(HandheldMetro))
                            ddlMetro.Items.Add(new System.Web.UI.WebControls.ListItem(HandheldMetro, HandheldMetro));

                        string SensorWafers = Convert.ToString(item["Sensor_x0020_Wafers"]);
                        if (!string.IsNullOrEmpty(SensorWafers))
                            ddlSensorWafers.Items.Add(new System.Web.UI.WebControls.ListItem(SensorWafers, SensorWafers));
                    }
                }
                //Surface Technology Dropdowns
                ddlCleaningMethod.Items.Clear();
                ddlCoating.Items.Clear();
                ddlInspectionMetrology.Items.Clear();
                ddlTexturing.Items.Clear();
                if (items2 != null)
                {
                    foreach (Microsoft.SharePoint.Client.ListItem item in items2)
                    {
                        string CleaningMethod = Convert.ToString(item["Cleaning_x0020_method"]);
                        if (!string.IsNullOrEmpty(CleaningMethod))
                            ddlCleaningMethod.Items.Add(new System.Web.UI.WebControls.ListItem(CleaningMethod, CleaningMethod));

                        string coating = Convert.ToString(item["Coating"]);
                        if (!string.IsNullOrEmpty(coating))
                            ddlCoating.Items.Add(new System.Web.UI.WebControls.ListItem(coating, coating));

                        string inspectionMetrology = Convert.ToString(item["Inspection_x0020_Metrology"]);
                        if (!string.IsNullOrEmpty(CleaningMethod))
                            ddlInspectionMetrology.Items.Add(new System.Web.UI.WebControls.ListItem(inspectionMetrology, inspectionMetrology));

                        string texturing = Convert.ToString(item["Texturing"]);
                        if (!string.IsNullOrEmpty(texturing))
                            ddlTexturing.Items.Add(new System.Web.UI.WebControls.ListItem(texturing, texturing));
                    }
                }
            }

        }

        /// <summary>
        /// Genarating new CIF Id
        /// </summary>
        public string GetNewCiFId()
        {
            string cifID = string.Empty;
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    BLL obj = new BLL();
                    cifID = obj.GetNewCIFId();
                    lblCIFID.InnerText = cifID;
                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "InsertCIFData", "CIF-Form.aspx");
                }
            }
            return cifID;
        }

        #region All Web method

        [WebMethod]
        public static List<TambaDetails> GetTambaBuProductDetails(string values)
        {
            List<TambaDetails> objlist = new List<TambaDetails>();
            if (!string.IsNullOrEmpty(values))
            {
                string[] tambaIds = values.Split(',');
                BLL objBll = new BLL();
                DataTable tambaInfoDt = (DataTable)HttpContext.Current.Session["TambaDetails"];

                if (tambaInfoDt == null)
                {
                    tambaInfoDt = new DataTable();
                    foreach (string str in values.Split(','))
                    {
                        DataTable dt = new DataTable();
                        dt = objBll.GetTambaDetails(str);
                        tambaInfoDt.Merge(dt);
                    }
                }

                DataTable newDt = new DataTable();
                if (tambaInfoDt != null && tambaInfoDt.Rows.Count > 0)
                {
                    newDt = tambaInfoDt.Clone();
                    foreach (string id in tambaIds)
                    {
                        DataRow[] rows = tambaInfoDt.Select("TAMBA_ID='" + id + "'");
                        if (rows != null && rows.Length > 0)
                        {
                            TambaDetails obj = GetRow(rows[0]);
                            objlist.Add(obj);
                        }
                    }
                }
            }
            return objlist;
        }

        [WebMethod]
        public static List<string> GetEquipmentNumbers(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {
                BLL obj = new BLL();
                DataTable dtEquipment = obj.GetAllEquipmentNo(values);

                foreach (DataRow row in dtEquipment.Rows)
                {
                    objlist.Add(Convert.ToString(row["AssemblyInfo"]));
                }
            }
            return objlist;
        }


        [WebMethod]
        public static List<EquipmentDetails> GetEquipmentDetailfromToolSerialNo(string assemblyNo)
        {
            List<EquipmentDetails> objlist = new List<EquipmentDetails>();
            string toolSerialNo = string.Empty;
            if (!string.IsNullOrEmpty(assemblyNo))
            {
                BLL obj = new BLL();
                EquipmentDetails objEquipment = new EquipmentDetails();
                DataTable dt = obj.GetEquipmentDetailsFromToolSerialNo(assemblyNo);
                if (dt != null && dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    objEquipment.MajorAssembly = Convert.ToString(row["AssemblyNo"]);
                    objEquipment.SerialNo = Convert.ToString(row["Serial"]);
                    objEquipment.Platform = Convert.ToString(row["Platform"]);
                    objEquipment.Customer = Convert.ToString(row["Customer"]);
                    objEquipment.Region = Convert.ToString(row["Region"]);
                    objEquipment.Fab = Convert.ToString(row["Fab"]);
                    objEquipment.PBG = Convert.ToString(row["PBG"]);
                    objEquipment.KPU = Convert.ToString(row["KPU"]);
                    objEquipment.ToolShipDate = Convert.ToString(row["Ship Date"]);
                    objEquipment.Contract = Convert.ToString(row["Contract"]);
                    objlist.Add(objEquipment);
                }

            }
            return objlist;
        }

        [WebMethod]
        public static List<EquipmentDetails> GetEquipmentDetailfromToolSerialNoInUpdateMode(string assemblyNo)
        {
            List<EquipmentDetails> objlist = new List<EquipmentDetails>();
            string toolSerialNo = string.Empty;
            if (!string.IsNullOrEmpty(assemblyNo))
            {
                BLL obj = new BLL();

                DataTable dt = obj.GetEquipmentDetailFromToolSerialinUpdatemode(assemblyNo);
                if (dt != null && dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        DataRow row = dt.Rows[i];
                        EquipmentDetails objEquipment = new EquipmentDetails();
                        objEquipment.MajorAssembly = Convert.ToString(row["AssemblyNo"]);
                        objEquipment.SerialNo = Convert.ToString(row["Serial"]);
                        objEquipment.Platform = Convert.ToString(row["Platform"]);
                        objEquipment.Customer = Convert.ToString(row["Customer"]);
                        objEquipment.Region = Convert.ToString(row["Region"]);
                        objEquipment.Fab = Convert.ToString(row["Fab"]);
                        objEquipment.PBG = Convert.ToString(row["PBG"]);
                        objEquipment.KPU = Convert.ToString(row["KPU"]);
                        objEquipment.ToolShipDate = Convert.ToString(row["Ship Date"]);
                        objEquipment.Contract = Convert.ToString(row["Contract"]);
                        objlist.Add(objEquipment);
                    }
                }

            }
            return objlist;
        }

        [WebMethod]
        public static List<string> GetMaterialNumbers(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {
                BLL obj = new BLL();
                DataTable dtMaterial = obj.GetMaterialNo(values);

                foreach (DataRow row in dtMaterial.Rows)
                {
                    objlist.Add(Convert.ToString(row["Materialdesc"]));
                }
            }
            return objlist;
        }

        [WebMethod]
        public static List<string> GetContractId(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {

                BLL obj = new BLL();
                DataTable dtMaterial = obj.GetContractID(values);
                foreach (DataRow row in dtMaterial.Rows)
                {
                    objlist.Add(Convert.ToString(row["ContractID"]));
                }
            }
            return objlist;
        }

        [WebMethod]
        public static List<string> GetFabLocation(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {
                bool isNumber = Regex.IsMatch(values, @"^\d+$");
                BLL obj = new BLL();
                DataTable dtMaterial = obj.GetFabLocation(values, isNumber.ToString());
                foreach (DataRow row in dtMaterial.Rows)
                {
                    objlist.Add(Convert.ToString(row["FabLocation"]));
                }
            }
            return objlist;
        }

        [WebMethod]
        public static List<string> GetProduct(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {
                BLL obj = new BLL();
                DataTable dt = obj.GetProductDetail(values);
                dt = dt.DefaultView.ToTable(true);
                if (dt != null && dt.Rows.Count > 0)
                {
                    dt = dt.Rows.Cast<DataRow>().Where(row => !row.ItemArray.All(field => field is DBNull || string.IsNullOrWhiteSpace(field as string)))
                   .CopyToDataTable();
                    foreach (DataRow row in dt.Rows)
                        objlist.Add(Convert.ToString(row["AMAT_Product"]));
                }
            }
            return objlist;
        }
        [WebMethod]
        public static List<string> GetTambaNoMultiselectProduct(string values)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(values))
            {
                BLL obj = new BLL();
                DataTable dt = obj.GetTambaNoMultiSelectProuct(values);
                if (dt != null && dt.Rows.Count > 0)
                {
                    dt = dt.Rows.Cast<DataRow>().Where(row => !row.ItemArray.All(field => field is DBNull || string.IsNullOrWhiteSpace(field as string)))
                   .CopyToDataTable();
                    foreach (DataRow row in dt.Rows)
                        objlist.Add(Convert.ToString(row["TAMBA_ID"]));
                }
            }
            return objlist;
        }


        [WebMethod]
        public static List<string> GetTambaDetail(string BU, string Product)
        {
            List<string> objlist = new List<string>();
            if (!string.IsNullOrEmpty(Product))
            {
                BLL obj = new BLL();
                DataTable dt = obj.GetTambNos(BU, Product);
                if (dt != null && dt.Rows.Count > 0)
                {
                    HttpContext.Current.Session["TambaDetails"] = dt;

                    dt = dt.Rows.Cast<DataRow>().Where(row => !row.ItemArray.All(field => field is DBNull || string.IsNullOrWhiteSpace(field as string)))
                   .CopyToDataTable();
                    foreach (DataRow row in dt.Rows)
                        objlist.Add(Convert.ToString(row["TAMBA_ID"]));
                }
            }
            return objlist;
        }

        [WebMethod]
        public static List<UserProperty> GetADUsers(string username)
        {
            List<UserProperty> lstADUsers = new List<UserProperty>();

            if (!string.IsNullOrEmpty(username))
            {
                using (PrincipalContext context = new PrincipalContext(ContextType.Domain))
                {
                    UserPrincipal user = new UserPrincipal(context);
                    user.DisplayName = username + "*";
                    using (PrincipalSearcher srch = new PrincipalSearcher(user))
                    {
                        int i = 0;
                        foreach (var result in srch.FindAll())
                        {
                            DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;
                            if (!String.IsNullOrEmpty((String)de.Properties["displayName"].Value))
                            {
                                i++;
                                UserProperty usp = new BAL.UserProperty();
                                usp.UserName = de.Properties["displayName"].Value.ToString();
                                if (de.Properties["EmployeeId"].Value != null)
                                    usp.EmpId = de.Properties["EmployeeId"].Value.ToString();
                                else
                                    usp.EmpId = string.Empty;

                                lstADUsers.Add(usp);
                                if (i == 10) break;

                            }
                        }
                    }
                }
            }
            return lstADUsers;
        }

        #endregion

        public static TambaDetails GetRow(DataRow row)
        {
            TambaDetails obj = new TambaDetails();
            obj.TAMBA_ID = Convert.ToString(row["TAMBA_ID"]);
            obj.BusinessUnit = Convert.ToString(row["BU"]);
            obj.AmatProduct = Convert.ToString(row["AMAT_Product"]);
            obj.PTORDate = Convert.ToString(row["PTOR_Date"]);
            obj.TAMBAStatus = Convert.ToString(row["TAMBA_Status"]);
            obj.ManagedAccount = Convert.ToString(row["Managed_Account"]);
            return obj;
        }

        #region insert update main data
        /// <summary>
        /// Inserting form data into CIF DB
        /// </summary>
        public void InsertUpdateData(string CIF_ID, string procedureName)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    BLL obj = new BLL();
                    //  string CIF_ID = lblCIFID.InnerText;
                    string CIFBenefitsYield = rdBenefits.SelectedItem.Text;
                    string CIFBenifitsOutput = rdBenefitsOut.SelectedItem.Text;
                    string CIFBenifitsCost = rdBenefitsCost.SelectedItem.Text;
                    string FY20CIFStatus = ddlCIFStatus.SelectedItem.Text != "Select" ? ddlCIFStatus.SelectedItem.Text : string.Empty;
                    string CIFTypeNew = ddlCIFType.SelectedItem.Text != "Select" ? ddlCIFType.SelectedItem.Text : string.Empty;
                    string CIFStartDate = txtCIFStartDate.Value != string.Empty ? Convert.ToDateTime(txtCIFStartDate.Value).ToString("MM-dd-yyyy") : string.Empty;
                    string CIFActualClosuredate = txtActCloseDate.Value != string.Empty ? Convert.ToDateTime(txtActCloseDate.Value).ToString("MM-dd-yyyy") : string.Empty;
                    string CIFBudget = txtBudget.Value;
                    // string FabLocation = txtFabLocation.Value == "" ? "" : txtFabLocation.Value.Split(':')[0].ToString();
                    string FabLocation = string.Empty;
                    string ELSNPI = rdELS.SelectedItem.Text;
                    // string ToolChamberShipped = rdToolChanber.SelectedItem.Text;
                    string ToolChamberShipped = string.Empty;

                    //  string ToolShipDate = txtToolshipDate.Value != string.Empty ? Convert.ToDateTime(txtToolshipDate.Value).ToString("MM-dd-yyyy") : string.Empty;
                    string ToolShipDate = string.Empty;
                    // string ServiceWin = rdServiceWin.SelectedItem.Text;
                    string ServiceWin = string.Empty;
                    string CoOModelExists = rdCoOModalExists.SelectedItem.Text;
                    string SRRExists = rdSRRExists.SelectedItem.Text;
                    string SRRtype = ddlSRRType.SelectedItem.Text != "Select" ? ddlSRRType.SelectedItem.Text : string.Empty;
                    string CoOModelNeedDate = txtCoOModelDate.Value != string.Empty ? Convert.ToDateTime(txtCoOModelDate.Value).ToString("MM-dd-yyyy") : string.Empty;
                    string FSSatMTC = rdFssMTC.SelectedItem.Text;
                    string FSSConAllowCustomer = rdFssConnection.SelectedItem.Text;
                    string IsthereDCP = ddlIsThereDCP.SelectedItem.Text != "Select" ? ddlIsThereDCP.SelectedItem.Text : string.Empty;
                    string FSSStatus = ddlFssStatus.SelectedItem.Text != "Select" ? ddlFssStatus.SelectedItem.Text : string.Empty;
                    string IsCleanSupplierExists = txtCleansupplier.Value == "" ? "No" : "Yes";
                    string IsRepairSupplierExists = txtRepairSupplier.Value == "" ? "No" : "Yes";
                    string IsRefurbSupplierExists = txtRefurbSupplier.Value == "" ? "No" : "Yes";
                    string IsGPSTSupplierExists = txtGPSTSupplier.Value == "" ? "No" : "Yes";
                    string EmployeeName = userName.InnerText;
                    string currentDate = DateTime.Now.ToString("MM-dd-yyyy");
                    string NetworkOfExperts = hdnNetworkExpert.Value;

                    string FSSBasicFeatures = hdnFSSBasicFeatures.Value;
                    string FSSAdvancedFeatures = hdnFSSAdvancedFeatures.Value;
                    string Dashboards = hdnDashboards.Value;
                    string HandheldMetro = hdnHandheldMetro.Value;
                    string SensorWafers = hdnSensorWafers.Value;

                    string Cleaningmethod = hdnCleaningMethod.Value;
                    string Coating = hdnCoating.Value;
                    string Texturing = hdnTexturing.Value;
                    string InspectionMetrology = hdnInspectionMetrology.Value;

                    string CIF_ProjectName = txtProjectName.Value;
                    string DefWinning = txtWinningDefinition.InnerText;
                    string SBU_Owner = txtSbuOwner.Value;
                    string FSO_Owner = txtFsoOwner.Value;
                    string GFG_Owner = txtGfgOwner.Value;
                    string BU_Owner = txtBUOwner.Value;
                    string PlannedInventryInvest = txtPlanningSparesInvestment.Value;
                    string ProjectObjective = txtProjectObjective.Value;
                    string Status = txtStatus.Value;

                    string InternalFundednumber = ddlIFP_number.SelectedItem.Text != "Select" ? ddlIFP_number.SelectedItem.Text : string.Empty;
                    string InternalOrdernumber = ddlIFP_number.SelectedItem.Text != "Select" ? ddlIFP_number.SelectedItem.Value : string.Empty;

                    string cooCommitStatus = ddlCommitStatus.SelectedItem.Text != "Select" ? ddlCommitStatus.SelectedItem.Text : string.Empty;
                    string tool_ASP = txtToolAsp.Value;

                    // Inserting data in manin table in CIF_requests

                    obj.InsertUpdateCIFData(
                             CIF_ID, CIFBenefitsYield, CIFBenifitsOutput, CIFBenifitsCost, FY20CIFStatus, CIFTypeNew, CIFStartDate,
                             CIFActualClosuredate, CIFBudget, FabLocation, ELSNPI, ToolChamberShipped, ToolShipDate,
                             ServiceWin, CoOModelExists, SRRExists, SRRtype, CoOModelNeedDate, FSSatMTC,
                             FSSConAllowCustomer, IsthereDCP, FSSStatus, IsCleanSupplierExists, IsRepairSupplierExists,
                             IsRefurbSupplierExists, IsGPSTSupplierExists, NetworkOfExperts, EmployeeName, currentDate,
                             FSSBasicFeatures, FSSAdvancedFeatures, Dashboards, HandheldMetro,
                             SensorWafers, Cleaningmethod, Coating, Texturing, InspectionMetrology, procedureName,
                             CIF_ProjectName, DefWinning, SBU_Owner, FSO_Owner, GFG_Owner, BU_Owner, PlannedInventryInvest, ProjectObjective, Status,
                             InternalFundednumber, InternalOrdernumber, cooCommitStatus, tool_ASP
                        );

                    if (procedureName == Common.InsertCIFData)
                    {

                        InsertOtherData(CIF_ID, obj);
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage1", "AlertCreateMsg('" + lblCIFID.InnerText + "')", true);

                    }
                    else  // for updating
                    {
                        //Delete existing records and update with latest values
                        obj.DeleteDatabeforeUpdating(CIF_ID);
                        InsertOtherData(CIF_ID, obj);
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage2", "AlertUpdateMsg('" + lblCIFID.InnerText + "')", true);
                    }


                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "InsertUpdateData", "CIF-Form.aspx");
                }
            }

        }

        #endregion

        #region Insert other table data
        public void InsertOtherData(string CIF_ID, BLL obj)
        {
            string[] supplierArray = { Common.CleanSupplier, Common.RepairSupplier, Common.RefurbSupplier, Common.GPSTSupplier, Common.Others };
            string[] supplierValuesArray = { txtCleansupplier.Value, txtRepairSupplier.Value, txtRefurbSupplier.Value, txtGPSTSupplier.Value, txtOthers.Value };

            // insert/update supplier data
            for (int i = 0; i < supplierArray.Length; i++)
            {
                if (!string.IsNullOrEmpty(supplierValuesArray[i]))
                    InsertSupplierData(CIF_ID, supplierArray[i], Common.GetIDfromString(supplierValuesArray[i]));
            }
            //insert/update contract ids
            obj.InsertContractIdData(CIF_ID, Common.GetIDfromString(txtContractID.Value));

            // insert/update tambaid
            obj.InsertTambaData(CIF_ID, Common.GetIDfromString(hdnTambaIds.Value));

            // insert/update tool id
            // obj.InsertToolData(CIF_ID, Common.GetIDfromString(txtCIFToolId.Value));
            obj.InsertToolData(CIF_ID, Common.GetIDfromString(hdnCIFToolID.Value));

            // inserting assembly info
            obj.InsertAssemblyInfo(CIF_ID, Common.GetAssemblyString(hdnAssemblyNos.Value), Common.GetToolString(hdnAssemblyNos.Value));

            // insert/update tool, planning data(5 box) eg, sbu,fso etc
            // InsertUpdatePlanningToolData(CIF_ID, Common.GetIDfromString(txtCIFToolId.Value));
            InsertUpdatePlanningToolData(CIF_ID, Common.GetIDfromString(hdnCIFToolID.Value));
        }

        /// <summary>
        /// Inserting supplier data,separate table
        /// </summary>
        /// <param name="CIF_ID"></param>
        /// <param name="supplierType"></param>
        /// <param name="supplierValues"></param>
        public void InsertSupplierData(string CIF_ID, string supplierType, string supplierValues)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    BLL obj = new BLL();
                    obj.InsertSupplierData(CIF_ID, supplierType, supplierValues);
                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "InsertSupplierData", "CIF-Form.aspx");
                }
            }
        }


        /// <summary>
        /// insert/update tool, planning data(5 box) eg, sbu,fso etc
        /// </summary>
        /// <param name="CIf_ID"></param>
        /// <param name="toolSerialIds"></param>
        public void InsertUpdatePlanningToolData(string CIf_ID, string toolSerialIds)
        {
            string values = hdnPlannedValues.Value;
            BLL obj = new BLL();
            if (!string.IsNullOrEmpty(values))
            {
                string[] txtValuesRows = values.Split('|');
                string[] toolValues = toolSerialIds.Split(',');

                if (toolValues != null && toolValues.Length > 0)
                {
                    for (int i = 0; i < toolValues.Length; i++)
                    {
                        string[] arrayVal = txtValuesRows[i].Split('_');
                        string toolserial = toolValues[i].Trim();
                        string sbu = arrayVal[0].Split(':')[1].Trim();
                        string fso = arrayVal[1].Split(':')[1].Trim();
                        string fv = arrayVal[2].Split(':')[1].Trim();
                        string spd = arrayVal[3].Split(':')[1].Trim();
                        string oce = arrayVal[4].Split(':')[1].Trim();

                        obj.UpdateEquipmentPlanned_HCValues(toolserial, sbu, fso, fv, spd, oce, CIf_ID);
                    }
                }
            }
        }
        #endregion


        #region Tamba binding region

        public void BindBUDropdown()
        {
            BLL obj = new BLL();
            DataTable dt = obj.GetBUDetail();
            dt = dt.Rows.Cast<DataRow>().Where(row => !row.ItemArray.All(field => field is DBNull || string.IsNullOrWhiteSpace(field as string)))
            .CopyToDataTable();
            ddlBu.DataTextField = "BU";
            ddlBu.DataValueField = "BU";
            ddlBu.DataSource = dt;
            ddlBu.DataBind();

        }


        #endregion

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string CIF_ID = GetNewCiFId();
            if (!string.IsNullOrEmpty(CIF_ID))
            {
                InsertUpdateData(CIF_ID, Common.InsertCIFData);
                ResetForm();
            }
        }

        public void UpdateMode(string cifNumber)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    BLL obj = new BLL();
                    DataSet ds = obj.GetCIFDetailBySearch(cifNumber);
                    DataTable cifDetailDt = ds.Tables[0];  // cif main table
                    hdnUpdateMode.Value = "UpdateMode";
                    IsupdateMode.Visible = true;
                    if (cifDetailDt != null && cifDetailDt.Rows.Count > 0)
                    {
                        DataRow row = cifDetailDt.Rows[0];
                        lblCIFID.InnerText = Convert.ToString(row["CIF_ID"]);
                        string rdbenValue = Convert.ToString(row["CIF_Benefits_Yield"]);
                        rdBenefits.Items.FindByValue(rdbenValue).Selected = true;

                        string rdbenoutValue = Convert.ToString(row["CIF_Benefits_Output"]);
                        rdBenefitsOut.Items.FindByValue(rdbenoutValue).Selected = true;

                        string rdbenoutCostValue = Convert.ToString(row["CIF_Benefits_Cost"]);
                        rdBenefitsCost.Items.FindByValue(rdbenoutCostValue).Selected = true;

                        string status = Convert.ToString(row["CIF_Status"]);
                        ddlCIFStatus.ClearSelection();
                        if (!string.IsNullOrEmpty(status))
                            ddlCIFStatus.Items.FindByText(status).Selected = true;

                        string CIFType = Convert.ToString(row["CIF_Type_New"]);
                        ddlCIFType.ClearSelection();
                        if (!string.IsNullOrEmpty(CIFType))
                            ddlCIFType.Items.FindByText(CIFType).Selected = true;

                        if (!string.IsNullOrEmpty(Convert.ToString(row["CIF_Start_Date"])))
                            txtCIFStartDate.Value = Convert.ToDateTime(row["CIF_Start_Date"]).ToString("MM-dd-yyyy");

                        if (!string.IsNullOrEmpty(Convert.ToString(row["CIF_Actual_Closure_Date"])))
                            txtActCloseDate.Value = Convert.ToDateTime(row["CIF_Actual_Closure_Date"]).ToString("MM-dd-yyyy");
                        txtBudget.Value = Convert.ToString(row["CIF_Budget"]);

                        string rdELSvalue = Convert.ToString(row["ELS/NPI"]);
                        rdELS.Items.FindByValue(rdELSvalue).Selected = true;

                        // rdToolChanber.SelectedItem.Text = Convert.ToString(row["Tool/Chamber Shipped"]);

                        if (!string.IsNullOrEmpty(Convert.ToString(row["Tool_Ship_Date"])))
                        { }
                        // txtToolshipDate.Value = Convert.ToDateTime(row["Tool_Ship_Date"]).ToString("MM-dd-yyyy");

                        // rdServiceWin.SelectedItem.Text = Convert.ToString(row["Service_Win"]);
                        string rdcoValue = Convert.ToString(row["CoO_Model_Exists"]);
                        rdCoOModalExists.Items.FindByValue(rdcoValue).Selected = true;

                        string rdsrrValue = Convert.ToString(row["SRR_Exists"]);
                        rdSRRExists.Items.FindByValue(rdsrrValue).Selected = true;

                        string SRRType = Convert.ToString(row["SRR_Type"]);
                        ddlSRRType.ClearSelection();
                        if (!string.IsNullOrEmpty(SRRType))
                            ddlSRRType.Items.FindByText(SRRType).Selected = true;

                        if (!string.IsNullOrEmpty(Convert.ToString(row["CoO_Model_Need_Date"])))
                            txtCoOModelDate.Value = Convert.ToDateTime(row["CoO_Model_Need_Date"]).ToString("MM-dd-yyyy");

                        string fssMTC = Convert.ToString(row["FSS_at_MTC"]);
                        rdFssMTC.Items.FindByValue(fssMTC).Selected = true;

                        string fssConnection = Convert.ToString(row["FSS_Connection_Allowed_by_Customer"]);
                        rdFssConnection.Items.FindByValue(fssConnection).Selected = true;

                        string ThereDCP = Convert.ToString(row["Is_there_DCP"]);
                        ddlIsThereDCP.ClearSelection();
                        if (!string.IsNullOrEmpty(ThereDCP))
                            ddlIsThereDCP.Items.FindByText(ThereDCP).Selected = true;

                        string fssStatus = Convert.ToString(row["FSS_Status"]);
                        ddlFssStatus.ClearSelection();
                        if (!string.IsNullOrEmpty(fssStatus))
                            ddlFssStatus.Items.FindByText(fssStatus).Selected = true;

                        hdnFSSBasicFeatures.Value = Convert.ToString(row["FSSBasicFeatures"]);
                        hdnFSSAdvancedFeatures.Value = Convert.ToString(row["FSSAdvancedFeatures"]);
                        hdnDashboards.Value = Convert.ToString(row["Dashboards"]);
                        hdnHandheldMetro.Value = Convert.ToString(row["HandheldMetro"]);
                        hdnSensorWafers.Value = Convert.ToString(row["SensorWafers"]);
                        hdnCleaningMethod.Value = Convert.ToString(row["CleaningMethod"]);
                        hdnCoating.Value = Convert.ToString(row["Coating"]);
                        hdnTexturing.Value = Convert.ToString(row["Texturing"]);
                        hdnInspectionMetrology.Value = Convert.ToString(row["InspectionMetrology"]);
                        hdnNetworkExpert.Value = Convert.ToString(row["Network_of_Experts"]);

                        txtProjectName.Value = Convert.ToString(row["CIF_ProjectName"]);
                        txtWinningDefinition.InnerText = Convert.ToString(row["DefWinning"]);

                        txtSbuOwner.Value = Convert.ToString(row["SBU_Owner"]);
                        txtFsoOwner.Value = Convert.ToString(row["FSO_Owner"]);
                        txtGfgOwner.Value = Convert.ToString(row["GFG_Owner"]);
                        txtBUOwner.Value = Convert.ToString(row["BU_Owner"]);
                        txtPlanningSparesInvestment.Value = Convert.ToString(row["PlannedInventryInvest"]);
                        txtProjectObjective.Value = Convert.ToString(row["CIF_ProjectObjective"]);
                        txtStatus.Value = Convert.ToString(row["StatusText"]);

                        string InternalFundedNumber = Convert.ToString(row["InternalFundedNumber"]);
                        ddlIFP_number.ClearSelection();
                        if (!string.IsNullOrEmpty(InternalFundedNumber))
                            ddlIFP_number.Items.FindByText(InternalFundedNumber).Selected = true;

                        txtInternalOrder.Value = Convert.ToString(row["InternalOrderNumber"]);

                        string coo_Commit_Status = Convert.ToString(row["CoO_Commit_Status"]);
                        ddlCommitStatus.ClearSelection();
                        if (!string.IsNullOrEmpty(coo_Commit_Status))
                            ddlCommitStatus.Items.FindByText(coo_Commit_Status).Selected = true;

                        txtToolAsp.Value = Convert.ToString(row["Tool_ASP"]);

                    }

                    DataTable cifToolDt = ds.Tables[1];  // cif tool id\Equipment id
                    if (cifToolDt != null && cifToolDt.Rows.Count > 0)
                    {
                        hdnCIFToolID.Value = AppendRowsInstring(cifToolDt, 0);
                        hdnCustomerName.Value = AppendRowsInstringForCustomerSerialNo(cifToolDt, 1);
                        hdnUpdateModePlannedValues.Value = GetPlannedInputValues(cifToolDt);
                    }

                    DataTable cifCOntractDt = ds.Tables[2];  // cif Contract id table
                    if (cifCOntractDt != null && cifCOntractDt.Rows.Count > 0)
                        hdnContractID.Value = AppendRowsInstring(cifCOntractDt, 0);

                    DataTable cifTambaDt = ds.Tables[3];  // cif tamba id table
                    if (cifTambaDt != null && cifTambaDt.Rows.Count > 0)
                    {
                        hdnTambaIds.Value = AppendRowsInstring(cifTambaDt, 0);
                        hdnProducts.Value = AppendRowsInstring(cifTambaDt, 1);
                        hdnBU.Value = AppendRowsInstring(cifTambaDt, 2);
                    }

                    DataTable cifSupplierDt = ds.Tables[4];  // cif supplier table data
                    if (cifSupplierDt != null && cifSupplierDt.Rows.Count > 0)
                    {
                        string[] supplierArray = { Common.CleanSupplier, Common.RepairSupplier, Common.RefurbSupplier, Common.GPSTSupplier, Common.Others };
                        List<string> hdnFieldvalueList = new List<string>();
                        Dictionary<string, string> dictTbSupplier = new Dictionary<string, string>();
                        foreach (string str in supplierArray)
                        {
                            DataRow[] rows = cifSupplierDt.Select("Supplier='" + str + "'");
                            if (rows != null && rows.Length > 0)
                            {
                                string value = string.Empty;
                                foreach (DataRow row in rows)
                                {
                                    value += Convert.ToString(row["MaterialNo"]) + ",";
                                }
                                value = value.Remove(value.Length - 1);

                                dictTbSupplier.Add(str, value);
                                hdnFieldvalueList.Add(value);
                            }
                        }
                        if (dictTbSupplier.Count > 0)
                        {
                            foreach (KeyValuePair<string, string> item in dictTbSupplier)
                            {
                                switch (item.Key)
                                {
                                    case Common.CleanSupplier:
                                        hdnCleanSupplier.Value = item.Value;
                                        break;
                                    case Common.RepairSupplier:
                                        hdnRepairSupplier.Value = item.Value;
                                        break;
                                    case Common.RefurbSupplier:
                                        hdnRefurbSupplier.Value = item.Value;
                                        break;
                                    case Common.GPSTSupplier:
                                        hdnGPSTSupplier.Value = item.Value;
                                        break;
                                    case Common.Others:
                                        hdnOthers.Value = item.Value;
                                        break;
                                }
                            }
                        }
                    }
                    DataTable supplierOther = ds.Tables[5];  // other supplier data
                    if (supplierOther != null && supplierOther.Rows.Count > 0)
                        txtOthers.Value = Convert.ToString(supplierOther.Rows[0][0]);

                    //DataTable fabLocation = ds.Tables[6];  // Fab location data
                    //if (fabLocation != null && fabLocation.Rows.Count > 0)
                    //{ //txtFabLocation.Value = Convert.ToString(fabLocation.Rows[0][0]);
                    //}
                    DataTable assemblyInfo = ds.Tables[7];  // get assenbly info data
                    if (assemblyInfo != null && assemblyInfo.Rows.Count > 0)
                    {
                        hdnAssemblyNos.Value = GetAssemblyNo(assemblyInfo);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "UpdateMode", "CIF-Form.aspx");
                }
            }
        }

        public string AppendRowsInstring(DataTable dt)
        {
            string value = string.Empty;
            foreach (DataRow row in dt.Rows)
            {
                value += Convert.ToString(row[0]) + ",";
            }
            value = value.Remove(value.Length - 1);
            return value;
        }
        public string GetAssemblyNo(DataTable dt)
        {
            string value = string.Empty;

            foreach (DataRow row in dt.Rows)
            {
                value += Convert.ToString(row[1]).Split('-')[0] + ",";
                // value += Convert.ToString(row[1]) + ",";                
            }
            value = value.Remove(value.Length - 1);
            return value;
        }

        public string AppendRowsInstring(DataTable dt, int columnIndex)
        {
            string value = string.Empty;
            foreach (DataRow row in dt.Rows)
            {
                string val = Convert.ToString(row[columnIndex]).Replace(",", "");
                if (!value.Contains(val))
                    value += Convert.ToString(row[columnIndex]) + ",";
            }

            if (!string.IsNullOrEmpty(value))
                value = value.Remove(value.Length - 1);
            return value;
        }

        public string AppendRowsInstringForCustomerSerialNo(DataTable dt, int columnIndex)
        {
            string value = string.Empty;
            foreach (DataRow row in dt.Rows)
            {
                string val = Convert.ToString(row[columnIndex]);
                value += Convert.ToString(row[columnIndex]) + ",";

                //if (!value.Contains(val))
                //    value += Convert.ToString(row[columnIndex]) + ",";
                //else
                //    value += " " + ",";
            }
            if (!string.IsNullOrEmpty(value))
                value = value.Remove(value.Length - 1);
            return value;
        }

        //public string GetPlannedInputValues(DataTable dt)
        //{
        //   string colValue = string.Empty;
        //    for (int i = 0; i < dt.Rows.Count; i++)
        //    {
        //        for (int j = 2; j < dt.Columns.Count; j++)
        //        {
        //           // if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i][j])))
        //                colValue += dt.Rows[i][j] + ":";
        //        }
        //        colValue += "|";
        //    }
        //    return colValue;
        //}

        public string GetPlannedInputValues(DataTable dt)
        {
            string colValue = string.Empty;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    if (j == 0)
                    {
                        colValue += Convert.ToString(dt.Rows[i][j]).Split(':')[0] + ":";
                    }
                    if (j > 1)
                    {
                        colValue += dt.Rows[i][j] + ":";
                    }
                }
                colValue += "|";
            }
            return colValue;
        }

        public void ResetForm()
        {
            ddlCIFType.SelectedIndex = 0;
            ddlTambaNo.SelectedIndex = 0;
            ddlSRRType.SelectedIndex = 0;
            ddlIsThereDCP.SelectedIndex = 0;
            ddlFssStatus.SelectedIndex = 0;
            ddlFSSfeatures.SelectedIndex = 0;
            ddlFSSAdvFeatures.SelectedIndex = 0;
            dllDashboard.SelectedIndex = 0;
            ddlMetro.SelectedIndex = 0;
            ddlSensorWafers.SelectedIndex = 0;
            ddlCleaningMethod.SelectedIndex = 0;
            ddlCoating.SelectedIndex = 0;
            ddlTexturing.SelectedIndex = 0;
            ddlInspectionMetrology.SelectedIndex = 0;
            ddlNetworkExpert.SelectedIndex = 0;
            ddlCIFStatus.SelectedIndex = 0;
            txtCIFStartDate.Value = string.Empty;
            txtActCloseDate.Value = string.Empty;
            txtBudget.Value = string.Empty;
            // txtFabLocation.Value = string.Empty;
            txtCIFToolId.Value = string.Empty;
            // txtToolshipDate.Value = string.Empty;
            txtContractID.Value = string.Empty;
            txtCoOModelDate.Value = string.Empty;
            txtCleansupplier.Value = string.Empty;
            txtRepairSupplier.Value = string.Empty;
            txtRefurbSupplier.Value = string.Empty;
            txtGPSTSupplier.Value = string.Empty;
            txtOthers.Value = string.Empty;
            txtCIFStartDate.Value = string.Empty;
        }

        public static void ErrorLog(ClientContext clientContext, string errorMessage, string source, string method, string pageName)
        {

            List logList = clientContext.Web.Lists.GetByTitle("ErrorLogList");
            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
            Microsoft.SharePoint.Client.ListItem item = logList.AddItem(itemCreateInfo);
            item["Message"] = errorMessage;
            item["Source"] = source;
            item["Method"] = method;
            item["PageName"] = pageName;
            item.Update();
            clientContext.ExecuteQuery();

        }

        public void GetInternalFundedOrderNo()
        {
            BLL obj = new BLL();
            DataTable dtIFPno = obj.GetInternalFundednumber();
            ddlIFP_number.DataTextField = "IFP";
            ddlIFP_number.DataValueField = "IO";
            ddlIFP_number.DataSource = dtIFPno;
            ddlIFP_number.DataBind();
            ddlIFP_number.Items.Insert(0, "Select");

        }
        protected void lnkSearch_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Search.aspx?";

            if (Page.ClientQueryString.Contains("ID"))
            {
                int position = Page.ClientQueryString.IndexOf("ID") - 1;
                string qrystring = Page.ClientQueryString.Remove(position);
                path = "../Pages/Search.aspx?" + qrystring;
            }
            else
            {
                path += Page.ClientQueryString;
            }

            Response.Redirect(path);
        }

        protected void lnkDashboard_Click(object sender, EventArgs e)
        {
            string path = "../Pages/Dashboard.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (Page.Request.QueryString["ID"] != null)
            {
                string cifId = Page.Request.QueryString["ID"];
                InsertUpdateData(cifId, Common.UpdateCIFData);
            }
        }

        protected void imgLogobtn_Click(object sender, ImageClickEventArgs e)
        {
            string path = "../Pages/Default.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        public void UserSecurityCheck()
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (ClientContext clientContext = spContext.CreateUserClientContextForSPHost())
            {
                try
                {
                    Web web = clientContext.Web;
                    User user = web.CurrentUser;
                    clientContext.Load(web);
                    clientContext.ExecuteQuery();
                    clientContext.Load(user);
                    clientContext.ExecuteQuery();
                    string username = user.Title;
                    userName.InnerText = username;

                    DataTable roleDt = IsUserProfileExistsInRAM(username);
                    if (roleDt != null && roleDt.Rows.Count > 0)
                    {
                        string roleName = Convert.ToString(roleDt.Rows[0]["ROLENAME"]);

                        if (!string.IsNullOrEmpty(username))
                        {
                            List list = web.Lists.GetByTitle(Common.SecurityList);                            
                            var query = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Roles' /><Value Type='Text'>" + roleName + "</Value></Eq></Where></Query></View>" };

                            Microsoft.SharePoint.Client.ListItemCollection items = list.GetItems(query);
                            clientContext.Load(items);
                            clientContext.ExecuteQuery();

                            if (items != null && items.Count > 0)
                            {
                                foreach (Microsoft.SharePoint.Client.ListItem item in items)
                                {
                                    bool isCreateAccess = Convert.ToBoolean(item["Create_x0020_Access"]);
                                    bool isViewAccess = Convert.ToBoolean(item["View"]);
                                    bool isEditAccess = Convert.ToBoolean(item["Edit_x0020_Access"]);
                                    bool isDashbaordAccess = Convert.ToBoolean(item["Dashboard"]);

                                    if (isViewAccess && isDashbaordAccess)
                                    {
                                        CIF_li.Visible = false;
                                        btnPnl.Visible = false;
                                        dashboard_li.Visible = true;

                                    }
                                    if (isViewAccess && !isDashbaordAccess)
                                    {
                                        CIF_li.Visible = false;
                                        btnPnl.Visible = false;
                                        dashboard_li.Visible = false;
                                    }
                                    if (!isViewAccess && isDashbaordAccess)
                                    {
                                        CIF_li.Visible = false;
                                        search_li.Visible = false;
                                        btnPnl.Visible = false;
                                        dashboard_li.Visible = true;                                       
                                    }

                                    if (!isCreateAccess && isEditAccess)
                                    {
                                        CIF_li.Visible = false;
                                        search_li.Visible = true;
                                        btnPnl.Visible = true;
                                        dashboard_li.Visible = true;
                                        if (roleName == Common.CIFEngineers)
                                            hdnEdituser.Value = "true";

                                        hdnUserCanEdit.Value = "true";
                                    }
                                    if (isCreateAccess)
                                    {
                                        hdnIsPowerUser.Value = "true";
                                        CIF_li.Visible = true;
                                        search_li.Visible = true;
                                        btnPnl.Visible = true;

                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        string path = "../Pages/Default.aspx?" + Page.ClientQueryString;
                        Response.Redirect(path);
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog(clientContext, ex.Message, ex.Source, "UserSecurityCheck", "CIF-Form.aspx");
                }

            }
        }
        /// <summary>
        /// New security implementation change.
        /// </summary>
        /// <param name="employeeName"></param>
        /// <returns></returns>
        public DataTable IsUserProfileExistsInRAM(string employeeName)
        {
            ADMethods adObj = new ADMethods();
            BLL objBal = new BLL();
            ADMethods.ADAttributes attributes = adObj.GetEmployeeAttributes(employeeName, ADMethods.AdPrpoertyParameters.displayName);
            string empId = attributes.employeeId;
           // string response = GetResponseFromAPI(Common.CheckRAMProfile, empId);
            return objBal.CheckIfUserExistsInRAM(empId);
        }

        //public void getProfile()
        //{
        //    var client = new RestClient("https://server-nodejs-api-rsm-dev.apps.ocp.amat.com/SMAPI/apps/CheckRAMProfileForUser/X099020");
        //    client.Timeout = -1;
        //    var request = new RestRequest(Method.GET);         
         
        //    var body = @"";
        //    request.AddParameter("text/plain", body, ParameterType.RequestBody);
        //    IRestResponse response = client.Execute(request);
        //    Console.WriteLine(response.Content);
        //}

        public string GetResponseFromAPI(string url, string employeeId)
        {
            string text = string.Empty;
            try
            {
                string responseText = string.Empty;
                DAL objdal = new DAL();
                string APIURL = objdal.APIUrl + url + employeeId;
                // string APIURL = "https://o365appweb.amat.com/AMAT.ToolCountAPI/api/toolcount";

                NetworkCredential crd = new NetworkCredential("NsharmaX099020", "Amat#@!3");

                var httpWebRequest = (HttpWebRequest)WebRequest.Create(APIURL);
                httpWebRequest.PreAuthenticate = true;
                httpWebRequest.Credentials = crd;
                httpWebRequest.UseDefaultCredentials = true;
                httpWebRequest.ContentType = "application/json; charset=utf-8";
                httpWebRequest.Accept = "application/json";
                httpWebRequest.Method = "GET";
           
                using (HttpWebResponse httpresponse = (HttpWebResponse)httpWebRequest.GetResponse())
                {
                    using (Stream stream = httpresponse.GetResponseStream())
                    {
                        responseText = (new StreamReader(stream).ReadToEnd());
                    }
                }
            }
            catch (WebException ex)
            {
                string message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
            }

            //using (var client = new HttpClient())
            //{

            //    var request = new HttpRequestMessage(HttpMethod.Get, APIURL);
            //    request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //    var response = client.SendAsync(request).Result;

            //    string content = response.Content.ReadAsStringAsync().Result;
            //    //JsonTextReader reader = new JsonTextReader(new System.IO.StringReader(content));
            //    //JsonSerializer serializer = new JsonSerializer();
            //  //  var objContent = serializer.Deserialize(reader).ToString();
            //}

            return text;
        }

        protected void lnkCif_Click(object sender, EventArgs e)
        {
            ResetForm();
            string path = "../Pages/CIF-Form.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);
        }

        protected void btnDiscard_Click(object sender, EventArgs e)
        {
            ResetForm();
            string path = "../Pages/Search.aspx?" + Page.ClientQueryString;
            Response.Redirect(path);

        }


    }
}